/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  java.lang.Object
 *  java.lang.String
 */
package com.gmail.heagoo.common;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class PackageUtil {
    public static void uninstallPackage(Context context, String string2) {
        context.startActivity(new Intent("android.intent.action.DELETE", Uri.parse((String)("package:" + string2))));
    }
}

