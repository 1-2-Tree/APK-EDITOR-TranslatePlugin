/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.AbsListView
 *  android.widget.AbsListView$OnScrollListener
 *  android.widget.BaseAdapter
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  java.lang.Object
 */
package com.gmail.heagoo.common;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

public class DynamicExpandListView
extends ListView
implements AbsListView.OnScrollListener {
    private int initListSize = 30;
    private int scrollState;
    private AdapterWrapper wrapper;

    public DynamicExpandListView(Context context) {
        super(context);
        this.setOnScrollListener((AbsListView.OnScrollListener)this);
    }

    public DynamicExpandListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.setOnScrollListener((AbsListView.OnScrollListener)this);
    }

    public DynamicExpandListView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.setOnScrollListener((AbsListView.OnScrollListener)this);
    }

    public void dataChanged() {
        if (this.wrapper != null) {
            this.wrapper.notifyDataSetChanged();
        }
    }

    public void onScroll(AbsListView absListView, int n, int n2, int n3) {
        if (n + n2 >= n3 && this.wrapper != null) {
            this.wrapper.loadMore();
        }
    }

    public void onScrollStateChanged(AbsListView absListView, int n) {
        this.scrollState = n;
    }

    public void setAdapter(ListAdapter listAdapter) {
        this.wrapper = new AdapterWrapper(listAdapter, this.initListSize);
        super.setAdapter((ListAdapter)this.wrapper);
    }

    public void setInitListSize(int n) {
        this.initListSize = n;
    }

    private static class AdapterWrapper
    extends BaseAdapter {
        private ListAdapter adapter;
        private int count;
        private int itemSteps = 30;
        private boolean loadEnded = false;
        private int pageItems;

        public AdapterWrapper(ListAdapter listAdapter, int n) {
            this.adapter = listAdapter;
            this.pageItems = n;
            if (listAdapter.getCount() > this.pageItems) {
                this.count = this.pageItems;
                this.loadEnded = false;
                return;
            }
            this.count = listAdapter.getCount();
            this.loadEnded = true;
        }

        public int getCount() {
            return this.count;
        }

        public Object getItem(int n) {
            return this.adapter.getItem(n);
        }

        public long getItemId(int n) {
            return this.adapter.getItemId(n);
        }

        public View getView(int n, View view, ViewGroup viewGroup) {
            return this.adapter.getView(n, view, viewGroup);
        }

        /*
         * Enabled aggressive block sorting
         */
        public void loadMore() {
            if (!this.loadEnded) {
                this.pageItems += this.itemSteps;
                if (this.adapter.getCount() > this.pageItems) {
                    this.loadEnded = false;
                    this.count = this.pageItems;
                } else {
                    this.loadEnded = true;
                    this.count = this.adapter.getCount();
                }
                this.notifyDataSetChanged();
            }
        }
    }

}

