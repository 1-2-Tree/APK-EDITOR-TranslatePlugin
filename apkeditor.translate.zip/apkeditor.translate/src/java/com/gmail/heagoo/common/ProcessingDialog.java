/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.app.Activity
 *  android.app.Dialog
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.ref.WeakReference
 */
package com.gmail.heagoo.common;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.gmail.heagoo.common.R;
import java.lang.ref.WeakReference;

public class ProcessingDialog
extends Dialog {
    private Activity activity;
    private ProcessingInterface processor;
    private int successTipResId;

    @SuppressLint(value={"InflateParams"})
    public ProcessingDialog(Activity activity, ProcessingInterface processingInterface, int n) {
        super((Context)activity, R.style.Dialog_No_Border_2);
        this.activity = activity;
        this.processor = processingInterface;
        this.successTipResId = n;
        this.requestWindowFeature(1);
        super.setContentView(activity.getLayoutInflater().inflate(R.layout.dlg_processing, null));
        super.setCancelable(false);
        new ProcessingThread(this).start();
    }

    protected void processCompleted(final String string2) {
        this.activity.runOnUiThread(new Runnable(){

            /*
             * Enabled aggressive block sorting
             */
            public void run() {
                ProcessingDialog.this.processor.afterProcess();
                if (string2 != null) {
                    ProcessingDialog.this.showTip("Failed: " + string2);
                } else {
                    ProcessingDialog.this.showTip(ProcessingDialog.this.successTipResId);
                }
                ProcessingDialog.this.dismiss();
            }
        });
    }

    protected void showTip(int n) {
        Toast.makeText((Context)this.activity, (int)n, (int)0).show();
    }

    protected void showTip(String string2) {
        Toast.makeText((Context)this.activity, (CharSequence)string2, (int)0).show();
    }

    public static interface ProcessingInterface {
        public void afterProcess();

        public void process() throws Exception;
    }

    static class ProcessingThread
    extends Thread {
        private WeakReference<ProcessingDialog> dlgRef;

        public ProcessingThread(ProcessingDialog processingDialog) {
            this.dlgRef = new WeakReference((Object)processingDialog);
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public void run() {
            String string2 = null;
            ProcessingDialog processingDialog = (ProcessingDialog)((Object)this.dlgRef.get());
            if (processingDialog == null) return;
            try {
                processingDialog.processor.process();
            }
            catch (Exception exception) {
                string2 = exception.getMessage();
            }
            processingDialog.processCompleted(string2);
        }
    }

}

