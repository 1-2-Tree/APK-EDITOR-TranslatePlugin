/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.gmail.heagoo.common;

public final class R {

    public static final class drawable {
        public static final int commonutil_progressbar = 2130837602;
        public static final int shape_roundcorner = 2130837603;
    }

    public static final class id {
        public static final int progressBar1 = 2131296320;
        public static final int progress_layout = 2131296327;
    }

    public static final class layout {
        public static final int dlg_processing = 2130903066;
    }

    public static final class string {
        public static final int in_progress = 2131361805;
    }

    public static final class style {
        public static final int Dialog_No_Border_2 = 2131427467;
    }

}

