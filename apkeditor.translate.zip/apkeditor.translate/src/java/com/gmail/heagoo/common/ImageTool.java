/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.Matrix
 *  android.net.Uri
 *  android.widget.Toast
 *  java.io.ByteArrayOutputStream
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.gmail.heagoo.common;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.widget.Toast;
import com.gmail.heagoo.common.FileUtil;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class ImageTool {
    private byte[] bitmap2Bytes(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, (OutputStream)byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void closeQuietly(OutputStream outputStream) {
        if (outputStream == null) return;
        try {
            outputStream.close();
            return;
        }
        catch (IOException iOException) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void zoomImage(Bitmap var1_1, int var2_2, int var3_3, String var4_4) {
        var5_5 = var1_1.getWidth();
        var6_6 = var1_1.getHeight();
        var7_7 = (float)var2_2 / (float)var5_5;
        var8_8 = (float)var3_3 / (float)var6_6;
        var9_9 = new Matrix();
        var9_9.postScale(var7_7, var8_8);
        var11_10 = Bitmap.createBitmap((Bitmap)var1_1, (int)0, (int)0, (int)var5_5, (int)var6_6, (Matrix)var9_9, (boolean)false);
        var12_11 = null;
        var13_12 = new FileOutputStream(var4_4);
        try {
            if (!var4_4.endsWith(".png")) {
                var11_10.compress(Bitmap.CompressFormat.JPEG, 80, (OutputStream)var13_12);
            }
            var11_10.compress(Bitmap.CompressFormat.PNG, 80, (OutputStream)var13_12);
        }
        catch (Exception var15_13) {
            block10 : {
                var12_11 = var13_12;
                break block10;
                catch (Throwable var14_18) {
                    var12_11 = var13_12;
                    ** GOTO lbl-1000
                }
            }
lbl24: // 2 sources:
            do {
                try {
                    var15_14.printStackTrace();
                }
                catch (Throwable var14_16) lbl-1000: // 2 sources:
                {
                    this.closeQuietly((OutputStream)var12_11);
                    throw var14_17;
                }
                this.closeQuietly((OutputStream)var12_11);
                return;
                break;
            } while (true);
        }
        this.closeQuietly((OutputStream)var13_12);
        return;
        catch (Exception var15_15) {
            var12_11 = null;
            ** continue;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void zoomToSmaller(Context context, String string2, String string3, int n) throws Exception {
        ContentResolver contentResolver = context.getContentResolver();
        Uri uri = Uri.fromFile((File)new File(string2));
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = n;
        InputStream inputStream = contentResolver.openInputStream(uri);
        Bitmap bitmap = BitmapFactory.decodeStream((InputStream)inputStream, null, (BitmapFactory.Options)options);
        try {
            inputStream.close();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        if (bitmap == null) {
            Toast.makeText((Context)context, (CharSequence)"Head is not set successful,Decode bitmap failure", (int)0).show();
            return;
        }
        int n2 = bitmap.getWidth();
        int n3 = bitmap.getHeight();
        float f = 1.0f / (float)n;
        Matrix matrix = new Matrix();
        matrix.postScale(f, f);
        Bitmap bitmap2 = Bitmap.createBitmap((Bitmap)bitmap, (int)0, (int)0, (int)n2, (int)n3, (Matrix)matrix, (boolean)false);
        bitmap.recycle();
        FileUtil.writeToFile(string3, this.bitmap2Bytes(bitmap2));
    }
}

