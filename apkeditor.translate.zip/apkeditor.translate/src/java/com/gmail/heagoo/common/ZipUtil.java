/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.BufferedInputStream
 *  java.io.BufferedOutputStream
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Enumeration
 *  java.util.zip.ZipEntry
 *  java.util.zip.ZipFile
 *  java.util.zip.ZipOutputStream
 */
package com.gmail.heagoo.common;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public class ZipUtil {
    private static void addFileToZip(String string2, String string3, ZipOutputStream zipOutputStream, boolean bl) throws IOException {
        File file = new File(string3);
        if (bl) {
            zipOutputStream.putNextEntry(new ZipEntry(String.valueOf((Object)string2) + "/" + file.getName() + "/"));
            return;
        }
        if (file.isDirectory()) {
            ZipUtil.addFolderToZip(string2, string3, zipOutputStream);
            return;
        }
        byte[] arrby = new byte[4096];
        FileInputStream fileInputStream = new FileInputStream(string3);
        zipOutputStream.putNextEntry(new ZipEntry(String.valueOf((Object)string2) + "/" + file.getName()));
        do {
            int n;
            if ((n = fileInputStream.read(arrby)) <= 0) {
                fileInputStream.close();
                return;
            }
            zipOutputStream.write(arrby, 0, n);
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void addFolderToZip(String string2, String string3, ZipOutputStream zipOutputStream) throws IOException {
        File file = new File(string3);
        String[] arrstring = file.list();
        if (arrstring == null || arrstring.length == 0) {
            ZipUtil.addFileToZip(string2, string3, zipOutputStream, true);
            return;
        }
        int n = arrstring.length;
        int n2 = 0;
        while (n2 < n) {
            String string4 = arrstring[n2];
            if (string2.equals((Object)"")) {
                ZipUtil.addFileToZip(file.getName(), String.valueOf((Object)string3) + "/" + string4, zipOutputStream, false);
            } else {
                ZipUtil.addFileToZip(String.valueOf((Object)string2) + "/" + file.getName(), String.valueOf((Object)string3) + "/" + string4, zipOutputStream, false);
            }
            ++n2;
        }
        return;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void closeQuietly(InputStream inputStream) {
        if (inputStream == null) return;
        try {
            inputStream.close();
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void closeQuietly(OutputStream outputStream) {
        if (outputStream == null) return;
        try {
            outputStream.close();
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void closeQuietly(ZipFile zipFile) {
        if (zipFile == null) return;
        try {
            zipFile.close();
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static File getFile(String string2, String string3) {
        String[] arrstring = string3.split("/");
        File file = new File(string2);
        if (!file.exists()) {
            file.mkdirs();
        }
        if (arrstring.length <= 1) return new File(file, arrstring[-1 + arrstring.length]);
        int n = 0;
        do {
            if (n >= -1 + arrstring.length) {
                if (file.exists()) return new File(file, arrstring[-1 + arrstring.length]);
                file.mkdirs();
                return new File(file, arrstring[-1 + arrstring.length]);
            }
            File file2 = new File(file, arrstring[n]);
            ++n;
            file = file2;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void unzip(String var0, String var1_1) throws IOException {
        var2_2 = null;
        var3_3 = null;
        try {
            var4_4 = new ZipFile(var0);
        }
        catch (Throwable var5_15) {
            var2_2 = null;
            var3_3 = null;
            var6_17 = null;
            ** GOTO lbl54
        }
        try {
            var8_5 = var4_4.entries();
            var9_6 = new byte[4096];
            var10_7 = null;
            var11_8 = null;
        }
lbl73: // 2 sources:
        catch (Throwable var5_14) {
            var6_17 = var4_4;
            ** continue;
        }
        block15 : do {
            block22 : {
                block21 : {
                    if (var8_5.hasMoreElements()) break block21;
                    var4_4.close();
                    ZipUtil.closeQuietly(var11_8);
                    ZipUtil.closeQuietly(var10_7);
                    if (var4_4 == null) return;
                    var4_4.close();
                    return;
                    {
                        catch (IOException var16_19) {
                            return;
                        }
                    }
                }
                var12_9 = (ZipEntry)var8_5.nextElement();
                if (!var12_9.isDirectory()) break block22;
                var13_10 = var1_1;
                if (!var1_1.endsWith("/")) {
                    var13_10 = String.valueOf((Object)new StringBuilder(String.valueOf((Object)var13_10)).append("/").toString()) + var12_9.getName();
                }
                new File(var13_10).mkdirs();
                continue;
            }
            try {
                var3_3 = new BufferedOutputStream((OutputStream)new FileOutputStream(ZipUtil.getFile(var1_1, var12_9.getName())));
                ** GOTO lbl48
            }
            catch (Throwable var5_12) {
                block23 : {
                    var3_3 = var10_7;
                    var2_2 = var11_8;
                    var6_17 = var4_4;
                    break block23;
lbl48: // 2 sources:
                    var2_2 = new BufferedInputStream(var4_4.getInputStream(var12_9));
                    ** try [egrp 8[TRYBLOCK] [10 : 233->280)] { 
lbl50: // 1 sources:
                    ** GOTO lbl-1000
                    catch (Throwable var5_16) {
                        var2_2 = var11_8;
                        var6_17 = var4_4;
                    }
                }
lbl55: // 2 sources:
                do {
                    ZipUtil.closeQuietly(var2_2);
                    ZipUtil.closeQuietly(var3_3);
                    if (var6_17 == null) throw var5_13;
                    try {
                        var6_17.close();
                    }
                    catch (IOException var7_18) {
                        throw var5_13;
                    }
                    throw var5_13;
                    break;
                } while (true);
            }
lbl-1000: // 1 sources:
            {
                do {
                    if ((var15_11 = var2_2.read(var9_6, 0, 4096)) == -1) {
                        ZipUtil.closeQuietly((InputStream)var2_2);
                        ZipUtil.closeQuietly((OutputStream)var3_3);
                        var10_7 = var3_3;
                        var11_8 = var2_2;
                        continue block15;
                    }
                    var3_3.write(var9_6, 0, var15_11);
                } while (true);
            }
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void unzipDirectory(String var0, String var1_1, String var2_2) throws IOException {
        var3_3 = null;
        var4_4 = null;
        if (!var1_1.endsWith("/")) {
            var1_1 = String.valueOf((Object)var1_1) + "/";
        }
        try {
            var5_5 = new ZipFile(var0);
        }
        catch (Throwable var6_15) {
            var3_3 = null;
            var4_4 = null;
            var7_17 = null;
            ** GOTO lbl49
        }
        try {
            var8_6 = var5_5.entries();
            var9_7 = new byte[4096];
        }
lbl62: // 2 sources:
        catch (Throwable var6_14) {
            var7_17 = var5_5;
            ** continue;
        }
        block11 : do {
            block18 : {
                block17 : {
                    var10_8 = var8_6.hasMoreElements();
                    if (var10_8) break block17;
                    ZipUtil.closeQuietly(null);
                    ZipUtil.closeQuietly(null);
                    ZipUtil.closeQuietly(var5_5);
                    return;
                }
                var11_9 = (ZipEntry)var8_6.nextElement();
                if (!var11_9.getName().startsWith(var1_1)) continue;
                var12_10 = var11_9.getName().substring(var1_1.length());
                if (!var11_9.isDirectory()) break block18;
                new File(String.valueOf((Object)var2_2) + "/" + var12_10).mkdirs();
                continue;
            }
            try {
                var4_4 = new BufferedOutputStream((OutputStream)new FileOutputStream(ZipUtil.getFile(var2_2, var12_10)));
                ** GOTO lbl43
            }
            catch (Throwable var6_12) {
                block19 : {
                    var4_4 = null;
                    var3_3 = null;
                    var7_17 = var5_5;
                    break block19;
lbl43: // 2 sources:
                    var3_3 = new BufferedInputStream(var5_5.getInputStream(var11_9));
                    ** try [egrp 6[TRYBLOCK] [6 : 235->278)] { 
lbl45: // 1 sources:
                    ** GOTO lbl-1000
                    catch (Throwable var6_16) {
                        var7_17 = var5_5;
                        var3_3 = null;
                    }
                }
lbl50: // 2 sources:
                do {
                    ZipUtil.closeQuietly(var3_3);
                    ZipUtil.closeQuietly(var4_4);
                    ZipUtil.closeQuietly(var7_17);
                    throw var6_13;
                    break;
                } while (true);
            }
lbl-1000: // 1 sources:
            {
                do {
                    if ((var13_11 = var3_3.read(var9_7, 0, 4096)) == -1) {
                        ZipUtil.closeQuietly((InputStream)var3_3);
                        ZipUtil.closeQuietly((OutputStream)var4_4);
                        continue block11;
                    }
                    var4_4.write(var9_7, 0, var13_11);
                } while (true);
            }
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void unzipFileTo(String var0, String var1_1, String var2_2) throws Exception {
        try {
            var3_3 = new ZipFile(var0);
        }
        catch (Throwable var4_11) {
            var6_15 = null;
            var7_14 = null;
            var5_16 = null;
            ** GOTO lbl33
        }
        try {
            var8_4 = var3_3.getEntry(var1_1);
            var9_5 = new byte[4096];
            var10_6 = new BufferedOutputStream((OutputStream)new FileOutputStream(var2_2));
        }
        catch (Throwable var4_12) {
            var5_16 = var3_3;
            var6_15 = null;
            var7_14 = null;
            ** GOTO lbl33
        }
        try {
            var11_7 = new BufferedInputStream(var3_3.getInputStream(var8_4));
        }
        catch (Throwable var4_13) {
            var7_14 = var10_6;
            var5_16 = var3_3;
            var6_15 = null;
            ** GOTO lbl33
        }
        do {
            var12_8 = var11_7.read(var9_5, 0, 4096);
            if (var12_8 != -1) break block10;
            break;
        } while (true);
        catch (Throwable var4_9) {
            var7_14 = var10_6;
            var6_15 = var11_7;
            var5_16 = var3_3;
lbl33: // 4 sources:
            ZipUtil.closeQuietly(var6_15);
            ZipUtil.closeQuietly(var7_14);
            ZipUtil.closeQuietly(var5_16);
            throw var4_10;
        }
        {
            block10 : {
                ZipUtil.closeQuietly((InputStream)var11_7);
                ZipUtil.closeQuietly((OutputStream)var10_6);
                ZipUtil.closeQuietly(var3_3);
                return;
            }
            var10_6.write(var9_5, 0, var12_8);
            continue;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void unzipNoThrow(String var0, String var1_1) {
        var2_2 = null;
        var3_3 = null;
        var4_4 = null;
        var5_5 = new ZipFile(var0);
        var10_6 = var5_5.entries();
        var11_7 = new byte[4096];
        var12_8 = null;
        var13_9 = null;
        block22 : do {
            block28 : {
                block27 : {
                    if (var10_6.hasMoreElements()) break block27;
                    var5_5.close();
                    ZipUtil.closeQuietly(var13_9);
                    ZipUtil.closeQuietly(var12_8);
                    if (var5_5 == null) return;
                    var5_5.close();
                    return;
                    {
                        catch (IOException var20_24) {
                            return;
                        }
                    }
                }
                var14_10 = (ZipEntry)var10_6.nextElement();
                if (!var14_10.isDirectory()) break block28;
                var15_11 = var1_1;
                if (!var1_1.endsWith("/")) {
                    var15_11 = String.valueOf((Object)new StringBuilder(String.valueOf((Object)var15_11)).append("/").toString()) + var14_10.getName();
                }
                new File(var15_11).mkdirs();
                continue;
            }
            try {
                var4_4 = new BufferedOutputStream((OutputStream)new FileOutputStream(ZipUtil.getFile(var1_1, var14_10.getName())));
                ** GOTO lbl42
            }
            catch (IOException var8_13) {
                block29 : {
                    var4_4 = var12_8;
                    var3_3 = var13_9;
                    var2_2 = var5_5;
                    break block29;
lbl42: // 2 sources:
                    var3_3 = new BufferedInputStream(var5_5.getInputStream(var14_10));
                    ** try [egrp 9[TRYBLOCK] [19, 20 : 248->298)] { 
lbl44: // 1 sources:
                    ** GOTO lbl-1000
                    catch (Throwable var6_22) {
                        var4_4 = var12_8;
                        var3_3 = var13_9;
                        var2_2 = var5_5;
                        ** GOTO lbl-1000
                    }
                    catch (Throwable var6_23) {
                        var3_3 = var13_9;
                        var2_2 = var5_5;
                        ** GOTO lbl-1000
                    }
                    catch (IOException var8_17) {
                        var3_3 = var13_9;
                        var2_2 = var5_5;
                    }
                }
lbl58: // 3 sources:
                do {
                    try {
                        var8_14.printStackTrace();
                    }
                    catch (Throwable var6_19) {}
                    ZipUtil.closeQuietly(var3_3);
                    ZipUtil.closeQuietly(var4_4);
                    if (var2_2 == null) return;
                    try {
                        var2_2.close();
                        return;
                    }
                    catch (IOException var9_18) {
                        return;
                    }
                    ** GOTO lbl-1000
                    break;
                } while (true);
                catch (IOException var8_16) {
                    var3_3 = null;
                    var4_4 = null;
                    var2_2 = null;
                    ** GOTO lbl58
                }
lbl-1000: // 1 sources:
                {
                    do {
                        if ((var17_12 = var3_3.read(var11_7, 0, 4096)) == -1) {
                            ZipUtil.closeQuietly((InputStream)var3_3);
                            ZipUtil.closeQuietly((OutputStream)var4_4);
                            var12_8 = var4_4;
                            var13_9 = var3_3;
                            continue block22;
                        }
                        var4_4.write(var11_7, 0, var17_12);
                    } while (true);
                }
lbl85: // 2 sources:
                catch (IOException var8_15) {
                    var2_2 = var5_5;
                    ** continue;
                }
lbl88: // 2 sources:
                catch (Throwable var6_21) {
                    var2_2 = var5_5;
                }
lbl-1000: // 4 sources:
                {
                    ZipUtil.closeQuietly(var3_3);
                    ZipUtil.closeQuietly(var4_4);
                    if (var2_2 == null) throw var6_20;
                    try {
                        var2_2.close();
                    }
                    catch (IOException var7_25) {
                        throw var6_20;
                    }
                    throw var6_20;
                }
            }
            break;
        } while (true);
    }

    public static void zipDir(String string2, String string3) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(string3);
        ZipOutputStream zipOutputStream = new ZipOutputStream((OutputStream)fileOutputStream);
        ZipUtil.addFolderToZip("", string2, zipOutputStream);
        zipOutputStream.close();
        fileOutputStream.close();
    }
}

