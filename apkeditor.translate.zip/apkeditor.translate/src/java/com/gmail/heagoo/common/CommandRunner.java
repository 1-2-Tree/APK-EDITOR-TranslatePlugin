/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.lang.Exception
 *  java.lang.IllegalThreadStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Process
 *  java.lang.Runtime
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.gmail.heagoo.common;

import com.gmail.heagoo.common.CommandInterface;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class CommandRunner
implements CommandInterface {
    private String[] outputs = new String[2];

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void closeQuietly(InputStream inputStream) {
        if (inputStream == null) return;
        try {
            inputStream.close();
            return;
        }
        catch (IOException iOException) {
            return;
        }
    }

    private Process createProcess(String string2, String[] arrstring) throws IOException {
        return Runtime.getRuntime().exec(string2, arrstring);
    }

    private Process createProcess(String[] arrstring, String[] arrstring2) throws IOException {
        return Runtime.getRuntime().exec(arrstring, arrstring2);
    }

    public static boolean isProcessAlive(Process process) {
        try {
            process.exitValue();
            return false;
        }
        catch (IllegalThreadStateException illegalThreadStateException) {
            return true;
        }
    }

    static String readStream(InputStream inputStream) throws IOException {
        int n;
        char[] arrc = new char[8192];
        StringBuilder stringBuilder = new StringBuilder();
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
        do {
            if ((n = inputStreamReader.read(arrc, 0, arrc.length)) <= 0) continue;
            stringBuilder.append(arrc, 0, n);
        } while (n >= 0);
        return stringBuilder.toString();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static Process runWithEnv(String var0, String[] var1_1, String var2_2) throws IOException {
        var3_3 = 0;
        var4_4 = System.getenv();
        var5_5 = var4_4.size();
        var6_6 = var1_1 != null ? var1_1.length : 0;
        var7_7 = new String[var6_6 + var5_5];
        var8_8 = 0;
        var9_9 = var4_4.entrySet().iterator();
        do {
            block7 : {
                if (var9_9.hasNext()) break block7;
                if (var1_1 != null) {
                    break;
                }
                ** GOTO lbl23
            }
            var10_10 = (Map.Entry)var9_9.next();
            var11_11 = var8_8 + 1;
            var7_7[var8_8] = String.valueOf((Object)((String)var10_10.getKey())) + "=" + (String)var10_10.getValue();
            var8_8 = var11_11;
        } while (true);
        var12_12 = var1_1.length;
        var13_13 = var8_8;
        do {
            block8 : {
                if (var3_3 < var12_12) break block8;
lbl23: // 2 sources:
                if (var2_2 == null) return Runtime.getRuntime().exec(var0, var7_7);
                return Runtime.getRuntime().exec(var0, var7_7, new File(var2_2));
            }
            var14_14 = var1_1[var3_3];
            var15_15 = var13_13 + 1;
            var7_7[var13_13] = var14_14;
            ++var3_3;
            var13_13 = var15_15;
        } while (true);
    }

    @Override
    public String getStdError() {
        return this.outputs[1];
    }

    @Override
    public String getStdOut() {
        return this.outputs[0];
    }

    /*
     * Exception decompiling
     */
    public boolean runCommand(Object var1_1, String[] var2_2, String var3_3, Integer var4_4, boolean var5_5) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 27[SIMPLE_IF_TAKEN]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public boolean runCommand(String string2, String[] arrstring, Integer n) {
        return this.runCommand(string2, arrstring, null, n, false);
    }

    public boolean runCommand(String[] arrstring, String[] arrstring2, Integer n) {
        return this.runCommand(arrstring, arrstring2, null, n, false);
    }

    private static class StreamReadThread
    extends Thread {
        private int index;
        private InputStream input;
        private String[] outputs;

        public StreamReadThread(InputStream inputStream, String[] arrstring, int n) {
            this.input = inputStream;
            this.outputs = arrstring;
            this.index = n;
        }

        public void close() {
            this.interrupt();
            try {
                this.input.close();
                return;
            }
            catch (IOException iOException) {
                return;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public void run() {
            StringBuilder stringBuilder;
            char[] arrc = new char[128];
            stringBuilder = new StringBuilder();
            try {
                int n;
                InputStreamReader inputStreamReader = new InputStreamReader(this.input, "UTF-8");
                do {
                    if ((n = inputStreamReader.read(arrc, 0, arrc.length)) <= 0) continue;
                    stringBuilder.append(arrc, 0, n);
                } while (n >= 0);
            }
            catch (Exception exception) {}
            this.outputs[this.index] = stringBuilder.toString();
        }
    }

}

