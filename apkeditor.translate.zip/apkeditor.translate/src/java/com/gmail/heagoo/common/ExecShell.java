/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.BufferedReader
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Process
 *  java.lang.Runtime
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 */
package com.gmail.heagoo.common;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;

class ExecShell {
    ExecShell() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public ArrayList<String> executeCommand(SHELL_CMD sHELL_CMD) {
        Process process;
        ArrayList arrayList = new ArrayList();
        try {
            process = Runtime.getRuntime().exec(sHELL_CMD.command);
        }
        catch (Exception exception) {
            return null;
        }
        BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(process.getInputStream()));
        try {}
        catch (Exception exception) {
            exception.printStackTrace();
            return arrayList;
        }
        {
            String string2;
            while ((string2 = bufferedReader.readLine()) != null) {
                arrayList.add((Object)string2);
            }
            return arrayList;
        }
    }

    public static final class SHELL_CMD
    extends Enum<SHELL_CMD> {
        private static final /* synthetic */ SHELL_CMD[] ENUM$VALUES;
        public static final /* enum */ SHELL_CMD check_su_binary = new SHELL_CMD(new String[]{"/system/xbin/which", "su"});
        String[] command;

        static {
            SHELL_CMD[] arrsHELL_CMD = new SHELL_CMD[]{check_su_binary};
            ENUM$VALUES = arrsHELL_CMD;
        }

        private SHELL_CMD(String[] arrstring) {
            this.command = arrstring;
        }

        public static SHELL_CMD valueOf(String string2) {
            return (SHELL_CMD)Enum.valueOf(SHELL_CMD.class, (String)string2);
        }

        public static SHELL_CMD[] values() {
            SHELL_CMD[] arrsHELL_CMD = ENUM$VALUES;
            int n = arrsHELL_CMD.length;
            SHELL_CMD[] arrsHELL_CMD2 = new SHELL_CMD[n];
            System.arraycopy((Object)arrsHELL_CMD, (int)0, (Object)arrsHELL_CMD2, (int)0, (int)n);
            return arrsHELL_CMD2;
        }
    }

}

