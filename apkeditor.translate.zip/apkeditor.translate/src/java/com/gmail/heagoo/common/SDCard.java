/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Environment
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.gmail.heagoo.common;

import android.content.Context;
import android.os.Environment;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class SDCard {
    public static void copyStream(InputStream inputStream, OutputStream outputStream) throws IOException {
        byte[] arrby = new byte[4096];
        int n;
        while ((n = inputStream.read(arrby)) > 0) {
            outputStream.write(arrby, 0, n);
        }
        return;
    }

    public static boolean exist() {
        return Environment.getExternalStorageState().equals((Object)"mounted");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static String getExternalStoragePath() {
        var0 = System.getenv((String)"SECONDARY_STORAGE");
        if (var0 != null) {
            if (var0.equals((Object)"") == false) return var0;
        }
        var1_1 = new File("/mnt/");
        var2_2 = var1_1.isDirectory();
        var3_3 = null;
        if (!var2_2) ** GOTO lbl17
        var4_4 = var1_1.list();
        var5_5 = var4_4.length;
        var6_6 = 0;
        do {
            block6 : {
                block5 : {
                    var3_3 = null;
                    if (var6_6 >= var5_5) break block5;
                    var7_7 = var4_4[var6_6];
                    if (!var7_7.equalsIgnoreCase("extsdcard") && (!var7_7.startsWith("external") || !var7_7.contains((CharSequence)"sd"))) break block6;
                    var3_3 = var7_7;
                }
                if (var3_3 == null) return var0;
                return "/mnt/" + var3_3;
            }
            ++var6_6;
        } while (true);
    }

    public static String getRootDirectory() {
        return Environment.getExternalStorageDirectory().getPath();
    }

    public static String makeBackupDir(Context context) throws Exception {
        return SDCard.makeDir(context, "backup");
    }

    /*
     * Enabled aggressive block sorting
     */
    public static String makeDir(Context context, String string2) throws Exception {
        String string3;
        File file;
        if (!SDCard.exist()) {
            throw new Exception("Can not find sd card.");
        }
        String string4 = "";
        String string5 = context.getPackageName();
        if (string5.startsWith("com.gmail.heagoo.apkpermremover")) {
            string4 = "/.ApkPermRemover/" + string2 + "/";
        } else if (string5.startsWith("com.gmail.heagoo.pmaster")) {
            string4 = "/PermMaster/" + string2 + "/";
        } else if (string5.equals((Object)"com.gmail.heagoo.permissionmanager")) {
            string4 = "/PermMaster/" + string2 + "/";
        } else if (string5.startsWith("com.gmail.heagoo.apkeditor")) {
            string4 = "/ApkEditor/" + string2 + "/";
        } else if (string5.startsWith("com.gmail.heagoo.appdm")) {
            string4 = "/HackAppData/" + string2 + "/";
        }
        if (!(file = new File(string3 = String.valueOf((Object)SDCard.getRootDirectory()) + string4)).exists()) {
            file.mkdirs();
        }
        return string3;
    }

    public static String makeImageDir(Context context) throws Exception {
        return SDCard.makeDir(context, "image");
    }

    public static String makeWorkingDir(Context context) throws Exception {
        return SDCard.makeDir(context, "tmp");
    }
}

