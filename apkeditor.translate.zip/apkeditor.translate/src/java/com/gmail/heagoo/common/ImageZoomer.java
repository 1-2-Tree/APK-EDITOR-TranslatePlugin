/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.media.ThumbnailUtils
 *  java.lang.Object
 *  java.lang.String
 */
package com.gmail.heagoo.common;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;

public class ImageZoomer {
    private int originHeight;
    private int originWidth;

    /*
     * Enabled aggressive block sorting
     */
    public Bitmap getImageThumbnail(String string2, int n, int n2) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile((String)string2, (BitmapFactory.Options)options);
        options.inJustDecodeBounds = false;
        this.originHeight = options.outHeight;
        this.originWidth = options.outWidth;
        int n3 = this.originWidth / n;
        int n4 = this.originHeight / n2;
        int n5 = n3 < n4 ? n3 : n4;
        if (n5 <= 0) {
            n5 = 1;
        }
        options.inSampleSize = n5;
        return ThumbnailUtils.extractThumbnail((Bitmap)BitmapFactory.decodeFile((String)string2, (BitmapFactory.Options)options), (int)n, (int)n2, (int)2);
    }

    public int getOriginHeight() {
        return this.originHeight;
    }

    public int getOriginWidth() {
        return this.originWidth;
    }
}

