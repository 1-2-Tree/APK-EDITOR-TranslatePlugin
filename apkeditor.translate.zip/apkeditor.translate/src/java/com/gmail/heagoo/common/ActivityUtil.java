/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Set
 */
package com.gmail.heagoo.common;

import android.content.Intent;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class ActivityUtil {
    public static Bundle attachBoolParam(Intent intent, String string2, boolean bl) {
        Bundle bundle = new Bundle();
        bundle.putBoolean(string2, bl);
        intent.putExtras(bundle);
        return bundle;
    }

    public static Bundle attachParam(Intent intent, String string2, String string3) {
        Bundle bundle = new Bundle();
        bundle.putString(string2, string3);
        intent.putExtras(bundle);
        return bundle;
    }

    public static Bundle attachParam(Intent intent, String string2, ArrayList<String> arrayList) {
        Bundle bundle = new Bundle();
        bundle.putStringArrayList(string2, arrayList);
        intent.putExtras(bundle);
        return bundle;
    }

    public static void attachParam(Intent intent, String string2, Map<String, String> map) {
        Bundle bundle = new Bundle();
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        Iterator iterator = map.keySet().iterator();
        do {
            if (!iterator.hasNext()) {
                bundle.putStringArrayList(String.valueOf((Object)string2) + "_keys", arrayList);
                bundle.putStringArrayList(String.valueOf((Object)string2) + "_values", arrayList2);
                intent.putExtras(bundle);
                return;
            }
            String string3 = (String)iterator.next();
            String string4 = (String)map.get((Object)string3);
            arrayList.add((Object)string3);
            arrayList2.add((Object)string4);
        } while (true);
    }

    public static boolean getBoolParam(Intent intent, String string2) {
        return intent.getExtras().getBoolean(string2, false);
    }

    public static Map<String, String> getMapParam(Intent intent, String string2) {
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            HashMap hashMap = new HashMap();
            ArrayList arrayList = bundle.getStringArrayList(String.valueOf((Object)string2) + "_keys");
            ArrayList arrayList2 = bundle.getStringArrayList(String.valueOf((Object)string2) + "_values");
            if (arrayList != null && arrayList2 != null) {
                int n = 0;
                do {
                    if (n >= arrayList.size()) {
                        return hashMap;
                    }
                    hashMap.put((Object)((String)arrayList.get(n)), (Object)((String)arrayList2.get(n)));
                    ++n;
                } while (true);
            }
        }
        return null;
    }

    public static String getParam(Intent intent, String string2) {
        return intent.getExtras().getString(string2);
    }

    public static ArrayList<String> getStringArray(Intent intent, String string2) {
        return intent.getExtras().getStringArrayList(string2);
    }
}

