/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  java.io.File
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.gmail.heagoo.common;

import android.os.Build;
import com.gmail.heagoo.common.ExecShell;
import java.io.File;
import java.util.ArrayList;

public class RootChecker {
    public boolean checkRootMethod1() {
        String string2 = Build.TAGS;
        return string2 != null && string2.contains((CharSequence)"test-keys");
    }

    public boolean checkRootMethod2() {
        try {
            boolean bl = new File("/system/app/Superuser.apk").exists();
            if (bl) {
                return true;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return false;
    }

    public boolean checkRootMethod3() {
        return new ExecShell().executeCommand(ExecShell.SHELL_CMD.check_su_binary) != null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean isDeviceRooted() {
        return this.checkRootMethod1() || this.checkRootMethod2() || this.checkRootMethod3();
    }
}

