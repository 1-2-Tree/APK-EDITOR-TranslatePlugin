/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.Random
 */
package com.gmail.heagoo.common;

import java.util.Random;

public class RandomUtil {
    private static final char[] letters = new char[]{'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
    private static Random r;

    public static String getRandomString(int n) {
        if (r == null) {
            r = new Random(System.currentTimeMillis());
        }
        StringBuilder stringBuilder = new StringBuilder();
        int n2 = 0;
        while (n2 < n) {
            int n3 = r.nextInt(letters.length);
            stringBuilder.append(letters[n3]);
            ++n2;
        }
        return stringBuilder.toString();
    }
}

