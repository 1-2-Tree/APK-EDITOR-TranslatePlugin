/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.util.DisplayMetrics
 *  android.view.Display
 *  android.view.WindowManager
 *  java.lang.Object
 */
package com.gmail.heagoo.common;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.view.WindowManager;

public class Display {
    public static int screenHeight;
    public static int screenWidth;

    static {
        screenWidth = 0;
        screenHeight = 0;
    }

    public static int getHeight(Activity activity) {
        if (screenHeight <= 0) {
            Display.init(activity);
        }
        return screenHeight;
    }

    public static int getWidth(Activity activity) {
        if (screenWidth <= 0) {
            Display.init(activity);
        }
        return screenWidth;
    }

    private static void init(Activity activity) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        screenWidth = displayMetrics.widthPixels;
        screenHeight = displayMetrics.heightPixels;
    }
}

