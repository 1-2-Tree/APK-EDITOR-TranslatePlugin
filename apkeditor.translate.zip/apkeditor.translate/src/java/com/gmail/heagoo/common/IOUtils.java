/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.OutputStream
 *  java.lang.ClassNotFoundException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.gmail.heagoo.common;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class IOUtils {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void closeWithoutThrow(Closeable closeable) {
        if (closeable == null) return;
        try {
            closeable.close();
            return;
        }
        catch (IOException iOException) {
            return;
        }
    }

    public static void copy(InputStream inputStream, OutputStream outputStream) throws IOException {
        byte[] arrby = new byte[4096];
        int n;
        while ((n = inputStream.read(arrby)) != -1) {
            outputStream.write(arrby, 0, n);
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void readFully(InputStream inputStream, byte[] arrby) throws IOException {
        int n = 0;
        int n2;
        while (n < arrby.length && (n2 = inputStream.read(arrby, n, arrby.length - n)) != -1) {
            n += n2;
        }
        return;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static Object readObjectFromFile(String var0) {
        var1_1 = new File(var0);
        var2_2 = null;
        var3_3 = new ObjectInputStream((InputStream)new FileInputStream(var1_1));
        try {
            var7_4 = var3_3.readObject();
        }
        catch (Throwable var5_13) {
            var2_2 = var3_3;
            ** GOTO lbl-1000
        }
        catch (ClassNotFoundException var6_10) {
            var2_2 = var3_3;
        }
        IOUtils.closeWithoutThrow((Closeable)var3_3);
        return var7_4;
        catch (IOException var4_5) {}
        ** GOTO lbl-1000
        catch (ClassNotFoundException var6_8) {}
        {
            var6_9.printStackTrace();
            {
                catch (Throwable var5_11) lbl-1000: // 2 sources:
                {
                    IOUtils.closeWithoutThrow(var2_2);
                    throw var5_12;
                }
            }
            IOUtils.closeWithoutThrow(var2_2);
            return null;
            catch (IOException var4_7) {
                var2_2 = var3_3;
            }
lbl-1000: // 2 sources:
            {
                var4_6.printStackTrace();
                IOUtils.closeWithoutThrow(var2_2);
                return null;
            }
        }
    }

    public static byte[] toByteArray(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        IOUtils.copy(inputStream, (OutputStream)byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void writeObjectToFile(String var0, Object var1_1) {
        var2_2 = new File(var0);
        var3_3 = null;
        var4_4 = new ObjectOutputStream((OutputStream)new FileOutputStream(var2_2));
        try {
            var4_4.writeObject(var1_1);
            var4_4.flush();
        }
        catch (Throwable var6_10) {
            var3_3 = var4_4;
            ** GOTO lbl-1000
        }
        catch (IOException var5_7) {
            var3_3 = var4_4;
        }
        IOUtils.closeWithoutThrow((Closeable)var4_4);
        return;
        catch (IOException var5_5) {}
        {
            try {
                var5_6.printStackTrace();
            }
            catch (Throwable var6_8) lbl-1000: // 2 sources:
            {
                IOUtils.closeWithoutThrow(var3_3);
                throw var6_9;
            }
            IOUtils.closeWithoutThrow(var3_3);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void writeZero(OutputStream outputStream, int n) throws IOException {
        int n2 = n / 1024;
        int n3 = n % 1024;
        byte[] arrby = new byte[1024];
        int n4 = 0;
        do {
            if (n4 >= 1024) break;
            arrby[n4] = 0;
            ++n4;
        } while (true);
        int n5 = 0;
        do {
            if (n5 >= n2) {
                if (n3 > 0) {
                    outputStream.write(arrby, 0, n3);
                }
                return;
            }
            outputStream.write(arrby);
            ++n5;
        } while (true);
    }
}

