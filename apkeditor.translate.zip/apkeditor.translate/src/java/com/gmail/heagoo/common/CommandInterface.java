/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 */
package com.gmail.heagoo.common;

public interface CommandInterface {
    public String getStdError();

    public String getStdOut();

    public boolean runCommand(String var1, String[] var2, Integer var3);
}

