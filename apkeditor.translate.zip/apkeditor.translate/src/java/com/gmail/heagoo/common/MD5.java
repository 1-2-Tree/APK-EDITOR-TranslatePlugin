/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.security.MessageDigest
 *  java.security.NoSuchAlgorithmException
 */
package com.gmail.heagoo.common;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5 {
    public static String byteArrayToHex(byte[] arrby) {
        char[] arrc = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
        char[] arrc2 = new char[2 * arrby.length];
        int n = arrby.length;
        int n2 = 0;
        int n3 = 0;
        while (n2 < n) {
            byte by = arrby[n2];
            int n4 = n3 + 1;
            arrc2[n3] = arrc[15 & by >>> 4];
            n3 = n4 + 1;
            arrc2[n4] = arrc[by & 15];
            ++n2;
        }
        return new String(arrc2);
    }

    public static String stringMD5(String string2) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance((String)"MD5");
            messageDigest.update(string2.getBytes());
            String string3 = MD5.byteArrayToHex(messageDigest.digest());
            return string3;
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            return null;
        }
    }
}

