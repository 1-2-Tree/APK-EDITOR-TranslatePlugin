/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.DisplayMetrics
 *  java.io.File
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 */
package com.gmail.heagoo.common;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.DisplayMetrics;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ApkInfoParser {
    public static final String AssetManagerPath = "android.content.res.AssetManager";
    public static final String PackageParserPath = "android.content.pm.PackageParser";

    /*
     * Enabled aggressive block sorting
     */
    public static AppInfo parse(Context context, String string2) throws Exception {
        if (Build.VERSION.SDK_INT > 20) {
            return ApkInfoParser.parse_50(context, string2);
        }
        Class class_ = Class.forName((String)PackageParserPath);
        Object object = class_.getConstructor(new Class[]{String.class}).newInstance(new Object[]{string2});
        DisplayMetrics displayMetrics = new DisplayMetrics();
        displayMetrics.setToDefaults();
        Class[] arrclass = new Class[]{File.class, String.class, DisplayMetrics.class, Integer.TYPE};
        Method method = class_.getDeclaredMethod("parsePackage", arrclass);
        Object[] arrobject = new Object[4];
        File file = new File(string2);
        arrobject[0] = file;
        arrobject[1] = string2;
        arrobject[2] = displayMetrics;
        arrobject[3] = 0;
        Object object2 = method.invoke(object, arrobject);
        ApplicationInfo applicationInfo = (ApplicationInfo)object2.getClass().getDeclaredField("applicationInfo").get(object2);
        Class class_2 = Class.forName((String)AssetManagerPath);
        Object object3 = class_2.getConstructor(null).newInstance(null);
        class_2.getDeclaredMethod("addAssetPath", new Class[]{String.class}).invoke(object3, new Object[]{string2});
        Resources resources = context.getResources();
        Class[] arrclass2 = new Class[]{object3.getClass(), resources.getDisplayMetrics().getClass(), resources.getConfiguration().getClass()};
        Constructor constructor = Resources.class.getConstructor(arrclass2);
        Object[] arrobject2 = new Object[]{object3, resources.getDisplayMetrics(), resources.getConfiguration()};
        Resources resources2 = (Resources)constructor.newInstance(arrobject2);
        int n = applicationInfo.labelRes;
        CharSequence charSequence = null;
        if (n != 0) {
            charSequence = resources2.getText(applicationInfo.labelRes);
        }
        if (charSequence == null) {
            charSequence = applicationInfo.nonLocalizedLabel;
        }
        int n2 = applicationInfo.icon;
        Drawable drawable2 = null;
        if (n2 != 0) {
            drawable2 = resources2.getDrawable(applicationInfo.icon);
        }
        AppInfo appInfo = new AppInfo();
        String string3 = charSequence != null ? charSequence.toString() : "";
        appInfo.label = string3;
        appInfo.packageName = applicationInfo.packageName;
        appInfo.icon = drawable2;
        return appInfo;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static AppInfo parse_50(Context context, String string2) throws Exception {
        Class class_ = Class.forName((String)PackageParserPath);
        Object object = class_.getConstructor(null).newInstance(null);
        Class[] arrclass = new Class[]{File.class, Integer.TYPE};
        Method method = class_.getDeclaredMethod("parsePackage", arrclass);
        Object[] arrobject = new Object[2];
        File file = new File(string2);
        arrobject[0] = file;
        arrobject[1] = 0;
        Object object2 = method.invoke(object, arrobject);
        ApplicationInfo applicationInfo = (ApplicationInfo)object2.getClass().getDeclaredField("applicationInfo").get(object2);
        Class class_2 = Class.forName((String)AssetManagerPath);
        Object object3 = class_2.getConstructor(null).newInstance(null);
        class_2.getDeclaredMethod("addAssetPath", new Class[]{String.class}).invoke(object3, new Object[]{string2});
        Resources resources = context.getResources();
        Class[] arrclass2 = new Class[]{object3.getClass(), resources.getDisplayMetrics().getClass(), resources.getConfiguration().getClass()};
        Constructor constructor = Resources.class.getConstructor(arrclass2);
        Object[] arrobject2 = new Object[]{object3, resources.getDisplayMetrics(), resources.getConfiguration()};
        Resources resources2 = (Resources)constructor.newInstance(arrobject2);
        int n = applicationInfo.labelRes;
        CharSequence charSequence = null;
        if (n != 0) {
            charSequence = resources2.getText(applicationInfo.labelRes);
        }
        if (charSequence == null) {
            charSequence = applicationInfo.nonLocalizedLabel;
        }
        int n2 = applicationInfo.icon;
        Drawable drawable2 = null;
        if (n2 != 0) {
            drawable2 = resources2.getDrawable(applicationInfo.icon);
        }
        AppInfo appInfo = new AppInfo();
        String string3 = charSequence != null ? charSequence.toString() : "";
        appInfo.label = string3;
        appInfo.packageName = applicationInfo.packageName;
        appInfo.icon = drawable2;
        return appInfo;
    }

    public static class AppInfo {
        public Drawable icon;
        public boolean isSysApp;
        public String label;
        public String packageName;
    }

}

