/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.gmail.heagoo.common;

public class StringUtil {
    /*
     * Enabled aggressive block sorting
     */
    public static String join(String string2, String[] arrstring) {
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        while (n < arrstring.length) {
            if (n == -1 + arrstring.length) {
                stringBuilder.append(arrstring[n]);
            } else {
                stringBuilder.append(arrstring[n]).append(string2);
            }
            ++n;
        }
        return stringBuilder.toString();
    }
}

