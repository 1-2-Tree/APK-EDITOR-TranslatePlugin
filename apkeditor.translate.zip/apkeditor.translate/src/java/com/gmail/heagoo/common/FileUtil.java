/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.gmail.heagoo.common;

import com.gmail.heagoo.common.IOUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class FileUtil {
    /*
     * Enabled aggressive block sorting
     */
    public static void copyAll(File file, File file2) throws IOException {
        if (file2.exists()) {
            file2.mkdirs();
        }
        File[] arrfile = file.listFiles();
        int n = arrfile.length;
        int n2 = 0;
        while (n2 < n) {
            File file3 = arrfile[n2];
            if (file3.isFile()) {
                FileUtil.copyFile(file3, new File(file2, file3.getName()));
            } else {
                FileUtil.copyAll(file3, new File(file2, file3.getName()));
            }
            ++n2;
        }
        return;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void copyFile(File var0, File var1_1) throws IOException {
        block7 : {
            var2_2 = null;
            var3_3 = null;
            try {
                var4_4 = new FileInputStream(var0);
            }
            catch (Throwable var6_6) {}
            try {
                var5_5 = new FileOutputStream(var1_1);
            }
            catch (Throwable var6_8) {
                var2_2 = var4_4;
                var3_3 = null;
                ** GOTO lbl-1000
            }
            try {
                IOUtils.copy((InputStream)var4_4, (OutputStream)var5_5);
                if (var4_4 == null) break block7;
            }
            catch (Throwable var6_9) {
                var3_3 = var5_5;
                var2_2 = var4_4;
            }
            var4_4.close();
        }
        if (var5_5 == null) return;
        var5_5.close();
        return;
lbl-1000: // 3 sources:
        {
            if (var2_2 != null) {
                var2_2.close();
            }
            if (var3_3 == null) throw var6_7;
            var3_3.close();
            throw var6_7;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void copyFile(String var0, String var1_1) throws IOException {
        block7 : {
            var2_2 = null;
            var3_3 = null;
            try {
                var4_4 = new FileInputStream(var0);
            }
            catch (Throwable var6_6) {}
            try {
                var5_5 = new FileOutputStream(var1_1);
            }
            catch (Throwable var6_8) {
                var2_2 = var4_4;
                var3_3 = null;
                ** GOTO lbl-1000
            }
            try {
                IOUtils.copy((InputStream)var4_4, (OutputStream)var5_5);
                if (var4_4 == null) break block7;
            }
            catch (Throwable var6_9) {
                var3_3 = var5_5;
                var2_2 = var4_4;
            }
            var4_4.close();
        }
        if (var5_5 == null) return;
        var5_5.close();
        return;
lbl-1000: // 3 sources:
        {
            if (var2_2 != null) {
                var2_2.close();
            }
            if (var3_3 == null) throw var6_7;
            var3_3.close();
            throw var6_7;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void deleteAll(File file) throws IOException {
        if (file.isDirectory()) {
            File[] arrfile = file.listFiles();
            int n = arrfile.length;
            for (int i = 0; i < n; ++i) {
                FileUtil.deleteAll(arrfile[i]);
            }
        }
        file.delete();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void writeToFile(String var0, byte[] var1_1) {
        var2_2 = null;
        var3_3 = new FileOutputStream(var0);
        var3_3.write(var1_1);
        if (var3_3 == null) return;
        try {
            var3_3.close();
            return;
        }
        catch (IOException var8_11) {
            return;
        }
        catch (IOException var4_4) {}
        ** GOTO lbl-1000
        catch (Throwable var5_10) {
            var2_2 = var3_3;
            ** GOTO lbl-1000
        }
        catch (IOException var4_6) {
            var2_2 = var3_3;
        }
lbl-1000: // 2 sources:
        {
            try {
                var4_5.printStackTrace();
                if (var2_2 == null) return;
            }
            catch (Throwable var5_8) lbl-1000: // 2 sources:
            {
                if (var2_2 == null) throw var5_9;
                try {
                    var2_2.close();
                }
                catch (IOException var6_12) {
                    throw var5_9;
                }
                throw var5_9;
            }
            try {
                var2_2.close();
                return;
            }
            catch (IOException var7_7) {
                return;
            }
        }
    }
}

