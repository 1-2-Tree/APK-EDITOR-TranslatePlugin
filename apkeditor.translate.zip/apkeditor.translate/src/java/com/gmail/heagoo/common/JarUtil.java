/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Object
 *  java.lang.String
 *  java.util.jar.JarEntry
 *  java.util.jar.JarFile
 *  java.util.zip.ZipEntry
 */
package com.gmail.heagoo.common;

import com.gmail.heagoo.common.IOUtils;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;

public class JarUtil {
    public static void extractFile(String string2, String string3, String string4) throws IOException {
        JarFile jarFile = new JarFile(new File(string2), false);
        InputStream inputStream = jarFile.getInputStream((ZipEntry)jarFile.getJarEntry(string3));
        FileOutputStream fileOutputStream = new FileOutputStream(string4);
        IOUtils.copy(inputStream, (OutputStream)fileOutputStream);
        fileOutputStream.close();
        jarFile.close();
    }
}

