/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.gmail.heagoo.common;

public interface ITaskCallback {
    public void setTaskProgress(float var1);

    public void setTaskStepInfo(TaskStepInfo var1);

    public void taskFailed(String var1);

    public void taskSucceed();

    public void taskWarning(String var1);

    public static class TaskStepInfo {
        public String stepDescription;
        public int stepIndex = 0;
        public int stepTotal;
    }

}

