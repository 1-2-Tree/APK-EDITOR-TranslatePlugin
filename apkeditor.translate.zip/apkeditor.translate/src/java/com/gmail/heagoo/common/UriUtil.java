/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.app.Activity
 *  android.content.ContentResolver
 *  android.content.ContentUris
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.provider.DocumentsContract
 *  android.provider.MediaStore
 *  android.provider.MediaStore$Audio
 *  android.provider.MediaStore$Audio$Media
 *  android.provider.MediaStore$Images
 *  android.provider.MediaStore$Images$Media
 *  android.provider.MediaStore$Video
 *  android.provider.MediaStore$Video$Media
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 */
package com.gmail.heagoo.common;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

@SuppressLint(value={"NewApi"})
public class UriUtil {
    /*
     * Enabled aggressive block sorting
     */
    public static String getAbsolutePath(Activity activity, Uri uri) {
        if (activity == null || uri == null) return null;
        if (Build.VERSION.SDK_INT >= 19 && DocumentsContract.isDocumentUri((Context)activity, (Uri)uri)) {
            if (UriUtil.isExternalStorageDocument(uri)) {
                String[] arrstring = DocumentsContract.getDocumentId((Uri)uri).split(":");
                return (Object)Environment.getExternalStorageDirectory() + "/" + arrstring[1];
            }
            if (UriUtil.isDownloadsDocument(uri)) {
                String string2 = DocumentsContract.getDocumentId((Uri)uri);
                return UriUtil.getDataColumn((Context)activity, ContentUris.withAppendedId((Uri)Uri.parse((String)"content://downloads/public_downloads"), (long)Long.valueOf((String)string2)), null, null);
            }
            if (!UriUtil.isMediaDocument(uri)) return null;
            {
                Uri uri2;
                String[] arrstring = DocumentsContract.getDocumentId((Uri)uri).split(":");
                String string3 = arrstring[0];
                if ("image".equals((Object)string3)) {
                    uri2 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals((Object)string3)) {
                    uri2 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else {
                    boolean bl = "audio".equals((Object)string3);
                    uri2 = null;
                    if (bl) {
                        uri2 = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    }
                }
                String[] arrstring2 = new String[]{arrstring[1]};
                return UriUtil.getDataColumn((Context)activity, uri2, "_id=?", arrstring2);
            }
        }
        if ("content".equalsIgnoreCase(uri.getScheme())) {
            if (!UriUtil.isGooglePhotosUri(uri)) return UriUtil.getDataColumn((Context)activity, uri, null, null);
            return uri.getLastPathSegment();
        }
        if ("file".equalsIgnoreCase(uri.getScheme())) return uri.getPath();
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String getDataColumn(Context context, Uri uri, String string2, String[] arrstring) {
        Cursor cursor = null;
        String[] arrstring2 = new String[]{"_data"};
        cursor = context.getContentResolver().query(uri, arrstring2, string2, arrstring, null);
        if (cursor == null) return null;
        try {
            if (!cursor.moveToFirst()) return null;
            String string3 = cursor.getString(cursor.getColumnIndexOrThrow("_data"));
            return string3;
        }
        finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals((Object)uri.getAuthority());
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals((Object)uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals((Object)uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals((Object)uri.getAuthority());
    }
}

