/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.gmail.heagoo.apkeditor.translate;

import java.io.Serializable;

public class TranslateItem
implements Serializable {
    private static final long serialVersionUID = -3101805950698159689L;
    public String name;
    public String originValue;
    public String translatedValue;

    public TranslateItem(String string2, String string3) {
        this.name = string2;
        this.originValue = string3;
    }

    public TranslateItem(String string2, String string3, String string4) {
        this.name = string2;
        this.originValue = string3;
        this.translatedValue = string4;
    }
}

