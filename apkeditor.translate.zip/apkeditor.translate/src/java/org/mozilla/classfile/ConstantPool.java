/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package org.mozilla.classfile;

import org.mozilla.classfile.ClassFileWriter;
import org.mozilla.classfile.FieldOrMethodRef;
import org.mozilla.javascript.ObjToIntMap;
import org.mozilla.javascript.UintMap;

final class ConstantPool {
    static final byte CONSTANT_Class = 7;
    static final byte CONSTANT_Double = 6;
    static final byte CONSTANT_Fieldref = 9;
    static final byte CONSTANT_Float = 4;
    static final byte CONSTANT_Integer = 3;
    static final byte CONSTANT_InterfaceMethodref = 11;
    static final byte CONSTANT_Long = 5;
    static final byte CONSTANT_Methodref = 10;
    static final byte CONSTANT_NameAndType = 12;
    static final byte CONSTANT_String = 8;
    static final byte CONSTANT_Utf8 = 1;
    private static final int ConstantPoolSize = 256;
    private static final int MAX_UTF_ENCODING_SIZE = 65535;
    private ClassFileWriter cfw;
    private ObjToIntMap itsClassHash = new ObjToIntMap();
    private UintMap itsConstantData = new UintMap();
    private ObjToIntMap itsFieldRefHash = new ObjToIntMap();
    private ObjToIntMap itsMethodRefHash = new ObjToIntMap();
    private byte[] itsPool;
    private UintMap itsPoolTypes = new UintMap();
    private UintMap itsStringConstHash = new UintMap();
    private int itsTop;
    private int itsTopIndex;
    private ObjToIntMap itsUtf8Hash = new ObjToIntMap();

    ConstantPool(ClassFileWriter classFileWriter) {
        this.cfw = classFileWriter;
        this.itsTopIndex = 1;
        this.itsPool = new byte[256];
        this.itsTop = 0;
    }

    private short addNameAndType(String string2, String string3) {
        short s = this.addUtf8(string2);
        short s2 = this.addUtf8(string3);
        this.ensure(5);
        byte[] arrby = this.itsPool;
        int n = this.itsTop;
        this.itsTop = n + 1;
        arrby[n] = 12;
        this.itsTop = ClassFileWriter.putInt16(s, this.itsPool, this.itsTop);
        this.itsTop = ClassFileWriter.putInt16(s2, this.itsPool, this.itsTop);
        this.itsPoolTypes.put(this.itsTopIndex, 12);
        int n2 = this.itsTopIndex;
        this.itsTopIndex = n2 + 1;
        return (short)n2;
    }

    short addClass(String string2) {
        int n = this.itsClassHash.get(string2, -1);
        if (n == -1) {
            String string3 = string2;
            if (string2.indexOf(46) > 0 && (n = this.itsClassHash.get(string3 = ClassFileWriter.getSlashedForm(string2), -1)) != -1) {
                this.itsClassHash.put(string2, n);
            }
            if (n == -1) {
                short s = this.addUtf8(string3);
                this.ensure(3);
                byte[] arrby = this.itsPool;
                int n2 = this.itsTop;
                this.itsTop = n2 + 1;
                arrby[n2] = 7;
                this.itsTop = ClassFileWriter.putInt16(s, this.itsPool, this.itsTop);
                n = this.itsTopIndex;
                this.itsTopIndex = n + 1;
                this.itsClassHash.put(string3, n);
                if (string2 != string3) {
                    this.itsClassHash.put(string2, n);
                }
            }
        }
        this.setConstantData(n, string2);
        this.itsPoolTypes.put(n, 7);
        return (short)n;
    }

    int addConstant(double d) {
        this.ensure(9);
        byte[] arrby = this.itsPool;
        int n = this.itsTop;
        this.itsTop = n + 1;
        arrby[n] = 6;
        this.itsTop = ClassFileWriter.putInt64(Double.doubleToLongBits((double)d), this.itsPool, this.itsTop);
        int n2 = this.itsTopIndex;
        this.itsTopIndex = 2 + this.itsTopIndex;
        this.itsPoolTypes.put(n2, 6);
        return n2;
    }

    int addConstant(float f) {
        this.ensure(5);
        byte[] arrby = this.itsPool;
        int n = this.itsTop;
        this.itsTop = n + 1;
        arrby[n] = 4;
        this.itsTop = ClassFileWriter.putInt32(Float.floatToIntBits((float)f), this.itsPool, this.itsTop);
        this.itsPoolTypes.put(this.itsTopIndex, 4);
        int n2 = this.itsTopIndex;
        this.itsTopIndex = n2 + 1;
        return n2;
    }

    int addConstant(int n) {
        this.ensure(5);
        byte[] arrby = this.itsPool;
        int n2 = this.itsTop;
        this.itsTop = n2 + 1;
        arrby[n2] = 3;
        this.itsTop = ClassFileWriter.putInt32(n, this.itsPool, this.itsTop);
        this.itsPoolTypes.put(this.itsTopIndex, 3);
        int n3 = this.itsTopIndex;
        this.itsTopIndex = n3 + 1;
        return (short)n3;
    }

    int addConstant(long l) {
        this.ensure(9);
        byte[] arrby = this.itsPool;
        int n = this.itsTop;
        this.itsTop = n + 1;
        arrby[n] = 5;
        this.itsTop = ClassFileWriter.putInt64(l, this.itsPool, this.itsTop);
        int n2 = this.itsTopIndex;
        this.itsTopIndex = 2 + this.itsTopIndex;
        this.itsPoolTypes.put(n2, 5);
        return n2;
    }

    int addConstant(String string2) {
        int n = 65535 & this.addUtf8(string2);
        int n2 = this.itsStringConstHash.getInt(n, -1);
        if (n2 == -1) {
            n2 = this.itsTopIndex;
            this.itsTopIndex = n2 + 1;
            this.ensure(3);
            byte[] arrby = this.itsPool;
            int n3 = this.itsTop;
            this.itsTop = n3 + 1;
            arrby[n3] = 8;
            this.itsTop = ClassFileWriter.putInt16(n, this.itsPool, this.itsTop);
            this.itsStringConstHash.put(n, n2);
        }
        this.itsPoolTypes.put(n2, 8);
        return n2;
    }

    short addFieldRef(String string2, String string3, String string4) {
        FieldOrMethodRef fieldOrMethodRef = new FieldOrMethodRef(string2, string3, string4);
        int n = this.itsFieldRefHash.get(fieldOrMethodRef, -1);
        if (n == -1) {
            short s = this.addNameAndType(string3, string4);
            short s2 = this.addClass(string2);
            this.ensure(5);
            byte[] arrby = this.itsPool;
            int n2 = this.itsTop;
            this.itsTop = n2 + 1;
            arrby[n2] = 9;
            this.itsTop = ClassFileWriter.putInt16(s2, this.itsPool, this.itsTop);
            this.itsTop = ClassFileWriter.putInt16(s, this.itsPool, this.itsTop);
            n = this.itsTopIndex;
            this.itsTopIndex = n + 1;
            this.itsFieldRefHash.put(fieldOrMethodRef, n);
        }
        this.setConstantData(n, fieldOrMethodRef);
        this.itsPoolTypes.put(n, 9);
        return (short)n;
    }

    short addInterfaceMethodRef(String string2, String string3, String string4) {
        short s = this.addNameAndType(string3, string4);
        short s2 = this.addClass(string2);
        this.ensure(5);
        byte[] arrby = this.itsPool;
        int n = this.itsTop;
        this.itsTop = n + 1;
        arrby[n] = 11;
        this.itsTop = ClassFileWriter.putInt16(s2, this.itsPool, this.itsTop);
        this.itsTop = ClassFileWriter.putInt16(s, this.itsPool, this.itsTop);
        FieldOrMethodRef fieldOrMethodRef = new FieldOrMethodRef(string2, string3, string4);
        this.setConstantData(this.itsTopIndex, fieldOrMethodRef);
        this.itsPoolTypes.put(this.itsTopIndex, 11);
        int n2 = this.itsTopIndex;
        this.itsTopIndex = n2 + 1;
        return (short)n2;
    }

    short addMethodRef(String string2, String string3, String string4) {
        FieldOrMethodRef fieldOrMethodRef = new FieldOrMethodRef(string2, string3, string4);
        int n = this.itsMethodRefHash.get(fieldOrMethodRef, -1);
        if (n == -1) {
            short s = this.addNameAndType(string3, string4);
            short s2 = this.addClass(string2);
            this.ensure(5);
            byte[] arrby = this.itsPool;
            int n2 = this.itsTop;
            this.itsTop = n2 + 1;
            arrby[n2] = 10;
            this.itsTop = ClassFileWriter.putInt16(s2, this.itsPool, this.itsTop);
            this.itsTop = ClassFileWriter.putInt16(s, this.itsPool, this.itsTop);
            n = this.itsTopIndex;
            this.itsTopIndex = n + 1;
            this.itsMethodRefHash.put(fieldOrMethodRef, n);
        }
        this.setConstantData(n, fieldOrMethodRef);
        this.itsPoolTypes.put(n, 10);
        return (short)n;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    short addUtf8(String var1_1) {
        block6 : {
            block9 : {
                block8 : {
                    block7 : {
                        var2_2 = this.itsUtf8Hash.get(var1_1, -1);
                        if (var2_2 != -1) break block6;
                        var3_3 = var1_1.length();
                        if (var3_3 > 65535) break block7;
                        this.ensure(3 + var3_3 * 3);
                        var4_5 = this.itsTop;
                        var5_6 = this.itsPool;
                        var6_7 = var4_5 + 1;
                        var5_6[var4_5] = 1;
                        var7_8 = var6_7 + 2;
                        var8_9 = this.cfw.getCharBuffer(var3_3);
                        var1_1.getChars(0, var3_3, var8_9, 0);
                        var10_11 = var7_8;
                        break block8;
                    }
                    var12_4 = true;
lbl17: // 3 sources:
                    while (var12_4) {
                        throw new IllegalArgumentException("Too big string");
                    }
                    break block6;
                }
                for (var9_10 = 0; var9_10 != var3_3; ++var9_10) {
                    var13_12 = var8_9[var9_10];
                    if (var13_12 != '\u0000' && var13_12 <= '') {
                        var24_23 = this.itsPool;
                        var18_17 = var10_11 + 1;
                        var24_23[var10_11] = (byte)var13_12;
                    } else if (var13_12 > '\u07ff') {
                        var19_18 = this.itsPool;
                        var20_19 = var10_11 + 1;
                        var19_18[var10_11] = (byte)(224 | var13_12 >> 12);
                        var21_20 = this.itsPool;
                        var22_21 = var20_19 + 1;
                        var21_20[var20_19] = (byte)(128 | 63 & var13_12 >> 6);
                        var23_22 = this.itsPool;
                        var18_17 = var22_21 + 1;
                        var23_22[var22_21] = (byte)(128 | var13_12 & 63);
                    } else {
                        var14_13 = this.itsPool;
                        var15_14 = var10_11 + 1;
                        var14_13[var10_11] = (byte)(192 | var13_12 >> 6);
                        var16_15 = this.itsPool;
                        var17_16 = var15_14 + 1;
                        var16_15[var15_14] = (byte)(128 | var13_12 & 63);
                        var18_17 = var17_16;
                    }
                    var10_11 = var18_17;
                }
                var11_24 = var10_11 - (2 + (1 + this.itsTop));
                if (var11_24 <= 65535) break block9;
                var12_4 = true;
                ** GOTO lbl17
            }
            this.itsPool[1 + this.itsTop] = (byte)(var11_24 >>> 8);
            this.itsPool[2 + this.itsTop] = (byte)var11_24;
            this.itsTop = var10_11;
            var2_2 = this.itsTopIndex;
            this.itsTopIndex = var2_2 + 1;
            this.itsUtf8Hash.put(var1_1, var2_2);
            var12_4 = false;
            ** GOTO lbl17
        }
        this.setConstantData(var2_2, var1_1);
        this.itsPoolTypes.put(var2_2, 1);
        return (short)var2_2;
    }

    void ensure(int n) {
        if (n + this.itsTop > this.itsPool.length) {
            int n2 = 2 * this.itsPool.length;
            if (n + this.itsTop > n2) {
                n2 = n + this.itsTop;
            }
            byte[] arrby = new byte[n2];
            System.arraycopy((Object)this.itsPool, (int)0, (Object)arrby, (int)0, (int)this.itsTop);
            this.itsPool = arrby;
        }
    }

    Object getConstantData(int n) {
        return this.itsConstantData.getObject(n);
    }

    byte getConstantType(int n) {
        return (byte)this.itsPoolTypes.getInt(n, 0);
    }

    /*
     * Enabled aggressive block sorting
     */
    int getUtfEncodingLimit(String string2, int n, int n2) {
        if (3 * (n2 - n) > 65535) {
            int n3 = 65535;
            for (int i = n; i != n2; ++i) {
                char c = string2.charAt(i);
                n3 = c != '\u0000' && c <= '' ? --n3 : (c < '\u07ff' ? (n3 -= 2) : (n3 -= 3));
                if (n3 >= 0) continue;
                return i;
            }
        }
        return n2;
    }

    int getWriteSize() {
        return 2 + this.itsTop;
    }

    /*
     * Enabled aggressive block sorting
     */
    boolean isUnderUtfEncodingLimit(String string2) {
        block5 : {
            block4 : {
                int n = string2.length();
                if (n * 3 <= 65535) break block4;
                if (n > 65535) {
                    return false;
                }
                if (n != this.getUtfEncodingLimit(string2, 0, n)) break block5;
            }
            return true;
        }
        return false;
    }

    void setConstantData(int n, Object object) {
        this.itsConstantData.put(n, object);
    }

    int write(byte[] arrby, int n) {
        int n2 = ClassFileWriter.putInt16((short)this.itsTopIndex, arrby, n);
        System.arraycopy((Object)this.itsPool, (int)0, (Object)arrby, (int)n2, (int)this.itsTop);
        return n2 + this.itsTop;
    }
}

