/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.classfile;

final class FieldOrMethodRef {
    private String className;
    private int hashCode = -1;
    private String name;
    private String type;

    FieldOrMethodRef(String string2, String string3, String string4) {
        this.className = string2;
        this.name = string3;
        this.type = string4;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean equals(Object object) {
        block3 : {
            block2 : {
                if (!(object instanceof FieldOrMethodRef)) break block2;
                FieldOrMethodRef fieldOrMethodRef = (FieldOrMethodRef)object;
                if (this.className.equals((Object)fieldOrMethodRef.className) && this.name.equals((Object)fieldOrMethodRef.name) && this.type.equals((Object)fieldOrMethodRef.type)) break block3;
            }
            return false;
        }
        return true;
    }

    public String getClassName() {
        return this.className;
    }

    public String getName() {
        return this.name;
    }

    public String getType() {
        return this.type;
    }

    public int hashCode() {
        if (this.hashCode == -1) {
            int n = this.className.hashCode();
            int n2 = this.name.hashCode();
            this.hashCode = this.type.hashCode() ^ (n ^ n2);
        }
        return this.hashCode;
    }
}

