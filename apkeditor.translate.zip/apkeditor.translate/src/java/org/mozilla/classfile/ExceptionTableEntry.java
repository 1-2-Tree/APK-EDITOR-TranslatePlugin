/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.mozilla.classfile;

final class ExceptionTableEntry {
    short itsCatchType;
    int itsEndLabel;
    int itsHandlerLabel;
    int itsStartLabel;

    ExceptionTableEntry(int n, int n2, int n3, short s) {
        this.itsStartLabel = n;
        this.itsEndLabel = n2;
        this.itsHandlerLabel = n3;
        this.itsCatchType = s;
    }
}

