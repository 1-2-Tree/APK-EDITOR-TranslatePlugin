/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package org.mozilla.classfile;

import org.mozilla.classfile.ConstantPool;
import org.mozilla.classfile.TypeInfo;

final class SuperBlock {
    private int end;
    private int index;
    private boolean isInQueue;
    private boolean isInitialized;
    private int[] locals;
    private int[] stack;
    private int start;

    SuperBlock(int n, int n2, int n3, int[] arrn) {
        this.index = n;
        this.start = n2;
        this.end = n3;
        this.locals = new int[arrn.length];
        System.arraycopy((Object)arrn, (int)0, (Object)this.locals, (int)0, (int)arrn.length);
        this.stack = new int[0];
        this.isInitialized = false;
        this.isInQueue = false;
    }

    private boolean mergeState(int[] arrn, int[] arrn2, int n, ConstantPool constantPool) {
        boolean bl = false;
        for (int i = 0; i < n; ++i) {
            int n2 = arrn[i];
            arrn[i] = TypeInfo.merge(arrn[i], arrn2[i], constantPool);
            if (n2 == arrn[i]) continue;
            bl = true;
        }
        return bl;
    }

    int getEnd() {
        return this.end;
    }

    int getIndex() {
        return this.index;
    }

    int[] getLocals() {
        int[] arrn = new int[this.locals.length];
        System.arraycopy((Object)this.locals, (int)0, (Object)arrn, (int)0, (int)this.locals.length);
        return arrn;
    }

    int[] getStack() {
        int[] arrn = new int[this.stack.length];
        System.arraycopy((Object)this.stack, (int)0, (Object)arrn, (int)0, (int)this.stack.length);
        return arrn;
    }

    int getStart() {
        return this.start;
    }

    int[] getTrimmedLocals() {
        int n;
        int n2;
        for (n2 = -1 + this.locals.length; n2 >= 0 && this.locals[n2] == 0 && !TypeInfo.isTwoWords(this.locals[n2 - 1]); --n2) {
        }
        int n3 = n = n2 + 1;
        for (int i = 0; i < n; ++i) {
            if (!TypeInfo.isTwoWords(this.locals[i])) continue;
            --n3;
        }
        int[] arrn = new int[n3];
        int n4 = 0;
        int n5 = 0;
        while (n4 < n3) {
            arrn[n4] = this.locals[n5];
            if (TypeInfo.isTwoWords(this.locals[n5])) {
                ++n5;
            }
            ++n4;
            ++n5;
        }
        return arrn;
    }

    boolean isInQueue() {
        return this.isInQueue;
    }

    boolean isInitialized() {
        return this.isInitialized;
    }

    boolean merge(int[] arrn, int n, int[] arrn2, int n2, ConstantPool constantPool) {
        block4 : {
            boolean bl;
            block6 : {
                block5 : {
                    if (!this.isInitialized) {
                        System.arraycopy((Object)arrn, (int)0, (Object)this.locals, (int)0, (int)n);
                        this.stack = new int[n2];
                        System.arraycopy((Object)arrn2, (int)0, (Object)this.stack, (int)0, (int)n2);
                        this.isInitialized = true;
                        return true;
                    }
                    if (this.locals.length != n || this.stack.length != n2) break block4;
                    boolean bl2 = this.mergeState(this.locals, arrn, n, constantPool);
                    boolean bl3 = this.mergeState(this.stack, arrn2, n2, constantPool);
                    if (bl2) break block5;
                    bl = false;
                    if (!bl3) break block6;
                }
                bl = true;
            }
            return bl;
        }
        throw new IllegalArgumentException("bad merge attempt");
    }

    void setInQueue(boolean bl) {
        this.isInQueue = bl;
    }

    void setInitialized(boolean bl) {
        this.isInitialized = bl;
    }

    public String toString() {
        return "sb " + this.index;
    }
}

