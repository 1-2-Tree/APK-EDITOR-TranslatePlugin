/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.PrintStream
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 */
package org.mozilla.classfile;

import java.io.PrintStream;
import org.mozilla.classfile.ClassFileWriter;
import org.mozilla.classfile.ConstantPool;

final class TypeInfo {
    static final int DOUBLE = 3;
    static final int FLOAT = 2;
    static final int INTEGER = 1;
    static final int LONG = 4;
    static final int NULL = 5;
    static final int OBJECT_TAG = 7;
    static final int TOP = 0;
    static final int UNINITIALIZED_THIS = 6;
    static final int UNINITIALIZED_VAR_TAG = 8;

    private TypeInfo() {
    }

    static final int OBJECT(int n) {
        return 7 | (65535 & n) << 8;
    }

    static final int OBJECT(String string2, ConstantPool constantPool) {
        return TypeInfo.OBJECT(constantPool.addClass(string2));
    }

    static final int UNINITIALIZED_VARIABLE(int n) {
        return 8 | (65535 & n) << 8;
    }

    static final int fromType(String string2, ConstantPool constantPool) {
        int n = 1;
        if (string2.length() == n) {
            switch (string2.charAt(0)) {
                default: {
                    throw new IllegalArgumentException("bad type");
                }
                case 'D': {
                    n = 3;
                }
                case 'B': 
                case 'C': 
                case 'I': 
                case 'S': 
                case 'Z': {
                    return n;
                }
                case 'F': {
                    return 2;
                }
                case 'J': 
            }
            return 4;
        }
        return TypeInfo.OBJECT(string2, constantPool);
    }

    static Class<?> getClassFromInternalName(String string2) {
        try {
            Class class_ = Class.forName((String)string2.replace('/', '.'));
            return class_;
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new RuntimeException((Throwable)classNotFoundException);
        }
    }

    static final int getPayload(int n) {
        return n >>> 8;
    }

    static final String getPayloadAsType(int n, ConstantPool constantPool) {
        if (TypeInfo.getTag(n) == 7) {
            return (String)constantPool.getConstantData(TypeInfo.getPayload(n));
        }
        throw new IllegalArgumentException("expecting object type");
    }

    static final int getTag(int n) {
        return n & 255;
    }

    static boolean isTwoWords(int n) {
        return n == 3 || n == 4;
    }

    /*
     * Enabled aggressive block sorting
     */
    static int merge(int n, int n2, ConstantPool constantPool) {
        Class<?> class_;
        Class<?> class_2;
        int n3 = TypeInfo.getTag(n);
        int n4 = TypeInfo.getTag(n2);
        boolean bl = n3 == 7;
        boolean bl2 = n4 == 7;
        if (n == n2) return n;
        if (bl && n2 == 5) {
            return n;
        }
        if (n3 == 0) return 0;
        if (n4 == 0) {
            return 0;
        }
        if (n == 5) {
            if (bl2) return n2;
        }
        if (!bl) throw new IllegalArgumentException("bad merge attempt between " + TypeInfo.toString(n, constantPool) + " and " + TypeInfo.toString(n2, constantPool));
        if (!bl2) throw new IllegalArgumentException("bad merge attempt between " + TypeInfo.toString(n, constantPool) + " and " + TypeInfo.toString(n2, constantPool));
        String string2 = TypeInfo.getPayloadAsType(n, constantPool);
        String string3 = TypeInfo.getPayloadAsType(n2, constantPool);
        String string4 = (String)constantPool.getConstantData(2);
        String string5 = (String)constantPool.getConstantData(4);
        if (string2.equals((Object)string4)) {
            string2 = string5;
        }
        if (string3.equals((Object)string4)) {
            string3 = string5;
        }
        if ((class_2 = TypeInfo.getClassFromInternalName(string2)).isAssignableFrom(class_ = TypeInfo.getClassFromInternalName(string3))) {
            return n;
        }
        if (class_.isAssignableFrom(class_2)) return n2;
        if (class_.isInterface()) return TypeInfo.OBJECT("java/lang/Object", constantPool);
        if (class_2.isInterface()) {
            return TypeInfo.OBJECT("java/lang/Object", constantPool);
        }
        Class class_3 = class_.getSuperclass();
        while (class_3 != null) {
            if (class_3.isAssignableFrom(class_2)) {
                return TypeInfo.OBJECT(ClassFileWriter.getSlashedForm(class_3.getName()), constantPool);
            }
            class_3 = class_3.getSuperclass();
        }
        throw new IllegalArgumentException("bad merge attempt between " + TypeInfo.toString(n, constantPool) + " and " + TypeInfo.toString(n2, constantPool));
    }

    static void print(int[] arrn, int n, int[] arrn2, int n2, ConstantPool constantPool) {
        System.out.print("locals: ");
        System.out.println(TypeInfo.toString(arrn, n, constantPool));
        System.out.print("stack: ");
        System.out.println(TypeInfo.toString(arrn2, n2, constantPool));
        System.out.println();
    }

    static void print(int[] arrn, int[] arrn2, ConstantPool constantPool) {
        TypeInfo.print(arrn, arrn.length, arrn2, arrn2.length, constantPool);
    }

    static String toString(int n, ConstantPool constantPool) {
        int n2 = TypeInfo.getTag(n);
        switch (n2) {
            default: {
                if (n2 != 7) break;
                return TypeInfo.getPayloadAsType(n, constantPool);
            }
            case 0: {
                return "top";
            }
            case 1: {
                return "int";
            }
            case 2: {
                return "float";
            }
            case 3: {
                return "double";
            }
            case 4: {
                return "long";
            }
            case 5: {
                return "null";
            }
            case 6: {
                return "uninitialized_this";
            }
        }
        if (n2 == 8) {
            return "uninitialized";
        }
        throw new IllegalArgumentException("bad type");
    }

    static String toString(int[] arrn, int n, ConstantPool constantPool) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        for (int i = 0; i < n; ++i) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(TypeInfo.toString(arrn[i], constantPool));
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    static String toString(int[] arrn, ConstantPool constantPool) {
        return TypeInfo.toString(arrn, arrn.length, constantPool);
    }
}

