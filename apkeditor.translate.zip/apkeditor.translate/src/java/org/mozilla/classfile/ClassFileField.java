/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.mozilla.classfile;

import org.mozilla.classfile.ClassFileWriter;

final class ClassFileField {
    private short itsAttr1;
    private short itsAttr2;
    private short itsAttr3;
    private short itsFlags;
    private boolean itsHasAttributes;
    private int itsIndex;
    private short itsNameIndex;
    private short itsTypeIndex;

    ClassFileField(short s, short s2, short s3) {
        this.itsNameIndex = s;
        this.itsTypeIndex = s2;
        this.itsFlags = s3;
        this.itsHasAttributes = false;
    }

    int getWriteSize() {
        if (!this.itsHasAttributes) {
            return 6 + 2;
        }
        return 6 + 10;
    }

    void setAttributes(short s, short s2, short s3, int n) {
        this.itsHasAttributes = true;
        this.itsAttr1 = s;
        this.itsAttr2 = s2;
        this.itsAttr3 = s3;
        this.itsIndex = n;
    }

    int write(byte[] arrby, int n) {
        int n2 = ClassFileWriter.putInt16(this.itsFlags, arrby, n);
        int n3 = ClassFileWriter.putInt16(this.itsNameIndex, arrby, n2);
        int n4 = ClassFileWriter.putInt16(this.itsTypeIndex, arrby, n3);
        if (!this.itsHasAttributes) {
            return ClassFileWriter.putInt16(0, arrby, n4);
        }
        int n5 = ClassFileWriter.putInt16(1, arrby, n4);
        int n6 = ClassFileWriter.putInt16(this.itsAttr1, arrby, n5);
        int n7 = ClassFileWriter.putInt16(this.itsAttr2, arrby, n6);
        int n8 = ClassFileWriter.putInt16(this.itsAttr3, arrby, n7);
        return ClassFileWriter.putInt16(this.itsIndex, arrby, n8);
    }
}

