/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.Arrays
 */
package org.mozilla.classfile;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import org.mozilla.classfile.ClassFileField;
import org.mozilla.classfile.ClassFileMethod;
import org.mozilla.classfile.ConstantPool;
import org.mozilla.classfile.ExceptionTableEntry;
import org.mozilla.classfile.FieldOrMethodRef;
import org.mozilla.classfile.SuperBlock;
import org.mozilla.classfile.TypeInfo;
import org.mozilla.javascript.ObjArray;
import org.mozilla.javascript.UintMap;

public class ClassFileWriter {
    public static final short ACC_ABSTRACT = 1024;
    public static final short ACC_FINAL = 16;
    public static final short ACC_NATIVE = 256;
    public static final short ACC_PRIVATE = 2;
    public static final short ACC_PROTECTED = 4;
    public static final short ACC_PUBLIC = 1;
    public static final short ACC_STATIC = 8;
    public static final short ACC_SUPER = 32;
    public static final short ACC_SYNCHRONIZED = 32;
    public static final short ACC_TRANSIENT = 128;
    public static final short ACC_VOLATILE = 64;
    private static final boolean DEBUGCODE = false;
    private static final boolean DEBUGLABELS = false;
    private static final boolean DEBUGSTACK = false;
    private static final int ExceptionTableSize = 4;
    private static final int FileHeaderConstant = -889275714;
    private static final boolean GenerateStackMap = false;
    private static final int LineNumberTableSize = 16;
    private static final int MIN_FIXUP_TABLE_SIZE = 40;
    private static final int MIN_LABEL_TABLE_SIZE = 32;
    private static final int MajorVersion = 0;
    private static final int MinorVersion = 0;
    private static final int SuperBlockStartsSize = 4;
    private String generatedClassName;
    private byte[] itsCodeBuffer = new byte[256];
    private int itsCodeBufferTop;
    private ConstantPool itsConstantPool;
    private ClassFileMethod itsCurrentMethod;
    private ExceptionTableEntry[] itsExceptionTable;
    private int itsExceptionTableTop;
    private ObjArray itsFields = new ObjArray();
    private long[] itsFixupTable;
    private int itsFixupTableTop;
    private short itsFlags;
    private ObjArray itsInterfaces = new ObjArray();
    private UintMap itsJumpFroms = null;
    private int[] itsLabelTable;
    private int itsLabelTableTop;
    private int[] itsLineNumberTable;
    private int itsLineNumberTableTop;
    private short itsMaxLocals;
    private short itsMaxStack;
    private ObjArray itsMethods = new ObjArray();
    private short itsSourceFileNameIndex;
    private short itsStackTop;
    private int[] itsSuperBlockStarts = null;
    private int itsSuperBlockStartsTop = 0;
    private short itsSuperClassIndex;
    private short itsThisClassIndex;
    private ObjArray itsVarDescriptors;
    private char[] tmpCharBuffer = new char[64];

    /*
     * Exception decompiling
     */
    static {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [5[CATCHBLOCK]], but top level block is 7[CATCHBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    public ClassFileWriter(String string2, String string3, String string4) {
        this.generatedClassName = string2;
        this.itsConstantPool = new ConstantPool(this);
        this.itsThisClassIndex = this.itsConstantPool.addClass(string2);
        this.itsSuperClassIndex = this.itsConstantPool.addClass(string3);
        if (string4 != null) {
            this.itsSourceFileNameIndex = this.itsConstantPool.addUtf8(string4);
        }
        this.itsFlags = (short)33;
    }

    static /* synthetic */ int access$1000(String string2) {
        return ClassFileWriter.sizeOfParameters(string2);
    }

    static /* synthetic */ short access$1100(ClassFileWriter classFileWriter) {
        return classFileWriter.itsThisClassIndex;
    }

    static /* synthetic */ String access$1200(String string2) {
        return ClassFileWriter.descriptorToInternalName(string2);
    }

    static /* synthetic */ int access$410(ClassFileWriter classFileWriter) {
        int n = classFileWriter.itsExceptionTableTop;
        classFileWriter.itsExceptionTableTop = n - 1;
        return n;
    }

    static /* synthetic */ char access$900(int n) {
        return ClassFileWriter.arrayTypeToName(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void addLabelFixup(int n, int n2) {
        if (n >= 0) {
            throw new IllegalArgumentException("Bad label, no biscuit");
        }
        int n3 = n & Integer.MAX_VALUE;
        if (n3 >= this.itsLabelTableTop) {
            throw new IllegalArgumentException("Bad label");
        }
        int n4 = this.itsFixupTableTop;
        if (this.itsFixupTable == null || n4 == this.itsFixupTable.length) {
            if (this.itsFixupTable == null) {
                this.itsFixupTable = new long[40];
            } else {
                long[] arrl = new long[2 * this.itsFixupTable.length];
                System.arraycopy((Object)this.itsFixupTable, (int)0, (Object)arrl, (int)0, (int)n4);
                this.itsFixupTable = arrl;
            }
        }
        this.itsFixupTableTop = n4 + 1;
        this.itsFixupTable[n4] = (long)n3 << 32 | (long)n2;
    }

    private int addReservedCodeSpace(int n) {
        if (this.itsCurrentMethod == null) {
            throw new IllegalArgumentException("No method to add to");
        }
        int n2 = this.itsCodeBufferTop;
        int n3 = n2 + n;
        if (n3 > this.itsCodeBuffer.length) {
            int n4 = 2 * this.itsCodeBuffer.length;
            if (n3 > n4) {
                n4 = n3;
            }
            byte[] arrby = new byte[n4];
            System.arraycopy((Object)this.itsCodeBuffer, (int)0, (Object)arrby, (int)0, (int)n2);
            this.itsCodeBuffer = arrby;
        }
        this.itsCodeBufferTop = n3;
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void addSuperBlockStart(int n) {
        if (GenerateStackMap) {
            if (this.itsSuperBlockStarts == null) {
                this.itsSuperBlockStarts = new int[4];
            } else if (this.itsSuperBlockStarts.length == this.itsSuperBlockStartsTop) {
                int[] arrn = new int[2 * this.itsSuperBlockStartsTop];
                System.arraycopy((Object)this.itsSuperBlockStarts, (int)0, (Object)arrn, (int)0, (int)this.itsSuperBlockStartsTop);
                this.itsSuperBlockStarts = arrn;
            }
            int[] arrn = this.itsSuperBlockStarts;
            int n2 = this.itsSuperBlockStartsTop;
            this.itsSuperBlockStartsTop = n2 + 1;
            arrn[n2] = n;
        }
    }

    private void addToCodeBuffer(int n) {
        int n2 = this.addReservedCodeSpace(1);
        this.itsCodeBuffer[n2] = (byte)n;
    }

    private void addToCodeInt16(int n) {
        int n2 = this.addReservedCodeSpace(2);
        ClassFileWriter.putInt16(n, this.itsCodeBuffer, n2);
    }

    private static char arrayTypeToName(int n) {
        switch (n) {
            default: {
                throw new IllegalArgumentException("bad operand");
            }
            case 4: {
                return 'Z';
            }
            case 5: {
                return 'C';
            }
            case 6: {
                return 'F';
            }
            case 7: {
                return 'D';
            }
            case 8: {
                return 'B';
            }
            case 9: {
                return 'S';
            }
            case 10: {
                return 'I';
            }
            case 11: 
        }
        return 'J';
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void badStack(int n) {
        String string2;
        if (n < 0) {
            string2 = "Stack underflow: " + n;
            do {
                throw new IllegalStateException(string2);
                break;
            } while (true);
        }
        string2 = "Too big stack: " + n;
        throw new IllegalStateException(string2);
    }

    private static String bytecodeStr(int n) {
        return "";
    }

    private static String classDescriptorToInternalName(String string2) {
        return string2.substring(1, -1 + string2.length());
    }

    public static String classNameToSignature(String string2) {
        int n = string2.length();
        int n2 = n + 1;
        char[] arrc = new char[n2 + 1];
        arrc[0] = 76;
        arrc[n2] = 59;
        string2.getChars(0, n, arrc, 1);
        for (int i = 1; i != n2; ++i) {
            if (arrc[i] != '.') continue;
            arrc[i] = 47;
        }
        return new String(arrc, 0, n2 + 1);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private int[] createInitialLocals() {
        var1_1 = new int[this.itsMaxLocals];
        var2_2 = 8 & this.itsCurrentMethod.getFlags();
        var3_3 = 0;
        if (var2_2 == 0) {
            if ("<init>".equals((Object)this.itsCurrentMethod.getName())) {
                var17_4 = 0 + 1;
                var1_1[0] = 6;
                var3_3 = var17_4;
            } else {
                var16_5 = 0 + 1;
                var1_1[0] = TypeInfo.OBJECT(this.itsThisClassIndex);
                var3_3 = var16_5;
            }
        }
        var4_6 = this.itsCurrentMethod.getType();
        var5_7 = var4_6.indexOf(40);
        var6_8 = var4_6.indexOf(41);
        if (var5_7 != 0) throw new IllegalArgumentException("bad method type");
        if (var6_8 < 0) {
            throw new IllegalArgumentException("bad method type");
        }
        var7_9 = var5_7 + 1;
        var8_10 = new StringBuilder();
        var9_11 = var3_3;
        block5 : while (var7_9 < var6_8) {
            switch (var4_6.charAt(var7_9)) {
                case 'B': 
                case 'C': 
                case 'D': 
                case 'F': 
                case 'I': 
                case 'J': 
                case 'S': 
                case 'Z': {
                    var8_10.append(var4_6.charAt(var7_9));
                    ++var7_9;
                    ** break;
                }
                case 'L': {
                    var11_12 = 1 + var4_6.indexOf(59, var7_9);
                    var8_10.append(var4_6.substring(var7_9, var11_12));
                    var7_9 = var11_12;
                }
lbl32: // 3 sources:
                default: {
                    var13_13 = TypeInfo.fromType(ClassFileWriter.descriptorToInternalName(var8_10.toString()), this.itsConstantPool);
                    var14_14 = var9_11 + 1;
                    var1_1[var9_11] = var13_13;
                    if (TypeInfo.isTwoWords(var13_13)) {
                        // empty if block
                    }
                    var8_10.setLength(0);
                    var9_11 = ++var14_14;
                    continue block5;
                }
                case '[': 
            }
            var8_10.append('[');
            ++var7_9;
        }
        return var1_1;
    }

    private static String descriptorToInternalName(String string2) {
        switch (string2.charAt(0)) {
            default: {
                throw new IllegalArgumentException("bad descriptor:" + string2);
            }
            case 'L': {
                string2 = ClassFileWriter.classDescriptorToInternalName(string2);
            }
            case 'B': 
            case 'C': 
            case 'D': 
            case 'F': 
            case 'I': 
            case 'J': 
            case 'S': 
            case 'V': 
            case 'Z': 
            case '[': 
        }
        return string2;
    }

    private void finalizeSuperBlockStarts() {
        if (GenerateStackMap) {
            for (int i = 0; i < this.itsExceptionTableTop; ++i) {
                this.addSuperBlockStart((short)this.getLabelPC(this.itsExceptionTable[i].itsHandlerLabel));
            }
            Arrays.sort((int[])this.itsSuperBlockStarts, (int)0, (int)this.itsSuperBlockStartsTop);
            int n = this.itsSuperBlockStarts[0];
            int n2 = 1;
            for (int i = 1; i < this.itsSuperBlockStartsTop; ++i) {
                int n3 = this.itsSuperBlockStarts[i];
                if (n == n3) continue;
                if (n2 != i) {
                    this.itsSuperBlockStarts[n2] = n3;
                }
                ++n2;
                n = n3;
            }
            this.itsSuperBlockStartsTop = n2;
            if (this.itsSuperBlockStarts[n2 - 1] == this.itsCodeBufferTop) {
                this.itsSuperBlockStartsTop = -1 + this.itsSuperBlockStartsTop;
            }
        }
    }

    private void fixLabelGotos() {
        byte[] arrby = this.itsCodeBuffer;
        for (int i = 0; i < this.itsFixupTableTop; ++i) {
            long l = this.itsFixupTable[i];
            int n = (int)(l >> 32);
            int n2 = (int)l;
            int n3 = this.itsLabelTable[n];
            if (n3 == -1) {
                throw new RuntimeException();
            }
            this.addSuperBlockStart(n3);
            this.itsJumpFroms.put(n3, n2 - 1);
            int n4 = n3 - (n2 - 1);
            if ((short)n4 != n4) {
                throw new ClassFileFormatException("Program too complex: too big jump offset");
            }
            arrby[n2] = (byte)(n4 >> 8);
            arrby[n2 + 1] = (byte)n4;
        }
        this.itsFixupTableTop = 0;
    }

    static String getSlashedForm(String string2) {
        return string2.replace('.', '/');
    }

    private int getWriteSize() {
        if (this.itsSourceFileNameIndex != 0) {
            this.itsConstantPool.addUtf8("SourceFile");
        }
        0 + 8;
        int n = 2 + (2 + (2 + (2 + (2 + (8 + this.itsConstantPool.getWriteSize())))) + 2 * this.itsInterfaces.size());
        for (int i = 0; i < this.itsFields.size(); ++i) {
            n += ((ClassFileField)this.itsFields.get(i)).getWriteSize();
        }
        int n2 = n + 2;
        for (int i = 0; i < this.itsMethods.size(); ++i) {
            n2 += ((ClassFileMethod)this.itsMethods.get(i)).getWriteSize();
        }
        if (this.itsSourceFileNameIndex != 0) {
            return 2 + (4 + (2 + (n2 + 2)));
        }
        return n2 + 2;
    }

    static int opcodeCount(int n) {
        switch (n) {
            default: {
                throw new IllegalArgumentException("Bad opcode: " + n);
            }
            case 0: 
            case 1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 12: 
            case 13: 
            case 14: 
            case 15: 
            case 26: 
            case 27: 
            case 28: 
            case 29: 
            case 30: 
            case 31: 
            case 32: 
            case 33: 
            case 34: 
            case 35: 
            case 36: 
            case 37: 
            case 38: 
            case 39: 
            case 40: 
            case 41: 
            case 42: 
            case 43: 
            case 44: 
            case 45: 
            case 46: 
            case 47: 
            case 48: 
            case 49: 
            case 50: 
            case 51: 
            case 52: 
            case 53: 
            case 59: 
            case 60: 
            case 61: 
            case 62: 
            case 63: 
            case 64: 
            case 65: 
            case 66: 
            case 67: 
            case 68: 
            case 69: 
            case 70: 
            case 71: 
            case 72: 
            case 73: 
            case 74: 
            case 75: 
            case 76: 
            case 77: 
            case 78: 
            case 79: 
            case 80: 
            case 81: 
            case 82: 
            case 83: 
            case 84: 
            case 85: 
            case 86: 
            case 87: 
            case 88: 
            case 89: 
            case 90: 
            case 91: 
            case 92: 
            case 93: 
            case 94: 
            case 95: 
            case 96: 
            case 97: 
            case 98: 
            case 99: 
            case 100: 
            case 101: 
            case 102: 
            case 103: 
            case 104: 
            case 105: 
            case 106: 
            case 107: 
            case 108: 
            case 109: 
            case 110: 
            case 111: 
            case 112: 
            case 113: 
            case 114: 
            case 115: 
            case 116: 
            case 117: 
            case 118: 
            case 119: 
            case 120: 
            case 121: 
            case 122: 
            case 123: 
            case 124: 
            case 125: 
            case 126: 
            case 127: 
            case 128: 
            case 129: 
            case 130: 
            case 131: 
            case 133: 
            case 134: 
            case 135: 
            case 136: 
            case 137: 
            case 138: 
            case 139: 
            case 140: 
            case 141: 
            case 142: 
            case 143: 
            case 144: 
            case 145: 
            case 146: 
            case 147: 
            case 148: 
            case 149: 
            case 150: 
            case 151: 
            case 152: 
            case 172: 
            case 173: 
            case 174: 
            case 175: 
            case 176: 
            case 177: 
            case 190: 
            case 191: 
            case 194: 
            case 195: 
            case 196: 
            case 202: 
            case 254: 
            case 255: {
                return 0;
            }
            case 16: 
            case 17: 
            case 18: 
            case 19: 
            case 20: 
            case 21: 
            case 22: 
            case 23: 
            case 24: 
            case 25: 
            case 54: 
            case 55: 
            case 56: 
            case 57: 
            case 58: 
            case 153: 
            case 154: 
            case 155: 
            case 156: 
            case 157: 
            case 158: 
            case 159: 
            case 160: 
            case 161: 
            case 162: 
            case 163: 
            case 164: 
            case 165: 
            case 166: 
            case 167: 
            case 168: 
            case 169: 
            case 178: 
            case 179: 
            case 180: 
            case 181: 
            case 182: 
            case 183: 
            case 184: 
            case 185: 
            case 187: 
            case 188: 
            case 189: 
            case 192: 
            case 193: 
            case 198: 
            case 199: 
            case 200: 
            case 201: {
                return 1;
            }
            case 132: 
            case 197: {
                return 2;
            }
            case 170: 
            case 171: 
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static int opcodeLength(int n, boolean bl) {
        int n2 = 3;
        switch (n) {
            default: {
                throw new IllegalArgumentException("Bad opcode: " + n);
            }
            case 0: 
            case 1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 12: 
            case 13: 
            case 14: 
            case 15: 
            case 26: 
            case 27: 
            case 28: 
            case 29: 
            case 30: 
            case 31: 
            case 32: 
            case 33: 
            case 34: 
            case 35: 
            case 36: 
            case 37: 
            case 38: 
            case 39: 
            case 40: 
            case 41: 
            case 42: 
            case 43: 
            case 44: 
            case 45: 
            case 46: 
            case 47: 
            case 48: 
            case 49: 
            case 50: 
            case 51: 
            case 52: 
            case 53: 
            case 59: 
            case 60: 
            case 61: 
            case 62: 
            case 63: 
            case 64: 
            case 65: 
            case 66: 
            case 67: 
            case 68: 
            case 69: 
            case 70: 
            case 71: 
            case 72: 
            case 73: 
            case 74: 
            case 75: 
            case 76: 
            case 77: 
            case 78: 
            case 79: 
            case 80: 
            case 81: 
            case 82: 
            case 83: 
            case 84: 
            case 85: 
            case 86: 
            case 87: 
            case 88: 
            case 89: 
            case 90: 
            case 91: 
            case 92: 
            case 93: 
            case 94: 
            case 95: 
            case 96: 
            case 97: 
            case 98: 
            case 99: 
            case 100: 
            case 101: 
            case 102: 
            case 103: 
            case 104: 
            case 105: 
            case 106: 
            case 107: 
            case 108: 
            case 109: 
            case 110: 
            case 111: 
            case 112: 
            case 113: 
            case 114: 
            case 115: 
            case 116: 
            case 117: 
            case 118: 
            case 119: 
            case 120: 
            case 121: 
            case 122: 
            case 123: 
            case 124: 
            case 125: 
            case 126: 
            case 127: 
            case 128: 
            case 129: 
            case 130: 
            case 131: 
            case 133: 
            case 134: 
            case 135: 
            case 136: 
            case 137: 
            case 138: 
            case 139: 
            case 140: 
            case 141: 
            case 142: 
            case 143: 
            case 144: 
            case 145: 
            case 146: 
            case 147: 
            case 148: 
            case 149: 
            case 150: 
            case 151: 
            case 152: 
            case 172: 
            case 173: 
            case 174: 
            case 175: 
            case 176: 
            case 177: 
            case 190: 
            case 191: 
            case 194: 
            case 195: 
            case 196: 
            case 202: 
            case 254: 
            case 255: {
                n2 = 1;
            }
            case 17: 
            case 19: 
            case 20: 
            case 153: 
            case 154: 
            case 155: 
            case 156: 
            case 157: 
            case 158: 
            case 159: 
            case 160: 
            case 161: 
            case 162: 
            case 163: 
            case 164: 
            case 165: 
            case 166: 
            case 167: 
            case 168: 
            case 178: 
            case 179: 
            case 180: 
            case 181: 
            case 182: 
            case 183: 
            case 184: 
            case 187: 
            case 189: 
            case 192: 
            case 193: 
            case 198: 
            case 199: {
                return n2;
            }
            case 16: 
            case 18: 
            case 188: {
                return 2;
            }
            case 21: 
            case 22: 
            case 23: 
            case 24: 
            case 25: 
            case 54: 
            case 55: 
            case 56: 
            case 57: 
            case 58: 
            case 169: {
                if (bl) return n2;
                return 2;
            }
            case 132: {
                if (!bl) return n2;
                return 5;
            }
            case 197: {
                return 4;
            }
            case 185: 
            case 200: 
            case 201: 
        }
        return 5;
    }

    static int putInt16(int n, byte[] arrby, int n2) {
        arrby[n2 + 0] = (byte)(n >>> 8);
        arrby[n2 + 1] = (byte)n;
        return n2 + 2;
    }

    static int putInt32(int n, byte[] arrby, int n2) {
        arrby[n2 + 0] = (byte)(n >>> 24);
        arrby[n2 + 1] = (byte)(n >>> 16);
        arrby[n2 + 2] = (byte)(n >>> 8);
        arrby[n2 + 3] = (byte)n;
        return n2 + 4;
    }

    static int putInt64(long l, byte[] arrby, int n) {
        int n2 = ClassFileWriter.putInt32((int)(l >>> 32), arrby, n);
        return ClassFileWriter.putInt32((int)l, arrby, n2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int sizeOfParameters(String var0) {
        var1_1 = var0.length();
        var2_2 = var0.lastIndexOf(41);
        if (3 > var1_1) throw new IllegalArgumentException("Bad parameter signature: " + var0);
        if (var0.charAt(0) != '(') throw new IllegalArgumentException("Bad parameter signature: " + var0);
        if (1 > var2_2) throw new IllegalArgumentException("Bad parameter signature: " + var0);
        if (var2_2 + 1 >= var1_1) throw new IllegalArgumentException("Bad parameter signature: " + var0);
        var3_3 = true;
        var4_4 = 1;
        var5_5 = 0;
        var6_6 = 0;
        block15 : while (var4_4 != var2_2) {
            switch (var0.charAt(var4_4)) {
                default: {
                    var3_3 = false;
                    break block15;
                }
                case 'D': 
                case 'J': {
                    --var5_5;
                }
                case 'B': 
                case 'C': 
                case 'F': 
                case 'I': 
                case 'S': 
                case 'Z': {
                    --var5_5;
                    ++var6_6;
                    ++var4_4;
                    ** break;
                }
                case '[': {
                    var9_9 = var0.charAt(++var4_4);
                    while (var9_9 == '[') {
                        var9_9 = var0.charAt(++var4_4);
                    }
                    switch (var9_9) {
                        default: {
                            var3_3 = false;
                            break block15;
                        }
                        case 'B': 
                        case 'C': 
                        case 'D': 
                        case 'F': 
                        case 'I': 
                        case 'J': 
                        case 'S': 
                        case 'Z': {
                            --var5_5;
                            ++var6_6;
                            ++var4_4;
                            ** break;
                        }
                        case 'L': 
                    }
                }
                case 'L': {
                    --var5_5;
                    ++var6_6;
                    var7_7 = var4_4 + 1;
                    var8_8 = var0.indexOf(59, var7_7);
                    if (var7_7 + 1 > var8_8 || var8_8 >= var2_2) {
                        var3_3 = false;
                        break block15;
                    }
                    var4_4 = var8_8 + 1;
                    ** break;
lbl48: // 3 sources:
                    continue block15;
                }
            }
        }
        if (var3_3 == false) throw new IllegalArgumentException("Bad parameter signature: " + var0);
        switch (var0.charAt(var2_2 + 1)) {
            default: {
                var3_3 = false;
                break;
            }
            case 'D': 
            case 'J': {
                ++var5_5;
            }
            case 'B': 
            case 'C': 
            case 'F': 
            case 'I': 
            case 'L': 
            case 'S': 
            case 'Z': 
            case '[': {
                ++var5_5;
            }
            case 'V': 
        }
        if (var3_3 == false) throw new IllegalArgumentException("Bad parameter signature: " + var0);
        return var6_6 << 16 | 65535 & var5_5;
    }

    static int stackChange(int n) {
        switch (n) {
            default: {
                throw new IllegalArgumentException("Bad opcode: " + n);
            }
            case 80: 
            case 82: {
                return -4;
            }
            case 79: 
            case 81: 
            case 83: 
            case 84: 
            case 85: 
            case 86: 
            case 148: 
            case 151: 
            case 152: {
                return -3;
            }
            case 55: 
            case 57: 
            case 63: 
            case 64: 
            case 65: 
            case 66: 
            case 71: 
            case 72: 
            case 73: 
            case 74: 
            case 88: 
            case 97: 
            case 99: 
            case 101: 
            case 103: 
            case 105: 
            case 107: 
            case 109: 
            case 111: 
            case 113: 
            case 115: 
            case 127: 
            case 129: 
            case 131: 
            case 159: 
            case 160: 
            case 161: 
            case 162: 
            case 163: 
            case 164: 
            case 165: 
            case 166: 
            case 173: 
            case 175: {
                return -2;
            }
            case 46: 
            case 48: 
            case 50: 
            case 51: 
            case 52: 
            case 53: 
            case 54: 
            case 56: 
            case 58: 
            case 59: 
            case 60: 
            case 61: 
            case 62: 
            case 67: 
            case 68: 
            case 69: 
            case 70: 
            case 75: 
            case 76: 
            case 77: 
            case 78: 
            case 87: 
            case 96: 
            case 98: 
            case 100: 
            case 102: 
            case 104: 
            case 106: 
            case 108: 
            case 110: 
            case 112: 
            case 114: 
            case 120: 
            case 121: 
            case 122: 
            case 123: 
            case 124: 
            case 125: 
            case 126: 
            case 128: 
            case 130: 
            case 136: 
            case 137: 
            case 142: 
            case 144: 
            case 149: 
            case 150: 
            case 153: 
            case 154: 
            case 155: 
            case 156: 
            case 157: 
            case 158: 
            case 170: 
            case 171: 
            case 172: 
            case 174: 
            case 176: 
            case 180: 
            case 181: 
            case 182: 
            case 183: 
            case 185: 
            case 191: 
            case 194: 
            case 195: 
            case 198: 
            case 199: {
                return -1;
            }
            case 0: 
            case 47: 
            case 49: 
            case 95: 
            case 116: 
            case 117: 
            case 118: 
            case 119: 
            case 132: 
            case 134: 
            case 138: 
            case 139: 
            case 143: 
            case 145: 
            case 146: 
            case 147: 
            case 167: 
            case 169: 
            case 177: 
            case 178: 
            case 179: 
            case 184: 
            case 188: 
            case 189: 
            case 190: 
            case 192: 
            case 193: 
            case 196: 
            case 200: 
            case 202: 
            case 254: 
            case 255: {
                return 0;
            }
            case 1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: 
            case 11: 
            case 12: 
            case 13: 
            case 16: 
            case 17: 
            case 18: 
            case 19: 
            case 21: 
            case 23: 
            case 25: 
            case 26: 
            case 27: 
            case 28: 
            case 29: 
            case 34: 
            case 35: 
            case 36: 
            case 37: 
            case 42: 
            case 43: 
            case 44: 
            case 45: 
            case 89: 
            case 90: 
            case 91: 
            case 133: 
            case 135: 
            case 140: 
            case 141: 
            case 168: 
            case 187: 
            case 197: 
            case 201: {
                return 1;
            }
            case 9: 
            case 10: 
            case 14: 
            case 15: 
            case 20: 
            case 22: 
            case 24: 
            case 30: 
            case 31: 
            case 32: 
            case 33: 
            case 38: 
            case 39: 
            case 40: 
            case 41: 
            case 92: 
            case 93: 
            case 94: 
        }
        return 2;
    }

    private void xop(int n, int n2, int n3) {
        switch (n3) {
            default: {
                this.add(n2, n3);
                return;
            }
            case 0: {
                this.add(n);
                return;
            }
            case 1: {
                this.add(n + 1);
                return;
            }
            case 2: {
                this.add(n + 2);
                return;
            }
            case 3: 
        }
        this.add(n + 3);
    }

    /*
     * Enabled aggressive block sorting
     */
    public int acquireLabel() {
        int n = this.itsLabelTableTop;
        if (this.itsLabelTable == null || n == this.itsLabelTable.length) {
            if (this.itsLabelTable == null) {
                this.itsLabelTable = new int[32];
            } else {
                int[] arrn = new int[2 * this.itsLabelTable.length];
                System.arraycopy((Object)this.itsLabelTable, (int)0, (Object)arrn, (int)0, (int)n);
                this.itsLabelTable = arrn;
            }
        }
        this.itsLabelTableTop = n + 1;
        this.itsLabelTable[n] = -1;
        return Integer.MIN_VALUE | n;
    }

    public void add(int n) {
        if (ClassFileWriter.opcodeCount(n) != 0) {
            throw new IllegalArgumentException("Unexpected operands");
        }
        int n2 = this.itsStackTop + ClassFileWriter.stackChange(n);
        if (n2 < 0 || 32767 < n2) {
            ClassFileWriter.badStack(n2);
        }
        this.addToCodeBuffer(n);
        this.itsStackTop = (short)n2;
        if (n2 > this.itsMaxStack) {
            this.itsMaxStack = (short)n2;
        }
        if (n == 191) {
            this.addSuperBlockStart(this.itsCodeBufferTop);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void add(int n, int n2) {
        int n3 = this.itsStackTop + ClassFileWriter.stackChange(n);
        if (n3 < 0 || 32767 < n3) {
            ClassFileWriter.badStack(n3);
        }
        switch (n) {
            default: {
                throw new IllegalArgumentException("Unexpected opcode for 1 operand");
            }
            case 167: {
                this.addSuperBlockStart(3 + this.itsCodeBufferTop);
            }
            case 153: 
            case 154: 
            case 155: 
            case 156: 
            case 157: 
            case 158: 
            case 159: 
            case 160: 
            case 161: 
            case 162: 
            case 163: 
            case 164: 
            case 165: 
            case 166: 
            case 168: 
            case 198: 
            case 199: {
                if ((n2 & Integer.MIN_VALUE) != Integer.MIN_VALUE && (n2 < 0 || n2 > 65535)) {
                    throw new IllegalArgumentException("Bad label for branch");
                }
                int n4 = this.itsCodeBufferTop;
                this.addToCodeBuffer(n);
                if ((n2 & Integer.MIN_VALUE) != Integer.MIN_VALUE) {
                    this.addToCodeInt16(n2);
                    int n5 = n2 + n4;
                    this.addSuperBlockStart(n5);
                    this.itsJumpFroms.put(n5, n4);
                    break;
                }
                int n6 = this.getLabelPC(n2);
                if (n6 != -1) {
                    this.addToCodeInt16(n6 - n4);
                    this.addSuperBlockStart(n6);
                    this.itsJumpFroms.put(n6, n4);
                    break;
                }
                this.addLabelFixup(n2, n4 + 1);
                this.addToCodeInt16(0);
                break;
            }
            case 16: {
                if ((byte)n2 != n2) {
                    throw new IllegalArgumentException("out of range byte");
                }
                this.addToCodeBuffer(n);
                this.addToCodeBuffer((byte)n2);
                break;
            }
            case 17: {
                if ((short)n2 != n2) {
                    throw new IllegalArgumentException("out of range short");
                }
                this.addToCodeBuffer(n);
                this.addToCodeInt16(n2);
                break;
            }
            case 188: {
                if (n2 < 0 || n2 >= 256) {
                    throw new IllegalArgumentException("out of range index");
                }
                this.addToCodeBuffer(n);
                this.addToCodeBuffer(n2);
                break;
            }
            case 180: 
            case 181: {
                if (n2 < 0 || n2 >= 65536) {
                    throw new IllegalArgumentException("out of range field");
                }
                this.addToCodeBuffer(n);
                this.addToCodeInt16(n2);
                break;
            }
            case 18: 
            case 19: 
            case 20: {
                if (n2 < 0 || n2 >= 65536) {
                    throw new IllegalArgumentException("out of range index");
                }
                if (n2 >= 256 || n == 19 || n == 20) {
                    if (n == 18) {
                        this.addToCodeBuffer(19);
                    } else {
                        this.addToCodeBuffer(n);
                    }
                    this.addToCodeInt16(n2);
                    break;
                }
                this.addToCodeBuffer(n);
                this.addToCodeBuffer(n2);
                break;
            }
            case 21: 
            case 22: 
            case 23: 
            case 24: 
            case 25: 
            case 54: 
            case 55: 
            case 56: 
            case 57: 
            case 58: 
            case 169: {
                if (n2 < 0 || n2 >= 65536) {
                    throw new ClassFileFormatException("out of range variable");
                }
                if (n2 >= 256) {
                    this.addToCodeBuffer(196);
                    this.addToCodeBuffer(n);
                    this.addToCodeInt16(n2);
                    break;
                }
                this.addToCodeBuffer(n);
                this.addToCodeBuffer(n2);
            }
        }
        this.itsStackTop = (short)n3;
        if (n3 > this.itsMaxStack) {
            this.itsMaxStack = (short)n3;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void add(int n, int n2, int n3) {
        int n4 = this.itsStackTop + ClassFileWriter.stackChange(n);
        if (n4 < 0 || 32767 < n4) {
            ClassFileWriter.badStack(n4);
        }
        if (n == 132) {
            if (n2 < 0 || n2 >= 65536) {
                throw new ClassFileFormatException("out of range variable");
            }
            if (n3 < 0 || n3 >= 65536) {
                throw new ClassFileFormatException("out of range increment");
            }
            if (n2 > 255 || n3 < -128 || n3 > 127) {
                this.addToCodeBuffer(196);
                this.addToCodeBuffer(132);
                this.addToCodeInt16(n2);
                this.addToCodeInt16(n3);
            } else {
                this.addToCodeBuffer(132);
                this.addToCodeBuffer(n2);
                this.addToCodeBuffer(n3);
            }
        } else {
            if (n != 197) {
                throw new IllegalArgumentException("Unexpected opcode for 2 operands");
            }
            if (n2 < 0 || n2 >= 65536) {
                throw new IllegalArgumentException("out of range index");
            }
            if (n3 < 0 || n3 >= 256) {
                throw new IllegalArgumentException("out of range dimensions");
            }
            this.addToCodeBuffer(197);
            this.addToCodeInt16(n2);
            this.addToCodeBuffer(n3);
        }
        this.itsStackTop = (short)n4;
        if (n4 > this.itsMaxStack) {
            this.itsMaxStack = (short)n4;
        }
    }

    public void add(int n, String string2) {
        int n2 = this.itsStackTop + ClassFileWriter.stackChange(n);
        if (n2 < 0 || 32767 < n2) {
            ClassFileWriter.badStack(n2);
        }
        switch (n) {
            default: {
                throw new IllegalArgumentException("bad opcode for class reference");
            }
            case 187: 
            case 189: 
            case 192: 
            case 193: 
        }
        short s = this.itsConstantPool.addClass(string2);
        this.addToCodeBuffer(n);
        this.addToCodeInt16(s);
        this.itsStackTop = (short)n2;
        if (n2 > this.itsMaxStack) {
            this.itsMaxStack = (short)n2;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void add(int n, String string2, String string3, String string4) {
        int n2;
        int n3 = this.itsStackTop + ClassFileWriter.stackChange(n);
        char c = string4.charAt(0);
        int n4 = c == 'J' || c == 'D' ? 2 : 1;
        switch (n) {
            default: {
                throw new IllegalArgumentException("bad opcode for field reference");
            }
            case 178: 
            case 180: {
                n2 = n3 + n4;
                break;
            }
            case 179: 
            case 181: {
                n2 = n3 - n4;
            }
        }
        if (n2 < 0 || 32767 < n2) {
            ClassFileWriter.badStack(n2);
        }
        short s = this.itsConstantPool.addFieldRef(string2, string3, string4);
        this.addToCodeBuffer(n);
        this.addToCodeInt16(s);
        this.itsStackTop = (short)n2;
        if (n2 > this.itsMaxStack) {
            this.itsMaxStack = (short)n2;
        }
    }

    public void addALoad(int n) {
        this.xop(42, 25, n);
    }

    public void addAStore(int n) {
        this.xop(75, 58, n);
    }

    public void addDLoad(int n) {
        this.xop(38, 24, n);
    }

    public void addDStore(int n) {
        this.xop(71, 57, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void addExceptionHandler(int n, int n2, int n3, String string2) {
        if ((n & Integer.MIN_VALUE) != Integer.MIN_VALUE) {
            throw new IllegalArgumentException("Bad startLabel");
        }
        if ((n2 & Integer.MIN_VALUE) != Integer.MIN_VALUE) {
            throw new IllegalArgumentException("Bad endLabel");
        }
        if ((n3 & Integer.MIN_VALUE) != Integer.MIN_VALUE) {
            throw new IllegalArgumentException("Bad handlerLabel");
        }
        short s = string2 == null ? (short)0 : this.itsConstantPool.addClass(string2);
        ExceptionTableEntry exceptionTableEntry = new ExceptionTableEntry(n, n2, n3, s);
        int n4 = this.itsExceptionTableTop;
        if (n4 == 0) {
            this.itsExceptionTable = new ExceptionTableEntry[4];
        } else if (n4 == this.itsExceptionTable.length) {
            ExceptionTableEntry[] arrexceptionTableEntry = new ExceptionTableEntry[n4 * 2];
            System.arraycopy((Object)this.itsExceptionTable, (int)0, (Object)arrexceptionTableEntry, (int)0, (int)n4);
            this.itsExceptionTable = arrexceptionTableEntry;
        }
        this.itsExceptionTable[n4] = exceptionTableEntry;
        this.itsExceptionTableTop = n4 + 1;
    }

    public void addFLoad(int n) {
        this.xop(34, 23, n);
    }

    public void addFStore(int n) {
        this.xop(67, 56, n);
    }

    public void addField(String string2, String string3, short s) {
        short s2 = this.itsConstantPool.addUtf8(string2);
        short s3 = this.itsConstantPool.addUtf8(string3);
        this.itsFields.add(new ClassFileField(s2, s3, s));
    }

    public void addField(String string2, String string3, short s, double d) {
        ClassFileField classFileField = new ClassFileField(this.itsConstantPool.addUtf8(string2), this.itsConstantPool.addUtf8(string3), s);
        classFileField.setAttributes(this.itsConstantPool.addUtf8("ConstantValue"), (short)0, (short)2, this.itsConstantPool.addConstant(d));
        this.itsFields.add(classFileField);
    }

    public void addField(String string2, String string3, short s, int n) {
        ClassFileField classFileField = new ClassFileField(this.itsConstantPool.addUtf8(string2), this.itsConstantPool.addUtf8(string3), s);
        classFileField.setAttributes(this.itsConstantPool.addUtf8("ConstantValue"), (short)0, (short)0, this.itsConstantPool.addConstant(n));
        this.itsFields.add(classFileField);
    }

    public void addField(String string2, String string3, short s, long l) {
        ClassFileField classFileField = new ClassFileField(this.itsConstantPool.addUtf8(string2), this.itsConstantPool.addUtf8(string3), s);
        classFileField.setAttributes(this.itsConstantPool.addUtf8("ConstantValue"), (short)0, (short)2, this.itsConstantPool.addConstant(l));
        this.itsFields.add(classFileField);
    }

    public void addILoad(int n) {
        this.xop(26, 21, n);
    }

    public void addIStore(int n) {
        this.xop(59, 54, n);
    }

    public void addInterface(String string2) {
        short s = this.itsConstantPool.addClass(string2);
        this.itsInterfaces.add(s);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void addInvoke(int n, String string2, String string3, String string4) {
        int n2 = ClassFileWriter.sizeOfParameters(string4);
        int n3 = n2 >>> 16;
        int n4 = (short)n2 + this.itsStackTop + ClassFileWriter.stackChange(n);
        if (n4 < 0 || 32767 < n4) {
            ClassFileWriter.badStack(n4);
        }
        switch (n) {
            default: {
                throw new IllegalArgumentException("bad opcode for method reference");
            }
            case 182: 
            case 183: 
            case 184: 
            case 185: 
        }
        this.addToCodeBuffer(n);
        if (n == 185) {
            this.addToCodeInt16(this.itsConstantPool.addInterfaceMethodRef(string2, string3, string4));
            this.addToCodeBuffer(n3 + 1);
            this.addToCodeBuffer(0);
        } else {
            this.addToCodeInt16(this.itsConstantPool.addMethodRef(string2, string3, string4));
        }
        this.itsStackTop = (short)n4;
        if (n4 > this.itsMaxStack) {
            this.itsMaxStack = (short)n4;
        }
    }

    public void addLLoad(int n) {
        this.xop(30, 22, n);
    }

    public void addLStore(int n) {
        this.xop(63, 55, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void addLineNumberEntry(short s) {
        if (this.itsCurrentMethod == null) {
            throw new IllegalArgumentException("No method to stop");
        }
        int n = this.itsLineNumberTableTop;
        if (n == 0) {
            this.itsLineNumberTable = new int[16];
        } else if (n == this.itsLineNumberTable.length) {
            int[] arrn = new int[n * 2];
            System.arraycopy((Object)this.itsLineNumberTable, (int)0, (Object)arrn, (int)0, (int)n);
            this.itsLineNumberTable = arrn;
        }
        this.itsLineNumberTable[n] = s + (this.itsCodeBufferTop << 16);
        this.itsLineNumberTableTop = n + 1;
    }

    public void addLoadConstant(double d) {
        this.add(20, this.itsConstantPool.addConstant(d));
    }

    public void addLoadConstant(float f) {
        this.add(18, this.itsConstantPool.addConstant(f));
    }

    public void addLoadConstant(int n) {
        switch (n) {
            default: {
                this.add(18, this.itsConstantPool.addConstant(n));
                return;
            }
            case 0: {
                this.add(3);
                return;
            }
            case 1: {
                this.add(4);
                return;
            }
            case 2: {
                this.add(5);
                return;
            }
            case 3: {
                this.add(6);
                return;
            }
            case 4: {
                this.add(7);
                return;
            }
            case 5: 
        }
        this.add(8);
    }

    public void addLoadConstant(long l) {
        this.add(20, this.itsConstantPool.addConstant(l));
    }

    public void addLoadConstant(String string2) {
        this.add(18, this.itsConstantPool.addConstant(string2));
    }

    public void addLoadThis() {
        this.add(42);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void addPush(double d) {
        if (d == 0.0) {
            this.add(14);
            if (!(1.0 / d < 0.0)) return;
            {
                this.add(119);
                return;
            }
        } else {
            if (d != 1.0 && d != -1.0) {
                this.addLoadConstant(d);
                return;
            }
            this.add(15);
            if (!(d < 0.0)) return;
            {
                this.add(119);
                return;
            }
        }
    }

    public void addPush(int n) {
        if ((byte)n == n) {
            if (n == -1) {
                this.add(2);
                return;
            }
            if (n >= 0 && n <= 5) {
                this.add((byte)(n + 3));
                return;
            }
            this.add(16, (byte)n);
            return;
        }
        if ((short)n == n) {
            this.add(17, (short)n);
            return;
        }
        this.addLoadConstant(n);
    }

    public void addPush(long l) {
        int n = (int)l;
        if ((long)n == l) {
            this.addPush(n);
            this.add(133);
            return;
        }
        this.addLoadConstant(l);
    }

    public void addPush(String string2) {
        int n = string2.length();
        int n2 = this.itsConstantPool.getUtfEncodingLimit(string2, 0, n);
        if (n2 == n) {
            this.addLoadConstant(string2);
            return;
        }
        this.add(187, "java/lang/StringBuilder");
        this.add(89);
        this.addPush(n);
        this.addInvoke(183, "java/lang/StringBuilder", "<init>", "(I)V");
        int n3 = 0;
        do {
            this.add(89);
            this.addLoadConstant(string2.substring(n3, n2));
            this.addInvoke(182, "java/lang/StringBuilder", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
            this.add(87);
            if (n2 == n) {
                this.addInvoke(182, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
                return;
            }
            n3 = n2;
            n2 = this.itsConstantPool.getUtfEncodingLimit(string2, n2, n);
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void addPush(boolean bl) {
        int n = bl ? 4 : 3;
        this.add(n);
    }

    public int addTableSwitch(int n, int n2) {
        int n3;
        if (n > n2) {
            throw new ClassFileFormatException("Bad bounds: " + n + ' ' + n2);
        }
        int n4 = this.itsStackTop + ClassFileWriter.stackChange(170);
        if (n4 < 0 || 32767 < n4) {
            ClassFileWriter.badStack(n4);
        }
        int n5 = 1 + (n2 - n);
        int n6 = this.addReservedCodeSpace(n3 + 1 + 4 * (n5 + 3));
        byte[] arrby = this.itsCodeBuffer;
        int n7 = n6 + 1;
        arrby[n6] = -86;
        for (n3 = 3 & (-1 ^ this.itsCodeBufferTop); n3 != 0; --n3) {
            byte[] arrby2 = this.itsCodeBuffer;
            int n8 = n7 + 1;
            arrby2[n7] = 0;
            n7 = n8;
        }
        int n9 = n7 + 4;
        int n10 = ClassFileWriter.putInt32(n, this.itsCodeBuffer, n9);
        ClassFileWriter.putInt32(n2, this.itsCodeBuffer, n10);
        this.itsStackTop = (short)n4;
        if (n4 > this.itsMaxStack) {
            this.itsMaxStack = (short)n4;
        }
        return n6;
    }

    public void addVariableDescriptor(String string2, String string3, int n, int n2) {
        int[] arrn = new int[]{this.itsConstantPool.addUtf8(string2), this.itsConstantPool.addUtf8(string3), n, n2};
        if (this.itsVarDescriptors == null) {
            this.itsVarDescriptors = new ObjArray();
        }
        this.itsVarDescriptors.add(arrn);
    }

    public void adjustStackTop(int n) {
        int n2 = n + this.itsStackTop;
        if (n2 < 0 || 32767 < n2) {
            ClassFileWriter.badStack(n2);
        }
        this.itsStackTop = (short)n2;
        if (n2 > this.itsMaxStack) {
            this.itsMaxStack = (short)n2;
        }
    }

    final char[] getCharBuffer(int n) {
        if (n > this.tmpCharBuffer.length) {
            int n2 = 2 * this.tmpCharBuffer.length;
            if (n > n2) {
                n2 = n;
            }
            this.tmpCharBuffer = new char[n2];
        }
        return this.tmpCharBuffer;
    }

    public final String getClassName() {
        return this.generatedClassName;
    }

    public int getCurrentCodeOffset() {
        return this.itsCodeBufferTop;
    }

    public int getLabelPC(int n) {
        if (n >= 0) {
            throw new IllegalArgumentException("Bad label, no biscuit");
        }
        int n2 = n & Integer.MAX_VALUE;
        if (n2 >= this.itsLabelTableTop) {
            throw new IllegalArgumentException("Bad label");
        }
        return this.itsLabelTable[n2];
    }

    public short getStackTop() {
        return this.itsStackTop;
    }

    public boolean isUnderStringSizeLimit(String string2) {
        return this.itsConstantPool.isUnderUtfEncodingLimit(string2);
    }

    public void markHandler(int n) {
        this.itsStackTop = 1;
        this.markLabel(n);
    }

    public void markLabel(int n) {
        if (n >= 0) {
            throw new IllegalArgumentException("Bad label, no biscuit");
        }
        int n2 = n & Integer.MAX_VALUE;
        if (n2 > this.itsLabelTableTop) {
            throw new IllegalArgumentException("Bad label");
        }
        if (this.itsLabelTable[n2] != -1) {
            throw new IllegalStateException("Can only mark label once");
        }
        this.itsLabelTable[n2] = this.itsCodeBufferTop;
    }

    public void markLabel(int n, short s) {
        this.markLabel(n);
        this.itsStackTop = s;
    }

    public final void markTableSwitchCase(int n, int n2) {
        this.addSuperBlockStart(this.itsCodeBufferTop);
        this.itsJumpFroms.put(this.itsCodeBufferTop, n);
        this.setTableSwitchJump(n, n2, this.itsCodeBufferTop);
    }

    public final void markTableSwitchCase(int n, int n2, int n3) {
        if (n3 < 0 || n3 > this.itsMaxStack) {
            throw new IllegalArgumentException("Bad stack index: " + n3);
        }
        this.itsStackTop = (short)n3;
        this.addSuperBlockStart(this.itsCodeBufferTop);
        this.itsJumpFroms.put(this.itsCodeBufferTop, n);
        this.setTableSwitchJump(n, n2, this.itsCodeBufferTop);
    }

    public final void markTableSwitchDefault(int n) {
        this.addSuperBlockStart(this.itsCodeBufferTop);
        this.itsJumpFroms.put(this.itsCodeBufferTop, n);
        this.setTableSwitchJump(n, -1, this.itsCodeBufferTop);
    }

    public void setFlags(short s) {
        this.itsFlags = s;
    }

    public void setStackTop(short s) {
        this.itsStackTop = s;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setTableSwitchJump(int n, int n2, int n3) {
        if (n3 < 0 || n3 > this.itsCodeBufferTop) {
            throw new IllegalArgumentException("Bad jump target: " + n3);
        }
        if (n2 < -1) {
            throw new IllegalArgumentException("Bad case index: " + n2);
        }
        int n4 = 3 & ~n;
        int n5 = n2 < 0 ? n4 + (n + 1) : n4 + (n + 1) + 4 * (n2 + 3);
        if (n < 0 || n > -1 + (-16 + this.itsCodeBufferTop - n4)) {
            throw new IllegalArgumentException(n + " is outside a possible range of tableswitch" + " in already generated code");
        }
        if ((255 & this.itsCodeBuffer[n]) != 170) {
            throw new IllegalArgumentException(n + " is not offset of tableswitch statement");
        }
        if (n5 >= 0 && n5 + 4 <= this.itsCodeBufferTop) {
            ClassFileWriter.putInt32(n3 - n, this.itsCodeBuffer, n5);
            return;
        }
        throw new ClassFileFormatException("Too big case index: " + n2);
    }

    public void startMethod(String string2, String string3, short s) {
        this.itsCurrentMethod = new ClassFileMethod(string2, this.itsConstantPool.addUtf8(string2), string3, this.itsConstantPool.addUtf8(string3), s);
        this.itsJumpFroms = new UintMap();
        this.itsMethods.add(this.itsCurrentMethod);
        this.addSuperBlockStart(0);
    }

    public void stopMethod(short s) {
        int n;
        int n2;
        if (this.itsCurrentMethod == null) {
            throw new IllegalStateException("No method to stop");
        }
        this.fixLabelGotos();
        this.itsMaxLocals = s;
        boolean bl = GenerateStackMap;
        StackMapTable stackMapTable = null;
        if (bl) {
            this.finalizeSuperBlockStarts();
            stackMapTable = new StackMapTable();
            stackMapTable.generate();
        }
        int[] arrn = this.itsLineNumberTable;
        int n3 = 0;
        if (arrn != null) {
            n3 = 8 + 4 * this.itsLineNumberTableTop;
        }
        ObjArray objArray = this.itsVarDescriptors;
        int n4 = 0;
        if (objArray != null) {
            n4 = 8 + 10 * this.itsVarDescriptors.size();
        }
        int n5 = 0;
        if (stackMapTable != null) {
            int n6 = stackMapTable.computeWriteSize();
            n5 = 0;
            if (n6 > 0) {
                n5 = n6 + 6;
            }
        }
        if ((n2 = n5 + (n4 + (n3 + (2 + (2 + (14 + this.itsCodeBufferTop) + 8 * this.itsExceptionTableTop))))) > 65536) {
            throw new ClassFileFormatException("generated bytecode for method exceeds 64K limit.");
        }
        byte[] arrby = new byte[n2];
        int n7 = ClassFileWriter.putInt16(this.itsConstantPool.addUtf8("Code"), arrby, 0);
        int n8 = ClassFileWriter.putInt32(n2 - 6, arrby, n7);
        int n9 = ClassFileWriter.putInt16(this.itsMaxStack, arrby, n8);
        int n10 = ClassFileWriter.putInt16(this.itsMaxLocals, arrby, n9);
        int n11 = ClassFileWriter.putInt32(this.itsCodeBufferTop, arrby, n10);
        System.arraycopy((Object)this.itsCodeBuffer, (int)0, (Object)arrby, (int)n11, (int)this.itsCodeBufferTop);
        int n12 = n11 + this.itsCodeBufferTop;
        if (this.itsExceptionTableTop > 0) {
            n = ClassFileWriter.putInt16(this.itsExceptionTableTop, arrby, n12);
            for (int i = 0; i < this.itsExceptionTableTop; ++i) {
                ExceptionTableEntry exceptionTableEntry = this.itsExceptionTable[i];
                short s2 = (short)this.getLabelPC(exceptionTableEntry.itsStartLabel);
                short s3 = (short)this.getLabelPC(exceptionTableEntry.itsEndLabel);
                short s4 = (short)this.getLabelPC(exceptionTableEntry.itsHandlerLabel);
                short s5 = exceptionTableEntry.itsCatchType;
                if (s2 == -1) {
                    throw new IllegalStateException("start label not defined");
                }
                if (s3 == -1) {
                    throw new IllegalStateException("end label not defined");
                }
                if (s4 == -1) {
                    throw new IllegalStateException("handler label not defined");
                }
                n = ClassFileWriter.putInt16(s5, arrby, ClassFileWriter.putInt16(s4, arrby, ClassFileWriter.putInt16(s3, arrby, ClassFileWriter.putInt16(s2, arrby, n))));
            }
        } else {
            n = ClassFileWriter.putInt16(0, arrby, n12);
        }
        int[] arrn2 = this.itsLineNumberTable;
        int n13 = 0;
        if (arrn2 != null) {
            n13 = 0 + 1;
        }
        if (this.itsVarDescriptors != null) {
            ++n13;
        }
        if (n5 > 0) {
            ++n13;
        }
        int n14 = ClassFileWriter.putInt16(n13, arrby, n);
        if (this.itsLineNumberTable != null) {
            int n15 = ClassFileWriter.putInt16(this.itsConstantPool.addUtf8("LineNumberTable"), arrby, n14);
            int n16 = ClassFileWriter.putInt32(2 + 4 * this.itsLineNumberTableTop, arrby, n15);
            n14 = ClassFileWriter.putInt16(this.itsLineNumberTableTop, arrby, n16);
            for (int i = 0; i < this.itsLineNumberTableTop; ++i) {
                n14 = ClassFileWriter.putInt32(this.itsLineNumberTable[i], arrby, n14);
            }
        }
        if (this.itsVarDescriptors != null) {
            int n17 = ClassFileWriter.putInt16(this.itsConstantPool.addUtf8("LocalVariableTable"), arrby, n14);
            int n18 = this.itsVarDescriptors.size();
            n14 = ClassFileWriter.putInt16(n18, arrby, ClassFileWriter.putInt32(2 + n18 * 10, arrby, n17));
            for (int i = 0; i < n18; ++i) {
                int[] arrn3 = (int[])this.itsVarDescriptors.get(i);
                int n19 = arrn3[0];
                int n20 = arrn3[1];
                int n21 = arrn3[2];
                n14 = ClassFileWriter.putInt16(arrn3[3], arrby, ClassFileWriter.putInt16(n20, arrby, ClassFileWriter.putInt16(n19, arrby, ClassFileWriter.putInt16(this.itsCodeBufferTop - n21, arrby, ClassFileWriter.putInt16(n21, arrby, n14)))));
            }
        }
        if (n5 > 0) {
            short s6 = this.itsConstantPool.addUtf8("StackMapTable");
            int n22 = ClassFileWriter.putInt16(s6, arrby, n14);
            stackMapTable.write(arrby, n22);
        }
        this.itsCurrentMethod.setCodeAttribute(arrby);
        this.itsExceptionTable = null;
        this.itsExceptionTableTop = 0;
        this.itsLineNumberTableTop = 0;
        this.itsCodeBufferTop = 0;
        this.itsCurrentMethod = null;
        this.itsMaxStack = 0;
        this.itsStackTop = 0;
        this.itsLabelTableTop = 0;
        this.itsFixupTableTop = 0;
        this.itsVarDescriptors = null;
        this.itsSuperBlockStarts = null;
        this.itsSuperBlockStartsTop = 0;
        this.itsJumpFroms = null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public byte[] toByteArray() {
        int n;
        int n2 = this.getWriteSize();
        byte[] arrby = new byte[n2];
        short s = this.itsSourceFileNameIndex;
        short s2 = 0;
        if (s != 0) {
            s2 = this.itsConstantPool.addUtf8("SourceFile");
        }
        int n3 = ClassFileWriter.putInt32(-889275714, arrby, 0);
        int n4 = ClassFileWriter.putInt16(MinorVersion, arrby, n3);
        int n5 = ClassFileWriter.putInt16(MajorVersion, arrby, n4);
        int n6 = this.itsConstantPool.write(arrby, n5);
        int n7 = ClassFileWriter.putInt16(this.itsFlags, arrby, n6);
        int n8 = ClassFileWriter.putInt16(this.itsThisClassIndex, arrby, n7);
        int n9 = ClassFileWriter.putInt16(this.itsSuperClassIndex, arrby, n8);
        int n10 = ClassFileWriter.putInt16(this.itsInterfaces.size(), arrby, n9);
        for (int i = 0; i < this.itsInterfaces.size(); ++i) {
            n10 = ClassFileWriter.putInt16(((Short)this.itsInterfaces.get(i)).shortValue(), arrby, n10);
        }
        int n11 = ClassFileWriter.putInt16(this.itsFields.size(), arrby, n10);
        for (int i = 0; i < this.itsFields.size(); ++i) {
            n11 = ((ClassFileField)this.itsFields.get(i)).write(arrby, n11);
        }
        int n12 = ClassFileWriter.putInt16(this.itsMethods.size(), arrby, n11);
        for (int i = 0; i < this.itsMethods.size(); ++i) {
            n12 = ((ClassFileMethod)this.itsMethods.get(i)).write(arrby, n12);
        }
        if (this.itsSourceFileNameIndex != 0) {
            int n13 = ClassFileWriter.putInt32(2, arrby, ClassFileWriter.putInt16(s2, arrby, ClassFileWriter.putInt16(1, arrby, n12)));
            n = ClassFileWriter.putInt16(this.itsSourceFileNameIndex, arrby, n13);
        } else {
            n = ClassFileWriter.putInt16(0, arrby, n12);
        }
        if (n != n2) {
            throw new RuntimeException();
        }
        return arrby;
    }

    public void write(OutputStream outputStream) throws IOException {
        outputStream.write(this.toByteArray());
    }

    public static class ClassFileFormatException
    extends RuntimeException {
        private static final long serialVersionUID = 1263998431033790599L;

        ClassFileFormatException(String string2) {
            super(string2);
        }
    }

    final class StackMapTable {
        static final boolean DEBUGSTACKMAP;
        private int[] locals = null;
        private int localsTop = 0;
        private byte[] rawStackMap = null;
        private int rawStackMapTop = 0;
        private int[] stack = null;
        private int stackTop = 0;
        private SuperBlock[] superBlockDeps;
        private SuperBlock[] superBlocks = null;
        private boolean wide = false;
        private SuperBlock[] workList = null;
        private int workListTop = 0;

        StackMapTable() {
        }

        private void addToWorkList(SuperBlock superBlock) {
            if (!superBlock.isInQueue()) {
                superBlock.setInQueue(true);
                superBlock.setInitialized(true);
                if (this.workListTop == this.workList.length) {
                    SuperBlock[] arrsuperBlock = new SuperBlock[2 * this.workListTop];
                    System.arraycopy((Object)this.workList, (int)0, (Object)arrsuperBlock, (int)0, (int)this.workListTop);
                    this.workList = arrsuperBlock;
                }
                SuperBlock[] arrsuperBlock = this.workList;
                int n = this.workListTop;
                this.workListTop = n + 1;
                arrsuperBlock[n] = superBlock;
            }
        }

        private void clearStack() {
            this.stackTop = 0;
        }

        /*
         * Enabled aggressive block sorting
         */
        private void computeRawStackMap() {
            int[] arrn = this.superBlocks[0].getTrimmedLocals();
            int n = -1;
            int n2 = 1;
            do {
                SuperBlock superBlock;
                int[] arrn2;
                block14 : {
                    if (n2 >= this.superBlocks.length) {
                        return;
                    }
                    superBlock = this.superBlocks[n2];
                    arrn2 = superBlock.getTrimmedLocals();
                    int[] arrn3 = superBlock.getStack();
                    int n3 = -1 + (superBlock.getStart() - n);
                    if (arrn3.length != 0) {
                        if (arrn3.length == 1) {
                            if (Arrays.equals((int[])arrn, (int[])arrn2)) {
                                this.writeSameLocalsOneStackItemFrame(arrn2, arrn3, n3);
                            } else {
                                this.writeFullFrame(arrn2, arrn3, n3);
                            }
                        } else {
                            this.writeFullFrame(arrn2, arrn3, n3);
                        }
                    } else {
                        int n4 = arrn.length > arrn2.length ? arrn2.length : arrn.length;
                        int n5 = Math.abs((int)(arrn.length - arrn2.length));
                        int n6 = 0;
                        do {
                            if (n6 >= n4 || arrn[n6] != arrn2[n6]) {
                                if (n6 != arrn2.length || n5 != 0) break;
                                this.writeSameFrame(arrn2, n3);
                                break block14;
                            }
                            ++n6;
                        } while (true);
                        if (n6 == arrn2.length && n5 <= 3) {
                            this.writeChopFrame(n5, n3);
                        } else if (n6 == arrn.length && n5 <= 3) {
                            this.writeAppendFrame(arrn2, n5, n3);
                        } else {
                            this.writeFullFrame(arrn2, arrn3, n3);
                        }
                    }
                }
                arrn = arrn2;
                n = superBlock.getStart();
                ++n2;
            } while (true);
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Lifted jumps to return sites
         */
        private int execute(int var1_1) {
            var2_2 = 255 & ClassFileWriter.access$700(ClassFileWriter.this)[var1_1];
            var3_3 = 0;
            block0 : switch (var2_2) {
                default: {
                    throw new IllegalArgumentException("bad opcode: " + var2_2);
                }
                case 192: {
                    this.pop();
                    this.push(TypeInfo.OBJECT(this.getOperand(var1_1 + 1, 2)));
                    break;
                }
                case 79: 
                case 80: 
                case 81: 
                case 82: 
                case 83: 
                case 84: 
                case 85: 
                case 86: {
                    this.pop();
                }
                case 159: 
                case 160: 
                case 161: 
                case 162: 
                case 163: 
                case 164: 
                case 165: 
                case 166: 
                case 181: {
                    this.pop();
                }
                case 87: 
                case 153: 
                case 154: 
                case 155: 
                case 156: 
                case 157: 
                case 158: 
                case 179: 
                case 194: 
                case 195: 
                case 198: 
                case 199: {
                    this.pop();
                    var3_3 = 0;
                    break;
                }
                case 88: {
                    this.pop2();
                    var3_3 = 0;
                    break;
                }
                case 1: {
                    this.push(5);
                    var3_3 = 0;
                    break;
                }
                case 46: 
                case 51: 
                case 52: 
                case 53: 
                case 96: 
                case 100: 
                case 104: 
                case 108: 
                case 112: 
                case 120: 
                case 122: 
                case 124: 
                case 126: 
                case 128: 
                case 130: 
                case 148: 
                case 149: 
                case 150: 
                case 151: 
                case 152: {
                    this.pop();
                }
                case 116: 
                case 136: 
                case 139: 
                case 142: 
                case 145: 
                case 146: 
                case 147: 
                case 190: 
                case 193: {
                    this.pop();
                }
                case 2: 
                case 3: 
                case 4: 
                case 5: 
                case 6: 
                case 7: 
                case 8: 
                case 16: 
                case 17: 
                case 21: 
                case 26: 
                case 27: 
                case 28: 
                case 29: {
                    this.push(1);
                    var3_3 = 0;
                    break;
                }
                case 47: 
                case 97: 
                case 101: 
                case 105: 
                case 109: 
                case 113: 
                case 121: 
                case 123: 
                case 125: 
                case 127: 
                case 129: 
                case 131: {
                    this.pop();
                }
                case 117: 
                case 133: 
                case 140: 
                case 143: {
                    this.pop();
                }
                case 9: 
                case 10: 
                case 22: 
                case 30: 
                case 31: 
                case 32: 
                case 33: {
                    this.push(4);
                    var3_3 = 0;
                    break;
                }
                case 48: 
                case 98: 
                case 102: 
                case 106: 
                case 110: 
                case 114: {
                    this.pop();
                }
                case 118: 
                case 134: 
                case 137: 
                case 144: {
                    this.pop();
                }
                case 11: 
                case 12: 
                case 13: 
                case 23: 
                case 34: 
                case 35: 
                case 36: 
                case 37: {
                    this.push(2);
                    var3_3 = 0;
                    break;
                }
                case 49: 
                case 99: 
                case 103: 
                case 107: 
                case 111: 
                case 115: {
                    this.pop();
                }
                case 119: 
                case 135: 
                case 138: 
                case 141: {
                    this.pop();
                }
                case 14: 
                case 15: 
                case 24: 
                case 38: 
                case 39: 
                case 40: 
                case 41: {
                    this.push(3);
                    var3_3 = 0;
                    break;
                }
                case 54: {
                    var59_4 = var1_1 + 1;
                    var60_5 = this.wide != false ? 2 : 1;
                    this.executeStore(this.getOperand(var59_4, var60_5), 1);
                    var3_3 = 0;
                    break;
                }
                case 59: 
                case 60: 
                case 61: 
                case 62: {
                    this.executeStore(var2_2 - 59, 1);
                    var3_3 = 0;
                    break;
                }
                case 55: {
                    var57_6 = var1_1 + 1;
                    var58_7 = this.wide != false ? 2 : 1;
                    this.executeStore(this.getOperand(var57_6, var58_7), 4);
                    var3_3 = 0;
                    break;
                }
                case 63: 
                case 64: 
                case 65: 
                case 66: {
                    this.executeStore(var2_2 - 63, 4);
                    var3_3 = 0;
                    break;
                }
                case 56: {
                    var55_8 = var1_1 + 1;
                    var56_9 = this.wide != false ? 2 : 1;
                    this.executeStore(this.getOperand(var55_8, var56_9), 2);
                    var3_3 = 0;
                    break;
                }
                case 67: 
                case 68: 
                case 69: 
                case 70: {
                    this.executeStore(var2_2 - 67, 2);
                    var3_3 = 0;
                    break;
                }
                case 57: {
                    var53_10 = var1_1 + 1;
                    var54_11 = this.wide != false ? 2 : 1;
                    this.executeStore(this.getOperand(var53_10, var54_11), 3);
                    var3_3 = 0;
                    break;
                }
                case 71: 
                case 72: 
                case 73: 
                case 74: {
                    this.executeStore(var2_2 - 71, 3);
                    var3_3 = 0;
                    break;
                }
                case 25: {
                    var51_12 = var1_1 + 1;
                    var52_13 = this.wide != false ? 2 : 1;
                    this.executeALoad(this.getOperand(var51_12, var52_13));
                    var3_3 = 0;
                    break;
                }
                case 42: 
                case 43: 
                case 44: 
                case 45: {
                    this.executeALoad(var2_2 - 42);
                    var3_3 = 0;
                    break;
                }
                case 58: {
                    var49_14 = var1_1 + 1;
                    var50_15 = this.wide != false ? 2 : 1;
                    this.executeAStore(this.getOperand(var49_14, var50_15));
                    var3_3 = 0;
                    break;
                }
                case 75: 
                case 76: 
                case 77: 
                case 78: {
                    this.executeAStore(var2_2 - 75);
                    var3_3 = 0;
                    break;
                }
                case 172: 
                case 173: 
                case 174: 
                case 175: 
                case 176: 
                case 177: {
                    this.clearStack();
                    var3_3 = 0;
                    break;
                }
                case 191: {
                    var48_16 = this.pop();
                    this.clearStack();
                    this.push(var48_16);
                    var3_3 = 0;
                    break;
                }
                case 95: {
                    var46_17 = this.pop();
                    var47_18 = this.pop();
                    this.push(var46_17);
                    this.push(var47_18);
                    var3_3 = 0;
                    break;
                }
                case 18: 
                case 19: 
                case 20: {
                    var44_19 = var2_2 == 18 ? this.getOperand(var1_1 + 1) : this.getOperand(var1_1 + 1, 2);
                    var45_20 = ClassFileWriter.access$800(ClassFileWriter.this).getConstantType(var44_19);
                    switch (var45_20) {
                        default: {
                            throw new IllegalArgumentException("bad const type " + var45_20);
                        }
                        case 6: {
                            this.push(3);
                            var3_3 = 0;
                            break block0;
                        }
                        case 4: {
                            this.push(2);
                            var3_3 = 0;
                            break block0;
                        }
                        case 5: {
                            this.push(4);
                            var3_3 = 0;
                            break block0;
                        }
                        case 3: {
                            this.push(1);
                            var3_3 = 0;
                            break block0;
                        }
                        case 8: 
                    }
                    this.push(TypeInfo.OBJECT("java/lang/String", ClassFileWriter.access$800(ClassFileWriter.this)));
                    var3_3 = 0;
                    break;
                }
                case 187: {
                    this.push(TypeInfo.UNINITIALIZED_VARIABLE(var1_1));
                    var3_3 = 0;
                    break;
                }
                case 188: {
                    this.pop();
                    var43_21 = ClassFileWriter.access$900(ClassFileWriter.access$700(ClassFileWriter.this)[var1_1 + 1]);
                    this.push(TypeInfo.OBJECT(ClassFileWriter.access$800(ClassFileWriter.this).addClass("[" + var43_21)));
                    var3_3 = 0;
                    break;
                }
                case 189: {
                    var39_22 = this.getOperand(var1_1 + 1, 2);
                    var40_23 = (String)ClassFileWriter.access$800(ClassFileWriter.this).getConstantData(var39_22);
                    this.pop();
                    this.push(TypeInfo.OBJECT("[L" + var40_23 + ';', ClassFileWriter.access$800(ClassFileWriter.this)));
                    var3_3 = 0;
                    break;
                }
                case 182: 
                case 183: 
                case 184: 
                case 185: {
                    var28_24 = this.getOperand(var1_1 + 1, 2);
                    var29_25 = (FieldOrMethodRef)ClassFileWriter.access$800(ClassFileWriter.this).getConstantData(var28_24);
                    var30_26 = var29_25.getType();
                    var31_27 = var29_25.getName();
                    var32_28 = ClassFileWriter.access$1000(var30_26) >>> 16;
                    for (var33_29 = 0; var33_29 < var32_28; ++var33_29) {
                        this.pop();
                    }
                    if (var2_2 != 184 && ((var37_31 = TypeInfo.getTag(var36_30 = this.pop())) == TypeInfo.UNINITIALIZED_VARIABLE(0) || var37_31 == 6)) {
                        if ("<init>".equals((Object)var31_27) == false) throw new IllegalStateException("bad instance");
                        this.initializeTypeInfo(var36_30, TypeInfo.OBJECT(ClassFileWriter.access$1100(ClassFileWriter.this)));
                    }
                    var34_32 = ClassFileWriter.access$1200(var30_26.substring(1 + var30_26.indexOf(41)));
                    var35_33 = var34_32.equals((Object)"V");
                    var3_3 = 0;
                    if (!var35_33) {
                        this.push(TypeInfo.fromType(var34_32, ClassFileWriter.access$800(ClassFileWriter.this)));
                        var3_3 = 0;
                        break;
                    }
                    ** GOTO lbl264
                }
                case 180: {
                    this.pop();
                }
                case 178: {
                    var26_34 = this.getOperand(var1_1 + 1, 2);
                    this.push(TypeInfo.fromType(ClassFileWriter.access$1200(((FieldOrMethodRef)ClassFileWriter.access$800(ClassFileWriter.this).getConstantData(var26_34)).getType()), ClassFileWriter.access$800(ClassFileWriter.this)));
                    var3_3 = 0;
                    break;
                }
                case 89: {
                    var25_35 = this.pop();
                    this.push(var25_35);
                    this.push(var25_35);
                    var3_3 = 0;
                    break;
                }
                case 90: {
                    var23_36 = this.pop();
                    var24_37 = this.pop();
                    this.push(var23_36);
                    this.push(var24_37);
                    this.push(var23_36);
                    var3_3 = 0;
                    break;
                }
                case 91: {
                    var20_38 = this.pop();
                    var21_39 = this.pop2();
                    this.push(var20_38);
                    this.push2(var21_39);
                    this.push(var20_38);
                    var3_3 = 0;
                    break;
                }
                case 92: {
                    var18_40 = this.pop2();
                    this.push2(var18_40);
                    this.push2(var18_40);
                    var3_3 = 0;
                    break;
                }
                case 93: {
                    var15_41 = this.pop2();
                    var17_42 = this.pop();
                    this.push2(var15_41);
                    this.push(var17_42);
                    this.push2(var15_41);
                    var3_3 = 0;
                    break;
                }
                case 94: {
                    var11_43 = this.pop2();
                    var13_44 = this.pop2();
                    this.push2(var11_43);
                    this.push2(var13_44);
                    this.push2(var11_43);
                    var3_3 = 0;
                    break;
                }
                case 170: {
                    var8_45 = var1_1 + 1 + (3 & ~var1_1);
                    var9_46 = this.getOperand(var8_45 + 4, 4);
                    var3_3 = var8_45 + 4 * (4 + (this.getOperand(var8_45 + 8, 4) - var9_46)) - var1_1;
                    this.pop();
                    break;
                }
                case 50: {
                    this.pop();
                    var5_47 = this.pop() >>> 8;
                    var6_48 = (String)ClassFileWriter.access$800(ClassFileWriter.this).getConstantData(var5_47);
                    if (var6_48.charAt(0) != '[') {
                        throw new IllegalStateException("bad array type");
                    }
                    var7_49 = ClassFileWriter.access$1200(var6_48.substring(1));
                    this.push(TypeInfo.OBJECT(ClassFileWriter.access$800(ClassFileWriter.this).addClass(var7_49)));
                    var3_3 = 0;
                }
lbl264: // 3 sources:
                case 0: 
                case 132: 
                case 167: 
                case 200: {
                    break;
                }
                case 196: {
                    this.wide = true;
                    var3_3 = 0;
                }
            }
            if (var3_3 == 0) {
                var3_3 = ClassFileWriter.opcodeLength(var2_2, this.wide);
            }
            if (this.wide == false) return var3_3;
            if (var2_2 == 196) return var3_3;
            this.wide = false;
            return var3_3;
        }

        private void executeALoad(int n) {
            int n2 = this.getLocal(n);
            int n3 = TypeInfo.getTag(n2);
            if (n3 == 7 || n3 == 6 || n3 == 8 || n3 == 5) {
                this.push(n2);
                return;
            }
            throw new IllegalStateException("bad local variable type: " + n2 + " at index: " + n);
        }

        private void executeAStore(int n) {
            this.setLocal(n, this.pop());
        }

        /*
         * Enabled aggressive block sorting
         */
        private void executeBlock(SuperBlock superBlock) {
            int n = 0;
            int n2 = superBlock.getStart();
            do {
                int n3;
                int n4;
                if (n2 < superBlock.getEnd()) {
                    n = 255 & ClassFileWriter.this.itsCodeBuffer[n2];
                    n3 = this.execute(n2);
                    if (this.isBranch(n)) {
                        this.flowInto(this.getBranchTarget(n2));
                    } else if (n == 170) {
                        int n5 = n2 + 1 + (3 & ~n2);
                        this.flowInto(this.getSuperBlockFromOffset(n2 + this.getOperand(n5, 4)));
                        int n6 = this.getOperand(n5 + 4, 4);
                        int n7 = 1 + (this.getOperand(n5 + 8, 4) - n6);
                        int n8 = n5 + 12;
                        for (int i = 0; i < n7; ++i) {
                            this.flowInto(this.getSuperBlockFromOffset(n2 + this.getOperand(n8 + i * 4, 4)));
                        }
                    }
                } else {
                    int n9;
                    if (!this.isSuperBlockEnd(n) && (n9 = 1 + superBlock.getIndex()) < this.superBlocks.length) {
                        this.flowInto(this.superBlocks[n9]);
                    }
                    return;
                }
                for (int i = 0; i < (n4 = ClassFileWriter.this.itsExceptionTableTop); ++i) {
                    ExceptionTableEntry exceptionTableEntry = ClassFileWriter.this.itsExceptionTable[i];
                    short s = (short)ClassFileWriter.this.getLabelPC(exceptionTableEntry.itsStartLabel);
                    short s2 = (short)ClassFileWriter.this.getLabelPC(exceptionTableEntry.itsEndLabel);
                    if (n2 < s || n2 >= s2) continue;
                    SuperBlock superBlock2 = this.getSuperBlockFromOffset((short)ClassFileWriter.this.getLabelPC(exceptionTableEntry.itsHandlerLabel));
                    int n10 = exceptionTableEntry.itsCatchType == 0 ? TypeInfo.OBJECT(ClassFileWriter.this.itsConstantPool.addClass("java/lang/Throwable")) : TypeInfo.OBJECT(exceptionTableEntry.itsCatchType);
                    superBlock2.merge(this.locals, this.localsTop, new int[]{n10}, 1, ClassFileWriter.this.itsConstantPool);
                    this.addToWorkList(superBlock2);
                }
                n2 += n3;
            } while (true);
        }

        private void executeStore(int n, int n2) {
            this.pop();
            this.setLocal(n, n2);
        }

        private void executeWorkList() {
            while (this.workListTop > 0) {
                int n;
                SuperBlock[] arrsuperBlock = this.workList;
                this.workListTop = n = -1 + this.workListTop;
                SuperBlock superBlock = arrsuperBlock[n];
                superBlock.setInQueue(false);
                this.locals = superBlock.getLocals();
                this.stack = superBlock.getStack();
                this.localsTop = this.locals.length;
                this.stackTop = this.stack.length;
                this.executeBlock(superBlock);
            }
        }

        private void flowInto(SuperBlock superBlock) {
            if (superBlock.merge(this.locals, this.localsTop, this.stack, this.stackTop, ClassFileWriter.this.itsConstantPool)) {
                this.addToWorkList(superBlock);
            }
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        private SuperBlock getBranchTarget(int n) {
            int n2;
            if ((255 & ClassFileWriter.this.itsCodeBuffer[n]) == 200) {
                n2 = n + this.getOperand(n + 1, 4);
                do {
                    return this.getSuperBlockFromOffset(n2);
                    break;
                } while (true);
            }
            n2 = n + (short)this.getOperand(n + 1, 2);
            return this.getSuperBlockFromOffset(n2);
        }

        private int getLocal(int n) {
            if (n < this.localsTop) {
                return this.locals[n];
            }
            return 0;
        }

        private int getOperand(int n) {
            return this.getOperand(n, 1);
        }

        private int getOperand(int n, int n2) {
            int n3 = 0;
            if (n2 > 4) {
                throw new IllegalArgumentException("bad operand size");
            }
            for (int i = 0; i < n2; ++i) {
                n3 = n3 << 8 | 255 & ClassFileWriter.this.itsCodeBuffer[n + i];
            }
            return n3;
        }

        private SuperBlock[] getSuperBlockDependencies() {
            SuperBlock[] arrsuperBlock = new SuperBlock[this.superBlocks.length];
            for (int i = 0; i < ClassFileWriter.this.itsExceptionTableTop; ++i) {
                SuperBlock superBlock;
                ExceptionTableEntry exceptionTableEntry = ClassFileWriter.this.itsExceptionTable[i];
                short s = (short)ClassFileWriter.this.getLabelPC(exceptionTableEntry.itsStartLabel);
                SuperBlock superBlock2 = this.getSuperBlockFromOffset((short)ClassFileWriter.this.getLabelPC(exceptionTableEntry.itsHandlerLabel));
                arrsuperBlock[superBlock2.getIndex()] = superBlock = this.getSuperBlockFromOffset(s);
            }
            int[] arrn = ClassFileWriter.this.itsJumpFroms.getKeys();
            for (int i = 0; i < arrn.length; ++i) {
                SuperBlock superBlock;
                int n = arrn[i];
                arrsuperBlock[this.getSuperBlockFromOffset((int)n).getIndex()] = superBlock = this.getSuperBlockFromOffset(ClassFileWriter.this.itsJumpFroms.getInt(n, -1));
            }
            return arrsuperBlock;
        }

        private SuperBlock getSuperBlockFromOffset(int n) {
            int n2 = 0;
            do {
                SuperBlock superBlock;
                if (n2 >= this.superBlocks.length || (superBlock = this.superBlocks[n2]) == null) {
                    throw new IllegalArgumentException("bad offset: " + n);
                }
                if (n >= superBlock.getStart() && n < superBlock.getEnd()) {
                    return superBlock;
                }
                ++n2;
            } while (true);
        }

        private int getWorstCaseWriteSize() {
            return (-1 + this.superBlocks.length) * (7 + 3 * ClassFileWriter.this.itsMaxLocals + 3 * ClassFileWriter.this.itsMaxStack);
        }

        private void initializeTypeInfo(int n, int n2) {
            this.initializeTypeInfo(n, n2, this.locals, this.localsTop);
            this.initializeTypeInfo(n, n2, this.stack, this.stackTop);
        }

        private void initializeTypeInfo(int n, int n2, int[] arrn, int n3) {
            for (int i = 0; i < n3; ++i) {
                if (arrn[i] != n) continue;
                arrn[i] = n2;
            }
        }

        private boolean isBranch(int n) {
            switch (n) {
                default: {
                    return false;
                }
                case 153: 
                case 154: 
                case 155: 
                case 156: 
                case 157: 
                case 158: 
                case 159: 
                case 160: 
                case 161: 
                case 162: 
                case 163: 
                case 164: 
                case 165: 
                case 166: 
                case 167: 
                case 198: 
                case 199: 
                case 200: 
            }
            return true;
        }

        private boolean isSuperBlockEnd(int n) {
            switch (n) {
                default: {
                    return false;
                }
                case 167: 
                case 170: 
                case 171: 
                case 172: 
                case 173: 
                case 174: 
                case 176: 
                case 177: 
                case 191: 
                case 200: 
            }
            return true;
        }

        /*
         * Enabled aggressive block sorting
         */
        private void killSuperBlock(SuperBlock superBlock) {
            int[] arrn = new int[]{};
            int[] arrn2 = new int[]{TypeInfo.OBJECT("java/lang/Throwable", ClassFileWriter.this.itsConstantPool)};
            int n = 0;
            do {
                if (n >= ClassFileWriter.this.itsExceptionTableTop) break;
                ExceptionTableEntry exceptionTableEntry = ClassFileWriter.this.itsExceptionTable[n];
                int n2 = ClassFileWriter.this.getLabelPC(exceptionTableEntry.itsStartLabel);
                int n3 = ClassFileWriter.this.getLabelPC(exceptionTableEntry.itsEndLabel);
                SuperBlock superBlock2 = this.getSuperBlockFromOffset(ClassFileWriter.this.getLabelPC(exceptionTableEntry.itsHandlerLabel));
                if (superBlock.getStart() > n2 && superBlock.getStart() < n3 || n2 > superBlock.getStart() && n2 < superBlock.getEnd() && superBlock2.isInitialized()) {
                    arrn = superBlock2.getLocals();
                    break;
                }
                ++n;
            } while (true);
            for (int i = 0; i < ClassFileWriter.this.itsExceptionTableTop; ++i) {
                ExceptionTableEntry exceptionTableEntry = ClassFileWriter.this.itsExceptionTable[i];
                if (ClassFileWriter.this.getLabelPC(exceptionTableEntry.itsStartLabel) != superBlock.getStart()) continue;
                for (int j = i + 1; j < ClassFileWriter.this.itsExceptionTableTop; ++j) {
                    ClassFileWriter.access$500((ClassFileWriter)ClassFileWriter.this)[j - 1] = ClassFileWriter.this.itsExceptionTable[j];
                }
                ClassFileWriter.access$410(ClassFileWriter.this);
                --i;
            }
            superBlock.merge(arrn, arrn.length, arrn2, arrn2.length, ClassFileWriter.this.itsConstantPool);
            int n4 = -1 + superBlock.getEnd();
            ClassFileWriter.access$700((ClassFileWriter)ClassFileWriter.this)[n4] = -65;
            int n5 = superBlock.getStart();
            while (n5 < n4) {
                ClassFileWriter.access$700((ClassFileWriter)ClassFileWriter.this)[n5] = 0;
                ++n5;
            }
            return;
        }

        private int pop() {
            int n;
            int[] arrn = this.stack;
            this.stackTop = n = -1 + this.stackTop;
            return arrn[n];
        }

        private long pop2() {
            long l = this.pop();
            if (TypeInfo.isTwoWords((int)l)) {
                return l;
            }
            return l << 32 | (long)(16777215 & this.pop());
        }

        private void push(int n) {
            if (this.stackTop == this.stack.length) {
                int[] arrn = new int[Math.max((int)(2 * this.stackTop), (int)4)];
                System.arraycopy((Object)this.stack, (int)0, (Object)arrn, (int)0, (int)this.stackTop);
                this.stack = arrn;
            }
            int[] arrn = this.stack;
            int n2 = this.stackTop;
            this.stackTop = n2 + 1;
            arrn[n2] = n;
        }

        private void push2(long l) {
            this.push((int)(l & 0xFFFFFFL));
            long l2 = l >>> 32;
            if (l2 != 0L) {
                this.push((int)(l2 & 0xFFFFFFL));
            }
        }

        private void setLocal(int n, int n2) {
            if (n >= this.localsTop) {
                int[] arrn = new int[n + 1];
                System.arraycopy((Object)this.locals, (int)0, (Object)arrn, (int)0, (int)this.localsTop);
                this.locals = arrn;
                this.localsTop = n + 1;
            }
            this.locals[n] = n2;
        }

        private void verify() {
            int[] arrn = ClassFileWriter.this.createInitialLocals();
            this.superBlocks[0].merge(arrn, arrn.length, new int[0], 0, ClassFileWriter.this.itsConstantPool);
            SuperBlock[] arrsuperBlock = new SuperBlock[]{this.superBlocks[0]};
            this.workList = arrsuperBlock;
            this.workListTop = 1;
            this.executeWorkList();
            for (int i = 0; i < this.superBlocks.length; ++i) {
                SuperBlock superBlock = this.superBlocks[i];
                if (superBlock.isInitialized()) continue;
                this.killSuperBlock(superBlock);
            }
            this.executeWorkList();
        }

        private void writeAppendFrame(int[] arrn, int n, int n2) {
            int n3 = arrn.length - n;
            byte[] arrby = this.rawStackMap;
            int n4 = this.rawStackMapTop;
            this.rawStackMapTop = n4 + 1;
            arrby[n4] = (byte)(n + 251);
            this.rawStackMapTop = ClassFileWriter.putInt16(n2, this.rawStackMap, this.rawStackMapTop);
            this.rawStackMapTop = this.writeTypes(arrn, n3);
        }

        private void writeChopFrame(int n, int n2) {
            byte[] arrby = this.rawStackMap;
            int n3 = this.rawStackMapTop;
            this.rawStackMapTop = n3 + 1;
            arrby[n3] = (byte)(251 - n);
            this.rawStackMapTop = ClassFileWriter.putInt16(n2, this.rawStackMap, this.rawStackMapTop);
        }

        private void writeFullFrame(int[] arrn, int[] arrn2, int n) {
            byte[] arrby = this.rawStackMap;
            int n2 = this.rawStackMapTop;
            this.rawStackMapTop = n2 + 1;
            arrby[n2] = -1;
            this.rawStackMapTop = ClassFileWriter.putInt16(n, this.rawStackMap, this.rawStackMapTop);
            this.rawStackMapTop = ClassFileWriter.putInt16(arrn.length, this.rawStackMap, this.rawStackMapTop);
            this.rawStackMapTop = this.writeTypes(arrn);
            this.rawStackMapTop = ClassFileWriter.putInt16(arrn2.length, this.rawStackMap, this.rawStackMapTop);
            this.rawStackMapTop = this.writeTypes(arrn2);
        }

        private void writeSameFrame(int[] arrn, int n) {
            if (n <= 63) {
                byte[] arrby = this.rawStackMap;
                int n2 = this.rawStackMapTop;
                this.rawStackMapTop = n2 + 1;
                arrby[n2] = (byte)n;
                return;
            }
            byte[] arrby = this.rawStackMap;
            int n3 = this.rawStackMapTop;
            this.rawStackMapTop = n3 + 1;
            arrby[n3] = -5;
            this.rawStackMapTop = ClassFileWriter.putInt16(n, this.rawStackMap, this.rawStackMapTop);
        }

        /*
         * Enabled aggressive block sorting
         */
        private void writeSameLocalsOneStackItemFrame(int[] arrn, int[] arrn2, int n) {
            if (n <= 63) {
                byte[] arrby = this.rawStackMap;
                int n2 = this.rawStackMapTop;
                this.rawStackMapTop = n2 + 1;
                arrby[n2] = (byte)(n + 64);
            } else {
                byte[] arrby = this.rawStackMap;
                int n3 = this.rawStackMapTop;
                this.rawStackMapTop = n3 + 1;
                arrby[n3] = -9;
                this.rawStackMapTop = ClassFileWriter.putInt16(n, this.rawStackMap, this.rawStackMapTop);
            }
            this.writeType(arrn2[0]);
        }

        private int writeType(int n) {
            int n2 = n & 255;
            byte[] arrby = this.rawStackMap;
            int n3 = this.rawStackMapTop;
            this.rawStackMapTop = n3 + 1;
            arrby[n3] = (byte)n2;
            if (n2 == 7 || n2 == 8) {
                this.rawStackMapTop = ClassFileWriter.putInt16(n >>> 8, this.rawStackMap, this.rawStackMapTop);
            }
            return this.rawStackMapTop;
        }

        private int writeTypes(int[] arrn) {
            return this.writeTypes(arrn, 0);
        }

        private int writeTypes(int[] arrn, int n) {
            for (int i = n; i < arrn.length; ++i) {
                this.rawStackMapTop = this.writeType(arrn[i]);
            }
            return this.rawStackMapTop;
        }

        int computeWriteSize() {
            this.rawStackMap = new byte[this.getWorstCaseWriteSize()];
            this.computeRawStackMap();
            return 2 + this.rawStackMapTop;
        }

        /*
         * Enabled aggressive block sorting
         */
        void generate() {
            this.superBlocks = new SuperBlock[ClassFileWriter.this.itsSuperBlockStartsTop];
            int[] arrn = ClassFileWriter.this.createInitialLocals();
            int n = 0;
            do {
                if (n >= ClassFileWriter.this.itsSuperBlockStartsTop) {
                    this.superBlockDeps = this.getSuperBlockDependencies();
                    this.verify();
                    return;
                }
                int n2 = ClassFileWriter.this.itsSuperBlockStarts[n];
                int n3 = n == -1 + ClassFileWriter.this.itsSuperBlockStartsTop ? ClassFileWriter.this.itsCodeBufferTop : ClassFileWriter.this.itsSuperBlockStarts[n + 1];
                this.superBlocks[n] = new SuperBlock(n, n2, n3, arrn);
                ++n;
            } while (true);
        }

        int write(byte[] arrby, int n) {
            int n2 = ClassFileWriter.putInt32(2 + this.rawStackMapTop, arrby, n);
            int n3 = ClassFileWriter.putInt16(-1 + this.superBlocks.length, arrby, n2);
            System.arraycopy((Object)this.rawStackMap, (int)0, (Object)arrby, (int)n3, (int)this.rawStackMapTop);
            return n3 + this.rawStackMapTop;
        }
    }

}

