/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package org.mozilla.classfile;

import org.mozilla.classfile.ClassFileWriter;

final class ClassFileMethod {
    private byte[] itsCodeAttribute;
    private short itsFlags;
    private String itsName;
    private short itsNameIndex;
    private String itsType;
    private short itsTypeIndex;

    ClassFileMethod(String string2, short s, String string3, short s2, short s3) {
        this.itsName = string2;
        this.itsNameIndex = s;
        this.itsType = string3;
        this.itsTypeIndex = s2;
        this.itsFlags = s3;
    }

    short getFlags() {
        return this.itsFlags;
    }

    String getName() {
        return this.itsName;
    }

    String getType() {
        return this.itsType;
    }

    int getWriteSize() {
        return 8 + this.itsCodeAttribute.length;
    }

    void setCodeAttribute(byte[] arrby) {
        this.itsCodeAttribute = arrby;
    }

    int write(byte[] arrby, int n) {
        int n2 = ClassFileWriter.putInt16(this.itsFlags, arrby, n);
        int n3 = ClassFileWriter.putInt16(this.itsNameIndex, arrby, n2);
        int n4 = ClassFileWriter.putInt16(1, arrby, ClassFileWriter.putInt16(this.itsTypeIndex, arrby, n3));
        System.arraycopy((Object)this.itsCodeAttribute, (int)0, (Object)arrby, (int)n4, (int)this.itsCodeAttribute.length);
        return n4 + this.itsCodeAttribute.length;
    }
}

