/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.ref.SoftReference
 *  java.lang.reflect.UndeclaredThrowableException
 *  java.security.AccessController
 *  java.security.CodeSource
 *  java.security.PrivilegedAction
 *  java.security.PrivilegedActionException
 *  java.security.PrivilegedExceptionAction
 *  java.security.SecureClassLoader
 *  java.util.Map
 *  java.util.WeakHashMap
 */
package org.mozilla.javascript;

import java.lang.ref.SoftReference;
import java.lang.reflect.UndeclaredThrowableException;
import java.security.AccessController;
import java.security.CodeSource;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.security.SecureClassLoader;
import java.util.Map;
import java.util.WeakHashMap;
import org.mozilla.classfile.ClassFileWriter;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.GeneratedClassLoader;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.SecurityController;

public class PolicySecurityController
extends SecurityController {
    private static final Map<CodeSource, Map<ClassLoader, SoftReference<SecureCaller>>> callers;
    private static final byte[] secureCallerImplBytecode;

    static {
        secureCallerImplBytecode = PolicySecurityController.loadBytecode();
        callers = new WeakHashMap();
    }

    private static byte[] loadBytecode() {
        String string2 = SecureCaller.class.getName();
        ClassFileWriter classFileWriter = new ClassFileWriter(string2 + "Impl", string2, "<generated>");
        classFileWriter.startMethod("<init>", "()V", (short)1);
        classFileWriter.addALoad(0);
        classFileWriter.addInvoke(183, string2, "<init>", "()V");
        classFileWriter.add(177);
        classFileWriter.stopMethod((short)1);
        classFileWriter.startMethod("call", "(Lorg/mozilla/javascript/Callable;" + "Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;", (short)17);
        for (int i = 1; i < 6; ++i) {
            classFileWriter.addALoad(i);
        }
        classFileWriter.addInvoke(185, "org/mozilla/javascript/Callable", "call", "(" + "Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;");
        classFileWriter.add(176);
        classFileWriter.stopMethod((short)6);
        return classFileWriter.toByteArray();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object callWithDomain(Object object, final Context context, Callable callable, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        Map<CodeSource, Map<ClassLoader, SoftReference<SecureCaller>>> map;
        Map map2;
        final ClassLoader classLoader = (ClassLoader)AccessController.doPrivileged((PrivilegedAction)new PrivilegedAction<Object>(){

            public Object run() {
                return context.getApplicationClassLoader();
            }
        });
        final CodeSource codeSource = (CodeSource)object;
        Map<CodeSource, Map<ClassLoader, SoftReference<SecureCaller>>> map3 = map = callers;
        synchronized (map3) {
            map2 = (Map)callers.get((Object)codeSource);
            if (map2 == null) {
                map2 = new WeakHashMap();
                callers.put((Object)codeSource, (Object)map2);
            }
        }
        Map map4 = map2;
        synchronized (map4) {
            SecureCaller secureCaller;
            block9 : {
                SoftReference softReference = (SoftReference)map2.get((Object)classLoader);
                secureCaller = softReference != null ? (SecureCaller)softReference.get() : null;
                if (secureCaller != null) break block9;
                try {
                    secureCaller = (SecureCaller)AccessController.doPrivileged((PrivilegedExceptionAction)new PrivilegedExceptionAction<Object>(){

                        public Object run() throws Exception {
                            return new Loader(classLoader, codeSource).defineClass(SecureCaller.class.getName() + "Impl", secureCallerImplBytecode).newInstance();
                        }
                    });
                    map2.put((Object)classLoader, (Object)new SoftReference((Object)secureCaller));
                }
                catch (PrivilegedActionException privilegedActionException) {
                    throw new UndeclaredThrowableException(privilegedActionException.getCause());
                }
            }
            return secureCaller.call(callable, context, scriptable, scriptable2, arrobject);
        }
    }

    @Override
    public GeneratedClassLoader createClassLoader(final ClassLoader classLoader, final Object object) {
        return (Loader)AccessController.doPrivileged((PrivilegedAction)new PrivilegedAction<Object>(){

            public Object run() {
                return new Loader(classLoader, (CodeSource)object);
            }
        });
    }

    @Override
    public Object getDynamicSecurityDomain(Object object) {
        return object;
    }

    @Override
    public Class<?> getStaticSecurityDomainClassInternal() {
        return CodeSource.class;
    }

    private static class Loader
    extends SecureClassLoader
    implements GeneratedClassLoader {
        private final CodeSource codeSource;

        Loader(ClassLoader classLoader, CodeSource codeSource) {
            super(classLoader);
            this.codeSource = codeSource;
        }

        @Override
        public Class<?> defineClass(String string2, byte[] arrby) {
            return this.defineClass(string2, arrby, 0, arrby.length, this.codeSource);
        }

        @Override
        public void linkClass(Class<?> class_) {
            this.resolveClass(class_);
        }
    }

    public static abstract class SecureCaller {
        public abstract Object call(Callable var1, Context var2, Scriptable var3, Scriptable var4, Object[] var5);
    }

}

