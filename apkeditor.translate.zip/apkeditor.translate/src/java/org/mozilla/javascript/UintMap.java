/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.Serializable
 *  java.lang.ClassNotFoundException
 *  java.lang.Object
 *  java.lang.System
 */
package org.mozilla.javascript;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import org.mozilla.javascript.Kit;

public class UintMap
implements Serializable {
    private static final int A = -1640531527;
    private static final int DELETED = -2;
    private static final int EMPTY = -1;
    private static final boolean check = false;
    static final long serialVersionUID = 4242698212885848444L;
    private transient int ivaluesShift;
    private int keyCount;
    private transient int[] keys;
    private transient int occupiedCount;
    private int power;
    private transient Object[] values;

    public UintMap() {
        this(4);
    }

    public UintMap(int n) {
        if (n < 0) {
            Kit.codeBug();
        }
        int n2 = n * 4 / 3;
        int n3 = 2;
        while (1 << n3 < n2) {
            ++n3;
        }
        this.power = n3;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int ensureIndex(int n, boolean bl) {
        int n2 = -1;
        int n3 = -1;
        int[] arrn = this.keys;
        if (arrn != null) {
            int n4 = n * -1640531527;
            n2 = n4 >>> 32 - this.power;
            int n5 = arrn[n2];
            if (n5 == n) {
                return n2;
            }
            if (n5 != -1) {
                int n6;
                if (n5 == -2) {
                    n3 = n2;
                }
                int n7 = -1 + (1 << this.power);
                int n8 = UintMap.tableLookupStep(n4, n7, this.power);
                do {
                    if ((n6 = arrn[n2 = n7 & n2 + n8]) == n) {
                        return n2;
                    }
                    if (n6 != -2 || n3 >= 0) continue;
                    n3 = n2;
                } while (n6 != -1);
            }
        }
        if (n3 >= 0) {
            n2 = n3;
        } else {
            if (arrn == null || 4 * this.occupiedCount >= 3 * (1 << this.power)) {
                this.rehashTable(bl);
                return this.insertNewKey(n);
            }
            this.occupiedCount = 1 + this.occupiedCount;
        }
        arrn[n2] = n;
        this.keyCount = 1 + this.keyCount;
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private int findIndex(int n) {
        int n2;
        int[] arrn = this.keys;
        if (arrn == null) return -1;
        int n3 = n * -1640531527;
        int n4 = n3 >>> 32 - this.power;
        int n5 = arrn[n4];
        if (n5 == n) {
            return n4;
        }
        if (n5 == -1) return -1;
        int n6 = -1 + (1 << this.power);
        int n7 = UintMap.tableLookupStep(n3, n6, this.power);
        do {
            if ((n2 = arrn[n4 = n6 & n4 + n7]) == n) return n4;
        } while (n2 != -1);
        return -1;
    }

    private int insertNewKey(int n) {
        int[] arrn = this.keys;
        int n2 = n * -1640531527;
        int n3 = n2 >>> 32 - this.power;
        if (arrn[n3] != -1) {
            int n4 = -1 + (1 << this.power);
            int n5 = UintMap.tableLookupStep(n2, n4, this.power);
            while (arrn[n3 = n4 & n3 + n5] != -1) {
            }
        }
        arrn[n3] = n;
        this.occupiedCount = 1 + this.occupiedCount;
        this.keyCount = 1 + this.keyCount;
        return n3;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        int n = this.keyCount;
        if (n != 0) {
            this.keyCount = 0;
            boolean bl = objectInputStream.readBoolean();
            boolean bl2 = objectInputStream.readBoolean();
            int n2 = 1 << this.power;
            if (bl) {
                this.keys = new int[n2 * 2];
                this.ivaluesShift = n2;
            } else {
                this.keys = new int[n2];
            }
            for (int i = 0; i != n2; ++i) {
                this.keys[i] = -1;
            }
            if (bl2) {
                this.values = new Object[n2];
            }
            for (int i = 0; i != n; ++i) {
                int n3 = this.insertNewKey(objectInputStream.readInt());
                if (bl) {
                    int n4;
                    this.keys[n3 + this.ivaluesShift] = n4 = objectInputStream.readInt();
                }
                if (!bl2) continue;
                this.values[n3] = objectInputStream.readObject();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void rehashTable(boolean bl) {
        if (this.keys != null && 2 * this.keyCount >= this.occupiedCount) {
            this.power = 1 + this.power;
        }
        int n = 1 << this.power;
        int[] arrn = this.keys;
        int n2 = this.ivaluesShift;
        if (n2 == 0 && !bl) {
            this.keys = new int[n];
        } else {
            this.ivaluesShift = n;
            this.keys = new int[n * 2];
        }
        for (int i = 0; i != n; ++i) {
            this.keys[i] = -1;
        }
        Object[] arrobject = this.values;
        if (arrobject != null) {
            this.values = new Object[n];
        }
        int n3 = this.keyCount;
        this.occupiedCount = 0;
        if (n3 != 0) {
            this.keyCount = 0;
            int n4 = 0;
            int n5 = n3;
            while (n5 != 0) {
                int n6 = arrn[n4];
                if (n6 != -1 && n6 != -2) {
                    int n7 = this.insertNewKey(n6);
                    if (arrobject != null) {
                        this.values[n7] = arrobject[n4];
                    }
                    if (n2 != 0) {
                        this.keys[n7 + this.ivaluesShift] = arrn[n2 + n4];
                    }
                    --n5;
                }
                ++n4;
            }
        }
    }

    private static int tableLookupStep(int n, int n2, int n3) {
        int n4 = 32 - n3 * 2;
        if (n4 >= 0) {
            return 1 | n2 & n >>> n4;
        }
        return 1 | n & n2 >>> -n4;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
        int n = this.keyCount;
        if (n != 0) {
            boolean bl = this.ivaluesShift != 0;
            boolean bl2 = this.values != null;
            objectOutputStream.writeBoolean(bl);
            objectOutputStream.writeBoolean(bl2);
            int n2 = 0;
            while (n != 0) {
                int n3 = this.keys[n2];
                if (n3 != -1 && n3 != -2) {
                    --n;
                    objectOutputStream.writeInt(n3);
                    if (bl) {
                        objectOutputStream.writeInt(this.keys[n2 + this.ivaluesShift]);
                    }
                    if (bl2) {
                        objectOutputStream.writeObject(this.values[n2]);
                    }
                }
                ++n2;
            }
        }
    }

    public void clear() {
        int n = 1 << this.power;
        if (this.keys != null) {
            for (int i = 0; i != n; ++i) {
                this.keys[i] = -1;
            }
            if (this.values != null) {
                for (int i = 0; i != n; ++i) {
                    this.values[i] = null;
                }
            }
        }
        this.ivaluesShift = 0;
        this.keyCount = 0;
        this.occupiedCount = 0;
    }

    public int getExistingInt(int n) {
        int n2;
        if (n < 0) {
            Kit.codeBug();
        }
        if ((n2 = this.findIndex(n)) >= 0) {
            int n3 = this.ivaluesShift;
            int n4 = 0;
            if (n3 != 0) {
                n4 = this.keys[n2 + this.ivaluesShift];
            }
            return n4;
        }
        Kit.codeBug();
        return 0;
    }

    public int getInt(int n, int n2) {
        block5 : {
            block4 : {
                int n3;
                if (n < 0) {
                    Kit.codeBug();
                }
                if ((n3 = this.findIndex(n)) < 0) break block4;
                if (this.ivaluesShift == 0) break block5;
                n2 = this.keys[n3 + this.ivaluesShift];
            }
            return n2;
        }
        return 0;
    }

    public int[] getKeys() {
        int[] arrn = this.keys;
        int n = this.keyCount;
        int[] arrn2 = new int[n];
        int n2 = 0;
        while (n != 0) {
            int n3 = arrn[n2];
            if (n3 != -1 && n3 != -2) {
                arrn2[--n] = n3;
            }
            ++n2;
        }
        return arrn2;
    }

    public Object getObject(int n) {
        int n2;
        if (n < 0) {
            Kit.codeBug();
        }
        if (this.values != null && (n2 = this.findIndex(n)) >= 0) {
            return this.values[n2];
        }
        return null;
    }

    public boolean has(int n) {
        if (n < 0) {
            Kit.codeBug();
        }
        return this.findIndex(n) >= 0;
    }

    public boolean isEmpty() {
        return this.keyCount == 0;
    }

    public void put(int n, int n2) {
        if (n < 0) {
            Kit.codeBug();
        }
        int n3 = this.ensureIndex(n, true);
        if (this.ivaluesShift == 0) {
            int n4 = 1 << this.power;
            if (this.keys.length != n4 * 2) {
                int[] arrn = new int[n4 * 2];
                System.arraycopy((Object)this.keys, (int)0, (Object)arrn, (int)0, (int)n4);
                this.keys = arrn;
            }
            this.ivaluesShift = n4;
        }
        this.keys[n3 + this.ivaluesShift] = n2;
    }

    public void put(int n, Object object) {
        if (n < 0) {
            Kit.codeBug();
        }
        int n2 = this.ensureIndex(n, false);
        if (this.values == null) {
            this.values = new Object[1 << this.power];
        }
        this.values[n2] = object;
    }

    public void remove(int n) {
        int n2;
        if (n < 0) {
            Kit.codeBug();
        }
        if ((n2 = this.findIndex(n)) >= 0) {
            this.keys[n2] = -2;
            this.keyCount = -1 + this.keyCount;
            if (this.values != null) {
                this.values[n2] = null;
            }
            if (this.ivaluesShift != 0) {
                this.keys[n2 + this.ivaluesShift] = 0;
            }
        }
    }

    public int size() {
        return this.keyCount;
    }
}

