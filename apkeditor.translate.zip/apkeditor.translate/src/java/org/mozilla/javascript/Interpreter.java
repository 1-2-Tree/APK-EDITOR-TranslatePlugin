/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.PrintStream
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.CloneNotSupportedException
 *  java.lang.Cloneable
 *  java.lang.IllegalStateException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 */
package org.mozilla.javascript;

import java.io.PrintStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.CodeGenerator;
import org.mozilla.javascript.CompilerEnvirons;
import org.mozilla.javascript.ConsString;
import org.mozilla.javascript.ConstProperties;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Evaluator;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Icode;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.InterpretedFunction;
import org.mozilla.javascript.InterpreterData;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.NativeContinuation;
import org.mozilla.javascript.NativeWith;
import org.mozilla.javascript.ObjArray;
import org.mozilla.javascript.RhinoException;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.ScriptStackElement;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.SecurityController;
import org.mozilla.javascript.SecurityUtilities;
import org.mozilla.javascript.UintMap;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.UniqueTag;
import org.mozilla.javascript.ast.ScriptNode;
import org.mozilla.javascript.debug.DebugFrame;
import org.mozilla.javascript.debug.DebuggableScript;
import org.mozilla.javascript.debug.Debugger;

public final class Interpreter
extends Icode
implements Evaluator {
    static final int EXCEPTION_HANDLER_SLOT = 2;
    static final int EXCEPTION_LOCAL_SLOT = 4;
    static final int EXCEPTION_SCOPE_SLOT = 5;
    static final int EXCEPTION_SLOT_SIZE = 6;
    static final int EXCEPTION_TRY_END_SLOT = 1;
    static final int EXCEPTION_TRY_START_SLOT = 0;
    static final int EXCEPTION_TYPE_SLOT = 3;
    InterpreterData itsData;

    private static void addInstructionCount(Context context, CallFrame callFrame, int n) {
        context.instructionCount += n + (callFrame.pc - callFrame.pcPrevBranch);
        if (context.instructionCount > context.instructionThreshold) {
            context.observeInstructionCount(context.instructionCount);
            context.instructionCount = 0;
        }
    }

    private static int bytecodeSpan(int n) {
        int n2 = 3;
        switch (n) {
            default: {
                if (Interpreter.validBytecode(n)) break;
                throw Kit.codeBug();
            }
            case -21: {
                n2 = 5;
            }
            case -63: 
            case -62: 
            case -54: 
            case -46: 
            case -39: 
            case -27: 
            case -26: 
            case -23: 
            case -6: 
            case 5: 
            case 6: 
            case 7: 
            case 50: 
            case 72: {
                return n2;
            }
            case 57: {
                return 2;
            }
            case -11: 
            case -10: 
            case -9: 
            case -8: 
            case -7: {
                return 2;
            }
            case -28: {
                return 5;
            }
            case -38: {
                return 2;
            }
            case -40: {
                return 5;
            }
            case -45: {
                return 2;
            }
            case -47: {
                return 5;
            }
            case -61: 
            case -49: 
            case -48: {
                return 2;
            }
        }
        return 1;
    }

    public static NativeContinuation captureContinuation(Context context) {
        if (context.lastInterpreterFrame == null || !(context.lastInterpreterFrame instanceof CallFrame)) {
            throw new IllegalStateException("Interpreter frames not found");
        }
        return Interpreter.captureContinuation(context, (CallFrame)context.lastInterpreterFrame, true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static NativeContinuation captureContinuation(Context context, CallFrame callFrame, boolean bl) {
        NativeContinuation nativeContinuation = new NativeContinuation();
        ScriptRuntime.setObjectProtoAndParent(nativeContinuation, ScriptRuntime.getTopCallScope(context));
        CallFrame callFrame2 = callFrame;
        CallFrame callFrame3 = callFrame;
        while (callFrame2 != null && !callFrame2.frozen) {
            callFrame2.frozen = true;
            for (int i = 1 + callFrame2.savedStackTop; i != callFrame2.stack.length; ++i) {
                callFrame2.stack[i] = null;
                callFrame2.stackAttributes[i] = 0;
            }
            if (callFrame2.savedCallOp == 38) {
                callFrame2.stack[callFrame2.savedStackTop] = null;
            } else if (callFrame2.savedCallOp != 30) {
                Kit.codeBug();
            }
            callFrame3 = callFrame2;
            callFrame2 = callFrame2.parentFrame;
        }
        if (bl) {
            while (callFrame3.parentFrame != null) {
                callFrame3 = callFrame3.parentFrame;
            }
            if (!callFrame3.isContinuationsTopFrame) {
                throw new IllegalStateException("Cannot capture continuation from JavaScript code not called directly by executeScriptWithContinuations or callFunctionWithContinuations");
            }
        }
        nativeContinuation.initImplementation(callFrame);
        return nativeContinuation;
    }

    private static CallFrame captureFrameForGenerator(CallFrame callFrame) {
        callFrame.frozen = true;
        CallFrame callFrame2 = callFrame.cloneFrozen();
        callFrame.frozen = false;
        callFrame2.parentFrame = null;
        callFrame2.frameIndex = 0;
        return callFrame2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void doAdd(Object[] arrobject, double[] arrd, int n, Context context) {
        double d;
        boolean bl;
        Object object = arrobject[n + 1];
        Object object2 = arrobject[n];
        if (object == UniqueTag.DOUBLE_MARK) {
            d = arrd[n + 1];
            if (object2 == UniqueTag.DOUBLE_MARK) {
                arrd[n] = d + arrd[n];
                return;
            }
            bl = true;
        } else {
            if (object2 != UniqueTag.DOUBLE_MARK) {
                if (object2 instanceof Scriptable || object instanceof Scriptable) {
                    arrobject[n] = ScriptRuntime.add(object2, object, context);
                    return;
                }
                if (object2 instanceof CharSequence || object instanceof CharSequence) {
                    arrobject[n] = new ConsString(ScriptRuntime.toCharSequence(object2), ScriptRuntime.toCharSequence(object));
                    return;
                }
                double d2 = object2 instanceof Number ? ((Number)object2).doubleValue() : ScriptRuntime.toNumber(object2);
                double d3 = object instanceof Number ? ((Number)object).doubleValue() : ScriptRuntime.toNumber(object);
                arrobject[n] = UniqueTag.DOUBLE_MARK;
                arrd[n] = d2 + d3;
                return;
            }
            d = arrd[n];
            object2 = object;
            bl = false;
        }
        if (object2 instanceof Scriptable) {
            void var17_10;
            Number number = ScriptRuntime.wrapNumber(d);
            if (!bl) {
                Object object3 = object2;
                object2 = number;
                Object object4 = object3;
            }
            arrobject[n] = ScriptRuntime.add(object2, var17_10, context);
            return;
        }
        if (object2 instanceof CharSequence) {
            CharSequence charSequence = (CharSequence)object2;
            CharSequence charSequence2 = ScriptRuntime.toCharSequence(d);
            if (bl) {
                arrobject[n] = new ConsString(charSequence, charSequence2);
                return;
            }
            arrobject[n] = new ConsString(charSequence2, charSequence);
            return;
        }
        double d4 = object2 instanceof Number ? ((Number)object2).doubleValue() : ScriptRuntime.toNumber(object2);
        arrobject[n] = UniqueTag.DOUBLE_MARK;
        arrd[n] = d4 + d;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int doArithmetic(CallFrame callFrame, int n, Object[] arrobject, double[] arrd, int n2) {
        double d = Interpreter.stack_double(callFrame, n2);
        int n3 = n2 - 1;
        double d2 = Interpreter.stack_double(callFrame, n3);
        arrobject[n3] = UniqueTag.DOUBLE_MARK;
        switch (n) {
            case 22: {
                d2 -= d;
                break;
            }
            case 23: {
                d2 *= d;
                break;
            }
            case 24: {
                d2 /= d;
                break;
            }
            case 25: {
                d2 %= d;
                break;
            }
        }
        arrd[n3] = d2;
        return n3;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int doBitOp(CallFrame callFrame, int n, Object[] arrobject, double[] arrd, int n2) {
        int n3 = Interpreter.stack_int32(callFrame, n2 - 1);
        int n4 = Interpreter.stack_int32(callFrame, n2);
        int n5 = n2 - 1;
        arrobject[n5] = UniqueTag.DOUBLE_MARK;
        switch (n) {
            case 11: {
                n3 &= n4;
                break;
            }
            case 9: {
                n3 |= n4;
                break;
            }
            case 10: {
                n3 ^= n4;
                break;
            }
            case 18: {
                n3 <<= n4;
                break;
            }
            case 19: {
                n3 >>= n4;
                break;
            }
        }
        arrd[n5] = n3;
        return n5;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int doCallSpecial(Context context, CallFrame callFrame, Object[] arrobject, double[] arrd, int n, byte[] arrby, int n2) {
        int n3;
        int n4 = 255 & arrby[callFrame.pc];
        boolean bl = arrby[1 + callFrame.pc] != 0;
        int n5 = Interpreter.getIndex(arrby, 2 + callFrame.pc);
        if (bl) {
            n3 = n - n2;
            Object object = arrobject[n3];
            if (object == UniqueTag.DOUBLE_MARK) {
                object = ScriptRuntime.wrapNumber(arrd[n3]);
            }
            arrobject[n3] = ScriptRuntime.newSpecial(context, object, Interpreter.getArgsArray(arrobject, arrd, n3 + 1, n2), callFrame.scope, n4);
        } else {
            n3 = n - (n2 + 1);
            Scriptable scriptable = (Scriptable)arrobject[n3 + 1];
            arrobject[n3] = ScriptRuntime.callSpecial(context, (Callable)arrobject[n3], scriptable, Interpreter.getArgsArray(arrobject, arrd, n3 + 2, n2), callFrame.scope, callFrame.thisObj, n4, callFrame.idata.itsSourceFile, n5);
        }
        callFrame.pc = 4 + callFrame.pc;
        return n3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int doCompare(CallFrame var0, int var1_1, Object[] var2_2, double[] var3_3, int var4_4) {
        block14 : {
            var5_5 = true;
            var6_6 = var4_4 - 1;
            var7_7 = var2_2[var6_6 + 1];
            var8_8 = var2_2[var6_6];
            if (var7_7 != UniqueTag.DOUBLE_MARK) break block14;
            var9_9 = var3_3[var6_6 + 1];
            var11_10 = Interpreter.stack_double(var0, var6_6);
            ** GOTO lbl13
        }
        if (var8_8 == UniqueTag.DOUBLE_MARK) {
            var9_9 = ScriptRuntime.toNumber(var7_7);
            var11_10 = var3_3[var6_6];
lbl13: // 2 sources:
            switch (var1_1) {
                default: {
                    throw Kit.codeBug();
                }
                case 17: {
                    if (var11_10 >= var9_9) break;
                    var5_5 = false;
                    break;
                }
                case 15: {
                    if (var11_10 <= var9_9) break;
                    var5_5 = false;
                    break;
                }
                case 16: {
                    if (var11_10 > var9_9) break;
                    var5_5 = false;
                    break;
                }
                case 14: {
                    if (var11_10 < var9_9) break;
                    var5_5 = false;
                    break;
                }
            }
        } else {
            switch (var1_1) {
                default: {
                    throw Kit.codeBug();
                }
                case 17: {
                    var5_5 = ScriptRuntime.cmp_LE(var7_7, var8_8);
                    break;
                }
                case 15: {
                    var5_5 = ScriptRuntime.cmp_LE(var8_8, var7_7);
                    break;
                }
                case 16: {
                    var5_5 = ScriptRuntime.cmp_LT(var7_7, var8_8);
                    break;
                }
                case 14: {
                    var5_5 = ScriptRuntime.cmp_LT(var8_8, var7_7);
                }
            }
        }
        var2_2[var6_6] = ScriptRuntime.wrapBoolean(var5_5);
        return var6_6;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int doDelName(Context context, CallFrame callFrame, int n, Object[] arrobject, double[] arrd, int n2) {
        int n3;
        Object object;
        Object object2 = arrobject[n2];
        if (object2 == UniqueTag.DOUBLE_MARK) {
            object2 = ScriptRuntime.wrapNumber(arrd[n2]);
        }
        if ((object = arrobject[n3 = n2 - 1]) == UniqueTag.DOUBLE_MARK) {
            object = ScriptRuntime.wrapNumber(arrd[n3]);
        }
        Scriptable scriptable = callFrame.scope;
        boolean bl = n == 0;
        arrobject[n3] = ScriptRuntime.delete(object, object2, context, scriptable, bl);
        return n3;
    }

    private static int doElemIncDec(Context context, CallFrame callFrame, byte[] arrby, Object[] arrobject, double[] arrd, int n) {
        int n2;
        Object object;
        Object object2 = arrobject[n];
        if (object2 == UniqueTag.DOUBLE_MARK) {
            object2 = ScriptRuntime.wrapNumber(arrd[n]);
        }
        if ((object = arrobject[n2 = n - 1]) == UniqueTag.DOUBLE_MARK) {
            object = ScriptRuntime.wrapNumber(arrd[n2]);
        }
        arrobject[n2] = ScriptRuntime.elemIncrDecr(object, object2, context, callFrame.scope, arrby[callFrame.pc]);
        callFrame.pc = 1 + callFrame.pc;
        return n2;
    }

    private static boolean doEquals(Object[] arrobject, double[] arrd, int n) {
        Object object = arrobject[n + 1];
        Object object2 = arrobject[n];
        if (object == UniqueTag.DOUBLE_MARK) {
            if (object2 == UniqueTag.DOUBLE_MARK) {
                return arrd[n] == arrd[n + 1];
            }
            return ScriptRuntime.eqNumber(arrd[n + 1], object2);
        }
        if (object2 == UniqueTag.DOUBLE_MARK) {
            return ScriptRuntime.eqNumber(arrd[n], object);
        }
        return ScriptRuntime.eq(object2, object);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int doGetElem(Context context, CallFrame callFrame, Object[] arrobject, double[] arrd, int n) {
        Object object;
        int n2 = n - 1;
        Object object2 = arrobject[n2];
        if (object2 == UniqueTag.DOUBLE_MARK) {
            object2 = ScriptRuntime.wrapNumber(arrd[n2]);
        }
        Object object3 = (object = arrobject[n2 + 1]) != UniqueTag.DOUBLE_MARK ? ScriptRuntime.getObjectElem(object2, object, context, callFrame.scope) : ScriptRuntime.getObjectIndex(object2, arrd[n2 + 1], context, callFrame.scope);
        arrobject[n2] = object3;
        return n2;
    }

    private static int doGetVar(CallFrame callFrame, Object[] arrobject, double[] arrd, int n, Object[] arrobject2, double[] arrd2, int n2) {
        int n3 = n + 1;
        if (!callFrame.useActivation) {
            arrobject[n3] = arrobject2[n2];
            arrd[n3] = arrd2[n2];
            return n3;
        }
        String string2 = callFrame.idata.argNames[n2];
        arrobject[n3] = callFrame.scope.get(string2, callFrame.scope);
        return n3;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int doInOrInstanceof(Context context, int n, Object[] arrobject, double[] arrd, int n2) {
        int n3;
        Object object;
        Object object2 = arrobject[n2];
        if (object2 == UniqueTag.DOUBLE_MARK) {
            object2 = ScriptRuntime.wrapNumber(arrd[n2]);
        }
        if ((object = arrobject[n3 = n2 - 1]) == UniqueTag.DOUBLE_MARK) {
            object = ScriptRuntime.wrapNumber(arrd[n3]);
        }
        boolean bl = n == 52 ? ScriptRuntime.in(object, object2, context) : ScriptRuntime.instanceOf(object, object2, context);
        arrobject[n3] = ScriptRuntime.wrapBoolean(bl);
        return n3;
    }

    private static int doRefMember(Context context, Object[] arrobject, double[] arrd, int n, int n2) {
        int n3;
        Object object;
        Object object2 = arrobject[n];
        if (object2 == UniqueTag.DOUBLE_MARK) {
            object2 = ScriptRuntime.wrapNumber(arrd[n]);
        }
        if ((object = arrobject[n3 = n - 1]) == UniqueTag.DOUBLE_MARK) {
            object = ScriptRuntime.wrapNumber(arrd[n3]);
        }
        arrobject[n3] = ScriptRuntime.memberRef(object, object2, context, n2);
        return n3;
    }

    private static int doRefNsMember(Context context, Object[] arrobject, double[] arrd, int n, int n2) {
        int n3;
        Object object;
        Object object2;
        int n4;
        Object object3 = arrobject[n];
        if (object3 == UniqueTag.DOUBLE_MARK) {
            object3 = ScriptRuntime.wrapNumber(arrd[n]);
        }
        if ((object = arrobject[n3 = n - 1]) == UniqueTag.DOUBLE_MARK) {
            object = ScriptRuntime.wrapNumber(arrd[n3]);
        }
        if ((object2 = arrobject[n4 = n3 - 1]) == UniqueTag.DOUBLE_MARK) {
            object2 = ScriptRuntime.wrapNumber(arrd[n4]);
        }
        arrobject[n4] = ScriptRuntime.memberRef(object2, object, object3, context, n2);
        return n4;
    }

    private static int doRefNsName(Context context, CallFrame callFrame, Object[] arrobject, double[] arrd, int n, int n2) {
        int n3;
        Object object;
        Object object2 = arrobject[n];
        if (object2 == UniqueTag.DOUBLE_MARK) {
            object2 = ScriptRuntime.wrapNumber(arrd[n]);
        }
        if ((object = arrobject[n3 = n - 1]) == UniqueTag.DOUBLE_MARK) {
            object = ScriptRuntime.wrapNumber(arrd[n3]);
        }
        arrobject[n3] = ScriptRuntime.nameRef(object, object2, context, callFrame.scope, n2);
        return n3;
    }

    private static int doSetConstVar(CallFrame callFrame, Object[] arrobject, double[] arrd, int n, Object[] arrobject2, double[] arrd2, int[] arrn, int n2) {
        if (!callFrame.useActivation) {
            if ((1 & arrn[n2]) == 0) {
                throw Context.reportRuntimeError1("msg.var.redecl", callFrame.idata.argNames[n2]);
            }
            if ((8 & arrn[n2]) != 0) {
                arrobject2[n2] = arrobject[n];
                arrn[n2] = -9 & arrn[n2];
                arrd2[n2] = arrd[n];
            }
            return n;
        }
        Object object = arrobject[n];
        if (object == UniqueTag.DOUBLE_MARK) {
            object = ScriptRuntime.wrapNumber(arrd[n]);
        }
        String string2 = callFrame.idata.argNames[n2];
        if (callFrame.scope instanceof ConstProperties) {
            ((ConstProperties)((Object)callFrame.scope)).putConst(string2, callFrame.scope, object);
            return n;
        }
        throw Kit.codeBug();
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int doSetElem(Context context, CallFrame callFrame, Object[] arrobject, double[] arrd, int n) {
        Object object;
        Object object2;
        int n2 = n - 2;
        Object object3 = arrobject[n2 + 2];
        if (object3 == UniqueTag.DOUBLE_MARK) {
            object3 = ScriptRuntime.wrapNumber(arrd[n2 + 2]);
        }
        if ((object = arrobject[n2]) == UniqueTag.DOUBLE_MARK) {
            object = ScriptRuntime.wrapNumber(arrd[n2]);
        }
        Object object4 = (object2 = arrobject[n2 + 1]) != UniqueTag.DOUBLE_MARK ? ScriptRuntime.setObjectElem(object, object2, object3, context, callFrame.scope) : ScriptRuntime.setObjectIndex(object, arrd[n2 + 1], object3, context, callFrame.scope);
        arrobject[n2] = object4;
        return n2;
    }

    private static int doSetVar(CallFrame callFrame, Object[] arrobject, double[] arrd, int n, Object[] arrobject2, double[] arrd2, int[] arrn, int n2) {
        if (!callFrame.useActivation) {
            if ((1 & arrn[n2]) == 0) {
                arrobject2[n2] = arrobject[n];
                arrd2[n2] = arrd[n];
            }
            return n;
        }
        Object object = arrobject[n];
        if (object == UniqueTag.DOUBLE_MARK) {
            object = ScriptRuntime.wrapNumber(arrd[n]);
        }
        String string2 = callFrame.idata.argNames[n2];
        callFrame.scope.put(string2, callFrame.scope, object);
        return n;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean doShallowEquals(Object[] arrobject, double[] arrd, int n) {
        double d;
        boolean bl;
        double d2;
        Object object = arrobject[n + 1];
        Object object2 = arrobject[n];
        UniqueTag uniqueTag = UniqueTag.DOUBLE_MARK;
        if (object == uniqueTag) {
            d = arrd[n + 1];
            if (object2 == uniqueTag) {
                d2 = arrd[n];
            } else {
                boolean bl2 = object2 instanceof Number;
                bl = false;
                if (!bl2) return bl;
                d2 = ((Number)object2).doubleValue();
            }
        } else {
            if (object2 != uniqueTag) {
                return ScriptRuntime.shallowEq(object2, object);
            }
            d2 = arrd[n];
            boolean bl3 = object instanceof Number;
            bl = false;
            if (!bl3) return bl;
            d = ((Number)object).doubleValue();
        }
        double d3 = d2 DCMPL d;
        bl = false;
        if (d3 != false) return bl;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int doVarIncDec(Context context, CallFrame callFrame, Object[] arrobject, double[] arrd, int n, Object[] arrobject2, double[] arrd2, int[] arrn, int n2) {
        int n3 = n + 1;
        byte by = callFrame.idata.itsICode[callFrame.pc];
        if (!callFrame.useActivation) {
            Object object = arrobject2[n2];
            double d = object == UniqueTag.DOUBLE_MARK ? arrd2[n2] : ScriptRuntime.toNumber(object);
            double d2 = (by & 1) == 0 ? d + 1.0 : d - 1.0;
            boolean bl = (by & 2) != 0;
            if ((1 & arrn[n2]) == 0) {
                if (object != UniqueTag.DOUBLE_MARK) {
                    arrobject2[n2] = UniqueTag.DOUBLE_MARK;
                }
                arrd2[n2] = d2;
                arrobject[n3] = UniqueTag.DOUBLE_MARK;
                if (!bl) {
                    d = d2;
                }
                arrd[n3] = d;
            } else if (bl && object != UniqueTag.DOUBLE_MARK) {
                arrobject[n3] = object;
            } else {
                arrobject[n3] = UniqueTag.DOUBLE_MARK;
                if (!bl) {
                    d = d2;
                }
                arrd[n3] = d;
            }
        } else {
            String string2 = callFrame.idata.argNames[n2];
            arrobject[n3] = ScriptRuntime.nameIncrDecr(callFrame.scope, string2, context, by);
        }
        callFrame.pc = 1 + callFrame.pc;
        return n3;
    }

    static void dumpICode(InterpreterData interpreterData) {
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void enterFrame(Context context, CallFrame callFrame, Object[] arrobject, boolean bl) {
        boolean bl2 = callFrame.idata.itsNeedsActivation;
        boolean bl3 = callFrame.debuggerFrame != null;
        if (bl2 || bl3) {
            Scriptable scriptable = callFrame.scope;
            if (scriptable == null) {
                Kit.codeBug();
            } else if (bl) {
                while (scriptable instanceof NativeWith) {
                    if ((scriptable = scriptable.getParentScope()) != null && (callFrame.parentFrame == null || callFrame.parentFrame.scope != scriptable)) continue;
                    Kit.codeBug();
                    break;
                }
            }
            if (bl3) {
                callFrame.debuggerFrame.onEnter(context, scriptable, callFrame.thisObj, arrobject);
            }
            if (bl2) {
                ScriptRuntime.enterActivationFunction(context, scriptable);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void exitFrame(Context context, CallFrame callFrame, Object object) {
        Object object2;
        block7 : {
            double d;
            if (callFrame.idata.itsNeedsActivation) {
                ScriptRuntime.exitActivationFunction(context);
            }
            if (callFrame.debuggerFrame == null) {
                return;
            }
            try {
                if (object instanceof Throwable) {
                    callFrame.debuggerFrame.onExit(context, true, object);
                    return;
                }
                ContinuationJump continuationJump = (ContinuationJump)object;
                object2 = continuationJump == null ? callFrame.result : continuationJump.result;
                if (object2 == UniqueTag.DOUBLE_MARK) {
                    d = continuationJump == null ? callFrame.resultDbl : continuationJump.resultDbl;
                }
                break block7;
            }
            catch (Throwable throwable) {
                System.err.println("RHINO USAGE WARNING: onExit terminated with exception");
                throwable.printStackTrace(System.err);
                return;
            }
            object2 = ScriptRuntime.wrapNumber(d);
        }
        callFrame.debuggerFrame.onExit(context, false, object2);
    }

    private static Object freezeGenerator(Context context, CallFrame callFrame, int n, GeneratorState generatorState) {
        if (generatorState.operation == 2) {
            throw ScriptRuntime.typeError0("msg.yield.closing");
        }
        callFrame.frozen = true;
        callFrame.result = callFrame.stack[n];
        callFrame.resultDbl = callFrame.sDbl[n];
        callFrame.savedStackTop = n;
        callFrame.pc = -1 + callFrame.pc;
        ScriptRuntime.exitActivationFunction(context);
        if (callFrame.result != UniqueTag.DOUBLE_MARK) {
            return callFrame.result;
        }
        return ScriptRuntime.wrapNumber(callFrame.resultDbl);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Object[] getArgsArray(Object[] arrobject, double[] arrd, int n, int n2) {
        if (n2 == 0) {
            return ScriptRuntime.emptyArgs;
        }
        Object[] arrobject2 = new Object[n2];
        int n3 = 0;
        while (n3 != n2) {
            Object object = arrobject[n];
            if (object == UniqueTag.DOUBLE_MARK) {
                object = ScriptRuntime.wrapNumber(arrd[n]);
            }
            arrobject2[n3] = object;
            ++n3;
            ++n;
        }
        return arrobject2;
    }

    static String getEncodedSource(InterpreterData interpreterData) {
        if (interpreterData.encodedSource == null) {
            return null;
        }
        return interpreterData.encodedSource.substring(interpreterData.encodedSourceStart, interpreterData.encodedSourceEnd);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int getExceptionHandler(CallFrame callFrame, boolean bl) {
        int[] arrn = callFrame.idata.itsExceptionTable;
        if (arrn == null) {
            return -1;
        }
        int n = -1 + callFrame.pc;
        int n2 = -1;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        while (n5 != arrn.length) {
            block7 : {
                int n6;
                int n7;
                block8 : {
                    n7 = arrn[n5 + 0];
                    n6 = arrn[n5 + 1];
                    if (n7 > n || n >= n6 || bl && arrn[n5 + 3] != 1) break block7;
                    if (n2 < 0) break block8;
                    if (n4 < n6) break block7;
                    if (n3 > n7) {
                        Kit.codeBug();
                    }
                    if (n4 == n6) {
                        Kit.codeBug();
                    }
                }
                n2 = n5;
                n3 = n7;
                n4 = n6;
            }
            n5 += 6;
        }
        return n2;
    }

    private static int getIndex(byte[] arrby, int n) {
        return (255 & arrby[n]) << 8 | 255 & arrby[n + 1];
    }

    private static int getInt(byte[] arrby, int n) {
        return arrby[n] << 24 | (255 & arrby[n + 1]) << 16 | (255 & arrby[n + 2]) << 8 | 255 & arrby[n + 3];
    }

    static int[] getLineNumbers(InterpreterData interpreterData) {
        int n;
        UintMap uintMap = new UintMap();
        byte[] arrby = interpreterData.itsICode;
        int n2 = arrby.length;
        for (int i = 0; i != n2; i += n) {
            byte by = arrby[i];
            n = Interpreter.bytecodeSpan(by);
            if (by != -26) continue;
            if (n != 3) {
                Kit.codeBug();
            }
            uintMap.put(Interpreter.getIndex(arrby, i + 1), 0);
        }
        return uintMap.getKeys();
    }

    private static int getShort(byte[] arrby, int n) {
        return arrby[n] << 8 | 255 & arrby[n + 1];
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void initFrame(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject, double[] arrd, int n, int n2, InterpretedFunction interpretedFunction, CallFrame callFrame, CallFrame callFrame2) {
        Object[] arrobject2;
        double[] arrd2;
        Scriptable scriptable3;
        int n3;
        int n4;
        int[] arrn;
        boolean bl;
        InterpreterData interpreterData = interpretedFunction.idata;
        boolean bl2 = interpreterData.itsNeedsActivation;
        Debugger debugger = context.debugger;
        DebugFrame debugFrame = null;
        if (debugger != null && (debugFrame = context.debugger.getFrame(context, interpreterData)) != null) {
            bl2 = true;
        }
        if (bl2) {
            if (arrd != null) {
                arrobject = Interpreter.getArgsArray(arrobject, arrd, n, n2);
            }
            n = 0;
            arrd = null;
        }
        if (interpreterData.itsFunctionType != 0) {
            scriptable3 = interpretedFunction.getParentScope();
            if (bl2) {
                scriptable3 = ScriptRuntime.createFunctionActivation(interpretedFunction, scriptable3, arrobject);
            }
        } else {
            scriptable3 = scriptable;
            ScriptRuntime.initScript(interpretedFunction, scriptable2, context, scriptable3, interpretedFunction.idata.evalScriptFlag);
        }
        if (interpreterData.itsNestedFunctions != null) {
            if (interpreterData.itsFunctionType != 0 && !interpreterData.itsNeedsActivation) {
                Kit.codeBug();
            }
            for (int i = 0; i < interpreterData.itsNestedFunctions.length; ++i) {
                if (interpreterData.itsNestedFunctions[i].itsFunctionType != 1) continue;
                Interpreter.initFunction(context, scriptable3, interpretedFunction, i);
            }
        }
        if ((n4 = interpreterData.itsMaxFrameArray) != 1 + ((n3 = -1 + (interpreterData.itsMaxVars + interpreterData.itsMaxLocals)) + interpreterData.itsMaxStack)) {
            Kit.codeBug();
        }
        if (callFrame2.stack != null && n4 <= callFrame2.stack.length) {
            bl = true;
            arrobject2 = callFrame2.stack;
            arrn = callFrame2.stackAttributes;
            arrd2 = callFrame2.sDbl;
        } else {
            arrobject2 = new Object[n4];
            arrn = new int[n4];
            arrd2 = new double[n4];
            bl = false;
        }
        int n5 = interpreterData.getParamAndVarCount();
        for (int i = 0; i < n5; ++i) {
            if (!interpreterData.getParamOrVarConst(i)) continue;
            arrn[i] = 13;
        }
        int n6 = interpreterData.argCount;
        if (n6 > n2) {
            n6 = n2;
        }
        callFrame2.parentFrame = callFrame;
        int n7 = callFrame == null ? 0 : 1 + callFrame.frameIndex;
        callFrame2.frameIndex = n7;
        if (callFrame2.frameIndex > context.getMaximumInterpreterStackDepth()) {
            throw Context.reportRuntimeError("Exceeded maximum stack depth");
        }
        callFrame2.frozen = false;
        callFrame2.fnOrScript = interpretedFunction;
        callFrame2.idata = interpreterData;
        callFrame2.stack = arrobject2;
        callFrame2.stackAttributes = arrn;
        callFrame2.sDbl = arrd2;
        callFrame2.varSource = callFrame2;
        callFrame2.localShift = interpreterData.itsMaxVars;
        callFrame2.emptyStackTop = n3;
        callFrame2.debuggerFrame = debugFrame;
        callFrame2.useActivation = bl2;
        callFrame2.thisObj = scriptable2;
        callFrame2.result = Undefined.instance;
        callFrame2.pc = 0;
        callFrame2.pcPrevBranch = 0;
        callFrame2.pcSourceLineStart = interpreterData.firstLinePC;
        callFrame2.scope = scriptable3;
        callFrame2.savedStackTop = n3;
        callFrame2.savedCallOp = 0;
        System.arraycopy((Object)arrobject, (int)n, (Object)arrobject2, (int)0, (int)n6);
        if (arrd != null) {
            System.arraycopy((Object)arrd, (int)n, (Object)arrd2, (int)0, (int)n6);
        }
        for (int i = n6; i != interpreterData.itsMaxVars; ++i) {
            arrobject2[i] = Undefined.instance;
        }
        if (bl) {
            for (int i = n3 + 1; i != arrobject2.length; ++i) {
                arrobject2[i] = null;
            }
        }
        Interpreter.enterFrame(context, callFrame2, arrobject, false);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static CallFrame initFrameForApplyOrCall(Context context, CallFrame callFrame, int n, Object[] arrobject, double[] arrd, int n2, int n3, Scriptable scriptable, IdFunctionObject idFunctionObject, InterpretedFunction interpretedFunction) {
        Scriptable scriptable2;
        if (n != 0) {
            Object object = arrobject[n2 + 2];
            UniqueTag uniqueTag = UniqueTag.DOUBLE_MARK;
            if (object == uniqueTag) {
                object = ScriptRuntime.wrapNumber(arrd[n2 + 2]);
            }
            Scriptable scriptable3 = callFrame.scope;
            scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable3);
        } else {
            scriptable2 = null;
        }
        if (scriptable2 == null) {
            scriptable2 = ScriptRuntime.getTopCallScope(context);
        }
        if (n3 == -55) {
            Interpreter.exitFrame(context, callFrame, null);
            callFrame = callFrame.parentFrame;
        } else {
            callFrame.savedStackTop = n2;
            callFrame.savedCallOp = n3;
        }
        CallFrame callFrame2 = new CallFrame();
        if (BaseFunction.isApply(idFunctionObject)) {
            Object[] arrobject2 = n < 2 ? ScriptRuntime.emptyArgs : ScriptRuntime.getApplyArguments(context, arrobject[n2 + 3]);
            Interpreter.initFrame(context, scriptable, scriptable2, arrobject2, null, 0, arrobject2.length, interpretedFunction, callFrame, callFrame2);
            return callFrame2;
        }
        for (int i = 1; i < n; ++i) {
            arrobject[i + (n2 + 1)] = arrobject[i + (n2 + 2)];
            arrd[i + (n2 + 1)] = arrd[i + (n2 + 2)];
        }
        int n4 = n < 2 ? 0 : n - 1;
        int n5 = n2 + 2;
        Interpreter.initFrame(context, scriptable, scriptable2, arrobject, arrd, n5, n4, interpretedFunction, callFrame, callFrame2);
        return callFrame2;
    }

    private static CallFrame initFrameForNoSuchMethod(Context context, CallFrame callFrame, int n, Object[] arrobject, double[] arrd, int n2, int n3, Scriptable scriptable, Scriptable scriptable2, ScriptRuntime.NoSuchMethodShim noSuchMethodShim, InterpretedFunction interpretedFunction) {
        int n4 = n2 + 2;
        Object[] arrobject2 = new Object[n];
        int n5 = 0;
        while (n5 < n) {
            Object object = arrobject[n4];
            if (object == UniqueTag.DOUBLE_MARK) {
                object = ScriptRuntime.wrapNumber(arrd[n4]);
            }
            arrobject2[n5] = object;
            ++n5;
            ++n4;
        }
        Object[] arrobject3 = new Object[]{noSuchMethodShim.methodName, context.newArray(scriptable2, arrobject2)};
        CallFrame callFrame2 = callFrame;
        CallFrame callFrame3 = new CallFrame();
        if (n3 == -55) {
            callFrame2 = callFrame.parentFrame;
            Interpreter.exitFrame(context, callFrame, null);
        }
        Interpreter.initFrame(context, scriptable2, scriptable, arrobject3, null, 0, 2, interpretedFunction, callFrame2, callFrame3);
        if (n3 != -55) {
            callFrame.savedStackTop = n2;
            callFrame.savedCallOp = n3;
        }
        return callFrame3;
    }

    private static void initFunction(Context context, Scriptable scriptable, InterpretedFunction interpretedFunction, int n) {
        InterpretedFunction interpretedFunction2 = InterpretedFunction.createFunction(context, scriptable, interpretedFunction, n);
        ScriptRuntime.initFunction(context, scriptable, interpretedFunction2, interpretedFunction2.idata.itsFunctionType, interpretedFunction.idata.evalScriptFlag);
    }

    static Object interpret(InterpretedFunction interpretedFunction, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!ScriptRuntime.hasTopCall(context)) {
            Kit.codeBug();
        }
        if (context.interpreterSecurityDomain != interpretedFunction.securityDomain) {
            Object object = context.interpreterSecurityDomain;
            context.interpreterSecurityDomain = interpretedFunction.securityDomain;
            try {
                Object object2 = interpretedFunction.securityController.callWithDomain(interpretedFunction.securityDomain, context, interpretedFunction, scriptable, scriptable2, arrobject);
                return object2;
            }
            finally {
                context.interpreterSecurityDomain = object;
            }
        }
        CallFrame callFrame = new CallFrame();
        Interpreter.initFrame(context, scriptable, scriptable2, arrobject, null, 0, arrobject.length, interpretedFunction, null, callFrame);
        callFrame.isContinuationsTopFrame = context.isContinuationsTopCall;
        context.isContinuationsTopCall = false;
        return Interpreter.interpretLoop(context, callFrame, null);
    }

    /*
     * Exception decompiling
     */
    private static Object interpretLoop(Context var0, CallFrame var1_1, Object var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    private static boolean isFrameEnterExitRequired(CallFrame callFrame) {
        return callFrame.debuggerFrame != null || callFrame.idata.itsNeedsActivation;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static CallFrame processThrowable(Context context, Object object, CallFrame callFrame, int n, boolean bl) {
        if (n >= 0) {
            if (callFrame.frozen) {
                callFrame = callFrame.cloneFrozen();
            }
            int[] arrn = callFrame.idata.itsExceptionTable;
            callFrame.pc = arrn[n + 2];
            if (bl) {
                callFrame.pcPrevBranch = callFrame.pc;
            }
            callFrame.savedStackTop = callFrame.emptyStackTop;
            int n2 = callFrame.localShift + arrn[n + 5];
            int n3 = callFrame.localShift + arrn[n + 4];
            callFrame.scope = (Scriptable)callFrame.stack[n2];
            callFrame.stack[n3] = object;
        } else {
            ContinuationJump continuationJump = (ContinuationJump)object;
            if (continuationJump.branchFrame != callFrame) {
                Kit.codeBug();
            }
            if (continuationJump.capturedFrame == null) {
                Kit.codeBug();
            }
            int n4 = 1 + continuationJump.capturedFrame.frameIndex;
            if (continuationJump.branchFrame != null) {
                n4 -= continuationJump.branchFrame.frameIndex;
            }
            int n5 = 0;
            CallFrame[] arrcallFrame = null;
            CallFrame callFrame2 = continuationJump.capturedFrame;
            for (int i = 0; i != n4; ++i) {
                if (!callFrame2.frozen) {
                    Kit.codeBug();
                }
                if (Interpreter.isFrameEnterExitRequired(callFrame2)) {
                    if (arrcallFrame == null) {
                        arrcallFrame = new CallFrame[n4 - i];
                    }
                    arrcallFrame[n5] = callFrame2;
                    ++n5;
                }
                callFrame2 = callFrame2.parentFrame;
            }
            while (n5 != 0) {
                Interpreter.enterFrame(context, (CallFrame)arrcallFrame[--n5], ScriptRuntime.emptyArgs, true);
            }
            callFrame = continuationJump.capturedFrame.cloneFrozen();
            Interpreter.setCallResult(callFrame, continuationJump.result, continuationJump.resultDbl);
        }
        callFrame.throwable = null;
        return callFrame;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Object restartContinuation(NativeContinuation nativeContinuation, Context context, Scriptable scriptable, Object[] arrobject) {
        if (!ScriptRuntime.hasTopCall(context)) {
            return ScriptRuntime.doTopCall(nativeContinuation, context, scriptable, null, arrobject);
        }
        Object object = arrobject.length == 0 ? Undefined.instance : arrobject[0];
        if ((CallFrame)nativeContinuation.getImplementation() == null) return object;
        ContinuationJump continuationJump = new ContinuationJump(nativeContinuation, null);
        continuationJump.result = object;
        return Interpreter.interpretLoop(context, null, continuationJump);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Object resumeGenerator(Context context, Scriptable scriptable, int n, Object object, Object object2) {
        CallFrame callFrame = (CallFrame)object;
        GeneratorState generatorState = new GeneratorState(n, object2);
        if (n == 2) {
            try {
                Object object3 = Interpreter.interpretLoop(context, callFrame, generatorState);
                return object3;
            }
            catch (RuntimeException runtimeException) {
                if (runtimeException == object2) return Undefined.instance;
                throw runtimeException;
            }
        }
        Object object4 = Interpreter.interpretLoop(context, callFrame, generatorState);
        if (generatorState.returnedException == null) return object4;
        throw generatorState.returnedException;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void setCallResult(CallFrame callFrame, Object object, double d) {
        if (callFrame.savedCallOp == 38) {
            callFrame.stack[callFrame.savedStackTop] = object;
            callFrame.sDbl[callFrame.savedStackTop] = d;
        } else if (callFrame.savedCallOp == 30) {
            if (object instanceof Scriptable) {
                callFrame.stack[callFrame.savedStackTop] = object;
            }
        } else {
            Kit.codeBug();
        }
        callFrame.savedCallOp = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean stack_boolean(CallFrame callFrame, int n) {
        Object object = callFrame.stack[n];
        if (object == Boolean.TRUE) return true;
        if (object == Boolean.FALSE) {
            return false;
        }
        if (object == UniqueTag.DOUBLE_MARK) {
            double d = callFrame.sDbl[n];
            if (d == d && d != 0.0) return true;
            return false;
        }
        if (object == null || object == Undefined.instance) {
            return false;
        }
        if (object instanceof Number) {
            double d = ((Number)object).doubleValue();
            if (d != d || d == 0.0) return false;
            return true;
        }
        if (!(object instanceof Boolean)) return ScriptRuntime.toBoolean(object);
        return (Boolean)object;
    }

    private static double stack_double(CallFrame callFrame, int n) {
        Object object = callFrame.stack[n];
        if (object != UniqueTag.DOUBLE_MARK) {
            return ScriptRuntime.toNumber(object);
        }
        return callFrame.sDbl[n];
    }

    private static int stack_int32(CallFrame callFrame, int n) {
        Object object = callFrame.stack[n];
        if (object == UniqueTag.DOUBLE_MARK) {
            return ScriptRuntime.toInt32(callFrame.sDbl[n]);
        }
        return ScriptRuntime.toInt32(object);
    }

    private static Object thawGenerator(CallFrame callFrame, int n, GeneratorState generatorState, int n2) {
        callFrame.frozen = false;
        int n3 = Interpreter.getIndex(callFrame.idata.itsICode, callFrame.pc);
        callFrame.pc = 2 + callFrame.pc;
        if (generatorState.operation == 1) {
            return new JavaScriptException(generatorState.value, callFrame.idata.itsSourceFile, n3);
        }
        if (generatorState.operation == 2) {
            return generatorState.value;
        }
        if (generatorState.operation != 0) {
            throw Kit.codeBug();
        }
        if (n2 == 72) {
            callFrame.stack[n] = generatorState.value;
        }
        return Scriptable.NOT_FOUND;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void captureStackInfo(RhinoException rhinoException) {
        Object[] arrobject;
        Context context = Context.getCurrentContext();
        if (context == null || context.lastInterpreterFrame == null) {
            rhinoException.interpreterStackInfo = null;
            rhinoException.interpreterLineData = null;
            return;
        }
        if (context.previousInterpreterInvocations == null || context.previousInterpreterInvocations.size() == 0) {
            arrobject = new CallFrame[1];
        } else {
            int n = context.previousInterpreterInvocations.size();
            if (context.previousInterpreterInvocations.peek() == context.lastInterpreterFrame) {
                --n;
            }
            arrobject = new CallFrame[n + 1];
            context.previousInterpreterInvocations.toArray(arrobject);
        }
        arrobject[-1 + arrobject.length] = (CallFrame)context.lastInterpreterFrame;
        int n = 0;
        for (int i = 0; i != arrobject.length; n += 1 + arrobject[i].frameIndex, ++i) {
        }
        int[] arrn = new int[n];
        int n2 = n;
        int n3 = arrobject.length;
        while (n3 != 0) {
            Object object = arrobject[--n3];
            while (object != null) {
                arrn[--n2] = ((CallFrame)object).pcSourceLineStart;
                object = ((CallFrame)object).parentFrame;
            }
        }
        if (n2 != 0) {
            Kit.codeBug();
        }
        rhinoException.interpreterStackInfo = arrobject;
        rhinoException.interpreterLineData = arrn;
    }

    @Override
    public Object compile(CompilerEnvirons compilerEnvirons, ScriptNode scriptNode, String string2, boolean bl) {
        this.itsData = new CodeGenerator().compile(compilerEnvirons, scriptNode, string2, bl);
        return this.itsData;
    }

    @Override
    public Function createFunctionObject(Context context, Scriptable scriptable, Object object, Object object2) {
        if (object != this.itsData) {
            Kit.codeBug();
        }
        return InterpretedFunction.createFunction(context, scriptable, this.itsData, object2);
    }

    @Override
    public Script createScriptObject(Object object, Object object2) {
        if (object != this.itsData) {
            Kit.codeBug();
        }
        return InterpretedFunction.createScript(this.itsData, object2);
    }

    @Override
    public String getPatchedStack(RhinoException rhinoException, String string2) {
        StringBuilder stringBuilder = new StringBuilder(1000 + string2.length());
        String string3 = SecurityUtilities.getSystemProperty("line.separator");
        CallFrame[] arrcallFrame = (CallFrame[])rhinoException.interpreterStackInfo;
        int[] arrn = rhinoException.interpreterLineData;
        int n = arrcallFrame.length;
        int n2 = arrn.length;
        int n3 = 0;
        block0 : do {
            int n4;
            block11 : {
                block10 : {
                    if (n == 0) break block10;
                    --n;
                    n4 = string2.indexOf("org.mozilla.javascript.Interpreter.interpretLoop", n3);
                    if (n4 >= 0) break block11;
                }
                stringBuilder.append(string2.substring(n3));
                return stringBuilder.toString();
            }
            int n5 = n4 + "org.mozilla.javascript.Interpreter.interpretLoop".length();
            do {
                char c;
                if (n5 == string2.length() || (c = string2.charAt(n5)) == '\n' || c == '\r') {
                    stringBuilder.append(string2.substring(n3, n5));
                    n3 = n5;
                    CallFrame callFrame = arrcallFrame[n];
                    do {
                        if (callFrame == null) continue block0;
                        if (n2 == 0) {
                            Kit.codeBug();
                        }
                        --n2;
                        InterpreterData interpreterData = callFrame.idata;
                        stringBuilder.append(string3);
                        stringBuilder.append("\tat script");
                        if (interpreterData.itsName != null && interpreterData.itsName.length() != 0) {
                            stringBuilder.append('.');
                            stringBuilder.append(interpreterData.itsName);
                        }
                        stringBuilder.append('(');
                        stringBuilder.append(interpreterData.itsSourceFile);
                        int n6 = arrn[n2];
                        if (n6 >= 0) {
                            stringBuilder.append(':');
                            stringBuilder.append(Interpreter.getIndex(interpreterData.itsICode, n6));
                        }
                        stringBuilder.append(')');
                        callFrame = callFrame.parentFrame;
                    } while (true);
                }
                ++n5;
            } while (true);
            break;
        } while (true);
    }

    @Override
    public List<String> getScriptStack(RhinoException rhinoException) {
        ScriptStackElement[][] arrscriptStackElement = this.getScriptStackElements(rhinoException);
        ArrayList arrayList = new ArrayList(arrscriptStackElement.length);
        String string2 = SecurityUtilities.getSystemProperty("line.separator");
        for (ScriptStackElement[] arrscriptStackElement2 : arrscriptStackElement) {
            StringBuilder stringBuilder = new StringBuilder();
            int n = arrscriptStackElement2.length;
            for (int i = 0; i < n; ++i) {
                arrscriptStackElement2[i].renderJavaStyle(stringBuilder);
                stringBuilder.append(string2);
            }
            arrayList.add((Object)stringBuilder.toString());
        }
        return arrayList;
    }

    public ScriptStackElement[][] getScriptStackElements(RhinoException rhinoException) {
        if (rhinoException.interpreterStackInfo == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        CallFrame[] arrcallFrame = (CallFrame[])rhinoException.interpreterStackInfo;
        int[] arrn = rhinoException.interpreterLineData;
        int n = arrcallFrame.length;
        int n2 = arrn.length;
        while (n != 0) {
            CallFrame callFrame = arrcallFrame[--n];
            ArrayList arrayList2 = new ArrayList();
            while (callFrame != null) {
                int n3;
                if (n2 == 0) {
                    Kit.codeBug();
                }
                InterpreterData interpreterData = callFrame.idata;
                String string2 = interpreterData.itsSourceFile;
                int n4 = -1;
                if ((n3 = arrn[--n2]) >= 0) {
                    n4 = Interpreter.getIndex(interpreterData.itsICode, n3);
                }
                String string3 = interpreterData.itsName;
                String string4 = null;
                if (string3 != null) {
                    int n5 = interpreterData.itsName.length();
                    string4 = null;
                    if (n5 != 0) {
                        string4 = interpreterData.itsName;
                    }
                }
                callFrame = callFrame.parentFrame;
                arrayList2.add((Object)new ScriptStackElement(string2, string4, n4));
            }
            arrayList.add((Object)arrayList2.toArray((Object[])new ScriptStackElement[arrayList2.size()]));
        }
        return (ScriptStackElement[][])arrayList.toArray((Object[])new ScriptStackElement[arrayList.size()][]);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public String getSourcePositionFromStack(Context context, int[] arrn) {
        CallFrame callFrame = (CallFrame)context.lastInterpreterFrame;
        InterpreterData interpreterData = callFrame.idata;
        if (callFrame.pcSourceLineStart >= 0) {
            arrn[0] = Interpreter.getIndex(interpreterData.itsICode, callFrame.pcSourceLineStart);
            do {
                return interpreterData.itsSourceFile;
                break;
            } while (true);
        }
        arrn[0] = 0;
        return interpreterData.itsSourceFile;
    }

    @Override
    public void setEvalScriptFlag(Script script) {
        ((InterpretedFunction)script).idata.evalScriptFlag = true;
    }

    private static class CallFrame
    implements Cloneable,
    Serializable {
        static final long serialVersionUID = -2843792508994958978L;
        DebugFrame debuggerFrame;
        int emptyStackTop;
        InterpretedFunction fnOrScript;
        int frameIndex;
        boolean frozen;
        InterpreterData idata;
        boolean isContinuationsTopFrame;
        int localShift;
        CallFrame parentFrame;
        int pc;
        int pcPrevBranch;
        int pcSourceLineStart;
        Object result;
        double resultDbl;
        double[] sDbl;
        int savedCallOp;
        int savedStackTop;
        Scriptable scope;
        Object[] stack;
        int[] stackAttributes;
        Scriptable thisObj;
        Object throwable;
        boolean useActivation;
        CallFrame varSource;

        private CallFrame() {
        }

        CallFrame cloneFrozen() {
            CallFrame callFrame;
            if (!this.frozen) {
                Kit.codeBug();
            }
            try {
                callFrame = (CallFrame)this.clone();
            }
            catch (CloneNotSupportedException cloneNotSupportedException) {
                throw new IllegalStateException();
            }
            callFrame.stack = (Object[])this.stack.clone();
            callFrame.stackAttributes = (int[])this.stackAttributes.clone();
            callFrame.sDbl = (double[])this.sDbl.clone();
            callFrame.frozen = false;
            return callFrame;
        }
    }

    private static final class ContinuationJump
    implements Serializable {
        static final long serialVersionUID = 7687739156004308247L;
        CallFrame branchFrame;
        CallFrame capturedFrame;
        Object result;
        double resultDbl;

        /*
         * Enabled aggressive block sorting
         */
        ContinuationJump(NativeContinuation nativeContinuation, CallFrame callFrame) {
            this.capturedFrame = (CallFrame)nativeContinuation.getImplementation();
            if (this.capturedFrame == null || callFrame == null) {
                this.branchFrame = null;
                return;
            } else {
                CallFrame callFrame2 = this.capturedFrame;
                CallFrame callFrame3 = callFrame;
                int n = callFrame2.frameIndex - callFrame3.frameIndex;
                if (n != 0) {
                    if (n < 0) {
                        callFrame2 = callFrame;
                        callFrame3 = this.capturedFrame;
                        n = -n;
                    }
                    do {
                        callFrame2 = callFrame2.parentFrame;
                    } while (--n != 0);
                    if (callFrame2.frameIndex != callFrame3.frameIndex) {
                        Kit.codeBug();
                    }
                }
                while (callFrame2 != callFrame3 && callFrame2 != null) {
                    callFrame2 = callFrame2.parentFrame;
                    callFrame3 = callFrame3.parentFrame;
                }
                this.branchFrame = callFrame2;
                if (this.branchFrame == null || this.branchFrame.frozen) return;
                {
                    Kit.codeBug();
                    return;
                }
            }
        }
    }

    static class GeneratorState {
        int operation;
        RuntimeException returnedException;
        Object value;

        GeneratorState(int n, Object object) {
            this.operation = n;
            this.value = object;
        }
    }

}

