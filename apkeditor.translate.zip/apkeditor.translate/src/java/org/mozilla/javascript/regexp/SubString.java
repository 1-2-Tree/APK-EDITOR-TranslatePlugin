/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript.regexp;

public class SubString {
    public static final SubString emptySubString = new SubString();
    int index;
    int length;
    String str;

    public SubString() {
    }

    public SubString(String string2) {
        this.str = string2;
        this.index = 0;
        this.length = string2.length();
    }

    public SubString(String string2, int n, int n2) {
        this.str = string2;
        this.index = n;
        this.length = n2;
    }

    public String toString() {
        if (this.str == null) {
            return "";
        }
        return this.str.substring(this.index, this.index + this.length);
    }
}

