/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript.regexp;

import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.TopLevel;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.regexp.NativeRegExp;
import org.mozilla.javascript.regexp.RegExpImpl;
import org.mozilla.javascript.regexp.SubString;

class NativeRegExpCtor
extends BaseFunction {
    private static final int DOLLAR_ID_BASE = 12;
    private static final int Id_AMPERSAND = 6;
    private static final int Id_BACK_QUOTE = 10;
    private static final int Id_DOLLAR_1 = 13;
    private static final int Id_DOLLAR_2 = 14;
    private static final int Id_DOLLAR_3 = 15;
    private static final int Id_DOLLAR_4 = 16;
    private static final int Id_DOLLAR_5 = 17;
    private static final int Id_DOLLAR_6 = 18;
    private static final int Id_DOLLAR_7 = 19;
    private static final int Id_DOLLAR_8 = 20;
    private static final int Id_DOLLAR_9 = 21;
    private static final int Id_PLUS = 8;
    private static final int Id_QUOTE = 12;
    private static final int Id_STAR = 2;
    private static final int Id_UNDERSCORE = 4;
    private static final int Id_input = 3;
    private static final int Id_lastMatch = 5;
    private static final int Id_lastParen = 7;
    private static final int Id_leftContext = 9;
    private static final int Id_multiline = 1;
    private static final int Id_rightContext = 11;
    private static final int MAX_INSTANCE_ID = 21;
    static final long serialVersionUID = -5733330028285400526L;
    private int inputAttr = 4;
    private int multilineAttr = 4;
    private int starAttr = 4;
    private int underscoreAttr = 4;

    NativeRegExpCtor() {
    }

    private static RegExpImpl getImpl() {
        return (RegExpImpl)ScriptRuntime.getRegExpProxy(Context.getCurrentContext());
    }

    @Override
    public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (arrobject.length > 0 && arrobject[0] instanceof NativeRegExp && (arrobject.length == 1 || arrobject[1] == Undefined.instance)) {
            return arrobject[0];
        }
        return this.construct(context, scriptable, arrobject);
    }

    @Override
    public Scriptable construct(Context context, Scriptable scriptable, Object[] arrobject) {
        NativeRegExp nativeRegExp = new NativeRegExp();
        nativeRegExp.compile(context, scriptable, arrobject);
        ScriptRuntime.setBuiltinProtoAndParent(nativeRegExp, scriptable, TopLevel.Builtins.RegExp);
        return nativeRegExp;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findInstanceIdInfo(String string2) {
        int n;
        int n2;
        block34 : {
            int n3 = string2.length();
            String string3 = null;
            n2 = 0;
            block0 : switch (n3) {
                case 2: {
                    switch (string2.charAt(1)) {
                        default: {
                            string3 = null;
                            n2 = 0;
                            break block0;
                        }
                        case '&': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 6;
                            break;
                        }
                        case '\'': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 12;
                            break;
                        }
                        case '*': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 2;
                            break;
                        }
                        case '+': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 8;
                            break;
                        }
                        case '1': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 13;
                            break;
                        }
                        case '2': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 14;
                            break;
                        }
                        case '3': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 15;
                            break;
                        }
                        case '4': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 16;
                            break;
                        }
                        case '5': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 17;
                            break;
                        }
                        case '6': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 18;
                            break;
                        }
                        case '7': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 19;
                            break;
                        }
                        case '8': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 20;
                            break;
                        }
                        case '9': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 21;
                            break;
                        }
                        case '_': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 4;
                            break;
                        }
                        case '`': {
                            char c = string2.charAt(0);
                            string3 = null;
                            n2 = 0;
                            if (c != '$') break block0;
                            n2 = 10;
                            break;
                        }
                    }
                    break block34;
                }
                case 5: {
                    string3 = "input";
                    n2 = 3;
                    break;
                }
                case 9: {
                    char c = string2.charAt(4);
                    if (c == 'M') {
                        string3 = "lastMatch";
                        n2 = 5;
                        break;
                    }
                    if (c == 'P') {
                        string3 = "lastParen";
                        n2 = 7;
                        break;
                    }
                    string3 = null;
                    n2 = 0;
                    if (c != 'i') break;
                    string3 = "multiline";
                    n2 = 1;
                    break;
                }
                case 11: {
                    string3 = "leftContext";
                    n2 = 9;
                    break;
                }
                case 12: {
                    string3 = "rightContext";
                    n2 = 11;
                }
            }
            if (string3 != null && string3 != string2 && !string3.equals((Object)string2)) {
                n2 = 0;
            }
        }
        if (n2 == 0) {
            return super.findInstanceIdInfo(string2);
        }
        switch (n2) {
            default: {
                n = 5;
                return NativeRegExpCtor.instanceIdInfo(n, n2 + super.getMaxInstanceId());
            }
            case 1: {
                n = this.multilineAttr;
                return NativeRegExpCtor.instanceIdInfo(n, n2 + super.getMaxInstanceId());
            }
            case 2: {
                n = this.starAttr;
                return NativeRegExpCtor.instanceIdInfo(n, n2 + super.getMaxInstanceId());
            }
            case 3: {
                n = this.inputAttr;
                return NativeRegExpCtor.instanceIdInfo(n, n2 + super.getMaxInstanceId());
            }
            case 4: 
        }
        n = this.underscoreAttr;
        return NativeRegExpCtor.instanceIdInfo(n, n2 + super.getMaxInstanceId());
    }

    @Override
    public int getArity() {
        return 2;
    }

    @Override
    public String getFunctionName() {
        return "RegExp";
    }

    @Override
    protected String getInstanceIdName(int n) {
        int n2 = n - super.getMaxInstanceId();
        if (1 <= n2 && n2 <= 21) {
            switch (n2) {
                default: {
                    int n3 = -1 + (n2 - 12);
                    char[] arrc = new char[]{'$', (char)(n3 + 49)};
                    return new String(arrc);
                }
                case 1: {
                    return "multiline";
                }
                case 2: {
                    return "$*";
                }
                case 3: {
                    return "input";
                }
                case 4: {
                    return "$_";
                }
                case 5: {
                    return "lastMatch";
                }
                case 6: {
                    return "$&";
                }
                case 7: {
                    return "lastParen";
                }
                case 8: {
                    return "$+";
                }
                case 9: {
                    return "leftContext";
                }
                case 10: {
                    return "$`";
                }
                case 11: {
                    return "rightContext";
                }
                case 12: 
            }
            return "$'";
        }
        return super.getInstanceIdName(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected Object getInstanceIdValue(int n) {
        int n2 = n - super.getMaxInstanceId();
        if (1 <= n2 && n2 <= 21) {
            Object object;
            RegExpImpl regExpImpl = NativeRegExpCtor.getImpl();
            switch (n2) {
                default: {
                    object = regExpImpl.getParenSubString(-1 + (n2 - 12));
                    break;
                }
                case 1: 
                case 2: {
                    return ScriptRuntime.wrapBoolean(regExpImpl.multiline);
                }
                case 3: 
                case 4: {
                    object = regExpImpl.input;
                    break;
                }
                case 5: 
                case 6: {
                    object = regExpImpl.lastMatch;
                    break;
                }
                case 7: 
                case 8: {
                    object = regExpImpl.lastParen;
                    break;
                }
                case 9: 
                case 10: {
                    object = regExpImpl.leftContext;
                    break;
                }
                case 11: 
                case 12: {
                    object = regExpImpl.rightContext;
                }
            }
            if (object == null) {
                return "";
            }
            return object.toString();
        }
        return super.getInstanceIdValue(n);
    }

    @Override
    public int getLength() {
        return 2;
    }

    @Override
    protected int getMaxInstanceId() {
        return 21 + super.getMaxInstanceId();
    }

    @Override
    protected void setInstanceIdAttributes(int n, int n2) {
        int n3 = n - super.getMaxInstanceId();
        switch (n3) {
            default: {
                int n4 = -1 + (n3 - 12);
                if (n4 < 0 || n4 > 8) break;
            }
            case 5: 
            case 6: 
            case 7: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 12: {
                return;
            }
            case 1: {
                this.multilineAttr = n2;
                return;
            }
            case 2: {
                this.starAttr = n2;
                return;
            }
            case 3: {
                this.inputAttr = n2;
                return;
            }
            case 4: {
                this.underscoreAttr = n2;
                return;
            }
        }
        super.setInstanceIdAttributes(n, n2);
    }

    @Override
    protected void setInstanceIdValue(int n, Object object) {
        int n2 = n - super.getMaxInstanceId();
        switch (n2) {
            default: {
                int n3 = -1 + (n2 - 12);
                if (n3 < 0 || n3 > 8) break;
            }
            case 5: 
            case 6: 
            case 7: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 12: {
                return;
            }
            case 1: 
            case 2: {
                NativeRegExpCtor.getImpl().multiline = ScriptRuntime.toBoolean(object);
                return;
            }
            case 3: 
            case 4: {
                NativeRegExpCtor.getImpl().input = ScriptRuntime.toString(object);
                return;
            }
        }
        super.setInstanceIdValue(n, object);
    }
}

