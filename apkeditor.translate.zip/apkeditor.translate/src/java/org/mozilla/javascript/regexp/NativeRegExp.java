/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.regexp;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.TopLevel;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.regexp.CompilerState;
import org.mozilla.javascript.regexp.NativeRegExpCtor;
import org.mozilla.javascript.regexp.REBackTrackData;
import org.mozilla.javascript.regexp.RECharSet;
import org.mozilla.javascript.regexp.RECompiled;
import org.mozilla.javascript.regexp.REGlobalData;
import org.mozilla.javascript.regexp.RENode;
import org.mozilla.javascript.regexp.REProgState;
import org.mozilla.javascript.regexp.RegExpImpl;
import org.mozilla.javascript.regexp.SubString;

public class NativeRegExp
extends IdScriptableObject
implements Function {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    private static final int ANCHOR_BOL = -2;
    private static final int INDEX_LEN = 2;
    private static final int Id_compile = 1;
    private static final int Id_exec = 4;
    private static final int Id_global = 3;
    private static final int Id_ignoreCase = 4;
    private static final int Id_lastIndex = 1;
    private static final int Id_multiline = 5;
    private static final int Id_prefix = 6;
    private static final int Id_source = 2;
    private static final int Id_test = 5;
    private static final int Id_toSource = 3;
    private static final int Id_toString = 2;
    public static final int JSREG_FOLD = 2;
    public static final int JSREG_GLOB = 1;
    public static final int JSREG_MULTILINE = 4;
    public static final int MATCH = 1;
    private static final int MAX_INSTANCE_ID = 5;
    private static final int MAX_PROTOTYPE_ID = 6;
    public static final int PREFIX = 2;
    private static final Object REGEXP_TAG;
    private static final byte REOP_ALNUM = 9;
    private static final byte REOP_ALT = 31;
    private static final byte REOP_ALTPREREQ = 53;
    private static final byte REOP_ALTPREREQ2 = 55;
    private static final byte REOP_ALTPREREQi = 54;
    private static final byte REOP_ASSERT = 41;
    private static final byte REOP_ASSERTNOTTEST = 44;
    private static final byte REOP_ASSERTTEST = 43;
    private static final byte REOP_ASSERT_NOT = 42;
    private static final byte REOP_BACKREF = 13;
    private static final byte REOP_BOL = 2;
    private static final byte REOP_CLASS = 22;
    private static final byte REOP_DIGIT = 7;
    private static final byte REOP_DOT = 6;
    private static final byte REOP_EMPTY = 1;
    private static final byte REOP_END = 57;
    private static final byte REOP_ENDCHILD = 49;
    private static final byte REOP_EOL = 3;
    private static final byte REOP_FLAT = 14;
    private static final byte REOP_FLAT1 = 15;
    private static final byte REOP_FLAT1i = 17;
    private static final byte REOP_FLATi = 16;
    private static final byte REOP_JUMP = 32;
    private static final byte REOP_LPAREN = 29;
    private static final byte REOP_MINIMALOPT = 47;
    private static final byte REOP_MINIMALPLUS = 46;
    private static final byte REOP_MINIMALQUANT = 48;
    private static final byte REOP_MINIMALREPEAT = 52;
    private static final byte REOP_MINIMALSTAR = 45;
    private static final byte REOP_NCLASS = 23;
    private static final byte REOP_NONALNUM = 10;
    private static final byte REOP_NONDIGIT = 8;
    private static final byte REOP_NONSPACE = 12;
    private static final byte REOP_OPT = 28;
    private static final byte REOP_PLUS = 27;
    private static final byte REOP_QUANT = 25;
    private static final byte REOP_REPEAT = 51;
    private static final byte REOP_RPAREN = 30;
    private static final byte REOP_SIMPLE_END = 23;
    private static final byte REOP_SIMPLE_START = 1;
    private static final byte REOP_SPACE = 11;
    private static final byte REOP_STAR = 26;
    private static final byte REOP_UCFLAT1 = 18;
    private static final byte REOP_UCFLAT1i = 19;
    private static final byte REOP_WBDRY = 4;
    private static final byte REOP_WNONBDRY = 5;
    public static final int TEST = 0;
    private static final boolean debug = false;
    static final long serialVersionUID = 4965263491464903264L;
    Object lastIndex = 0.0;
    private int lastIndexAttr = 6;
    private RECompiled re;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !NativeRegExp.class.desiredAssertionStatus();
        $assertionsDisabled = bl;
        REGEXP_TAG = new Object();
    }

    NativeRegExp() {
    }

    NativeRegExp(Scriptable scriptable, RECompiled rECompiled) {
        this.re = rECompiled;
        this.lastIndex = 0.0;
        ScriptRuntime.setBuiltinProtoAndParent(this, scriptable, TopLevel.Builtins.RegExp);
    }

    private static void addCharacterRangeToCharSet(RECharSet rECharSet, char c, char c2) {
        int n = c / 8;
        int n2 = c2 / 8;
        if (c2 >= rECharSet.length || c > c2) {
            throw ScriptRuntime.constructError("SyntaxError", "invalid range in character class");
        }
        char c3 = (char)(c & 7);
        char c4 = (char)(c2 & 7);
        if (n == n2) {
            byte[] arrby = rECharSet.bits;
            arrby[n] = (byte)(arrby[n] | 255 >> 7 - (c4 - c3) << c3);
            return;
        }
        byte[] arrby = rECharSet.bits;
        arrby[n] = (byte)(arrby[n] | 255 << c3);
        for (int i = n + 1; i < n2; ++i) {
            rECharSet.bits[i] = -1;
        }
        byte[] arrby2 = rECharSet.bits;
        arrby2[n2] = (byte)(arrby2[n2] | 255 >> 7 - c4);
    }

    private static void addCharacterToCharSet(RECharSet rECharSet, char c) {
        int n = c / 8;
        if (c >= rECharSet.length) {
            throw ScriptRuntime.constructError("SyntaxError", "invalid range in character class");
        }
        byte[] arrby = rECharSet.bits;
        arrby[n] = (byte)(arrby[n] | 1 << (c & 7));
    }

    private static int addIndex(byte[] arrby, int n, int n2) {
        if (n2 < 0) {
            throw Kit.codeBug();
        }
        if (n2 > 65535) {
            throw Context.reportRuntimeError("Too complex regexp");
        }
        arrby[n] = (byte)(n2 >> 8);
        arrby[n + 1] = (byte)n2;
        return n + 2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean backrefMatcher(REGlobalData rEGlobalData, int n, String string2, int n2) {
        boolean bl = true;
        if (rEGlobalData.parens == null) return false;
        if (n >= rEGlobalData.parens.length) {
            return false;
        }
        int n3 = rEGlobalData.parensIndex(n);
        if (n3 == -1) return bl;
        int n4 = rEGlobalData.parensLength(n);
        if (n4 + rEGlobalData.cp > n2) {
            return false;
        }
        if ((2 & rEGlobalData.regexp.flags) != 0) {
            for (int i = 0; i < n4; ++i) {
                char c;
                char c2 = string2.charAt(n3 + i);
                if (c2 == (c = string2.charAt(i + rEGlobalData.cp)) || NativeRegExp.upcase(c2) == NativeRegExp.upcase(c)) continue;
                return false;
            }
        } else if (!string2.regionMatches(n3, string2, rEGlobalData.cp, n4)) {
            return false;
        }
        rEGlobalData.cp = n4 + rEGlobalData.cp;
        return bl;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static boolean calculateBitmapSize(CompilerState var0, RENode var1_1, char[] var2_2, int var3_3, int var4_4) {
        var5_5 = 0;
        var6_6 = 0;
        var7_7 = false;
        var1_1.bmsize = 0;
        var1_1.sense = true;
        if (var3_3 == var4_4) {
            return true;
        }
        if (var2_2[var3_3] == '^') {
            ++var3_3;
            var1_1.sense = false;
        }
        var8_8 = var3_3;
        do {
            if (var8_8 == var4_4) {
                var1_1.bmsize = var6_6 + 1;
                return true;
            }
            var10_9 = 2;
            block0 : switch (var2_2[var8_8]) {
                default: {
                    var16_15 = var8_8 + 1;
                    var17_16 = var2_2[var8_8];
                    break;
                }
                case '\\': {
                    var11_10 = var8_8 + 1;
                    var12_11 = var11_10 + 1;
                    var13_12 = var2_2[var11_10];
                    switch (var13_12) {
                        default: {
                            var17_16 = var13_12;
                            var16_15 = var12_11;
                            break block0;
                        }
                        case 98: {
                            var17_16 = 8;
                            var16_15 = var12_11;
                            break block0;
                        }
                        case 102: {
                            var17_16 = 12;
                            var16_15 = var12_11;
                            break block0;
                        }
                        case 110: {
                            var17_16 = 10;
                            var16_15 = var12_11;
                            break block0;
                        }
                        case 114: {
                            var17_16 = 13;
                            var16_15 = var12_11;
                            break block0;
                        }
                        case 116: {
                            var17_16 = 9;
                            var16_15 = var12_11;
                            break block0;
                        }
                        case 118: {
                            var17_16 = 11;
                            var16_15 = var12_11;
                            break block0;
                        }
                        case 99: {
                            if (var12_11 < var4_4 && NativeRegExp.isControlLetter(var2_2[var12_11])) {
                                var16_15 = var12_11 + 1;
                                (char)(31 & var2_2[var12_11]);
                            } else {
                                var16_15 = var12_11 - 1;
                            }
                            var17_16 = 92;
                            break block0;
                        }
                        case 117: {
                            var10_9 += 2;
                        }
                        case 120: {
                            var27_23 = 0;
                            for (var28_24 = 0; var28_24 < var10_9 && var12_11 < var4_4; ++var28_24) {
                                var29_25 = var12_11 + 1;
                                if ((var27_23 = Kit.xDigitToInt(var2_2[var12_11], var27_23)) >= 0) ** GOTO lbl73
                                var16_15 = var29_25 - (var28_24 + 1);
                                var27_23 = 92;
                                ** GOTO lbl109
lbl73: // 1 sources:
                                var12_11 = var29_25;
                            }
                            break;
                        }
                        case 100: {
                            if (var7_7) {
                                NativeRegExp.reportError("msg.bad.range", "");
                                return false;
                            }
                            var17_16 = 57;
                            var16_15 = var12_11;
                            break block0;
                        }
                        case 68: 
                        case 83: 
                        case 87: 
                        case 115: 
                        case 119: {
                            if (var7_7) {
                                NativeRegExp.reportError("msg.bad.range", "");
                                return false;
                            }
                            var1_1.bmsize = 65536;
                            return true;
                        }
                        case 48: 
                        case 49: 
                        case 50: 
                        case 51: 
                        case 52: 
                        case 53: 
                        case 54: 
                        case 55: {
                            var14_13 = var13_12 - 48;
                            var15_14 = var2_2[var12_11];
                            if ('0' <= var15_14 && var15_14 <= '7') {
                                var16_15 = var12_11 + 1;
                                var14_13 = var14_13 * 8 + (var15_14 - 48);
                                var22_21 = var2_2[var16_15];
                                if ('0' <= var22_21 && var22_21 <= '7') {
                                    ++var16_15;
                                    var23_22 = var14_13 * 8 + (var22_21 - 48);
                                    if (var23_22 <= 255) {
                                        var14_13 = var23_22;
                                    } else {
                                        --var16_15;
                                        ** break;
                                    }
                                }
lbl104: // 3 sources:
                            } else {
                                var16_15 = var12_11;
                            }
                            var17_16 = var14_13;
                            break block0;
                        }
                    }
                    var16_15 = var12_11;
lbl109: // 2 sources:
                    var17_16 = var27_23;
                }
            }
            if (var7_7) {
                if (var5_5 > var17_16) {
                    NativeRegExp.reportError("msg.bad.range", "");
                    return false;
                }
                var7_7 = false;
            } else {
                var18_17 = var4_4 - 1;
                if (var16_15 < var18_17 && var2_2[var16_15] == '-') {
                    var19_18 = var16_15 + 1;
                    var7_7 = true;
                    var5_5 = (char)var17_16;
                    var8_8 = var19_18;
                    continue;
                }
            }
            if ((2 & var0.flags) != 0) {
                var20_19 = NativeRegExp.upcase((char)var17_16);
                var17_16 = var20_19 >= (var21_20 = NativeRegExp.downcase((char)var17_16)) ? (int)var20_19 : (int)var21_20;
            }
            if (var17_16 > var6_6) {
                var6_6 = var17_16;
            }
            var8_8 = var16_15;
        } while (true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean classMatcher(REGlobalData rEGlobalData, RECharSet rECharSet, char c) {
        int n = 1;
        if (!rECharSet.converted) {
            NativeRegExp.processCharSet(rEGlobalData, rECharSet);
        }
        int n2 = c >> 3;
        if (rECharSet.length == 0 || c >= rECharSet.length || (rECharSet.bits[n2] & n << (c & 7)) == 0) {
            do {
                return n ^ rECharSet.sense;
                break;
            } while (true);
        }
        n = 0;
        return (boolean)(n ^ rECharSet.sense);
    }

    /*
     * Enabled aggressive block sorting
     */
    static RECompiled compileRE(Context context, String string2, String string3, boolean bl) {
        RECompiled rECompiled = new RECompiled(string2);
        int n = string2.length();
        int n2 = 0;
        if (string3 != null) {
            int n3;
            for (int i = 0; i < string3.length(); n2 |= n3, ++i) {
                char c = string3.charAt(i);
                if (c == 'g') {
                    n3 = 1;
                } else if (c == 'i') {
                    n3 = 2;
                } else if (c == 'm') {
                    n3 = 4;
                } else {
                    NativeRegExp.reportError("msg.invalid.re.flag", String.valueOf((char)c));
                    n3 = 0;
                }
                if ((n2 & n3) == 0) continue;
                NativeRegExp.reportError("msg.invalid.re.flag", String.valueOf((char)c));
            }
        }
        rECompiled.flags = n2;
        CompilerState compilerState = new CompilerState(context, rECompiled.source, n, n2);
        if (bl && n > 0) {
            compilerState.result = new RENode(14);
            compilerState.result.chr = compilerState.cpbegin[0];
            compilerState.result.length = n;
            compilerState.result.flatIndex = 0;
            compilerState.progLength = 5 + compilerState.progLength;
        } else {
            if (!NativeRegExp.parseDisjunction(compilerState)) {
                return null;
            }
            if (compilerState.maxBackReference > compilerState.parenCount) {
                compilerState = new CompilerState(context, rECompiled.source, n, n2);
                compilerState.backReferenceLimit = compilerState.parenCount;
                if (!NativeRegExp.parseDisjunction(compilerState)) {
                    return null;
                }
            }
        }
        rECompiled.program = new byte[1 + compilerState.progLength];
        if (compilerState.classCount != 0) {
            rECompiled.classList = new RECharSet[compilerState.classCount];
            rECompiled.classCount = compilerState.classCount;
        }
        int n4 = NativeRegExp.emitREBytecode(compilerState, rECompiled, 0, compilerState.result);
        byte[] arrby = rECompiled.program;
        n4 + 1;
        arrby[n4] = 57;
        rECompiled.parenCount = compilerState.parenCount;
        switch (rECompiled.program[0]) {
            default: {
                return rECompiled;
            }
            case 18: 
            case 19: {
                rECompiled.anchorCh = (char)NativeRegExp.getIndex(rECompiled.program, 1);
                return rECompiled;
            }
            case 15: 
            case 17: {
                rECompiled.anchorCh = (char)(255 & rECompiled.program[1]);
                return rECompiled;
            }
            case 14: 
            case 16: {
                int n5 = NativeRegExp.getIndex(rECompiled.program, 1);
                rECompiled.anchorCh = rECompiled.source[n5];
                return rECompiled;
            }
            case 2: {
                rECompiled.anchorCh = -2;
                return rECompiled;
            }
            case 31: {
                RENode rENode = compilerState.result;
                if (rENode.kid.op != 2 || rENode.kid2.op != 2) return rECompiled;
                rECompiled.anchorCh = -2;
                return rECompiled;
            }
        }
    }

    private static void doFlat(CompilerState compilerState, char c) {
        compilerState.result = new RENode(14);
        compilerState.result.chr = c;
        compilerState.result.length = 1;
        compilerState.result.flatIndex = -1;
        compilerState.progLength = 3 + compilerState.progLength;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static char downcase(char c) {
        if (c < '') {
            if ('A' > c) return c;
            if (c > 'Z') return c;
            return (char)(c + 32);
        }
        char c2 = Character.toLowerCase((char)c);
        if (c2 < '') return c;
        return c2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int emitREBytecode(CompilerState var0, RECompiled var1_1, int var2_2, RENode var3_3) {
        var4_4 = var1_1.program;
        var5_5 = var2_2;
        while (var3_3 != null) {
            block25 : {
                var6_6 = var5_5 + 1;
                var4_4[var5_5] = var3_3.op;
                switch (var3_3.op) {
                    case 1: {
                        ** break;
                    }
                    case 53: 
                    case 54: 
                    case 55: {
                        var41_41 = var3_3.op == 54;
                        var42_42 = var41_41 != false ? NativeRegExp.upcase(var3_3.chr) : var3_3.chr;
                        NativeRegExp.addIndex(var4_4, var6_6, var42_42);
                        var44_43 = var6_6 + 2;
                        var45_44 = var41_41 != false ? (int)NativeRegExp.upcase((char)var3_3.index) : var3_3.index;
                        NativeRegExp.addIndex(var4_4, var44_43, var45_44);
                        var6_6 = var44_43 + 2;
                    }
                    case 31: {
                        var34_34 = var3_3.kid2;
                        var35_35 = var6_6;
                        var36_36 = NativeRegExp.emitREBytecode(var0, var1_1, var6_6 + 2, var3_3.kid);
                        var37_37 = var36_36 + 1;
                        var4_4[var36_36] = 32;
                        var38_38 = var37_37 + 2;
                        NativeRegExp.resolveForwardJump(var4_4, var35_35, var38_38);
                        var39_39 = NativeRegExp.emitREBytecode(var0, var1_1, var38_38, var34_34);
                        var40_40 = var39_39 + 1;
                        var4_4[var39_39] = 32;
                        var6_6 = var40_40 + 2;
                        NativeRegExp.resolveForwardJump(var4_4, var37_37, var6_6);
                        NativeRegExp.resolveForwardJump(var4_4, var40_40, var6_6);
                        ** break;
                    }
                    case 14: {
                        if (var3_3.flatIndex != -1) {
                            while (var3_3.next != null && var3_3.next.op == 14 && var3_3.flatIndex + var3_3.length == var3_3.next.flatIndex) {
                                var3_3.length = var32_32 = var3_3.length + var3_3.next.length;
                                var3_3.next = var33_33 = var3_3.next.next;
                            }
                        }
                        if (var3_3.flatIndex != -1 && var3_3.length > 1) {
                            var4_4[var6_6 - 1] = (2 & var0.flags) != 0 ? 16 : 14;
                            var31_31 = var3_3.flatIndex;
                            var6_6 = NativeRegExp.addIndex(var4_4, NativeRegExp.addIndex(var4_4, var6_6, var31_31), var3_3.length);
                            ** break;
                        }
                        if (var3_3.chr < '\u0100') {
                            var4_4[var6_6 - 1] = (2 & var0.flags) != 0 ? 17 : 15;
                            var30_30 = var6_6 + 1;
                            var4_4[var6_6] = (byte)var3_3.chr;
                            var6_6 = var30_30;
                            ** break;
                        }
                        var4_4[var6_6 - 1] = (2 & var0.flags) != 0 ? 19 : 18;
                        var29_29 = var3_3.chr;
                        var6_6 = NativeRegExp.addIndex(var4_4, var6_6, var29_29);
                        ** break;
                    }
                    case 29: {
                        var26_26 = var3_3.parenIndex;
                        var27_27 = NativeRegExp.emitREBytecode(var0, var1_1, NativeRegExp.addIndex(var4_4, var6_6, var26_26), var3_3.kid);
                        var28_28 = var27_27 + 1;
                        var4_4[var27_27] = 30;
                        var6_6 = NativeRegExp.addIndex(var4_4, var28_28, var3_3.parenIndex);
                        ** break;
                    }
                    case 13: {
                        var25_25 = var3_3.parenIndex;
                        var6_6 = NativeRegExp.addIndex(var4_4, var6_6, var25_25);
                        ** break;
                    }
                    case 41: {
                        var22_22 = var6_6;
                        var23_23 = NativeRegExp.emitREBytecode(var0, var1_1, var6_6 + 2, var3_3.kid);
                        var24_24 = var23_23 + 1;
                        var4_4[var23_23] = 43;
                        NativeRegExp.resolveForwardJump(var4_4, var22_22, var24_24);
                        var6_6 = var24_24;
                        ** break;
                    }
                    case 42: {
                        var19_19 = var6_6;
                        var20_20 = NativeRegExp.emitREBytecode(var0, var1_1, var6_6 + 2, var3_3.kid);
                        var21_21 = var20_20 + 1;
                        var4_4[var20_20] = 44;
                        NativeRegExp.resolveForwardJump(var4_4, var19_19, var21_21);
                        var6_6 = var21_21;
                        ** break;
                    }
                    case 25: {
                        if (var3_3.min == 0 && var3_3.max == -1) {
                            var17_17 = var6_6 - 1;
                            var18_18 = var3_3.greedy != false ? 26 : 45;
                            var4_4[var17_17] = var18_18;
                        } else if (var3_3.min == 0 && var3_3.max == 1) {
                            var15_15 = var6_6 - 1;
                            var16_16 = var3_3.greedy != false ? 28 : 47;
                            var4_4[var15_15] = var16_16;
                        } else if (var3_3.min == 1 && var3_3.max == -1) {
                            var13_13 = var6_6 - 1;
                            var14_14 = var3_3.greedy != false ? 27 : 46;
                            var4_4[var13_13] = var14_14;
                        } else {
                            if (!var3_3.greedy) {
                                var4_4[var6_6 - 1] = 48;
                            }
                            var8_8 = var3_3.min;
                            var6_6 = NativeRegExp.addIndex(var4_4, NativeRegExp.addIndex(var4_4, var6_6, var8_8), 1 + var3_3.max);
                        }
                        var9_9 = var3_3.parenCount;
                        var10_10 = NativeRegExp.addIndex(var4_4, NativeRegExp.addIndex(var4_4, var6_6, var9_9), var3_3.parenIndex);
                        var11_11 = NativeRegExp.emitREBytecode(var0, var1_1, var10_10 + 2, var3_3.kid);
                        var12_12 = var11_11 + 1;
                        var4_4[var11_11] = 49;
                        NativeRegExp.resolveForwardJump(var4_4, var10_10, var12_12);
                        var6_6 = var12_12;
                    }
lbl107: // 11 sources:
                    default: {
                        break block25;
                    }
                    case 22: 
                }
                if (!var3_3.sense) {
                    var4_4[var6_6 - 1] = 23;
                }
                var7_7 = var3_3.index;
                var6_6 = NativeRegExp.addIndex(var4_4, var6_6, var7_7);
                var1_1.classList[var3_3.index] = new RECharSet(var3_3.bmsize, var3_3.startIndex, var3_3.kidlen, var3_3.sense);
            }
            var3_3 = var3_3.next;
            var5_5 = --var6_6;
        }
        return var5_5;
    }

    private static String escapeRegExp(Object object) {
        String string2 = ScriptRuntime.toString(object);
        StringBuilder stringBuilder = null;
        int n = 0;
        int n2 = string2.indexOf(47);
        while (n2 > -1) {
            if (n2 == n || string2.charAt(n2 - 1) != '\\') {
                if (stringBuilder == null) {
                    stringBuilder = new StringBuilder();
                }
                stringBuilder.append((CharSequence)string2, n, n2);
                stringBuilder.append("\\/");
                n = n2 + 1;
            }
            n2 = string2.indexOf(47, n2 + 1);
        }
        if (stringBuilder != null) {
            stringBuilder.append((CharSequence)string2, n, string2.length());
            string2 = stringBuilder.toString();
        }
        return string2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private Object execSub(Context context, Scriptable scriptable, Object[] arrobject, int n) {
        String string2;
        RegExpImpl regExpImpl = NativeRegExp.getImpl(context);
        if (arrobject.length == 0) {
            string2 = regExpImpl.input;
            if (string2 == null) {
                string2 = ScriptRuntime.toString(Undefined.instance);
            }
        } else {
            string2 = ScriptRuntime.toString(arrobject[0]);
        }
        double d = 0.0;
        if ((1 & this.re.flags) != 0) {
            d = ScriptRuntime.toInteger(this.lastIndex);
        }
        if (d < 0.0 || (double)string2.length() < d) {
            this.lastIndex = 0.0;
            return null;
        }
        int[] arrn = new int[]{(int)d};
        Object object = this.executeRegExp(context, scriptable, regExpImpl, string2, arrn, n);
        if ((1 & this.re.flags) == 0) return object;
        double d2 = object == null || object == Undefined.instance ? 0.0 : (double)arrn[0];
        this.lastIndex = d2;
        return object;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static boolean executeREBytecode(REGlobalData var0, String var1_1, int var2_2) {
        var3_3 = var0.regexp.program;
        var4_4 = 57;
        var5_5 = 0 + 1;
        var6_6 = var3_3[0];
        var7_7 = var0.regexp.anchorCh;
        var8_8 = 0;
        var9_9 = false;
        if (var7_7 >= 0) ** GOTO lbl56
        var94_10 = NativeRegExp.reopIsSimple(var6_6);
        var8_8 = 0;
        var9_9 = false;
        if (!var94_10) ** GOTO lbl56
        do {
            block54 : {
                block53 : {
                    var95_13 = var0.cp;
                    var96_11 = false;
                    if (var95_13 > var2_2) break block53;
                    var97_12 = NativeRegExp.simpleMatch(var0, var1_1, var6_6, var3_3, var5_5, var2_2, true);
                    if (var97_12 < 0) break block54;
                    var96_11 = true;
                    var98_14 = var97_12 + 1;
                    var6_6 = var3_3[var97_12];
                    var5_5 = var98_14;
                }
                var8_8 = 0;
                var9_9 = false;
                if (!var96_11) {
                    return false;
                }
                ** GOTO lbl56
            }
            var0.skipped = 1 + var0.skipped;
            var0.cp = 1 + var0.cp;
        } while (true);
        {
            block57 : {
                block58 : {
                    block55 : {
                        block56 : {
                            var85_87 = var5_5 + NativeRegExp.getOffset(var3_3, var5_5);
                            var86_88 = var5_5 + 2;
                            var87_89 = var86_88 + 1;
                            var6_6 = var3_3[var86_88];
                            var88_90 = var0.cp;
                            if (!NativeRegExp.reopIsSimple(var6_6)) break block55;
                            var90_92 = NativeRegExp.simpleMatch(var0, var1_1, var6_6, var3_3, var87_89, var2_2, true);
                            if (var90_92 >= 0) break block56;
                            var92_94 = var85_87 + 1;
                            var6_6 = var3_3[var85_87];
                            var5_5 = var92_94;
                            break block57;
                        }
                        var9_9 = true;
                        var91_93 = var90_92 + 1;
                        var6_6 = var3_3[var90_92];
                        var5_5 = var91_93;
                        break block58;
                    }
                    var5_5 = var87_89;
                }
                var89_91 = var85_87 + 1;
                NativeRegExp.pushBackTrackState(var0, var3_3[var85_87], var89_91, var88_90, var4_4, var8_8);
            }
            block27 : do {
                block61 : {
                    block60 : {
                        block59 : {
                            if (!NativeRegExp.reopIsSimple(var6_6)) break block59;
                            var93_95 = NativeRegExp.simpleMatch(var0, var1_1, var6_6, var3_3, var5_5, var2_2, true);
                            var9_9 = var93_95 >= 0;
                            if (var9_9) {
                                var5_5 = var93_95;
                            }
                            var23_27 = var5_5;
                            break block60;
                        }
                        switch (var6_6) {
                            case 31: {
                                continue block26;
                            }
                            default: {
                                throw Kit.codeBug("invalid bytecode");
                            }
                            case 53: 
                            case 54: 
                            case 55: {
                                var81_83 = (char)NativeRegExp.getIndex(var3_3, var5_5);
                                var82_84 = var5_5 + 2;
                                var83_85 = (char)NativeRegExp.getIndex(var3_3, var82_84);
                                var5_5 = var82_84 + 2;
                                if (var0.cp == var2_2) {
                                    var23_27 = var5_5;
                                    var9_9 = false;
                                    break;
                                }
                                var84_86 = var1_1.charAt(var0.cp);
                                if (var6_6 == 55) {
                                    if (var84_86 == var81_83 || NativeRegExp.classMatcher(var0, var0.regexp.classList[var83_85], var84_86)) continue block26;
                                    var23_27 = var5_5;
                                    var9_9 = false;
                                    break;
                                }
                                if (var6_6 == 54) {
                                    var84_86 = NativeRegExp.upcase(var84_86);
                                }
                                if (var84_86 != var81_83 && var84_86 != var83_85) ** break;
                                continue block26;
                                var23_27 = var5_5;
                                var9_9 = false;
                                break;
                            }
                            case 32: {
                                var79_81 = var5_5 + NativeRegExp.getOffset(var3_3, var5_5);
                                var80_82 = var79_81 + 1;
                                var6_6 = var3_3[var79_81];
                                var5_5 = var80_82;
                                continue block27;
                            }
                            case 29: {
                                var76_78 = NativeRegExp.getIndex(var3_3, var5_5);
                                var77_79 = var5_5 + 2;
                                var0.setParens(var76_78, var0.cp, 0);
                                var78_80 = var77_79 + 1;
                                var6_6 = var3_3[var77_79];
                                var5_5 = var78_80;
                                continue block27;
                            }
                            case 30: {
                                var72_74 = NativeRegExp.getIndex(var3_3, var5_5);
                                var73_75 = var5_5 + 2;
                                var74_76 = var0.parensIndex(var72_74);
                                var0.setParens(var72_74, var74_76, var0.cp - var74_76);
                                var75_77 = var73_75 + 1;
                                var6_6 = var3_3[var73_75];
                                var5_5 = var75_77;
                                continue block27;
                            }
                            case 41: {
                                var70_72 = var5_5 + NativeRegExp.getIndex(var3_3, var5_5);
                                var71_73 = var5_5 + 2;
                                var23_27 = var71_73 + 1;
                                var6_6 = var3_3[var71_73];
                                if (NativeRegExp.reopIsSimple(var6_6) && NativeRegExp.simpleMatch(var0, var1_1, var6_6, var3_3, var23_27, var2_2, false) < 0) {
                                    var9_9 = false;
                                    break;
                                }
                                NativeRegExp.pushProgState(var0, 0, 0, var0.cp, var0.backTrackStackTop, var4_4, var8_8);
                                NativeRegExp.pushBackTrackState(var0, (byte)43, var70_72);
                                var5_5 = var23_27;
                                continue block27;
                            }
                            case 42: {
                                var67_69 = var5_5 + NativeRegExp.getIndex(var3_3, var5_5);
                                var68_70 = var5_5 + 2;
                                var23_27 = var68_70 + 1;
                                var6_6 = var3_3[var68_70];
                                if (NativeRegExp.reopIsSimple(var6_6) && (var69_71 = NativeRegExp.simpleMatch(var0, var1_1, var6_6, var3_3, var23_27, var2_2, false)) >= 0 && var3_3[var69_71] == 44) {
                                    var9_9 = false;
                                    break;
                                }
                                NativeRegExp.pushProgState(var0, 0, 0, var0.cp, var0.backTrackStackTop, var4_4, var8_8);
                                NativeRegExp.pushBackTrackState(var0, (byte)44, var67_69);
                                var5_5 = var23_27;
                                continue block27;
                            }
                            case 43: 
                            case 44: {
                                var66_68 = NativeRegExp.popProgState(var0);
                                var0.cp = var66_68.index;
                                var0.backTrackStackTop = var66_68.backTrack;
                                var8_8 = var66_68.continuationPc;
                                var4_4 = var66_68.continuationOp;
                                if (var6_6 == 44) {
                                    var9_9 = var9_9 == false;
                                }
                                var23_27 = var5_5;
                                break;
                            }
                            case 25: 
                            case 26: 
                            case 27: 
                            case 28: 
                            case 45: 
                            case 46: 
                            case 47: 
                            case 48: {
                                var54_57 = false;
                                switch (var6_6) {
                                    default: {
                                        throw Kit.codeBug();
                                    }
                                    case 26: {
                                        var54_57 = true;
                                    }
                                    case 45: {
                                        var55_58 = 0;
                                        var57_60 = -1;
                                        break;
                                    }
                                    case 27: {
                                        var54_57 = true;
                                    }
                                    case 46: {
                                        var55_58 = 1;
                                        var57_60 = -1;
                                        break;
                                    }
                                    case 28: {
                                        var54_57 = true;
                                    }
                                    case 47: {
                                        var57_60 = 1;
                                        var55_58 = 0;
                                        break;
                                    }
                                    case 25: {
                                        var54_57 = true;
                                    }
                                    case 48: {
                                        var55_58 = NativeRegExp.getOffset(var3_3, var5_5);
                                        var56_59 = var5_5 + 2;
                                        var57_60 = -1 + NativeRegExp.getOffset(var3_3, var56_59);
                                        var5_5 = var56_59 + 2;
                                    }
                                }
                                NativeRegExp.pushProgState(var0, var55_58, var57_60, var0.cp, null, var4_4, var8_8);
                                if (var54_57) {
                                    NativeRegExp.pushBackTrackState(var0, (byte)51, var5_5);
                                    var4_4 = 51;
                                    var8_8 = var5_5;
                                    var64_66 = var5_5 + 6;
                                    var65_67 = var64_66 + 1;
                                    var6_6 = var3_3[var64_66];
                                    var5_5 = var65_67;
                                    continue block27;
                                }
                                if (var55_58 != 0) {
                                    var4_4 = 52;
                                    var8_8 = var5_5;
                                    var62_64 = var5_5 + 6;
                                    var63_65 = var62_64 + 1;
                                    var6_6 = var3_3[var62_64];
                                    var5_5 = var63_65;
                                    continue block27;
                                }
                                NativeRegExp.pushBackTrackState(var0, (byte)52, var5_5);
                                NativeRegExp.popProgState(var0);
                                var59_61 = var5_5 + 4;
                                var60_62 = var59_61 + NativeRegExp.getOffset(var3_3, var59_61);
                                var61_63 = var60_62 + 1;
                                var6_6 = var3_3[var60_62];
                                var5_5 = var61_63;
                                continue block27;
                            }
                            case 49: {
                                var9_9 = true;
                                var5_5 = var8_8;
                                var6_6 = var4_4;
                                continue block27;
                            }
                            case 51: {
                                break block61;
                            }
                            case 52: {
                                var10_15 = NativeRegExp.popProgState(var0);
                                if (!var9_9) {
                                    if (var10_15.max == -1 || var10_15.max > 0) {
                                        NativeRegExp.pushProgState(var0, var10_15.min, var10_15.max, var0.cp, null, var10_15.continuationOp, var10_15.continuationPc);
                                        var4_4 = 52;
                                        var8_8 = var5_5;
                                        var26_29 = NativeRegExp.getIndex(var3_3, var5_5);
                                        var27_30 = var5_5 + 2;
                                        var28_31 = NativeRegExp.getIndex(var3_3, var27_30);
                                        var29_32 = var27_30 + 4;
                                        for (var30_33 = 0; var30_33 < var26_29; ++var30_33) {
                                            var0.setParens(var28_31 + var30_33, -1, 0);
                                        }
                                        var31_34 = var29_32 + 1;
                                        var6_6 = var3_3[var29_32];
                                        var5_5 = var31_34;
                                        continue block27;
                                    }
                                    var8_8 = var10_15.continuationPc;
                                    var4_4 = var10_15.continuationOp;
                                    var23_27 = var5_5;
                                    break;
                                }
                                if (var10_15.min == 0 && var0.cp == var10_15.index) {
                                    var8_8 = var10_15.continuationPc;
                                    var4_4 = var10_15.continuationOp;
                                    var23_27 = var5_5;
                                    var9_9 = false;
                                    break;
                                }
                                var11_16 = var10_15.min;
                                var12_17 = var10_15.max;
                                if (var11_16 != 0) {
                                    --var11_16;
                                }
                                if (var12_17 != -1) {
                                    --var12_17;
                                }
                                NativeRegExp.pushProgState(var0, var11_16, var12_17, var0.cp, null, var10_15.continuationOp, var10_15.continuationPc);
                                if (var11_16 != 0) {
                                    var4_4 = 52;
                                    var8_8 = var5_5;
                                    var17_21 = NativeRegExp.getIndex(var3_3, var5_5);
                                    var18_22 = var5_5 + 2;
                                    var19_23 = NativeRegExp.getIndex(var3_3, var18_22);
                                    var20_24 = var18_22 + 4;
                                    for (var21_25 = 0; var21_25 < var17_21; ++var21_25) {
                                        var0.setParens(var19_23 + var21_25, -1, 0);
                                    }
                                    var22_26 = var20_24 + 1;
                                    var6_6 = var3_3[var20_24];
                                    var5_5 = var22_26;
                                    continue block27;
                                }
                                var8_8 = var10_15.continuationPc;
                                var4_4 = var10_15.continuationOp;
                                NativeRegExp.pushBackTrackState(var0, (byte)52, var5_5);
                                NativeRegExp.popProgState(var0);
                                var14_18 = var5_5 + 4;
                                var15_19 = var14_18 + NativeRegExp.getOffset(var3_3, var14_18);
                                var16_20 = var15_19 + 1;
                                var6_6 = var3_3[var15_19];
                                var5_5 = var16_20;
                                continue block27;
                            }
                            case 57: {
                                return true;
                            }
                        }
                    }
lbl275: // 5 sources:
                    do {
                        if (!var9_9) {
                            var24_28 = var0.backTrackStackTop;
                            if (var24_28 == null) return false;
                            var0.backTrackStackTop = var24_28.previous;
                            var0.parens = var24_28.parens;
                            var0.cp = var24_28.cp;
                            var0.stateStackTop = var24_28.stateStackTop;
                            var4_4 = var24_28.continuationOp;
                            var8_8 = var24_28.continuationPc;
                            var5_5 = var24_28.pc;
                            var6_6 = var24_28.op;
                            continue block27;
                        }
                        var5_5 = var23_27 + 1;
                        var6_6 = var3_3[var23_27];
                        continue block27;
                        break;
                    } while (true);
                }
                do {
                    block64 : {
                        block63 : {
                            block62 : {
                                var32_35 = NativeRegExp.popProgState(var0);
                                if (var9_9) break block62;
                                if (var32_35.min == 0) {
                                    var9_9 = true;
                                }
                                var8_8 = var32_35.continuationPc;
                                var4_4 = var32_35.continuationOp;
                                var53_56 = var5_5 + 4;
                                var23_27 = var53_56 + NativeRegExp.getOffset(var3_3, var53_56);
                                ** GOTO lbl275
                            }
                            if (var32_35.min != 0 || var0.cp != var32_35.index) break block63;
                            var8_8 = var32_35.continuationPc;
                            var4_4 = var32_35.continuationOp;
                            var52_55 = var5_5 + 4;
                            var23_27 = var52_55 + NativeRegExp.getOffset(var3_3, var52_55);
                            var9_9 = false;
                            ** GOTO lbl275
                        }
                        var33_36 = var32_35.min;
                        var34_37 = var32_35.max;
                        var35_38 = var33_36 != 0 ? var33_36 - 1 : var33_36;
                        var36_39 = var34_37 != -1 ? var34_37 - 1 : var34_37;
                        if (var36_39 != 0) break block64;
                        var9_9 = true;
                        var8_8 = var32_35.continuationPc;
                        var4_4 = var32_35.continuationOp;
                        var51_54 = var5_5 + 4;
                        var23_27 = var51_54 + NativeRegExp.getOffset(var3_3, var51_54);
                        ** GOTO lbl275
                    }
                    var37_40 = var5_5 + 6;
                    var38_41 = var3_3[var37_40];
                    var39_42 = var0.cp;
                    if (NativeRegExp.reopIsSimple(var38_41)) {
                        var49_52 = NativeRegExp.simpleMatch(var0, var1_1, var38_41, var3_3, var37_40 + 1, var2_2, true);
                        if (var49_52 < 0) {
                            var9_9 = var35_38 == 0;
                            var8_8 = var32_35.continuationPc;
                            var4_4 = var32_35.continuationOp;
                            var50_53 = var5_5 + 4;
                            var23_27 = var50_53 + NativeRegExp.getOffset(var3_3, var50_53);
                            ** continue;
                        }
                        var9_9 = true;
                        var37_40 = var49_52;
                    }
                    var4_4 = 51;
                    var8_8 = var5_5;
                    var40_43 = var32_35.continuationOp;
                    var41_44 = var32_35.continuationPc;
                    NativeRegExp.pushProgState(var0, var35_38, var36_39, var39_42, null, var40_43, var41_44);
                    if (var35_38 != 0) continue;
                    var44_47 = var32_35.continuationOp;
                    var45_48 = var32_35.continuationPc;
                    NativeRegExp.pushBackTrackState(var0, (byte)51, var5_5, var39_42, var44_47, var45_48);
                    var46_49 = NativeRegExp.getIndex(var3_3, var5_5);
                    var47_50 = NativeRegExp.getIndex(var3_3, var5_5 + 2);
                    for (var48_51 = 0; var48_51 < var46_49; ++var48_51) {
                        var0.setParens(var47_50 + var48_51, -1, 0);
                    }
                } while (var3_3[var37_40] == 49);
                var42_45 = var37_40;
                var43_46 = var42_45 + 1;
                var6_6 = var3_3[var42_45];
                var5_5 = var43_46;
            } while (true);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean flatNIMatcher(REGlobalData rEGlobalData, int n, int n2, String string2, int n3) {
        if (n2 + rEGlobalData.cp <= n3) {
            char[] arrc = rEGlobalData.regexp.source;
            int n4 = 0;
            do {
                if (n4 >= n2) {
                    rEGlobalData.cp = n2 + rEGlobalData.cp;
                    return true;
                }
                char c = arrc[n + n4];
                char c2 = string2.charAt(n4 + rEGlobalData.cp);
                if (c != c2 && NativeRegExp.upcase(c) != NativeRegExp.upcase(c2)) break;
                ++n4;
            } while (true);
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean flatNMatcher(REGlobalData rEGlobalData, int n, int n2, String string2, int n3) {
        if (n2 + rEGlobalData.cp <= n3) {
            int n4 = 0;
            do {
                if (n4 >= n2) {
                    rEGlobalData.cp = n2 + rEGlobalData.cp;
                    return true;
                }
                if (rEGlobalData.regexp.source[n + n4] != string2.charAt(n4 + rEGlobalData.cp)) break;
                ++n4;
            } while (true);
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int getDecimalValue(char c, CompilerState compilerState, int n, String string2) {
        boolean bl = false;
        int n2 = compilerState.cp;
        char[] arrc = compilerState.cpbegin;
        int n3 = c - 48;
        do {
            char c2;
            if (compilerState.cp == compilerState.cpend || !NativeRegExp.isDigit(c2 = arrc[compilerState.cp])) {
                if (bl) {
                    NativeRegExp.reportError(string2, String.valueOf((char[])arrc, (int)n2, (int)(compilerState.cp - n2)));
                }
                return n3;
            }
            if (!bl) {
                int n4 = n3 * 10 + (c2 - 48);
                if (n4 < n) {
                    n3 = n4;
                } else {
                    bl = true;
                    n3 = n;
                }
            }
            compilerState.cp = 1 + compilerState.cp;
        } while (true);
    }

    private static RegExpImpl getImpl(Context context) {
        return (RegExpImpl)ScriptRuntime.getRegExpProxy(context);
    }

    private static int getIndex(byte[] arrby, int n) {
        return (255 & arrby[n]) << 8 | 255 & arrby[n + 1];
    }

    private static int getOffset(byte[] arrby, int n) {
        return NativeRegExp.getIndex(arrby, n);
    }

    public static void init(Context context, Scriptable scriptable, boolean bl) {
        NativeRegExp nativeRegExp = new NativeRegExp();
        nativeRegExp.re = NativeRegExp.compileRE(context, "", null, false);
        nativeRegExp.activatePrototypeMap(6);
        nativeRegExp.setParentScope(scriptable);
        nativeRegExp.setPrototype(NativeRegExp.getObjectPrototype(scriptable));
        NativeRegExpCtor nativeRegExpCtor = new NativeRegExpCtor();
        nativeRegExp.defineProperty("constructor", nativeRegExpCtor, 2);
        ScriptRuntime.setFunctionProtoAndParent(nativeRegExpCtor, scriptable);
        nativeRegExpCtor.setImmunePrototypeProperty(nativeRegExp);
        if (bl) {
            nativeRegExp.sealObject();
            nativeRegExpCtor.sealObject();
        }
        NativeRegExp.defineProperty(scriptable, "RegExp", nativeRegExpCtor, 2);
    }

    private static boolean isControlLetter(char c) {
        return 'a' <= c && c <= 'z' || 'A' <= c && c <= 'Z';
    }

    static boolean isDigit(char c) {
        return '0' <= c && c <= '9';
    }

    private static boolean isLineTerm(char c) {
        return ScriptRuntime.isJSLineTerminator(c);
    }

    private static boolean isREWhiteSpace(int n) {
        return ScriptRuntime.isJSWhitespaceOrLineTerminator(n);
    }

    private static boolean isWord(char c) {
        return 'a' <= c && c <= 'z' || 'A' <= c && c <= 'Z' || NativeRegExp.isDigit(c) || c == '_';
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static boolean matchRegExp(REGlobalData var0, RECompiled var1_1, String var2_2, int var3_3, int var4_4, boolean var5_5) {
        var0.parens = var1_1.parenCount != 0 ? new long[var1_1.parenCount] : null;
        var0.backTrackStackTop = null;
        var0.stateStackTop = null;
        var6_6 = var5_5 != false || (4 & var1_1.flags) != 0;
        var0.multiline = var6_6;
        var0.regexp = var1_1;
        var7_7 = var0.regexp.anchorCh;
        var8_8 = var3_3;
        while (var8_8 <= var4_4) {
            if (var7_7 < 0) ** GOTO lbl16
            do {
                block7 : {
                    if (var8_8 == var4_4) {
                        return false;
                    }
                    var11_11 = var2_2.charAt(var8_8);
                    if (var11_11 != var7_7 && ((2 & var0.regexp.flags) == 0 || NativeRegExp.upcase(var11_11) != NativeRegExp.upcase((char)var7_7))) break block7;
lbl16: // 2 sources:
                    var0.cp = var8_8;
                    var0.skipped = var8_8 - var3_3;
                    for (var9_9 = 0; var9_9 < var1_1.parenCount; ++var9_9) {
                        var0.parens[var9_9] = -1L;
                    }
                    break;
                }
                ++var8_8;
            } while (true);
            var10_10 = NativeRegExp.executeREBytecode(var0, var2_2, var4_4);
            var0.backTrackStackTop = null;
            var0.stateStackTop = null;
            if (var10_10) {
                return true;
            }
            if (var7_7 == -2 && !var0.multiline) {
                var0.skipped = var4_4;
                return false;
            }
            var8_8 = 1 + (var3_3 + var0.skipped);
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean parseAlternative(CompilerState compilerState) {
        RENode rENode = null;
        RENode rENode2 = null;
        char[] arrc = compilerState.cpbegin;
        block0 : do {
            if (compilerState.cp == compilerState.cpend || arrc[compilerState.cp] == '|' || compilerState.parenNesting != 0 && arrc[compilerState.cp] == ')') {
                if (rENode == null) {
                    compilerState.result = new RENode(1);
                    return true;
                }
                compilerState.result = rENode;
                return true;
            }
            if (!NativeRegExp.parseTerm(compilerState)) {
                return false;
            }
            if (rENode == null) {
                rENode2 = rENode = compilerState.result;
            } else {
                rENode2.next = compilerState.result;
            }
            do {
                if (rENode2.next == null) continue block0;
                rENode2 = rENode2.next;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean parseDisjunction(CompilerState compilerState) {
        if (!NativeRegExp.parseAlternative(compilerState)) {
            return false;
        }
        int n = compilerState.cp;
        char[] arrc = compilerState.cpbegin;
        if (n == arrc.length) return true;
        if (arrc[n] != '|') return true;
        compilerState.cp = 1 + compilerState.cp;
        RENode rENode = new RENode(31);
        rENode.kid = compilerState.result;
        if (!NativeRegExp.parseDisjunction(compilerState)) return false;
        rENode.kid2 = compilerState.result;
        compilerState.result = rENode;
        if (rENode.kid.op == 14 && rENode.kid2.op == 14) {
            int n2 = (2 & compilerState.flags) == 0 ? 53 : 54;
            rENode.op = (byte)n2;
            rENode.chr = rENode.kid.chr;
            rENode.index = rENode.kid2.chr;
            compilerState.progLength = 13 + compilerState.progLength;
            return true;
        }
        if (rENode.kid.op == 22 && rENode.kid.index < 256 && rENode.kid2.op == 14 && (2 & compilerState.flags) == 0) {
            rENode.op = (byte)55;
            rENode.chr = rENode.kid2.chr;
            rENode.index = rENode.kid.index;
            compilerState.progLength = 13 + compilerState.progLength;
            return true;
        }
        if (rENode.kid.op == 14 && rENode.kid2.op == 22 && rENode.kid2.index < 256 && (2 & compilerState.flags) == 0) {
            rENode.op = (byte)55;
            rENode.chr = rENode.kid.chr;
            rENode.index = rENode.kid2.index;
            compilerState.progLength = 13 + compilerState.progLength;
            return true;
        }
        compilerState.progLength = 9 + compilerState.progLength;
        return true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static boolean parseTerm(CompilerState var0) {
        block72 : {
            var1_1 = var0.cpbegin;
            var2_2 = var0.cp;
            var0.cp = var2_2 + 1;
            var3_3 = var1_1[var2_2];
            var4_4 = 2;
            var5_5 = var0.parenCount;
            switch (var3_3) {
                default: {
                    var0.result = new RENode(14);
                    var0.result.chr = var3_3;
                    var0.result.length = 1;
                    var0.result.flatIndex = -1 + var0.cp;
                    var0.progLength = 3 + var0.progLength;
                    ** GOTO lbl207
                }
                case '^': {
                    var0.result = new RENode(2);
                    var0.progLength = 1 + var0.progLength;
                    return true;
                }
                case '$': {
                    var0.result = new RENode(3);
                    var0.progLength = 1 + var0.progLength;
                    return true;
                }
                case '\\': {
                    if (var0.cp >= var0.cpend) {
                        NativeRegExp.reportError("msg.trail.backslash", "");
                        return false;
                    }
                    var27_7 = var0.cp;
                    var0.cp = var27_7 + 1;
                    var28_8 = var1_1[var27_7];
                    block10 : switch (var28_8) {
                        default: {
                            var0.result = new RENode(14);
                            var0.result.chr = var28_8;
                            var0.result.length = 1;
                            var0.result.flatIndex = -1 + var0.cp;
                            var0.progLength = 3 + var0.progLength;
                            break;
                        }
                        case 'b': {
                            var0.result = new RENode(4);
                            var0.progLength = 1 + var0.progLength;
                            return true;
                        }
                        case 'B': {
                            var0.result = new RENode(5);
                            var0.progLength = 1 + var0.progLength;
                            return true;
                        }
                        case '0': {
                            NativeRegExp.reportWarning(var0.cx, "msg.bad.backref", "");
                            var39_9 = 0;
                            while (var39_9 < 32 && var0.cp < var0.cpend && (var40_10 = var1_1[var0.cp]) >= '0' && var40_10 <= '7') {
                                var0.cp = 1 + var0.cp;
                                var39_9 = var39_9 * 8 + (var40_10 - 48);
                            }
                            NativeRegExp.doFlat(var0, (char)var39_9);
                            break;
                        }
                        case '1': 
                        case '2': 
                        case '3': 
                        case '4': 
                        case '5': 
                        case '6': 
                        case '7': 
                        case '8': 
                        case '9': {
                            var35_11 = -1 + var0.cp;
                            var36_12 = NativeRegExp.getDecimalValue(var28_8, var0, 65535, "msg.overlarge.backref");
                            if (var36_12 > var0.backReferenceLimit) {
                                NativeRegExp.reportWarning(var0.cx, "msg.bad.backref", "");
                            }
                            if (var36_12 > var0.backReferenceLimit) {
                                var0.cp = var35_11;
                                if (var28_8 >= '8') {
                                    NativeRegExp.doFlat(var0, '\\');
                                    break;
                                }
                                var0.cp = 1 + var0.cp;
                                var37_13 = var28_8 - 48;
                                while (var37_13 < 32 && var0.cp < var0.cpend && (var38_14 = var1_1[var0.cp]) >= '0' && var38_14 <= '7') {
                                    var0.cp = 1 + var0.cp;
                                    var37_13 = var37_13 * 8 + (var38_14 - 48);
                                }
                                NativeRegExp.doFlat(var0, (char)var37_13);
                                break;
                            }
                            var0.result = new RENode(13);
                            var0.result.parenIndex = var36_12 - 1;
                            var0.progLength = 3 + var0.progLength;
                            if (var0.maxBackReference >= var36_12) break;
                            var0.maxBackReference = var36_12;
                            break;
                        }
                        case 'f': {
                            NativeRegExp.doFlat(var0, '\f');
                            break;
                        }
                        case 'n': {
                            NativeRegExp.doFlat(var0, '\n');
                            break;
                        }
                        case 'r': {
                            NativeRegExp.doFlat(var0, '\r');
                            break;
                        }
                        case 't': {
                            NativeRegExp.doFlat(var0, '\t');
                            break;
                        }
                        case 'v': {
                            NativeRegExp.doFlat(var0, '\u000b');
                            break;
                        }
                        case 'c': {
                            if (var0.cp < var0.cpend && NativeRegExp.isControlLetter(var1_1[var0.cp])) {
                                var34_15 = var0.cp;
                                var0.cp = var34_15 + 1;
                                var33_16 = (char)(31 & var1_1[var34_15]);
                            } else {
                                var0.cp = -1 + var0.cp;
                                var33_16 = '\\';
                            }
                            NativeRegExp.doFlat(var0, var33_16);
                            break;
                        }
                        case 'u': {
                            var4_4 += 2;
                        }
                        case 'x': {
                            var29_17 = 0;
                            var30_18 = 0;
                            do {
                                if (var30_18 >= var4_4 || var0.cp >= var0.cpend) ** GOTO lbl118
                                var31_19 = var0.cp;
                                var0.cp = var31_19 + 1;
                                if ((var29_17 = Kit.xDigitToInt(var1_1[var31_19], var29_17)) >= 0) ** GOTO lbl120
                                var0.cp -= var30_18 + 2;
                                var32_20 = var0.cp;
                                var0.cp = var32_20 + 1;
                                var29_17 = var1_1[var32_20];
lbl118: // 2 sources:
                                NativeRegExp.doFlat(var0, (char)(var29_17 ? 1 : 0));
                                break block10;
lbl120: // 1 sources:
                                ++var30_18;
                            } while (true);
                        }
                        case 'd': {
                            var0.result = new RENode(7);
                            var0.progLength = 1 + var0.progLength;
                            break;
                        }
                        case 'D': {
                            var0.result = new RENode(8);
                            var0.progLength = 1 + var0.progLength;
                            break;
                        }
                        case 's': {
                            var0.result = new RENode(11);
                            var0.progLength = 1 + var0.progLength;
                            break;
                        }
                        case 'S': {
                            var0.result = new RENode(12);
                            var0.progLength = 1 + var0.progLength;
                            break;
                        }
                        case 'w': {
                            var0.result = new RENode(9);
                            var0.progLength = 1 + var0.progLength;
                            break;
                        }
                        case 'W': {
                            var0.result = new RENode(10);
                            var0.progLength = 1 + var0.progLength;
                            break;
                        }
                    }
                    ** GOTO lbl207
                }
                case '(': {
                    if (1 + var0.cp < var0.cpend && var1_1[var0.cp] == '?' && ((var26_21 = var1_1[1 + var0.cp]) == '=' || var26_21 == '!' || var26_21 == ':')) {
                        var0.cp = 2 + var0.cp;
                        if (var26_21 == '=') {
                            var24_22 = new RENode(41);
                            var0.progLength = 4 + var0.progLength;
                        } else {
                            var24_22 = null;
                            if (var26_21 == '!') {
                                var24_22 = new RENode(42);
                                var0.progLength = 4 + var0.progLength;
                            }
                        }
                    } else {
                        var24_22 = new RENode(29);
                        var0.progLength = 6 + var0.progLength;
                        var25_23 = var0.parenCount;
                        var0.parenCount = var25_23 + 1;
                        var24_22.parenIndex = var25_23;
                    }
                    var0.parenNesting = 1 + var0.parenNesting;
                    if (!NativeRegExp.parseDisjunction(var0)) {
                        return false;
                    }
                    if (var0.cp == var0.cpend || var1_1[var0.cp] != ')') {
                        NativeRegExp.reportError("msg.unterm.paren", "");
                        return false;
                    }
                    var0.cp = 1 + var0.cp;
                    var0.parenNesting = -1 + var0.parenNesting;
                    if (var24_22 != null) {
                        var24_22.kid = var0.result;
                        var0.result = var24_22;
                    }
                    ** GOTO lbl207
                }
                case ')': {
                    NativeRegExp.reportError("msg.re.unmatched.right.paren", "");
                    return false;
                }
                case '[': {
                    var0.result = new RENode(22);
                    var0.result.startIndex = var18_24 = var0.cp;
                    do {
                        if (var0.cp == var0.cpend) {
                            NativeRegExp.reportError("msg.unterm.class", "");
                            return false;
                        }
                        if (var1_1[var0.cp] == '\\') {
                            var0.cp = 1 + var0.cp;
                        } else if (var1_1[var0.cp] == ']') {
                            var0.result.kidlen = var0.cp - var18_24;
                            var19_25 = var0.result;
                            var20_26 = var0.classCount;
                            var0.classCount = var20_26 + 1;
                            var19_25.index = var20_26;
                            var21_27 = var0.result;
                            var22_28 = var0.cp;
                            var0.cp = var22_28 + 1;
                            if (NativeRegExp.calculateBitmapSize(var0, var21_27, var1_1, var18_24, var22_28)) break;
                            return false;
                        }
                        var0.cp = 1 + var0.cp;
                    } while (true);
                    var0.progLength = 3 + var0.progLength;
                    ** GOTO lbl207
                }
                case '.': {
                    var0.result = new RENode(6);
                    var0.progLength = 1 + var0.progLength;
lbl207: // 5 sources:
                    var6_6 = var0.result;
                    if (var0.cp == var0.cpend) {
                        return true;
                    }
                    break block72;
                }
                case '*': 
                case '+': 
                case '?': 
            }
            NativeRegExp.reportError("msg.bad.quant", String.valueOf((char)var1_1[-1 + var0.cp]));
            return false;
        }
        var7_29 = var1_1[var0.cp];
        var8_30 = false;
        switch (var7_29) {
            case '+': {
                var0.result = new RENode(25);
                var0.result.min = 1;
                var0.result.max = -1;
                var0.progLength = 8 + var0.progLength;
                var8_30 = true;
                break;
            }
            case '*': {
                var0.result = new RENode(25);
                var0.result.min = 0;
                var0.result.max = -1;
                var0.progLength = 8 + var0.progLength;
                var8_30 = true;
                break;
            }
            case '?': {
                var0.result = new RENode(25);
                var0.result.min = 0;
                var0.result.max = 1;
                var0.progLength = 8 + var0.progLength;
                var8_30 = true;
                break;
            }
            case '{': {
                var9_31 = -1;
                var10_32 = var0.cp;
                var0.cp = var11_33 = 1 + var0.cp;
                var12_34 = var1_1.length;
                var8_30 = false;
                if (var11_33 < var12_34) {
                    var13_35 = var1_1[var0.cp];
                    var14_36 = NativeRegExp.isDigit(var13_35);
                    var8_30 = false;
                    if (var14_36) {
                        var0.cp = 1 + var0.cp;
                        var15_37 = NativeRegExp.getDecimalValue(var13_35, var0, 65535, "msg.overlarge.min");
                        var16_38 = var1_1[var0.cp];
                        if (var16_38 == ',') {
                            var0.cp = var17_39 = 1 + var0.cp;
                            var16_38 = var1_1[var17_39];
                            if (NativeRegExp.isDigit(var16_38)) {
                                var0.cp = 1 + var0.cp;
                                var9_31 = NativeRegExp.getDecimalValue(var16_38, var0, 65535, "msg.overlarge.max");
                                var16_38 = var1_1[var0.cp];
                                if (var15_37 > var9_31) {
                                    NativeRegExp.reportError("msg.max.lt.min", String.valueOf((char)var1_1[var0.cp]));
                                    return false;
                                }
                            }
                        } else {
                            var9_31 = var15_37;
                        }
                        var8_30 = false;
                        if (var16_38 == '}') {
                            var0.result = new RENode(25);
                            var0.result.min = var15_37;
                            var0.result.max = var9_31;
                            var0.progLength = 12 + var0.progLength;
                            var8_30 = true;
                        }
                    }
                }
                if (var8_30) break;
                var0.cp = var10_32;
            }
        }
        if (!var8_30) {
            return true;
        }
        var0.cp = 1 + var0.cp;
        var0.result.kid = var6_6;
        var0.result.parenIndex = var5_5;
        var0.result.parenCount = var0.parenCount - var5_5;
        if (var0.cp < var0.cpend && var1_1[var0.cp] == '?') {
            var0.cp = 1 + var0.cp;
            var0.result.greedy = false;
            return true;
        }
        var0.result.greedy = true;
        return true;
    }

    private static REProgState popProgState(REGlobalData rEGlobalData) {
        REProgState rEProgState = rEGlobalData.stateStackTop;
        rEGlobalData.stateStackTop = rEProgState.previous;
        return rEProgState;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void processCharSet(REGlobalData rEGlobalData, RECharSet rECharSet) {
        RECharSet rECharSet2 = rECharSet;
        synchronized (rECharSet2) {
            if (!rECharSet.converted) {
                NativeRegExp.processCharSetImpl(rEGlobalData, rECharSet);
                rECharSet.converted = true;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void processCharSetImpl(REGlobalData var0, RECharSet var1_1) {
        block50 : {
            var2_2 = var1_1.startIndex;
            var3_3 = var2_2 + var1_1.strlength;
            var4_4 = '\u0000';
            var5_5 = false;
            var1_1.bits = new byte[(7 + var1_1.length) / 8];
            if (var2_2 == var3_3) {
                return;
            }
            if (var0.regexp.source[var2_2] == '^') break block50;
            var6_7 = NativeRegExp.$assertionsDisabled;
            var5_5 = false;
            var4_4 = '\u0000';
            if (!var6_7) {
                var33_32 = var1_1.sense;
                var5_5 = false;
                var4_4 = '\u0000';
                if (!var33_32) {
                    throw new AssertionError();
                }
            }
            ** GOTO lbl177
        }
        if (!NativeRegExp.$assertionsDisabled && var1_1.sense) {
            throw new AssertionError();
        }
        var7_6 = var2_2 + 1;
        block21 : do {
            block51 : {
                if (var7_6 == var3_3) return;
                var9_8 = 2;
                block0 : switch (var0.regexp.source[var7_6]) {
                    default: {
                        var32_31 = var0.regexp.source;
                        var2_2 = var7_6 + 1;
                        var19_18 = var32_31[var7_6];
                        break;
                    }
                    case '\\': {
                        var10_9 = var7_6 + 1;
                        var11_10 = var0.regexp.source;
                        var7_6 = var10_9 + 1;
                        var12_11 = var11_10[var10_9];
                        switch (var12_11) {
                            default: {
                                var19_18 = var12_11;
                                var2_2 = var7_6;
                                break block0;
                            }
                            case 98: {
                                var19_18 = '\b';
                                var2_2 = var7_6;
                                break block0;
                            }
                            case 102: {
                                var19_18 = '\f';
                                var2_2 = var7_6;
                                break block0;
                            }
                            case 110: {
                                var19_18 = '\n';
                                var2_2 = var7_6;
                                break block0;
                            }
                            case 114: {
                                var19_18 = '\r';
                                var2_2 = var7_6;
                                break block0;
                            }
                            case 116: {
                                var19_18 = '\t';
                                var2_2 = var7_6;
                                break block0;
                            }
                            case 118: {
                                var19_18 = '\u000b';
                                var2_2 = var7_6;
                                break block0;
                            }
                            case 99: {
                                if (var7_6 < var3_3 && NativeRegExp.isControlLetter(var0.regexp.source[var7_6])) {
                                    var31_30 = var0.regexp.source;
                                    var2_2 = var7_6 + 1;
                                    var19_18 = (char)(31 & var31_30[var7_6]);
                                    break block0;
                                }
                                var2_2 = var7_6 - 1;
                                var19_18 = '\\';
                                break block0;
                            }
                            case 117: {
                                var9_8 += 2;
                            }
                            case 120: {
                                var26_25 = 0;
                                for (var27_26 = 0; var27_26 < var9_8 && var7_6 < var3_3; ++var27_26) {
                                    var28_27 = var0.regexp.source;
                                    var29_28 = var7_6 + 1;
                                    var30_29 = NativeRegExp.toASCIIHexDigit(var28_27[var7_6]);
                                    if (var30_29 >= 0) ** GOTO lbl87
                                    var2_2 = var29_28 - (var27_26 + 1);
                                    var26_25 = 92;
                                    ** GOTO lbl144
lbl87: // 1 sources:
                                    var26_25 = var30_29 | var26_25 << 4;
                                    var7_6 = var29_28;
                                }
                                ** GOTO lbl143
                            }
                            case 48: 
                            case 49: 
                            case 50: 
                            case 51: 
                            case 52: 
                            case 53: 
                            case 54: 
                            case 55: {
                                var17_16 = var12_11 - 48;
                                var18_17 = var0.regexp.source[var7_6];
                                if ('0' > var18_17 || var18_17 > '7') break;
                                var2_2 = var7_6 + 1;
                                var17_16 = var17_16 * 8 + (var18_17 - 48);
                                var24_23 = var0.regexp.source[var2_2];
                                if ('0' <= var24_23 && var24_23 <= '7') {
                                    ++var2_2;
                                    var25_24 = var17_16 * 8 + (var24_23 - 48);
                                    if (var25_24 <= 255) {
                                        var17_16 = var25_24;
                                    } else {
                                        --var2_2;
                                    }
                                }
                                ** GOTO lbl141
                            }
                            case 100: {
                                NativeRegExp.addCharacterRangeToCharSet(var1_1, '0', '9');
                                continue block21;
                            }
                            case 68: {
                                NativeRegExp.addCharacterRangeToCharSet(var1_1, '\u0000', '/');
                                NativeRegExp.addCharacterRangeToCharSet(var1_1, ':', (char)(-1 + var1_1.length));
                                continue block21;
                            }
                            case 115: {
                                var16_15 = -1 + var1_1.length;
                                do {
                                    if (var16_15 < 0) continue block21;
                                    if (NativeRegExp.isREWhiteSpace(var16_15)) {
                                        NativeRegExp.addCharacterToCharSet(var1_1, (char)var16_15);
                                    }
                                    --var16_15;
                                } while (true);
                            }
                            case 83: {
                                var15_14 = -1 + var1_1.length;
                                do {
                                    if (var15_14 < 0) continue block21;
                                    if (!NativeRegExp.isREWhiteSpace(var15_14)) {
                                        NativeRegExp.addCharacterToCharSet(var1_1, (char)var15_14);
                                    }
                                    --var15_14;
                                } while (true);
                            }
                            case 119: {
                                var14_13 = -1 + var1_1.length;
                                do {
                                    if (var14_13 < 0) continue block21;
                                    if (NativeRegExp.isWord((char)var14_13)) {
                                        NativeRegExp.addCharacterToCharSet(var1_1, (char)var14_13);
                                    }
                                    --var14_13;
                                } while (true);
                            }
                            case 87: {
                                var13_12 = -1 + var1_1.length;
                                break block51;
                            }
                        }
                        var2_2 = var7_6;
lbl141: // 3 sources:
                        var19_18 = (char)var17_16;
                        break;
lbl143: // 1 sources:
                        var2_2 = var7_6;
lbl144: // 2 sources:
                        var19_18 = (char)(var26_25 ? 1 : 0);
                    }
                }
                if (var5_5) {
                    if ((2 & var0.regexp.flags) != 0) {
                        if (!NativeRegExp.$assertionsDisabled && var4_4 > var19_18) {
                            throw new AssertionError();
                        }
                        var21_20 = var4_4;
                        while (var21_20 <= var19_18) {
                            NativeRegExp.addCharacterToCharSet(var1_1, var21_20);
                            var22_21 = NativeRegExp.upcase(var21_20);
                            var23_22 = NativeRegExp.downcase(var21_20);
                            if (var21_20 != var22_21) {
                                NativeRegExp.addCharacterToCharSet(var1_1, var22_21);
                            }
                            if (var21_20 != var23_22) {
                                NativeRegExp.addCharacterToCharSet(var1_1, var23_22);
                            }
                            if ((var21_20 = (char)((char)(var21_20 + 1))) != '\u0000') continue;
                            break;
                        }
                    } else {
                        NativeRegExp.addCharacterRangeToCharSet(var1_1, var4_4, var19_18);
                    }
                    var7_6 = var2_2;
                    var5_5 = false;
                    continue;
                }
                if ((2 & var0.regexp.flags) != 0) {
                    NativeRegExp.addCharacterToCharSet(var1_1, NativeRegExp.upcase(var19_18));
                    NativeRegExp.addCharacterToCharSet(var1_1, NativeRegExp.downcase(var19_18));
                } else {
                    NativeRegExp.addCharacterToCharSet(var1_1, var19_18);
                }
                if (var2_2 < var3_3 - 1 && var0.regexp.source[var2_2] == '-') {
                    var20_19 = var2_2 + 1;
                    var5_5 = true;
                    var4_4 = var19_18;
                    var7_6 = var20_19;
                    continue;
                }
lbl177: // 3 sources:
                var7_6 = var2_2;
                continue;
            }
            do {
                if (var13_12 < 0) ** break;
                if (!NativeRegExp.isWord((char)var13_12)) {
                    NativeRegExp.addCharacterToCharSet(var1_1, (char)var13_12);
                }
                --var13_12;
                ** break;
lbl186: // 1 sources:
            } while (true);
            break;
        } while (true);
    }

    private static void pushBackTrackState(REGlobalData rEGlobalData, byte by, int n) {
        REProgState rEProgState = rEGlobalData.stateStackTop;
        rEGlobalData.backTrackStackTop = new REBackTrackData(rEGlobalData, by, n, rEGlobalData.cp, rEProgState.continuationOp, rEProgState.continuationPc);
    }

    private static void pushBackTrackState(REGlobalData rEGlobalData, byte by, int n, int n2, int n3, int n4) {
        rEGlobalData.backTrackStackTop = new REBackTrackData(rEGlobalData, by, n, n2, n3, n4);
    }

    private static void pushProgState(REGlobalData rEGlobalData, int n, int n2, int n3, REBackTrackData rEBackTrackData, int n4, int n5) {
        rEGlobalData.stateStackTop = new REProgState(rEGlobalData.stateStackTop, n, n2, n3, rEBackTrackData, n4, n5);
    }

    private static NativeRegExp realThis(Scriptable scriptable, IdFunctionObject idFunctionObject) {
        if (!(scriptable instanceof NativeRegExp)) {
            throw NativeRegExp.incompatibleCallError(idFunctionObject);
        }
        return (NativeRegExp)scriptable;
    }

    private static boolean reopIsSimple(int n) {
        return n >= 1 && n <= 23;
    }

    private static void reportError(String string2, String string3) {
        throw ScriptRuntime.constructError("SyntaxError", ScriptRuntime.getMessage1(string2, string3));
    }

    private static void reportWarning(Context context, String string2, String string3) {
        if (context.hasFeature(11)) {
            Context.reportWarning(ScriptRuntime.getMessage1(string2, string3));
        }
    }

    private static void resolveForwardJump(byte[] arrby, int n, int n2) {
        if (n > n2) {
            throw Kit.codeBug();
        }
        NativeRegExp.addIndex(arrby, n, n2 - n);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int simpleMatch(REGlobalData var0, String var1_1, int var2_2, byte[] var3_3, int var4_4, int var5_5, boolean var6_6) {
        block53 : {
            var7_7 = var0.cp;
            switch (var2_2) {
                default: {
                    throw Kit.codeBug();
                }
                case 1: {
                    var10_8 = true;
                    break block53;
                }
                case 2: {
                    if (var0.cp == 0) ** GOTO lbl16
                    var53_9 = var0.multiline;
                    var10_8 = false;
                    if (!var53_9) break block53;
                    var54_10 = NativeRegExp.isLineTerm(var1_1.charAt(-1 + var0.cp));
                    var10_8 = false;
                    if (!var54_10) break block53;
lbl16: // 2 sources:
                    var10_8 = true;
                    break block53;
                }
                case 3: {
                    if (var0.cp == var5_5) ** GOTO lbl27
                    var51_11 = var0.multiline;
                    var10_8 = false;
                    if (!var51_11) break block53;
                    var52_12 = NativeRegExp.isLineTerm(var1_1.charAt(var0.cp));
                    var10_8 = false;
                    if (!var52_12) break block53;
lbl27: // 2 sources:
                    var10_8 = true;
                    break block53;
                }
                case 4: {
                    var49_13 = var0.cp == 0 || NativeRegExp.isWord(var1_1.charAt(-1 + var0.cp)) == false;
                    var50_14 = var0.cp >= var5_5 || NativeRegExp.isWord(var1_1.charAt(var0.cp)) == false;
                    var10_8 = var49_13 ^ var50_14;
                    break block53;
                }
                case 5: {
                    var47_15 = var0.cp == 0 || NativeRegExp.isWord(var1_1.charAt(-1 + var0.cp)) == false;
                    var48_16 = var0.cp < var5_5 && NativeRegExp.isWord(var1_1.charAt(var0.cp)) != false;
                    var10_8 = var47_15 ^ var48_16;
                    break block53;
                }
                case 6: {
                    var45_17 = var0.cp;
                    var10_8 = false;
                    if (var45_17 != var5_5) {
                        var46_18 = NativeRegExp.isLineTerm(var1_1.charAt(var0.cp));
                        var10_8 = false;
                        if (!var46_18) {
                            var10_8 = true;
                            var0.cp = 1 + var0.cp;
                        }
                    }
                    break block53;
                }
                case 7: {
                    var43_19 = var0.cp;
                    var10_8 = false;
                    if (var43_19 != var5_5) {
                        var44_20 = NativeRegExp.isDigit(var1_1.charAt(var0.cp));
                        var10_8 = false;
                        if (var44_20) {
                            var10_8 = true;
                            var0.cp = 1 + var0.cp;
                        }
                    }
                    break block53;
                }
                case 8: {
                    var41_21 = var0.cp;
                    var10_8 = false;
                    if (var41_21 != var5_5) {
                        var42_22 = NativeRegExp.isDigit(var1_1.charAt(var0.cp));
                        var10_8 = false;
                        if (!var42_22) {
                            var10_8 = true;
                            var0.cp = 1 + var0.cp;
                        }
                    }
                    break block53;
                }
                case 9: {
                    var39_23 = var0.cp;
                    var10_8 = false;
                    if (var39_23 != var5_5) {
                        var40_24 = NativeRegExp.isWord(var1_1.charAt(var0.cp));
                        var10_8 = false;
                        if (var40_24) {
                            var10_8 = true;
                            var0.cp = 1 + var0.cp;
                        }
                    }
                    break block53;
                }
                case 10: {
                    var37_25 = var0.cp;
                    var10_8 = false;
                    if (var37_25 != var5_5) {
                        var38_26 = NativeRegExp.isWord(var1_1.charAt(var0.cp));
                        var10_8 = false;
                        if (!var38_26) {
                            var10_8 = true;
                            var0.cp = 1 + var0.cp;
                        }
                    }
                    break block53;
                }
                case 11: {
                    var35_27 = var0.cp;
                    var10_8 = false;
                    if (var35_27 != var5_5) {
                        var36_28 = NativeRegExp.isREWhiteSpace(var1_1.charAt(var0.cp));
                        var10_8 = false;
                        if (var36_28) {
                            var10_8 = true;
                            var0.cp = 1 + var0.cp;
                        }
                    }
                    break block53;
                }
                case 12: {
                    var33_29 = var0.cp;
                    var10_8 = false;
                    if (var33_29 != var5_5) {
                        var34_30 = NativeRegExp.isREWhiteSpace(var1_1.charAt(var0.cp));
                        var10_8 = false;
                        if (!var34_30) {
                            var10_8 = true;
                            var0.cp = 1 + var0.cp;
                        }
                    }
                    break block53;
                }
                case 13: {
                    var32_31 = NativeRegExp.getIndex(var3_3, var4_4);
                    var4_4 += 2;
                    var10_8 = NativeRegExp.backrefMatcher(var0, var32_31, var1_1, var5_5);
                    break block53;
                }
                case 14: {
                    var29_32 = NativeRegExp.getIndex(var3_3, var4_4);
                    var30_33 = var4_4 + 2;
                    var31_34 = NativeRegExp.getIndex(var3_3, var30_33);
                    var4_4 = var30_33 + 2;
                    var10_8 = NativeRegExp.flatNMatcher(var0, var29_32, var31_34, var1_1, var5_5);
                    break block53;
                }
                case 15: {
                    var20_35 = var4_4 + 1;
                    var28_36 = (char)(255 & var3_3[var4_4]);
                    if (var0.cp == var5_5 || var1_1.charAt(var0.cp) != var28_36) break;
                    var10_8 = true;
                    var0.cp = 1 + var0.cp;
                    var4_4 = var20_35;
                    break block53;
                }
                case 16: {
                    var25_37 = NativeRegExp.getIndex(var3_3, var4_4);
                    var26_38 = var4_4 + 2;
                    var27_39 = NativeRegExp.getIndex(var3_3, var26_38);
                    var4_4 = var26_38 + 2;
                    var10_8 = NativeRegExp.flatNIMatcher(var0, var25_37, var27_39, var1_1, var5_5);
                    break block53;
                }
                case 17: {
                    var20_35 = var4_4 + 1;
                    var21_40 = (char)(255 & var3_3[var4_4]);
                    if (var0.cp == var5_5) break;
                    var22_41 = var1_1.charAt(var0.cp);
                    if (var21_40 == var22_41) ** GOTO lbl147
                    var23_42 = NativeRegExp.upcase(var21_40);
                    var24_43 = NativeRegExp.upcase(var22_41);
                    var10_8 = false;
                    if (var23_42 != var24_43) ** GOTO lbl149
lbl147: // 2 sources:
                    var10_8 = true;
                    var0.cp = 1 + var0.cp;
lbl149: // 2 sources:
                    var4_4 = var20_35;
                    break block53;
                }
                case 18: {
                    var17_44 = (char)NativeRegExp.getIndex(var3_3, var4_4);
                    var4_4 += 2;
                    var18_45 = var0.cp;
                    var10_8 = false;
                    if (var18_45 != var5_5) {
                        var19_46 = var1_1.charAt(var0.cp);
                        var10_8 = false;
                        if (var19_46 == var17_44) {
                            var10_8 = true;
                            var0.cp = 1 + var0.cp;
                        }
                    }
                    break block53;
                }
                case 19: {
                    var12_47 = (char)NativeRegExp.getIndex(var3_3, var4_4);
                    var4_4 += 2;
                    var13_48 = var0.cp;
                    var10_8 = false;
                    if (var13_48 == var5_5) break block53;
                    var14_49 = var1_1.charAt(var0.cp);
                    if (var12_47 == var14_49) ** GOTO lbl175
                    var15_50 = NativeRegExp.upcase(var12_47);
                    var16_51 = NativeRegExp.upcase(var14_49);
                    var10_8 = false;
                    if (var15_50 != var16_51) break block53;
lbl175: // 2 sources:
                    var10_8 = true;
                    var0.cp = 1 + var0.cp;
                    break block53;
                }
                case 22: 
                case 23: {
                    var8_52 = NativeRegExp.getIndex(var3_3, var4_4);
                    var4_4 += 2;
                    var9_53 = var0.cp;
                    var10_8 = false;
                    if (var9_53 != var5_5) {
                        var11_54 = NativeRegExp.classMatcher(var0, var0.regexp.classList[var8_52], var1_1.charAt(var0.cp));
                        var10_8 = false;
                        if (var11_54) {
                            var0.cp = 1 + var0.cp;
                            var10_8 = true;
                        }
                    }
                    break block53;
                }
            }
            var4_4 = var20_35;
            var10_8 = false;
        }
        if (var10_8) {
            if (var6_6 != false) return var4_4;
            var0.cp = var7_7;
            return var4_4;
        }
        var0.cp = var7_7;
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int toASCIIHexDigit(int n) {
        int n2;
        block5 : {
            block4 : {
                if (n < 48) break block4;
                if (n <= 57) {
                    return n - 48;
                }
                n2 = n | 32;
                if (97 <= n2 && n2 <= 102) break block5;
            }
            return -1;
        }
        return 10 + (n2 - 97);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static char upcase(char c) {
        if (c < '') {
            if ('a' > c) return c;
            if (c > 'z') return c;
            return (char)(c - 32);
        }
        char c2 = Character.toUpperCase((char)c);
        if (c2 < '') return c;
        return c2;
    }

    @Override
    public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        return this.execSub(context, scriptable, arrobject, 1);
    }

    /*
     * Enabled aggressive block sorting
     */
    Scriptable compile(Context context, Scriptable scriptable, Object[] arrobject) {
        if (arrobject.length > 0 && arrobject[0] instanceof NativeRegExp) {
            if (arrobject.length > 1 && arrobject[1] != Undefined.instance) {
                throw ScriptRuntime.typeError0("msg.bad.regexp.compile");
            }
            NativeRegExp nativeRegExp = (NativeRegExp)arrobject[0];
            this.re = nativeRegExp.re;
            this.lastIndex = nativeRegExp.lastIndex;
            return this;
        }
        String string2 = arrobject.length == 0 || arrobject[0] instanceof Undefined ? "" : NativeRegExp.escapeRegExp(arrobject[0]);
        String string3 = arrobject.length > 1 && arrobject[1] != Undefined.instance ? ScriptRuntime.toString(arrobject[1]) : null;
        this.re = NativeRegExp.compileRE(context, string2, string3, false);
        this.lastIndex = 0.0;
        return this;
    }

    @Override
    public Scriptable construct(Context context, Scriptable scriptable, Object[] arrobject) {
        return (Scriptable)this.execSub(context, scriptable, arrobject, 1);
    }

    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(REGEXP_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                return NativeRegExp.realThis(scriptable2, idFunctionObject).compile(context, scriptable, arrobject);
            }
            case 2: 
            case 3: {
                return NativeRegExp.realThis(scriptable2, idFunctionObject).toString();
            }
            case 4: {
                return NativeRegExp.realThis(scriptable2, idFunctionObject).execSub(context, scriptable, arrobject, 1);
            }
            case 5: {
                Object object = NativeRegExp.realThis(scriptable2, idFunctionObject).execSub(context, scriptable, arrobject, 0);
                if (Boolean.TRUE.equals(object)) {
                    return Boolean.TRUE;
                }
                return Boolean.FALSE;
            }
            case 6: 
        }
        return NativeRegExp.realThis(scriptable2, idFunctionObject).execSub(context, scriptable, arrobject, 2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    Object executeRegExp(Context var1_1, Scriptable var2_2, RegExpImpl var3_3, String var4_4, int[] var5_5, int var6_6) {
        var7_7 = new REGlobalData();
        var8_8 = var5_5[0];
        var9_9 = var4_4.length();
        if (var8_8 > var9_9) {
            var8_8 = var9_9;
        }
        if (!NativeRegExp.matchRegExp(var7_7, this.re, var4_4, var8_8, var9_9, var3_3.multiline)) {
            if (var6_6 == 2) return Undefined.instance;
            return null;
        }
        var5_5[0] = var10_10 = var7_7.cp;
        var11_11 = var10_10 - (var8_8 + var7_7.skipped);
        var12_12 = var10_10 - var11_11;
        if (var6_6 == 0) {
            var13_13 = Boolean.TRUE;
            var14_16 = null;
        } else {
            var14_16 = var13_15 = var1_1.newArray(var2_2, 0);
            var15_17 = var4_4.substring(var12_12, var12_12 + var11_11);
            var14_16.put(0, var14_16, (Object)var15_17);
        }
        if (this.re.parenCount != 0) {
            var16_19 = null;
            var3_3.parens = new SubString[this.re.parenCount];
        } else {
            var3_3.parens = null;
            var3_3.lastParen = SubString.emptySubString;
lbl25: // 2 sources:
            do {
                if (var6_6 != 0) {
                    var19_18 = var8_8 + var7_7.skipped;
                    var14_16.put("index", var14_16, (Object)var19_18);
                    var14_16.put("input", var14_16, (Object)var4_4);
                }
                if (var3_3.lastMatch == null) {
                    var3_3.lastMatch = new SubString();
                    var3_3.leftContext = new SubString();
                    var3_3.rightContext = new SubString();
                }
                var3_3.lastMatch.str = var4_4;
                var3_3.lastMatch.index = var12_12;
                var3_3.lastMatch.length = var11_11;
                var3_3.leftContext.str = var4_4;
                if (var1_1.getLanguageVersion() == 120) {
                    var3_3.leftContext.index = var8_8;
                    var3_3.leftContext.length = var7_7.skipped;
                } else {
                    var3_3.leftContext.index = 0;
                    var3_3.leftContext.length = var8_8 + var7_7.skipped;
                }
                var3_3.rightContext.str = var4_4;
                var3_3.rightContext.index = var10_10;
                var3_3.rightContext.length = var9_9 - var10_10;
                return var13_14;
                break;
            } while (true);
        }
        for (var17_20 = 0; var17_20 < (var18_21 = this.re.parenCount); ++var17_20) {
            var20_22 = var7_7.parensIndex(var17_20);
            if (var20_22 != -1) {
                var23_25 = var7_7.parensLength(var17_20);
                var3_3.parens[var17_20] = var16_19 = new SubString(var4_4, var20_22, var23_25);
                if (var6_6 == 0) continue;
                var24_26 = var17_20 + 1;
                var25_27 = var16_19.toString();
                var14_16.put(var24_26, var14_16, (Object)var25_27);
                continue;
            }
            if (var6_6 == 0) continue;
            var21_23 = var17_20 + 1;
            var22_24 = Undefined.instance;
            var14_16.put(var21_23, var14_16, var22_24);
        }
        var3_3.lastParen = var16_19;
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findInstanceIdInfo(String string2) {
        String string3;
        int n;
        int n2;
        int n3 = string2.length();
        if (n3 == 6) {
            char c = string2.charAt(0);
            if (c == 'g') {
                string3 = "global";
                n = 3;
            } else {
                string3 = null;
                n = 0;
                if (c == 's') {
                    string3 = "source";
                    n = 2;
                }
            }
        } else if (n3 == 9) {
            char c = string2.charAt(0);
            if (c == 'l') {
                string3 = "lastIndex";
                n = 1;
            } else {
                string3 = null;
                n = 0;
                if (c == 'm') {
                    string3 = "multiline";
                    n = 5;
                }
            }
        } else {
            string3 = null;
            n = 0;
            if (n3 == 10) {
                string3 = "ignoreCase";
                n = 4;
            }
        }
        if (string3 != null && string3 != string2 && !string3.equals((Object)string2)) {
            n = 0;
        }
        if (n == 0) {
            return super.findInstanceIdInfo(string2);
        }
        switch (n) {
            default: {
                throw new IllegalStateException();
            }
            case 1: {
                n2 = this.lastIndexAttr;
                return NativeRegExp.instanceIdInfo(n2, n);
            }
            case 2: 
            case 3: 
            case 4: 
            case 5: 
        }
        n2 = 7;
        return NativeRegExp.instanceIdInfo(n2, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        switch (n) {
            case 4: {
                char c = string2.charAt(0);
                if (c == 'e') {
                    string3 = "exec";
                    n2 = 4;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "test";
                n2 = 5;
                break;
            }
            case 6: {
                string3 = "prefix";
                n2 = 6;
                break;
            }
            case 7: {
                string3 = "compile";
                n2 = 1;
                break;
            }
            case 8: {
                char c = string2.charAt(3);
                if (c == 'o') {
                    string3 = "toSource";
                    n2 = 3;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "toString";
                n2 = 2;
                break;
            }
        }
        if (string3 == null) return n2;
        if (string3 == string2) return n2;
        if (string3.equals((Object)string2)) return n2;
        return 0;
    }

    @Override
    public String getClassName() {
        return "RegExp";
    }

    int getFlags() {
        return this.re.flags;
    }

    @Override
    protected String getInstanceIdName(int n) {
        switch (n) {
            default: {
                return super.getInstanceIdName(n);
            }
            case 1: {
                return "lastIndex";
            }
            case 2: {
                return "source";
            }
            case 3: {
                return "global";
            }
            case 4: {
                return "ignoreCase";
            }
            case 5: 
        }
        return "multiline";
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected Object getInstanceIdValue(int n) {
        boolean bl = true;
        switch (n) {
            default: {
                return super.getInstanceIdValue(n);
            }
            case 1: {
                return this.lastIndex;
            }
            case 2: {
                return new String(this.re.source);
            }
            case 3: {
                if ((1 & this.re.flags) != 0) {
                    do {
                        return ScriptRuntime.wrapBoolean(bl);
                        break;
                    } while (true);
                }
                bl = false;
                return ScriptRuntime.wrapBoolean(bl);
            }
            case 4: {
                if ((2 & this.re.flags) != 0) {
                    do {
                        return ScriptRuntime.wrapBoolean(bl);
                        break;
                    } while (true);
                }
                bl = false;
                return ScriptRuntime.wrapBoolean(bl);
            }
            case 5: 
        }
        if ((4 & this.re.flags) != 0) {
            do {
                return ScriptRuntime.wrapBoolean(bl);
                break;
            } while (true);
        }
        bl = false;
        return ScriptRuntime.wrapBoolean(bl);
    }

    @Override
    protected int getMaxInstanceId() {
        return 5;
    }

    @Override
    public String getTypeOf() {
        return "object";
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 2;
                string2 = "compile";
                break;
            }
            case 2: {
                string2 = "toString";
                n2 = 0;
                break;
            }
            case 3: {
                string2 = "toSource";
                n2 = 0;
                break;
            }
            case 4: {
                n2 = 1;
                string2 = "exec";
                break;
            }
            case 5: {
                n2 = 1;
                string2 = "test";
                break;
            }
            case 6: {
                n2 = 1;
                string2 = "prefix";
            }
        }
        this.initPrototypeMethod(REGEXP_TAG, n, string2, n2);
    }

    @Override
    protected void setInstanceIdAttributes(int n, int n2) {
        switch (n) {
            default: {
                super.setInstanceIdAttributes(n, n2);
                return;
            }
            case 1: 
        }
        this.lastIndexAttr = n2;
    }

    @Override
    protected void setInstanceIdValue(int n, Object object) {
        switch (n) {
            default: {
                super.setInstanceIdValue(n, object);
            }
            case 2: 
            case 3: 
            case 4: 
            case 5: {
                return;
            }
            case 1: 
        }
        this.lastIndex = object;
    }

    /*
     * Enabled aggressive block sorting
     */
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('/');
        if (this.re.source.length != 0) {
            stringBuilder.append(this.re.source);
        } else {
            stringBuilder.append("(?:)");
        }
        stringBuilder.append('/');
        if ((1 & this.re.flags) != 0) {
            stringBuilder.append('g');
        }
        if ((2 & this.re.flags) != 0) {
            stringBuilder.append('i');
        }
        if ((4 & this.re.flags) != 0) {
            stringBuilder.append('m');
        }
        return stringBuilder.toString();
    }
}

