/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.regexp;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.RegExpProxy;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.regexp.GlobData;
import org.mozilla.javascript.regexp.NativeRegExp;
import org.mozilla.javascript.regexp.RECompiled;
import org.mozilla.javascript.regexp.SubString;

public class RegExpImpl
implements RegExpProxy {
    protected String input;
    protected SubString lastMatch;
    protected SubString lastParen;
    protected SubString leftContext;
    protected boolean multiline;
    protected SubString[] parens;
    protected SubString rightContext;

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static NativeRegExp createRegExp(Context context, Scriptable scriptable, Object[] arrobject, int n, boolean bl) {
        String string2;
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        if (arrobject.length == 0 || arrobject[0] == Undefined.instance) {
            return new NativeRegExp(scriptable2, NativeRegExp.compileRE(context, "", "", false));
        }
        if (arrobject[0] instanceof NativeRegExp) {
            return (NativeRegExp)arrobject[0];
        }
        String string3 = ScriptRuntime.toString(arrobject[0]);
        if (n < arrobject.length) {
            arrobject[0] = string3;
            string2 = ScriptRuntime.toString(arrobject[n]);
            do {
                return new NativeRegExp(scriptable2, NativeRegExp.compileRE(context, string3, string2, bl));
                break;
            } while (true);
        }
        string2 = null;
        return new NativeRegExp(scriptable2, NativeRegExp.compileRE(context, string3, string2, bl));
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void do_replace(GlobData globData, Context context, RegExpImpl regExpImpl) {
        int n;
        StringBuilder stringBuilder = globData.charBuf;
        String string2 = globData.repstr;
        int n2 = globData.dollar;
        int n3 = 0;
        if (n2 != -1) {
            int n4;
            int[] arrn = new int[1];
            do {
                n2 - n3;
                stringBuilder.append(string2.substring(n3, n2));
                n3 = n2;
                SubString subString = RegExpImpl.interpretDollar(context, regExpImpl, string2, n2, arrn);
                if (subString != null) {
                    int n5 = subString.length;
                    if (n5 > 0) {
                        stringBuilder.append((CharSequence)subString.str, subString.index, n5 + subString.index);
                    }
                    n3 += arrn[0];
                    n4 = n2 + arrn[0];
                    continue;
                }
                n4 = n2 + 1;
            } while ((n2 = string2.indexOf(36, n4)) >= 0);
        }
        if ((n = string2.length()) > n3) {
            stringBuilder.append(string2.substring(n3, n));
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static int find_split(Context context, Scriptable scriptable, String string2, String string3, int n, RegExpProxy regExpProxy, Scriptable scriptable2, int[] arrn, int[] arrn2, boolean[] arrbl, String[][] arrstring) {
        int n2;
        int n3 = string2.length();
        if (n == 120 && scriptable2 == null && string3.length() == 1 && string3.charAt(0) == ' ') {
            int n4;
            if (n2 == 0) {
                for (n2 = arrn[0]; n2 < n3 && Character.isWhitespace((char)string2.charAt(n2)); ++n2) {
                }
                arrn[0] = n2;
            }
            if (n2 == n3) {
                return -1;
            }
            while (n2 < n3 && !Character.isWhitespace((char)string2.charAt(n2))) {
                ++n2;
            }
            for (n4 = n2; n4 < n3 && Character.isWhitespace((char)string2.charAt(n4)); ++n4) {
            }
            arrn2[0] = n4 - n2;
            return n2;
        }
        if (n2 > n3) {
            return -1;
        }
        if (scriptable2 != null) {
            return regExpProxy.find_split(context, scriptable, string2, string3, scriptable2, arrn, arrn2, arrbl, arrstring);
        }
        if (n != 0 && n < 130 && n3 == 0) {
            return -1;
        }
        if (string3.length() == 0) {
            if (n == 120) {
                if (n2 != n3) return n2 + 1;
                arrn2[0] = 1;
                return n2;
            }
            if (n2 != n3) return n2 + 1;
            return -1;
        }
        if (arrn[0] >= n3) return n3;
        int n5 = string2.indexOf(string3, arrn[0]);
        if (n5 == -1) return n3;
        return n5;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static SubString interpretDollar(Context context, RegExpImpl regExpImpl, String string2, int n, int[] arrn) {
        int n2;
        char c;
        block18 : {
            block21 : {
                int n3;
                int n4;
                block20 : {
                    int n5;
                    char c2;
                    int n6;
                    block19 : {
                        int n7;
                        char c3;
                        if (string2.charAt(n) != '$') {
                            Kit.codeBug();
                        }
                        if ((n2 = context.getLanguageVersion()) != 0 && n2 <= 140 && n > 0 && string2.charAt(n - 1) == '\\') {
                            return null;
                        }
                        n5 = string2.length();
                        if (n + 1 >= n5) {
                            return null;
                        }
                        c = string2.charAt(n + 1);
                        if (!NativeRegExp.isDigit(c)) break block18;
                        if (n2 == 0 || n2 > 140) break block19;
                        if (c == '0') {
                            return null;
                        }
                        n3 = 0;
                        n4 = n;
                        while (++n4 < n5 && NativeRegExp.isDigit(c3 = string2.charAt(n4)) && (n7 = n3 * 10 + (c3 - 48)) >= n3) {
                            n3 = n7;
                        }
                        break block20;
                    }
                    n3 = c - 48;
                    int n8 = regExpImpl.parens == null ? 0 : regExpImpl.parens.length;
                    if (n3 > n8) {
                        return null;
                    }
                    n4 = n + 2;
                    if (n + 2 < n5 && NativeRegExp.isDigit(c2 = string2.charAt(n + 2)) && (n6 = n3 * 10 + (c2 - 48)) <= n8) {
                        ++n4;
                        n3 = n6;
                    }
                    if (n3 == 0) break block21;
                }
                int n9 = n3 - 1;
                arrn[0] = n4 - n;
                return regExpImpl.getParenSubString(n9);
            }
            return null;
        }
        arrn[0] = 2;
        switch (c) {
            default: {
                return null;
            }
            case '$': {
                return new SubString("$");
            }
            case '&': {
                return regExpImpl.lastMatch;
            }
            case '+': {
                return regExpImpl.lastParen;
            }
            case '`': {
                if (n2 == 120) {
                    regExpImpl.leftContext.index = 0;
                    regExpImpl.leftContext.length = regExpImpl.lastMatch.index;
                }
                return regExpImpl.leftContext;
            }
            case '\'': 
        }
        return regExpImpl.rightContext;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object matchOrReplace(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject, RegExpImpl regExpImpl, GlobData globData, NativeRegExp nativeRegExp) {
        void var10_12;
        String string2 = globData.str;
        boolean bl = (1 & nativeRegExp.getFlags()) != 0;
        globData.global = bl;
        int[] arrn = new int[]{0};
        Object var10_10 = null;
        if (globData.mode == 3) {
            Object object = nativeRegExp.executeRegExp(context, scriptable, regExpImpl, string2, arrn, 0);
            if (object == null) return -1;
            if (!object.equals((Object)Boolean.TRUE)) return -1;
            Integer n = regExpImpl.leftContext.length;
            return var10_12;
        }
        if (!globData.global) {
            int n;
            if (globData.mode == 2) {
                n = 0;
                return nativeRegExp.executeRegExp(context, scriptable, regExpImpl, string2, arrn, n);
            }
            n = 1;
            return nativeRegExp.executeRegExp(context, scriptable, regExpImpl, string2, arrn, n);
        }
        nativeRegExp.lastIndex = 0.0;
        int n = 0;
        while (arrn[0] <= string2.length()) {
            Object object = nativeRegExp.executeRegExp(context, scriptable, regExpImpl, string2, arrn, 0);
            if (object == null) return var10_12;
            Boolean bl2 = Boolean.TRUE;
            if (!object.equals((Object)bl2)) return var10_12;
            if (globData.mode == 1) {
                RegExpImpl.match_glob(globData, context, scriptable, n, regExpImpl);
            } else {
                if (globData.mode != 2) {
                    Kit.codeBug();
                }
                SubString subString = regExpImpl.lastMatch;
                int n2 = globData.leftIndex;
                int n3 = subString.index - n2;
                globData.leftIndex = subString.index + subString.length;
                RegExpImpl.replace_glob(globData, context, scriptable, regExpImpl, n2, n3);
            }
            if (regExpImpl.lastMatch.length == 0) {
                if (arrn[0] == string2.length()) return var10_12;
                arrn[0] = 1 + arrn[0];
            }
            ++n;
        }
        return var10_12;
    }

    private static void match_glob(GlobData globData, Context context, Scriptable scriptable, int n, RegExpImpl regExpImpl) {
        if (globData.arrayobj == null) {
            globData.arrayobj = context.newArray(scriptable, 0);
        }
        String string2 = regExpImpl.lastMatch.toString();
        globData.arrayobj.put(n, globData.arrayobj, (Object)string2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static void replace_glob(GlobData var0, Context var1_1, Scriptable var2_2, RegExpImpl var3_3, int var4_4, int var5_5) {
        block14 : {
            block13 : {
                block12 : {
                    block11 : {
                        if (var0.lambda == null) break block11;
                        var17_6 = var3_3.parens;
                        var18_7 = var17_6 == null ? 0 : var17_6.length;
                        var19_8 = new Object[var18_7 + 3];
                        var19_8[0] = var3_3.lastMatch.toString();
                        break block12;
                    }
                    var6_15 = var0.repstr.length();
                    var7_19 = var0.dollar;
                    var8_14 = null;
                    if (var7_19 < 0) break block13;
                    break block14;
                }
                for (var20_9 = 0; var20_9 < var18_7; ++var20_9) {
                    var26_10 = var17_6[var20_9];
                    var19_8[var20_9 + 1] = var26_10 != null ? var26_10.toString() : Undefined.instance;
                }
                var19_8[var18_7 + 1] = var3_3.leftContext.length;
                var19_8[var18_7 + 2] = var0.str;
                if (var3_3 != ScriptRuntime.getRegExpProxy(var1_1)) {
                    Kit.codeBug();
                }
                var21_11 = new RegExpImpl();
                var21_11.multiline = var3_3.multiline;
                var21_11.input = var3_3.input;
                ScriptRuntime.setRegExpProxy(var1_1, var21_11);
                var23_12 = ScriptableObject.getTopLevelScope(var2_2);
                var8_14 = var24_13 = ScriptRuntime.toString(var0.lambda.call(var1_1, var23_12, var23_12, var19_8));
                var6_15 = var8_14.length();
                break block13;
                finally {
                    ScriptRuntime.setRegExpProxy(var1_1, var3_3);
                }
            }
lbl35: // 2 sources:
            do {
                var13_16 = var5_5 + var6_15 + var3_3.rightContext.length;
                var14_17 = var0.charBuf;
                if (var14_17 == null) {
                    var0.charBuf = var14_17 = new StringBuilder(var13_16);
                } else {
                    var14_17.ensureCapacity(var13_16 + var0.charBuf.length());
                }
                var14_17.append((CharSequence)var3_3.leftContext.str, var4_4, var4_4 + var5_5);
                if (var0.lambda != null) {
                    var14_17.append(var8_14);
                    return;
                }
                RegExpImpl.do_replace(var0, var1_1, var3_3);
                return;
                break;
            } while (true);
        }
        var9_20 = new int[1];
        var10_21 = var0.dollar;
        do {
            if ((var11_22 = RegExpImpl.interpretDollar(var1_1, var3_3, var0.repstr, var10_21, var9_20)) != null) {
                var6_15 += var11_22.length - var9_20[0];
                var12_23 = var10_21 + var9_20[0];
                continue;
            }
            var12_23 = var10_21 + 1;
        } while ((var10_21 = var0.repstr.indexOf(36, var12_23)) >= 0);
        var8_14 = null;
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object action(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject, int n) {
        Object object;
        NativeRegExp nativeRegExp;
        Function function;
        GlobData globData = new GlobData();
        globData.mode = n;
        globData.str = ScriptRuntime.toString(scriptable2);
        switch (n) {
            default: {
                throw Kit.codeBug();
            }
            case 1: {
                Object object2 = RegExpImpl.matchOrReplace(context, scriptable, scriptable2, arrobject, this, globData, RegExpImpl.createRegExp(context, scriptable, arrobject, 1, false));
                if (globData.arrayobj == null) {
                    return object2;
                }
                return globData.arrayobj;
            }
            case 3: {
                return RegExpImpl.matchOrReplace(context, scriptable, scriptable2, arrobject, this, globData, RegExpImpl.createRegExp(context, scriptable, arrobject, 1, false));
            }
            case 2: 
        }
        boolean bl = arrobject.length > 0 && arrobject[0] instanceof NativeRegExp || arrobject.length > 2;
        String string2 = null;
        if (bl) {
            nativeRegExp = RegExpImpl.createRegExp(context, scriptable, arrobject, 2, true);
        } else {
            Object object3 = arrobject.length < 1 ? Undefined.instance : arrobject[0];
            string2 = ScriptRuntime.toString(object3);
            nativeRegExp = null;
        }
        Object object4 = arrobject.length < 2 ? Undefined.instance : arrobject[1];
        String string3 = null;
        if (object4 instanceof Function) {
            function = (Function)object4;
        } else {
            string3 = ScriptRuntime.toString(object4);
            function = null;
        }
        globData.lambda = function;
        globData.repstr = string3;
        int n2 = string3 == null ? -1 : string3.indexOf(36);
        globData.dollar = n2;
        globData.charBuf = null;
        globData.leftIndex = 0;
        if (bl) {
            object = RegExpImpl.matchOrReplace(context, scriptable, scriptable2, arrobject, this, globData, nativeRegExp);
        } else {
            String string4 = globData.str;
            int n3 = string4.indexOf(string2);
            if (n3 >= 0) {
                int n4 = string2.length();
                this.lastParen = null;
                this.leftContext = new SubString(string4, 0, n3);
                this.lastMatch = new SubString(string4, n3, n4);
                this.rightContext = new SubString(string4, n3 + n4, string4.length() - n3 - n4);
                object = Boolean.TRUE;
            } else {
                object = Boolean.FALSE;
            }
        }
        if (globData.charBuf == null) {
            Boolean bl2;
            if (globData.global || object == null || !object.equals((Object)(bl2 = Boolean.TRUE))) {
                return globData.str;
            }
            SubString subString = this.leftContext;
            RegExpImpl.replace_glob(globData, context, scriptable, this, subString.index, subString.length);
        }
        SubString subString = this.rightContext;
        globData.charBuf.append((CharSequence)subString.str, subString.index, subString.index + subString.length);
        return globData.charBuf.toString();
    }

    @Override
    public Object compileRegExp(Context context, String string2, String string3) {
        return NativeRegExp.compileRE(context, string2, string3, false);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public int find_split(Context context, Scriptable scriptable, String string2, String string3, Scriptable scriptable2, int[] arrn, int[] arrn2, boolean[] arrbl, String[][] arrstring) {
        int n;
        block7 : {
            int n2;
            int n3 = arrn[0];
            int n4 = string2.length();
            int n5 = context.getLanguageVersion();
            NativeRegExp nativeRegExp = (NativeRegExp)scriptable2;
            do {
                int n6 = arrn[0];
                arrn[0] = n3;
                if (nativeRegExp.executeRegExp(context, scriptable, this, string2, arrn, 0) != Boolean.TRUE) {
                    arrn[0] = n6;
                    arrn2[0] = 1;
                    arrbl[0] = false;
                    return n4;
                }
                n2 = arrn[0];
                arrn[0] = n6;
                arrbl[0] = true;
                arrn2[0] = this.lastMatch.length;
                if (arrn2[0] != 0 || n2 != arrn[0]) break;
                if (n2 == n4) {
                    if (n5 == 120) {
                        arrn2[0] = 1;
                        n = n2;
                    } else {
                        n = -1;
                    }
                    break block7;
                }
                n3 = n2 + 1;
            } while (true);
            n = n2 - arrn2[0];
        }
        int n7 = this.parens == null ? 0 : this.parens.length;
        arrstring[0] = new String[n7];
        int n8 = 0;
        while (n8 < n7) {
            SubString subString = this.getParenSubString(n8);
            arrstring[0][n8] = subString.toString();
            ++n8;
        }
        return n;
    }

    SubString getParenSubString(int n) {
        SubString subString;
        if (this.parens != null && n < this.parens.length && (subString = this.parens[n]) != null) {
            return subString;
        }
        return SubString.emptySubString;
    }

    @Override
    public boolean isRegExp(Scriptable scriptable) {
        return scriptable instanceof NativeRegExp;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public Object js_split(Context var1_1, Scriptable var2_2, String var3_3, Object[] var4_4) {
        var5_5 = var1_1.newArray(var2_2, 0);
        var6_6 = var4_4.length > 1 && var4_4[1] != Undefined.instance;
        var7_7 = 0L;
        if (var6_6 && (var7_7 = ScriptRuntime.toUint32(var4_4[1])) > (long)var3_3.length()) {
            var7_7 = 1 + var3_3.length();
        }
        if (var4_4.length < 1 || var4_4[0] == Undefined.instance) {
            var5_5.put(0, var5_5, (Object)var3_3);
            return var5_5;
        }
        var9_8 = new int[1];
        var10_9 = var4_4[0] instanceof Scriptable;
        var11_10 = null;
        var12_11 = null;
        if (var10_9) {
            var11_10 = ScriptRuntime.getRegExpProxy(var1_1);
            var12_11 = null;
            if (var11_10 != null) {
                var23_12 = (Scriptable)var4_4[0];
                var24_13 = var11_10.isRegExp(var23_12);
                var12_11 = null;
                if (var24_13) {
                    var12_11 = var23_12;
                }
            }
        }
        var13_14 = null;
        if (var12_11 == null) {
            var13_14 = ScriptRuntime.toString(var4_4[0]);
            var9_8[0] = var13_14.length();
        }
        var14_15 = new int[]{0};
        var15_16 = 0;
        var16_17 = new boolean[]{false};
        var17_18 = new String[][]{null};
        var18_19 = var1_1.getLanguageVersion();
        block0 : do {
            if ((var19_20 = RegExpImpl.find_split(var1_1, var2_2, var3_3, var13_14, var18_19, var11_10, var12_11, var14_15, var9_8, var16_17, var17_18)) < 0) return var5_5;
            if (var6_6) {
                if ((long)var15_16 >= var7_7) return var5_5;
            }
            if (var19_20 > var3_3.length()) return var5_5;
            var20_21 = var3_3.length() == 0 ? var3_3 : var3_3.substring(var14_15[0], var19_20);
            var5_5.put(var15_16, var5_5, (Object)var20_21);
            ++var15_16;
            if (var12_11 == null || !var16_17[0]) ** GOTO lbl45
            var21_22 = var17_18[0].length;
            var22_23 = 0;
            do {
                block12 : {
                    if (var22_23 < var21_22 && (!var6_6 || (long)var15_16 < var7_7)) break block12;
                    var16_17[0] = false;
lbl45: // 2 sources:
                    var14_15[0] = var19_20 + var9_8[0];
                    if (var18_19 >= 130 || var18_19 == 0 || var6_6 || var14_15[0] != var3_3.length()) continue block0;
                    return var5_5;
                }
                var5_5.put(var15_16, var5_5, (Object)var17_18[0][var22_23]);
                ++var15_16;
                ++var22_23;
            } while (true);
            break;
        } while (true);
    }

    @Override
    public Scriptable wrapRegExp(Context context, Scriptable scriptable, Object object) {
        return new NativeRegExp(scriptable, (RECompiled)object);
    }
}

