/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package org.mozilla.javascript;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.mozilla.javascript.CompilerEnvirons;
import org.mozilla.javascript.Decompiler;
import org.mozilla.javascript.ErrorReporter;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.Parser;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Token;
import org.mozilla.javascript.ast.ArrayComprehension;
import org.mozilla.javascript.ast.ArrayComprehensionLoop;
import org.mozilla.javascript.ast.ArrayLiteral;
import org.mozilla.javascript.ast.Assignment;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.AstRoot;
import org.mozilla.javascript.ast.Block;
import org.mozilla.javascript.ast.BreakStatement;
import org.mozilla.javascript.ast.CatchClause;
import org.mozilla.javascript.ast.ConditionalExpression;
import org.mozilla.javascript.ast.ContinueStatement;
import org.mozilla.javascript.ast.DestructuringForm;
import org.mozilla.javascript.ast.DoLoop;
import org.mozilla.javascript.ast.ElementGet;
import org.mozilla.javascript.ast.EmptyExpression;
import org.mozilla.javascript.ast.ExpressionStatement;
import org.mozilla.javascript.ast.ForInLoop;
import org.mozilla.javascript.ast.ForLoop;
import org.mozilla.javascript.ast.FunctionCall;
import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.ast.GeneratorExpression;
import org.mozilla.javascript.ast.GeneratorExpressionLoop;
import org.mozilla.javascript.ast.IfStatement;
import org.mozilla.javascript.ast.InfixExpression;
import org.mozilla.javascript.ast.Jump;
import org.mozilla.javascript.ast.Label;
import org.mozilla.javascript.ast.LabeledStatement;
import org.mozilla.javascript.ast.LetNode;
import org.mozilla.javascript.ast.Loop;
import org.mozilla.javascript.ast.Name;
import org.mozilla.javascript.ast.NewExpression;
import org.mozilla.javascript.ast.NumberLiteral;
import org.mozilla.javascript.ast.ObjectLiteral;
import org.mozilla.javascript.ast.ObjectProperty;
import org.mozilla.javascript.ast.ParenthesizedExpression;
import org.mozilla.javascript.ast.PropertyGet;
import org.mozilla.javascript.ast.RegExpLiteral;
import org.mozilla.javascript.ast.ReturnStatement;
import org.mozilla.javascript.ast.Scope;
import org.mozilla.javascript.ast.ScriptNode;
import org.mozilla.javascript.ast.StringLiteral;
import org.mozilla.javascript.ast.SwitchCase;
import org.mozilla.javascript.ast.SwitchStatement;
import org.mozilla.javascript.ast.Symbol;
import org.mozilla.javascript.ast.ThrowStatement;
import org.mozilla.javascript.ast.TryStatement;
import org.mozilla.javascript.ast.UnaryExpression;
import org.mozilla.javascript.ast.VariableDeclaration;
import org.mozilla.javascript.ast.VariableInitializer;
import org.mozilla.javascript.ast.WhileLoop;
import org.mozilla.javascript.ast.WithStatement;
import org.mozilla.javascript.ast.XmlDotQuery;
import org.mozilla.javascript.ast.XmlElemRef;
import org.mozilla.javascript.ast.XmlExpression;
import org.mozilla.javascript.ast.XmlFragment;
import org.mozilla.javascript.ast.XmlLiteral;
import org.mozilla.javascript.ast.XmlMemberGet;
import org.mozilla.javascript.ast.XmlPropRef;
import org.mozilla.javascript.ast.XmlRef;
import org.mozilla.javascript.ast.XmlString;
import org.mozilla.javascript.ast.Yield;

public final class IRFactory
extends Parser {
    private static final int ALWAYS_FALSE_BOOLEAN = -1;
    private static final int ALWAYS_TRUE_BOOLEAN = 1;
    private static final int LOOP_DO_WHILE = 0;
    private static final int LOOP_FOR = 2;
    private static final int LOOP_WHILE = 1;
    private Decompiler decompiler = new Decompiler();

    public IRFactory() {
    }

    public IRFactory(CompilerEnvirons compilerEnvirons) {
        this(compilerEnvirons, compilerEnvirons.getErrorReporter());
    }

    public IRFactory(CompilerEnvirons compilerEnvirons, ErrorReporter errorReporter) {
        super(compilerEnvirons, errorReporter);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void addSwitchCase(Node node, Node node2, Node node3) {
        if (node.getType() != 129) {
            throw Kit.codeBug();
        }
        Jump jump = (Jump)node.getFirstChild();
        if (jump.getType() != 114) {
            throw Kit.codeBug();
        }
        Node node4 = Node.newTarget();
        if (node2 != null) {
            Jump jump2 = new Jump(115, node2);
            jump2.target = node4;
            jump.addChildToBack(jump2);
        } else {
            jump.setDefault(node4);
        }
        node.addChildToBack(node4);
        node.addChildToBack(node3);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private Node arrayCompTransformHelper(ArrayComprehension arrayComprehension, String string2) {
        this.decompiler.addToken(83);
        int n = arrayComprehension.getLineno();
        Node node = this.transform(arrayComprehension.getResult());
        List<ArrayComprehensionLoop> list = arrayComprehension.getLoops();
        int n2 = list.size();
        Node[] arrnode = new Node[n2];
        Node[] arrnode2 = new Node[n2];
        for (int i = 0; i < n2; ++i) {
            String string3;
            ArrayComprehensionLoop arrayComprehensionLoop = (ArrayComprehensionLoop)list.get(i);
            this.decompiler.addName(" ");
            this.decompiler.addToken(119);
            if (arrayComprehensionLoop.isForEach()) {
                this.decompiler.addName("each ");
            }
            this.decompiler.addToken(87);
            AstNode astNode = arrayComprehensionLoop.getIterator();
            if (astNode.getType() == 39) {
                string3 = astNode.getString();
                this.decompiler.addName(string3);
            } else {
                this.decompile(astNode);
                string3 = this.currentScriptOrFn.getNextTempName();
                this.defineSymbol(87, string3, false);
                node = this.createBinary(89, this.createAssignment(90, astNode, this.createName(string3)), node);
            }
            Node node2 = this.createName(string3);
            this.defineSymbol(153, string3, false);
            arrnode[i] = node2;
            this.decompiler.addToken(52);
            arrnode2[i] = this.transform(arrayComprehensionLoop.getIteratedObject());
            this.decompiler.addToken(88);
        }
        Node node3 = this.createCallOrNew(38, this.createPropertyGet(this.createName(string2), null, "push", 0));
        Node node4 = new Node(133, node3, n);
        if (arrayComprehension.getFilter() != null) {
            this.decompiler.addName(" ");
            this.decompiler.addToken(112);
            this.decompiler.addToken(87);
            node4 = this.createIf(this.transform(arrayComprehension.getFilter()), node4, null, n);
            this.decompiler.addToken(88);
        }
        int n3 = 0;
        for (int i = n2 - 1; i >= 0; ++n3, --i) {
            Node node5;
            ArrayComprehensionLoop arrayComprehensionLoop = (ArrayComprehensionLoop)list.get(i);
            Scope scope = this.createLoopNode(null, arrayComprehensionLoop.getLineno());
            this.pushScope(scope);
            node4 = node5 = this.createForIn(153, scope, arrnode[i], arrnode2[i], node4, arrayComprehensionLoop.isForEach());
            continue;
        }
        int n4 = 0;
        do {
            if (n4 >= n3) {
                this.decompiler.addToken(84);
                node3.addChildToBack(node);
                return node4;
            }
            this.popScope();
            ++n4;
        } while (true);
        catch (Throwable throwable) {
            int n5 = 0;
            while (n5 < n3) {
                this.popScope();
                ++n5;
            }
            throw throwable;
        }
    }

    private void closeSwitch(Node node) {
        Node node2;
        if (node.getType() != 129) {
            throw Kit.codeBug();
        }
        Jump jump = (Jump)node.getFirstChild();
        if (jump.getType() != 114) {
            throw Kit.codeBug();
        }
        jump.target = node2 = Node.newTarget();
        Node node3 = jump.getDefault();
        if (node3 == null) {
            node3 = node2;
        }
        node.addChildAfter(this.makeJump(5, node3), jump);
        node.addChildToBack(node2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node createAssignment(int n, Node node, Node node2) {
        int n2;
        Node node3 = this.makeReference(node);
        if (node3 == null) {
            if (node.getType() != 65 && node.getType() != 66) {
                this.reportError("msg.bad.assign.left");
                return node2;
            }
            if (n == 90) return this.createDestructuringAssignment(-1, node, node2);
            this.reportError("msg.bad.destruct.op");
            return node2;
        }
        switch (n) {
            default: {
                throw Kit.codeBug();
            }
            case 90: {
                return this.simpleAssignment(node3, node2);
            }
            case 91: {
                n2 = 9;
                break;
            }
            case 92: {
                n2 = 10;
                break;
            }
            case 93: {
                n2 = 11;
                break;
            }
            case 94: {
                n2 = 18;
                break;
            }
            case 95: {
                n2 = 19;
                break;
            }
            case 96: {
                n2 = 20;
                break;
            }
            case 97: {
                n2 = 21;
                break;
            }
            case 98: {
                n2 = 22;
                break;
            }
            case 99: {
                n2 = 23;
                break;
            }
            case 100: {
                n2 = 24;
                break;
            }
            case 101: {
                n2 = 25;
            }
        }
        int n3 = node3.getType();
        switch (n3) {
            default: {
                throw Kit.codeBug();
            }
            case 39: {
                Node node4 = new Node(n2, node3, node2);
                return new Node(8, Node.newString(49, node3.getString()), node4);
            }
            case 33: 
            case 36: {
                int n4;
                Node node5 = node3.getFirstChild();
                Node node6 = node3.getLastChild();
                if (n3 == 33) {
                    n4 = 139;
                    return new Node(n4, node5, node6, new Node(n2, new Node(138), node2));
                }
                n4 = 140;
                return new Node(n4, node5, node6, new Node(n2, new Node(138), node2));
            }
            case 67: 
        }
        Node node7 = node3.getFirstChild();
        this.checkMutableReference(node7);
        return new Node(142, node7, new Node(n2, new Node(138), node2));
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node createBinary(int n, Node node, Node node2) {
        switch (n) {
            case 21: {
                if (node.type == 41) {
                    String string2;
                    if (node2.type == 41) {
                        string2 = node2.getString();
                    } else {
                        if (node2.type != 40) return new Node(n, node, node2);
                        string2 = ScriptRuntime.numberToString(node2.getDouble(), 10);
                    }
                    node.setString(node.getString().concat(string2));
                    return node;
                }
                if (node.type != 40) return new Node(n, node, node2);
                if (node2.type == 40) {
                    node.setDouble(node.getDouble() + node2.getDouble());
                    return node;
                }
                if (node2.type != 41) return new Node(n, node, node2);
                node2.setString(ScriptRuntime.numberToString(node.getDouble(), 10).concat(node2.getString()));
                return node2;
            }
            case 22: {
                if (node.type == 40) {
                    double d = node.getDouble();
                    if (node2.type == 40) {
                        node.setDouble(d - node2.getDouble());
                        return node;
                    }
                    if (d != 0.0) return new Node(n, node, node2);
                    return new Node(29, node2);
                }
                if (node2.type != 40) return new Node(n, node, node2);
                if (node2.getDouble() != 0.0) return new Node(n, node, node2);
                return new Node(28, node);
            }
            case 23: {
                if (node.type == 40) {
                    double d = node.getDouble();
                    if (node2.type == 40) {
                        node.setDouble(d * node2.getDouble());
                        return node;
                    }
                    if (d != 1.0) return new Node(n, node, node2);
                    return new Node(28, node2);
                }
                if (node2.type != 40) return new Node(n, node, node2);
                if (node2.getDouble() != 1.0) return new Node(n, node, node2);
                return new Node(28, node);
            }
            case 24: {
                if (node2.type != 40) return new Node(n, node, node2);
                double d = node2.getDouble();
                if (node.type == 40) {
                    node.setDouble(node.getDouble() / d);
                    return node;
                }
                if (d != 1.0) return new Node(n, node, node2);
                return new Node(28, node);
            }
            case 105: {
                int n2 = IRFactory.isAlwaysDefinedBoolean(node);
                if (n2 == -1) return node;
                if (n2 != 1) return new Node(n, node, node2);
                return node2;
            }
            default: {
                return new Node(n, node, node2);
            }
            case 104: 
        }
        int n3 = IRFactory.isAlwaysDefinedBoolean(node);
        if (n3 == 1) return node;
        if (n3 != -1) return new Node(n, node, node2);
        return node2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node createCallOrNew(int n, Node node) {
        int n2;
        if (node.getType() == 39) {
            String string2 = node.getString();
            if (string2.equals((Object)"eval")) {
                n2 = 1;
            } else {
                boolean bl = string2.equals((Object)"With");
                n2 = 0;
                if (bl) {
                    n2 = 2;
                }
            }
        } else {
            int n3 = node.getType();
            n2 = 0;
            if (n3 == 33) {
                boolean bl = node.getLastChild().getString().equals((Object)"eval");
                n2 = 0;
                if (bl) {
                    n2 = 1;
                }
            }
        }
        Node node2 = new Node(n, node);
        if (n2 != 0) {
            this.setRequiresActivation();
            node2.putIntProp(10, n2);
        }
        return node2;
    }

    private Node createCatch(String string2, Node node, Node node2, int n) {
        if (node == null) {
            node = new Node(128);
        }
        return new Node(124, this.createName(string2), node, node2, n);
    }

    private Node createCondExpr(Node node, Node node2, Node node3) {
        int n = IRFactory.isAlwaysDefinedBoolean(node);
        if (n == 1) {
            return node2;
        }
        if (n == -1) {
            return node3;
        }
        return new Node(102, node, node2, node3);
    }

    private Node createElementGet(Node node, String string2, Node node2, int n) {
        if (string2 == null && n == 0) {
            if (node == null) {
                throw Kit.codeBug();
            }
            return new Node(36, node, node2);
        }
        return this.createMemberRefGet(node, string2, node2, n);
    }

    private Node createExprStatementNoReturn(Node node, int n) {
        return new Node(133, node, n);
    }

    private Node createFor(Scope scope, Node node, Node node2, Node node3, Node node4) {
        if (node.getType() == 153) {
            Scope scope2 = Scope.splitScope(scope);
            scope2.setType(153);
            scope2.addChildrenToBack(node);
            scope2.addChildToBack(this.createLoop(scope, 2, node4, node2, new Node(128), node3));
            return scope2;
        }
        return this.createLoop(scope, 2, node4, node2, node, node3);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node createForIn(int n, Node node, Node node2, Node node3, Node node4, boolean bl) {
        int n2;
        Node node5;
        Node node6;
        int n3 = -1;
        int n4 = node2.getType();
        if (n4 == 122 || n4 == 153) {
            Node node7 = node2.getLastChild();
            int n5 = node7.getType();
            if (n5 == 65 || n5 == 66) {
                n3 = n5;
                n4 = n5;
                node5 = node7;
                boolean bl2 = node7 instanceof ArrayLiteral;
                n2 = 0;
                if (bl2) {
                    n2 = ((ArrayLiteral)node7).getDestructuringLength();
                }
            } else {
                if (n5 != 39) {
                    this.reportError("msg.bad.for.in.lhs");
                    return null;
                }
                node5 = Node.newString(39, node7.getString());
                n2 = 0;
            }
        } else if (n4 == 65 || n4 == 66) {
            n3 = n4;
            node5 = node2;
            boolean bl3 = node2 instanceof ArrayLiteral;
            n2 = 0;
            if (bl3) {
                n2 = ((ArrayLiteral)node2).getDestructuringLength();
            }
        } else {
            node5 = this.makeReference(node2);
            n2 = 0;
            if (node5 == null) {
                this.reportError("msg.bad.for.in.lhs");
                return null;
            }
        }
        Node node8 = new Node(141);
        int n6 = bl ? 59 : (n3 != -1 ? 60 : 58);
        Node node9 = new Node(n6, node3);
        node9.putProp(3, node8);
        Node node10 = new Node(61);
        node10.putProp(3, node8);
        Node node11 = new Node(62);
        node11.putProp(3, node8);
        Node node12 = new Node(129);
        if (n3 != -1) {
            node6 = this.createDestructuringAssignment(n, node5, node11);
            if (!(bl || n3 != 66 && n2 == 2)) {
                this.reportError("msg.bad.for.in.destruct");
            }
        } else {
            node6 = this.simpleAssignment(node5, node11);
        }
        node12.addChildToBack(new Node(133, node6));
        node12.addChildToBack(node4);
        Node node13 = this.createLoop((Jump)node, 1, node12, node10, null, null);
        node13.addChildToFront(node9);
        if (n4 == 122 || n4 == 153) {
            node13.addChildToFront(node2);
        }
        node8.addChildToBack(node13);
        return node8;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Node createIf(Node node, Node node2, Node node3, int n) {
        int n2 = IRFactory.isAlwaysDefinedBoolean(node);
        if (n2 == 1) {
            return node2;
        }
        if (n2 == -1) {
            if (node3 == null) return new Node(129, n);
            return node3;
        }
        Node node4 = new Node(129, n);
        Node node5 = Node.newTarget();
        Jump jump = new Jump(7, node);
        jump.target = node5;
        node4.addChildToBack(jump);
        node4.addChildrenToBack(node2);
        if (node3 != null) {
            Node node6 = Node.newTarget();
            node4.addChildToBack(this.makeJump(5, node6));
            node4.addChildToBack(node5);
            node4.addChildrenToBack(node3);
            node4.addChildToBack(node6);
            do {
                return node4;
                break;
            } while (true);
        }
        node4.addChildToBack(node5);
        return node4;
    }

    private Node createIncDec(int n, boolean bl, Node node) {
        Node node2 = this.makeReference(node);
        switch (node2.getType()) {
            default: {
                throw Kit.codeBug();
            }
            case 33: 
            case 36: 
            case 39: 
            case 67: 
        }
        Node node3 = new Node(n, node2);
        int n2 = 0;
        if (n == 107) {
            n2 = false | true;
        }
        if (bl) {
            n2 |= 2;
        }
        node3.putIntProp(13, n2);
        return node3;
    }

    private Node createLoop(Jump jump, int n, Node node, Node node2, Node node3, Node node4) {
        Node node5 = Node.newTarget();
        Node node6 = Node.newTarget();
        if (n == 2 && node2.getType() == 128) {
            node2 = new Node(45);
        }
        Jump jump2 = new Jump(6, node2);
        jump2.target = node5;
        Node node7 = Node.newTarget();
        jump.addChildToBack(node5);
        jump.addChildrenToBack(node);
        if (n == 1 || n == 2) {
            jump.addChildrenToBack(new Node(128, jump.getLineno()));
        }
        jump.addChildToBack(node6);
        jump.addChildToBack(jump2);
        jump.addChildToBack(node7);
        jump.target = node7;
        Node node8 = node6;
        if (n == 1 || n == 2) {
            jump.addChildToFront(this.makeJump(5, node6));
            if (n == 2) {
                int n2 = node3.getType();
                if (n2 != 128) {
                    if (n2 != 122 && n2 != 153) {
                        node3 = new Node(133, node3);
                    }
                    jump.addChildToFront(node3);
                }
                Node node9 = Node.newTarget();
                jump.addChildAfter(node9, node);
                if (node4.getType() != 128) {
                    jump.addChildAfter(new Node(133, node4), node9);
                }
                node8 = node9;
            }
        }
        jump.setContinue(node8);
        return jump;
    }

    private Scope createLoopNode(Node node, int n) {
        Scope scope = this.createScopeNode(132, n);
        if (node != null) {
            ((Jump)node).setLoop(scope);
        }
        return scope;
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node createMemberRefGet(Node node, String string2, Node node2, int n) {
        Node node3 = null;
        if (string2 != null) {
            node3 = string2.equals((Object)"*") ? new Node(42) : this.createName(string2);
        }
        Node node4 = node == null ? (string2 == null ? new Node(79, node2) : new Node(80, node3, node2)) : (string2 == null ? new Node(77, node, node2) : new Node(78, node, node3, node2));
        if (n != 0) {
            node4.putIntProp(16, n);
        }
        return new Node(67, node4);
    }

    private Node createPropertyGet(Node node, String string2, String string3, int n) {
        if (string2 == null && n == 0) {
            if (node == null) {
                return this.createName(string3);
            }
            this.checkActivationName(string3, 33);
            if (ScriptRuntime.isSpecialProperty(string3)) {
                Node node2 = new Node(71, node);
                node2.putProp(17, string3);
                return new Node(67, node2);
            }
            return new Node(33, node, Node.newString(string3));
        }
        return this.createMemberRefGet(node, string2, Node.newString(string3), n | 1);
    }

    private Node createString(String string2) {
        return Node.newString(string2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node createTryCatchFinally(Node node, Node node2, Node node3, int n) {
        boolean bl;
        boolean bl2;
        block10 : {
            block9 : {
                bl = node3 != null && (node3.getType() != 129 || node3.hasChildren());
                if (node.getType() == 129 && !node.hasChildren() && !bl) break block9;
                bl2 = node2.hasChildren();
                if (bl || bl2) break block10;
            }
            return node;
        }
        Node node4 = new Node(141);
        Jump jump = new Jump(81, node, n);
        jump.putProp(3, node4);
        if (bl2) {
            Node node5;
            Node node6 = Node.newTarget();
            jump.addChildToBack(this.makeJump(5, node6));
            jump.target = node5 = Node.newTarget();
            jump.addChildToBack(node5);
            Node node7 = new Node(141);
            boolean bl3 = false;
            int n2 = 0;
            for (Node node8 = node2.getFirstChild(); node8 != null; node8 = node8.getNext(), ++n2) {
                Node node9;
                int n3 = node8.getLineno();
                Node node10 = node8.getFirstChild();
                Node node11 = node10.getNext();
                Node node12 = node11.getNext();
                node8.removeChild(node10);
                node8.removeChild(node11);
                node8.removeChild(node12);
                node12.addChildToBack(new Node(3));
                node12.addChildToBack(this.makeJump(5, node6));
                if (node11.getType() == 128) {
                    node9 = node12;
                    bl3 = true;
                } else {
                    node9 = this.createIf(node11, node12, null, n3);
                }
                Node node13 = new Node(57, node10, this.createUseLocal(node4));
                node13.putProp(3, node7);
                node13.putIntProp(14, n2);
                node7.addChildToBack(node13);
                node7.addChildToBack(this.createWith(this.createUseLocal(node7), node9, n3));
            }
            jump.addChildToBack(node7);
            if (!bl3) {
                Node node14 = new Node(51);
                node14.putProp(3, node4);
                jump.addChildToBack(node14);
            }
            jump.addChildToBack(node6);
        }
        if (bl) {
            Node node15 = Node.newTarget();
            jump.setFinally(node15);
            jump.addChildToBack(this.makeJump(135, node15));
            Node node16 = Node.newTarget();
            jump.addChildToBack(this.makeJump(5, node16));
            jump.addChildToBack(node15);
            Node node17 = new Node(125, node3);
            node17.putProp(3, node4);
            jump.addChildToBack(node17);
            jump.addChildToBack(node16);
        }
        node4.addChildToBack(jump);
        return node4;
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node createUnary(int n, Node node) {
        int n2 = node.getType();
        switch (n) {
            default: {
                return new Node(n, node);
            }
            case 31: {
                if (n2 == 39) {
                    node.setType(49);
                    return new Node(n, node, Node.newString(node.getString()));
                }
                if (n2 == 33 || n2 == 36) {
                    Node node2 = node.getFirstChild();
                    Node node3 = node.getLastChild();
                    node.removeChild(node2);
                    node.removeChild(node3);
                    return new Node(n, node2, node3);
                }
                if (n2 != 67) return new Node(n, new Node(45), node);
                Node node4 = node.getFirstChild();
                node.removeChild(node4);
                return new Node(69, node4);
            }
            case 32: {
                if (n2 != 39) return new Node(n, node);
                node.setType(137);
                return node;
            }
            case 27: {
                if (n2 != 40) return new Node(n, node);
                node.setDouble(-1 ^ ScriptRuntime.toInt32(node.getDouble()));
                return node;
            }
            case 29: {
                if (n2 != 40) return new Node(n, node);
                node.setDouble(-node.getDouble());
                return node;
            }
            case 26: 
        }
        int n3 = IRFactory.isAlwaysDefinedBoolean(node);
        if (n3 == 0) return new Node(n, node);
        int n4 = n3 == 1 ? 44 : 45;
        if (n2 != 45) {
            if (n2 != 44) return new Node(n4);
        }
        node.setType(n4);
        return node;
    }

    private Node createUseLocal(Node node) {
        if (141 != node.getType()) {
            throw Kit.codeBug();
        }
        Node node2 = new Node(54);
        node2.putProp(3, node);
        return node2;
    }

    private Node createWith(Node node, Node node2, int n) {
        this.setRequiresActivation();
        Node node3 = new Node(129, n);
        node3.addChildToBack(new Node(2, node));
        node3.addChildrenToBack(new Node(123, node2, n));
        node3.addChildToBack(new Node(3));
        return node3;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private Node genExprTransformHelper(GeneratorExpression generatorExpression) {
        this.decompiler.addToken(87);
        int n = generatorExpression.getLineno();
        Node node = this.transform(generatorExpression.getResult());
        List<GeneratorExpressionLoop> list = generatorExpression.getLoops();
        int n2 = list.size();
        Node[] arrnode = new Node[n2];
        Node[] arrnode2 = new Node[n2];
        for (int i = 0; i < n2; ++i) {
            String string2;
            GeneratorExpressionLoop generatorExpressionLoop = (GeneratorExpressionLoop)list.get(i);
            this.decompiler.addName(" ");
            this.decompiler.addToken(119);
            this.decompiler.addToken(87);
            AstNode astNode = generatorExpressionLoop.getIterator();
            if (astNode.getType() == 39) {
                string2 = astNode.getString();
                this.decompiler.addName(string2);
            } else {
                this.decompile(astNode);
                string2 = this.currentScriptOrFn.getNextTempName();
                this.defineSymbol(87, string2, false);
                node = this.createBinary(89, this.createAssignment(90, astNode, this.createName(string2)), node);
            }
            Node node2 = this.createName(string2);
            this.defineSymbol(153, string2, false);
            arrnode[i] = node2;
            this.decompiler.addToken(52);
            arrnode2[i] = this.transform(generatorExpressionLoop.getIteratedObject());
            this.decompiler.addToken(88);
        }
        Node node3 = new Node(72, node, generatorExpression.getLineno());
        Node node4 = new Node(133, node3, n);
        if (generatorExpression.getFilter() != null) {
            this.decompiler.addName(" ");
            this.decompiler.addToken(112);
            this.decompiler.addToken(87);
            node4 = this.createIf(this.transform(generatorExpression.getFilter()), node4, null, n);
            this.decompiler.addToken(88);
        }
        int n3 = 0;
        for (int i = n2 - 1; i >= 0; ++n3, --i) {
            Node node5;
            GeneratorExpressionLoop generatorExpressionLoop = (GeneratorExpressionLoop)list.get(i);
            Scope scope = this.createLoopNode(null, generatorExpressionLoop.getLineno());
            this.pushScope(scope);
            node4 = node5 = this.createForIn(153, scope, arrnode[i], arrnode2[i], node4, generatorExpressionLoop.isForEach());
            continue;
        }
        int n4 = 0;
        do {
            if (n4 >= n3) {
                this.decompiler.addToken(88);
                return node4;
            }
            this.popScope();
            ++n4;
        } while (true);
        catch (Throwable throwable) {
            int n5 = 0;
            while (n5 < n3) {
                this.popScope();
                ++n5;
            }
            throw throwable;
        }
    }

    private Object getPropKey(Node node) {
        if (node instanceof Name) {
            String string2 = ((Name)node).getIdentifier();
            this.decompiler.addName(string2);
            return ScriptRuntime.getIndexObject(string2);
        }
        if (node instanceof StringLiteral) {
            String string3 = ((StringLiteral)node).getValue();
            this.decompiler.addString(string3);
            return ScriptRuntime.getIndexObject(string3);
        }
        if (node instanceof NumberLiteral) {
            double d = ((NumberLiteral)node).getNumber();
            this.decompiler.addNumber(d);
            return ScriptRuntime.getIndexObject(d);
        }
        throw Kit.codeBug();
    }

    private Node initFunction(FunctionNode functionNode, int n, Node node, int n2) {
        Node node2;
        Name name;
        functionNode.setFunctionType(n2);
        functionNode.addChildToBack(node);
        if (functionNode.getFunctionCount() != 0) {
            functionNode.setRequiresActivation();
        }
        if (n2 == 2 && (name = functionNode.getFunctionName()) != null && name.length() != 0 && functionNode.getSymbol(name.getIdentifier()) == null) {
            functionNode.putSymbol(new Symbol(109, name.getIdentifier()));
            node.addChildrenToFront(new Node(133, new Node(8, Node.newString(49, name.getIdentifier()), new Node(63))));
        }
        if ((node2 = node.getLastChild()) == null || node2.getType() != 4) {
            node.addChildToBack(new Node(4));
        }
        Node node3 = Node.newString(109, functionNode.getName());
        node3.putIntProp(1, n);
        return node3;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int isAlwaysDefinedBoolean(Node node) {
        int n = -1;
        switch (node.getType()) {
            default: {
                n = 0;
            }
            case 42: 
            case 44: {
                return n;
            }
            case 45: {
                return 1;
            }
            case 40: {
                double d = node.getDouble();
                if (d != d || d == 0.0) return n;
                return 1;
            }
        }
    }

    private Jump makeJump(int n, Node node) {
        Jump jump = new Jump(n);
        jump.target = node;
        return jump;
    }

    private Node makeReference(Node node) {
        switch (node.getType()) {
            default: {
                node = null;
            }
            case 33: 
            case 36: 
            case 39: 
            case 67: {
                return node;
            }
            case 38: 
        }
        node.setType(70);
        return new Node(67, node);
    }

    private Node transformArrayComp(ArrayComprehension arrayComprehension) {
        int n = arrayComprehension.getLineno();
        Scope scope = this.createScopeNode(157, n);
        String string2 = this.currentScriptOrFn.getNextTempName();
        this.pushScope(scope);
        try {
            this.defineSymbol(153, string2, false);
            Node node = new Node(129, n);
            Node node2 = this.createCallOrNew(30, this.createName("Array"));
            node.addChildToBack(new Node(133, this.createAssignment(90, this.createName(string2), node2), n));
            node.addChildToBack(this.arrayCompTransformHelper(arrayComprehension, string2));
            scope.addChildToBack(node);
            scope.addChildToBack(this.createName(string2));
            return scope;
        }
        finally {
            this.popScope();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node transformArrayLiteral(ArrayLiteral arrayLiteral) {
        if (arrayLiteral.isDestructuring()) {
            return arrayLiteral;
        }
        this.decompiler.addToken(83);
        List<AstNode> list = arrayLiteral.getElements();
        Node node = new Node(65);
        ArrayList arrayList = null;
        for (int i = 0; i < list.size(); ++i) {
            AstNode astNode = (AstNode)list.get(i);
            if (astNode.getType() != 128) {
                node.addChildToBack(this.transform(astNode));
            } else {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add((Object)i);
            }
            if (i >= -1 + list.size()) continue;
            this.decompiler.addToken(89);
        }
        this.decompiler.addToken(84);
        node.putIntProp(21, arrayLiteral.getDestructuringLength());
        if (arrayList != null) {
            int[] arrn = new int[arrayList.size()];
            for (int i = 0; i < arrayList.size(); ++i) {
                arrn[i] = (Integer)arrayList.get(i);
            }
            node.putProp(11, arrn);
        }
        return node;
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node transformAssignment(Assignment assignment) {
        Node node;
        AstNode astNode = this.removeParens(assignment.getLeft());
        if (this.isDestructuring(astNode)) {
            this.decompile(astNode);
            node = astNode;
        } else {
            node = this.transform(astNode);
        }
        this.decompiler.addToken(assignment.getType());
        return this.createAssignment(assignment.getType(), node, this.transform(assignment.getRight()));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Node transformBlock(AstNode astNode) {
        if (astNode instanceof Scope) {
            this.pushScope((Scope)astNode);
        }
        try {
            ArrayList arrayList = new ArrayList();
            Iterator<Node> iterator = astNode.iterator();
            while (iterator.hasNext()) {
                arrayList.add((Object)this.transform((AstNode)((Node)iterator.next())));
            }
            astNode.removeChildren();
            Iterator iterator2 = arrayList.iterator();
            while (iterator2.hasNext()) {
                astNode.addChildToBack((Node)iterator2.next());
            }
            return astNode;
        }
        finally {
            if (astNode instanceof Scope) {
                this.popScope();
            }
        }
    }

    private Node transformBreak(BreakStatement breakStatement) {
        this.decompiler.addToken(120);
        if (breakStatement.getBreakLabel() != null) {
            this.decompiler.addName(breakStatement.getBreakLabel().getIdentifier());
        }
        this.decompiler.addEOL(82);
        return breakStatement;
    }

    private Node transformCondExpr(ConditionalExpression conditionalExpression) {
        Node node = this.transform(conditionalExpression.getTestExpression());
        this.decompiler.addToken(102);
        Node node2 = this.transform(conditionalExpression.getTrueExpression());
        this.decompiler.addToken(103);
        return this.createCondExpr(node, node2, this.transform(conditionalExpression.getFalseExpression()));
    }

    private Node transformContinue(ContinueStatement continueStatement) {
        this.decompiler.addToken(121);
        if (continueStatement.getLabel() != null) {
            this.decompiler.addName(continueStatement.getLabel().getIdentifier());
        }
        this.decompiler.addEOL(82);
        return continueStatement;
    }

    private Node transformDefaultXmlNamepace(UnaryExpression unaryExpression) {
        this.decompiler.addToken(116);
        this.decompiler.addName(" xml");
        this.decompiler.addName(" namespace");
        this.decompiler.addToken(90);
        return this.createUnary(74, this.transform(unaryExpression.getOperand()));
    }

    private Node transformDoLoop(DoLoop doLoop) {
        doLoop.setType(132);
        this.pushScope(doLoop);
        try {
            this.decompiler.addToken(118);
            this.decompiler.addEOL(85);
            Node node = this.transform(doLoop.getBody());
            this.decompiler.addToken(86);
            this.decompiler.addToken(117);
            this.decompiler.addToken(87);
            Node node2 = this.transform(doLoop.getCondition());
            this.decompiler.addToken(88);
            this.decompiler.addEOL(82);
            Node node3 = this.createLoop(doLoop, 0, node, node2, null, null);
            return node3;
        }
        finally {
            this.popScope();
        }
    }

    private Node transformElementGet(ElementGet elementGet) {
        Node node = this.transform(elementGet.getTarget());
        this.decompiler.addToken(83);
        Node node2 = this.transform(elementGet.getElement());
        this.decompiler.addToken(84);
        return new Node(36, node, node2);
    }

    private Node transformExprStmt(ExpressionStatement expressionStatement) {
        Node node = this.transform(expressionStatement.getExpression());
        this.decompiler.addEOL(82);
        return new Node(expressionStatement.getType(), node, expressionStatement.getLineno());
    }

    private Node transformForInLoop(ForInLoop forInLoop) {
        this.decompiler.addToken(119);
        if (forInLoop.isForEach()) {
            this.decompiler.addName("each ");
        }
        this.decompiler.addToken(87);
        forInLoop.setType(132);
        this.pushScope(forInLoop);
        int n = -1;
        try {
            AstNode astNode = forInLoop.getIterator();
            if (astNode instanceof VariableDeclaration) {
                n = ((VariableDeclaration)astNode).getType();
            }
            Node node = this.transform(astNode);
            this.decompiler.addToken(52);
            Node node2 = this.transform(forInLoop.getIteratedObject());
            this.decompiler.addToken(88);
            this.decompiler.addEOL(85);
            Node node3 = this.transform(forInLoop.getBody());
            this.decompiler.addEOL(86);
            Node node4 = this.createForIn(n, forInLoop, node, node2, node3, forInLoop.isForEach());
            return node4;
        }
        finally {
            this.popScope();
        }
    }

    private Node transformForLoop(ForLoop forLoop) {
        this.decompiler.addToken(119);
        this.decompiler.addToken(87);
        forLoop.setType(132);
        Scope scope = this.currentScope;
        this.currentScope = forLoop;
        try {
            Node node = this.transform(forLoop.getInitializer());
            this.decompiler.addToken(82);
            Node node2 = this.transform(forLoop.getCondition());
            this.decompiler.addToken(82);
            Node node3 = this.transform(forLoop.getIncrement());
            this.decompiler.addToken(88);
            this.decompiler.addEOL(85);
            Node node4 = this.transform(forLoop.getBody());
            this.decompiler.addEOL(86);
            Node node5 = this.createFor(forLoop, node, node2, node3, node4);
            return node5;
        }
        finally {
            this.currentScope = scope;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Node transformFunction(FunctionNode functionNode) {
        int n = functionNode.getFunctionType();
        int n2 = this.decompiler.markFunctionStart(n);
        Node node = this.decompileFunctionHeader(functionNode);
        int n3 = this.currentScriptOrFn.addFunction(functionNode);
        Parser.PerFunctionVariables perFunctionVariables = new Parser.PerFunctionVariables(functionNode);
        try {
            Node node2 = (Node)functionNode.getProp(23);
            functionNode.removeProp(23);
            int n4 = functionNode.getBody().getLineno();
            this.nestingOfFunction = 1 + this.nestingOfFunction;
            Node node3 = this.transform(functionNode.getBody());
            if (!functionNode.isExpressionClosure()) {
                this.decompiler.addToken(86);
            }
            functionNode.setEncodedSourceBounds(n2, this.decompiler.markFunctionEnd(n2));
            if (n != 2 && !functionNode.isExpressionClosure()) {
                this.decompiler.addToken(1);
            }
            if (node2 != null) {
                node3.addChildToFront(new Node(133, node2, n4));
            }
            int n5 = functionNode.getFunctionType();
            Node node4 = this.initFunction(functionNode, n3, node3, n5);
            if (node != null) {
                node4 = this.createAssignment(90, node, node4);
                if (n5 != 2) {
                    Node node5;
                    node4 = node5 = this.createExprStatementNoReturn(node4, functionNode.getLineno());
                }
            }
            return node4;
        }
        finally {
            this.nestingOfFunction = -1 + this.nestingOfFunction;
            perFunctionVariables.restore();
        }
    }

    private Node transformFunctionCall(FunctionCall functionCall) {
        Node node = this.createCallOrNew(38, this.transform(functionCall.getTarget()));
        node.setLineno(functionCall.getLineno());
        this.decompiler.addToken(87);
        List<AstNode> list = functionCall.getArguments();
        for (int i = 0; i < list.size(); ++i) {
            node.addChildToBack(this.transform((AstNode)list.get(i)));
            if (i >= -1 + list.size()) continue;
            this.decompiler.addToken(89);
        }
        this.decompiler.addToken(88);
        return node;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Node transformGenExpr(GeneratorExpression generatorExpression) {
        FunctionNode functionNode = new FunctionNode();
        functionNode.setSourceName(this.currentScriptOrFn.getNextTempName());
        functionNode.setIsGenerator();
        functionNode.setFunctionType(2);
        functionNode.setRequiresActivation();
        int n = functionNode.getFunctionType();
        int n2 = this.decompiler.markFunctionStart(n);
        Node node = this.decompileFunctionHeader(functionNode);
        int n3 = this.currentScriptOrFn.addFunction(functionNode);
        Parser.PerFunctionVariables perFunctionVariables = new Parser.PerFunctionVariables(functionNode);
        Node node2 = (Node)functionNode.getProp(23);
        functionNode.removeProp(23);
        int n4 = generatorExpression.lineno;
        this.nestingOfFunction = 1 + this.nestingOfFunction;
        Node node3 = this.genExprTransformHelper(generatorExpression);
        if (!functionNode.isExpressionClosure()) {
            this.decompiler.addToken(86);
        }
        functionNode.setEncodedSourceBounds(n2, this.decompiler.markFunctionEnd(n2));
        if (n != 2 && !functionNode.isExpressionClosure()) {
            this.decompiler.addToken(1);
        }
        if (node2 != null) {
            node3.addChildToFront(new Node(133, node2, n4));
        }
        int n5 = functionNode.getFunctionType();
        Node node4 = this.initFunction(functionNode, n3, node3, n5);
        if (node != null) {
            node4 = this.createAssignment(90, node, node4);
            if (n5 != 2) {
                Node node5;
                node4 = node5 = this.createExprStatementNoReturn(node4, functionNode.getLineno());
            }
        }
        Node node6 = this.createCallOrNew(38, node4);
        node6.setLineno(generatorExpression.getLineno());
        this.decompiler.addToken(87);
        this.decompiler.addToken(88);
        return node6;
        finally {
            this.nestingOfFunction = -1 + this.nestingOfFunction;
            perFunctionVariables.restore();
        }
    }

    private Node transformIf(IfStatement ifStatement) {
        this.decompiler.addToken(112);
        this.decompiler.addToken(87);
        Node node = this.transform(ifStatement.getCondition());
        this.decompiler.addToken(88);
        this.decompiler.addEOL(85);
        Node node2 = this.transform(ifStatement.getThenPart());
        AstNode astNode = ifStatement.getElsePart();
        Node node3 = null;
        if (astNode != null) {
            this.decompiler.addToken(86);
            this.decompiler.addToken(113);
            this.decompiler.addEOL(85);
            node3 = this.transform(ifStatement.getElsePart());
        }
        this.decompiler.addEOL(86);
        return this.createIf(node, node2, node3, ifStatement.getLineno());
    }

    private Node transformInfix(InfixExpression infixExpression) {
        Node node = this.transform(infixExpression.getLeft());
        this.decompiler.addToken(infixExpression.getType());
        Node node2 = this.transform(infixExpression.getRight());
        if (infixExpression instanceof XmlDotQuery) {
            this.decompiler.addToken(88);
        }
        return this.createBinary(infixExpression.getType(), node, node2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node transformLabeledStatement(LabeledStatement labeledStatement) {
        Label label = labeledStatement.getFirstLabel();
        List<Label> list = labeledStatement.getLabels();
        this.decompiler.addName(label.getName());
        if (list.size() > 1) {
            for (Label label2 : list.subList(1, list.size())) {
                this.decompiler.addEOL(103);
                this.decompiler.addName(label2.getName());
            }
        }
        if (labeledStatement.getStatement().getType() == 129) {
            this.decompiler.addToken(66);
            this.decompiler.addEOL(85);
        } else {
            this.decompiler.addEOL(103);
        }
        Node node = this.transform(labeledStatement.getStatement());
        if (labeledStatement.getStatement().getType() == 129) {
            this.decompiler.addEOL(86);
        }
        Node node2 = Node.newTarget();
        Node node3 = new Node(129, (Node)label, node, node2);
        label.target = node2;
        return node3;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Node transformLetNode(LetNode letNode) {
        this.pushScope(letNode);
        try {
            this.decompiler.addToken(153);
            this.decompiler.addToken(87);
            Node node = this.transformVariableInitializers(letNode.getVariables());
            this.decompiler.addToken(88);
            letNode.addChildToBack(node);
            boolean bl = letNode.getType() == 158;
            if (letNode.getBody() != null) {
                if (bl) {
                    this.decompiler.addName(" ");
                } else {
                    this.decompiler.addEOL(85);
                }
                letNode.addChildToBack(this.transform(letNode.getBody()));
                if (!bl) {
                    this.decompiler.addEOL(86);
                }
            }
            return letNode;
        }
        finally {
            this.popScope();
        }
    }

    private Node transformLiteral(AstNode astNode) {
        this.decompiler.addToken(astNode.getType());
        return astNode;
    }

    private Node transformName(Name name) {
        this.decompiler.addName(name.getIdentifier());
        return name;
    }

    private Node transformNewExpr(NewExpression newExpression) {
        this.decompiler.addToken(30);
        Node node = this.createCallOrNew(30, this.transform(newExpression.getTarget()));
        node.setLineno(newExpression.getLineno());
        List<AstNode> list = newExpression.getArguments();
        this.decompiler.addToken(87);
        for (int i = 0; i < list.size(); ++i) {
            node.addChildToBack(this.transform((AstNode)list.get(i)));
            if (i >= -1 + list.size()) continue;
            this.decompiler.addToken(89);
        }
        this.decompiler.addToken(88);
        if (newExpression.getInitializer() != null) {
            node.addChildToBack(this.transformObjectLiteral(newExpression.getInitializer()));
        }
        return node;
    }

    private Node transformNumber(NumberLiteral numberLiteral) {
        this.decompiler.addNumber(numberLiteral.getNumber());
        return numberLiteral;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private Node transformObjectLiteral(ObjectLiteral var1_1) {
        block17 : {
            if (var1_1.isDestructuring()) {
                return var1_1;
            }
            this.decompiler.addToken(85);
            var2_2 = var1_1.getElements();
            var3_3 = new Node(66);
            if (!var2_2.isEmpty()) break block17;
            var6_4 = ScriptRuntime.emptyArgs;
            ** GOTO lbl16
        }
        var4_5 = var2_2.size();
        var5_6 = 0;
        var6_4 = new Object[var4_5];
        var7_7 = var2_2.iterator();
        do {
            block18 : {
                if (var7_7.hasNext()) break block18;
lbl16: // 2 sources:
                this.decompiler.addToken(86);
                var3_3.putProp(12, var6_4);
                return var3_3;
            }
            var8_8 = (ObjectProperty)var7_7.next();
            if (var8_8.isGetterMethod()) {
                this.decompiler.addToken(151);
            } else if (var8_8.isSetterMethod()) {
                this.decompiler.addToken(152);
            } else if (var8_8.isNormalMethod()) {
                this.decompiler.addToken(163);
            }
            var9_9 = var5_6 + 1;
            var6_4[var5_6] = this.getPropKey(var8_8.getLeft());
            if (!var8_8.isMethod()) {
                this.decompiler.addToken(66);
            }
            var10_10 = this.transform(var8_8.getRight());
            if (var8_8.isGetterMethod()) {
                var10_10 = this.createUnary(151, var10_10);
            } else if (var8_8.isSetterMethod()) {
                var10_10 = this.createUnary(152, var10_10);
            } else if (var8_8.isNormalMethod()) {
                var10_10 = this.createUnary(163, var10_10);
            }
            var3_3.addChildToBack(var10_10);
            if (var9_9 < var4_5) {
                this.decompiler.addToken(89);
            }
            var5_6 = var9_9;
        } while (true);
    }

    private Node transformParenExpr(ParenthesizedExpression parenthesizedExpression) {
        AstNode astNode = parenthesizedExpression.getExpression();
        this.decompiler.addToken(87);
        int n = 1;
        while (astNode instanceof ParenthesizedExpression) {
            this.decompiler.addToken(87);
            ++n;
            astNode = ((ParenthesizedExpression)astNode).getExpression();
        }
        Node node = this.transform(astNode);
        for (int i = 0; i < n; ++i) {
            this.decompiler.addToken(88);
        }
        node.putProp(19, (Object)Boolean.TRUE);
        return node;
    }

    private Node transformPropertyGet(PropertyGet propertyGet) {
        Node node = this.transform(propertyGet.getTarget());
        String string2 = propertyGet.getProperty().getIdentifier();
        this.decompiler.addToken(108);
        this.decompiler.addName(string2);
        return this.createPropertyGet(node, null, string2, 0);
    }

    private Node transformRegExp(RegExpLiteral regExpLiteral) {
        this.decompiler.addRegexp(regExpLiteral.getValue(), regExpLiteral.getFlags());
        this.currentScriptOrFn.addRegExp(regExpLiteral);
        return regExpLiteral;
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node transformReturn(ReturnStatement returnStatement) {
        AstNode astNode;
        boolean bl = Boolean.TRUE.equals(returnStatement.getProp(25));
        if (bl) {
            this.decompiler.addName(" ");
        } else {
            this.decompiler.addToken(4);
        }
        Node node = (astNode = returnStatement.getReturnValue()) == null ? null : this.transform(astNode);
        if (!bl) {
            this.decompiler.addEOL(82);
        }
        if (astNode == null) {
            return new Node(4, returnStatement.getLineno());
        }
        return new Node(4, node, returnStatement.getLineno());
    }

    private Node transformScript(ScriptNode scriptNode) {
        this.decompiler.addToken(136);
        if (this.currentScope != null) {
            Kit.codeBug();
        }
        this.currentScope = scriptNode;
        Node node = new Node(129);
        Iterator<Node> iterator = scriptNode.iterator();
        while (iterator.hasNext()) {
            node.addChildToBack(this.transform((AstNode)((Node)iterator.next())));
        }
        scriptNode.removeChildren();
        Node node2 = node.getFirstChild();
        if (node2 != null) {
            scriptNode.addChildrenToBack(node2);
        }
        return scriptNode;
    }

    private Node transformString(StringLiteral stringLiteral) {
        this.decompiler.addString(stringLiteral.getValue());
        return Node.newString(stringLiteral.getValue());
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node transformSwitch(SwitchStatement switchStatement) {
        this.decompiler.addToken(114);
        this.decompiler.addToken(87);
        Node node = this.transform(switchStatement.getExpression());
        this.decompiler.addToken(88);
        switchStatement.addChildToBack(node);
        Node node2 = new Node(129, (Node)switchStatement, switchStatement.getLineno());
        this.decompiler.addEOL(85);
        Iterator iterator = switchStatement.getCases().iterator();
        do {
            Node node3;
            if (!iterator.hasNext()) {
                this.decompiler.addEOL(86);
                this.closeSwitch(node2);
                return node2;
            }
            SwitchCase switchCase = (SwitchCase)iterator.next();
            AstNode astNode = switchCase.getExpression();
            if (astNode != null) {
                this.decompiler.addToken(115);
                node3 = this.transform(astNode);
            } else {
                this.decompiler.addToken(116);
                node3 = null;
            }
            this.decompiler.addEOL(103);
            List<AstNode> list = switchCase.getStatements();
            Block block = new Block();
            if (list != null) {
                Iterator iterator2 = list.iterator();
                while (iterator2.hasNext()) {
                    block.addChildToBack(this.transform((AstNode)iterator2.next()));
                }
            }
            this.addSwitchCase(node2, node3, block);
        } while (true);
    }

    private Node transformThrow(ThrowStatement throwStatement) {
        this.decompiler.addToken(50);
        Node node = this.transform(throwStatement.getExpression());
        this.decompiler.addEOL(82);
        return new Node(50, node, throwStatement.getLineno());
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node transformTry(TryStatement tryStatement) {
        this.decompiler.addToken(81);
        this.decompiler.addEOL(85);
        Node node = this.transform(tryStatement.getTryBlock());
        this.decompiler.addEOL(86);
        Block block = new Block();
        for (CatchClause catchClause : tryStatement.getCatchClauses()) {
            Node node2;
            this.decompiler.addToken(124);
            this.decompiler.addToken(87);
            String string2 = catchClause.getVarName().getIdentifier();
            this.decompiler.addName(string2);
            AstNode astNode = catchClause.getCatchCondition();
            if (astNode != null) {
                this.decompiler.addName(" ");
                this.decompiler.addToken(112);
                node2 = this.transform(astNode);
            } else {
                node2 = new EmptyExpression();
            }
            this.decompiler.addToken(88);
            this.decompiler.addEOL(85);
            Node node3 = this.transform(catchClause.getBody());
            this.decompiler.addEOL(86);
            block.addChildToBack(this.createCatch(string2, node2, node3, catchClause.getLineno()));
        }
        AstNode astNode = tryStatement.getFinallyBlock();
        Node node4 = null;
        if (astNode != null) {
            this.decompiler.addToken(125);
            this.decompiler.addEOL(85);
            node4 = this.transform(tryStatement.getFinallyBlock());
            this.decompiler.addEOL(86);
        }
        return this.createTryCatchFinally(node, block, node4, tryStatement.getLineno());
    }

    private Node transformUnary(UnaryExpression unaryExpression) {
        int n = unaryExpression.getType();
        if (n == 74) {
            return this.transformDefaultXmlNamepace(unaryExpression);
        }
        if (unaryExpression.isPrefix()) {
            this.decompiler.addToken(n);
        }
        Node node = this.transform(unaryExpression.getOperand());
        if (unaryExpression.isPostfix()) {
            this.decompiler.addToken(n);
        }
        if (n == 106 || n == 107) {
            return this.createIncDec(n, unaryExpression.isPostfix(), node);
        }
        return this.createUnary(n, node);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node transformVariableInitializers(VariableDeclaration variableDeclaration) {
        List<VariableInitializer> list = variableDeclaration.getVariables();
        int n = list.size();
        int n2 = 0;
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            Node node;
            VariableInitializer variableInitializer = (VariableInitializer)iterator.next();
            AstNode astNode = variableInitializer.getTarget();
            AstNode astNode2 = variableInitializer.getInitializer();
            if (variableInitializer.isDestructuring()) {
                this.decompile(astNode);
                node = astNode;
            } else {
                node = this.transform(astNode);
            }
            Node node2 = null;
            if (astNode2 != null) {
                this.decompiler.addToken(90);
                node2 = this.transform(astNode2);
            }
            if (variableInitializer.isDestructuring()) {
                if (node2 == null) {
                    variableDeclaration.addChildToBack(node);
                } else {
                    variableDeclaration.addChildToBack(this.createDestructuringAssignment(variableDeclaration.getType(), node, node2));
                }
            } else {
                if (node2 != null) {
                    node.addChildToBack(node2);
                }
                variableDeclaration.addChildToBack(node);
            }
            int n3 = n2 + 1;
            if (n2 < n - 1) {
                this.decompiler.addToken(89);
            }
            n2 = n3;
        }
        return variableDeclaration;
    }

    private Node transformVariables(VariableDeclaration variableDeclaration) {
        this.decompiler.addToken(variableDeclaration.getType());
        this.transformVariableInitializers(variableDeclaration);
        AstNode astNode = variableDeclaration.getParent();
        if (!(astNode instanceof Loop) && !(astNode instanceof LetNode)) {
            this.decompiler.addEOL(82);
        }
        return variableDeclaration;
    }

    private Node transformWhileLoop(WhileLoop whileLoop) {
        this.decompiler.addToken(117);
        whileLoop.setType(132);
        this.pushScope(whileLoop);
        try {
            this.decompiler.addToken(87);
            Node node = this.transform(whileLoop.getCondition());
            this.decompiler.addToken(88);
            this.decompiler.addEOL(85);
            Node node2 = this.transform(whileLoop.getBody());
            this.decompiler.addEOL(86);
            Node node3 = this.createLoop(whileLoop, 1, node2, node, null, null);
            return node3;
        }
        finally {
            this.popScope();
        }
    }

    private Node transformWith(WithStatement withStatement) {
        this.decompiler.addToken(123);
        this.decompiler.addToken(87);
        Node node = this.transform(withStatement.getExpression());
        this.decompiler.addToken(88);
        this.decompiler.addEOL(85);
        Node node2 = this.transform(withStatement.getStatement());
        this.decompiler.addEOL(86);
        return this.createWith(node, node2, withStatement.getLineno());
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node transformXmlLiteral(XmlLiteral xmlLiteral) {
        Node node = new Node(30, xmlLiteral.getLineno());
        List<XmlFragment> list = xmlLiteral.getFragments();
        String string2 = ((XmlString)list.get(0)).getXml().trim().startsWith("<>") ? "XMLList" : "XML";
        node.addChildToBack(this.createName(string2));
        Node node2 = null;
        Iterator iterator = list.iterator();
        do {
            Node node3;
            if (!iterator.hasNext()) {
                node.addChildToBack(node2);
                return node;
            }
            XmlFragment xmlFragment = (XmlFragment)iterator.next();
            if (xmlFragment instanceof XmlString) {
                String string3 = ((XmlString)xmlFragment).getXml();
                this.decompiler.addName(string3);
                if (node2 == null) {
                    node2 = this.createString(string3);
                    continue;
                }
                node2 = this.createBinary(21, node2, this.createString(string3));
                continue;
            }
            XmlExpression xmlExpression = (XmlExpression)xmlFragment;
            boolean bl = xmlExpression.isXmlAttribute();
            this.decompiler.addToken(85);
            Node node4 = xmlExpression.getExpression() instanceof EmptyExpression ? this.createString("") : this.transform(xmlExpression.getExpression());
            this.decompiler.addToken(86);
            if (bl) {
                Node node5 = this.createUnary(75, node4);
                node3 = this.createBinary(21, this.createBinary(21, this.createString("\""), node5), this.createString("\""));
            } else {
                node3 = this.createUnary(76, node4);
            }
            node2 = this.createBinary(21, node2, node3);
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node transformXmlMemberGet(XmlMemberGet xmlMemberGet) {
        XmlRef xmlRef = xmlMemberGet.getMemberRef();
        Node node = this.transform(xmlMemberGet.getLeft());
        int n = xmlRef.isAttributeAccess() ? 2 : 0;
        if (xmlMemberGet.getType() == 143) {
            n |= 4;
            this.decompiler.addToken(143);
            return this.transformXmlRef(node, xmlRef, n);
        }
        this.decompiler.addToken(108);
        return this.transformXmlRef(node, xmlRef, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node transformXmlRef(Node node, XmlRef xmlRef, int n) {
        Name name;
        String string2;
        if ((n & 2) != 0) {
            this.decompiler.addToken(147);
        }
        if ((string2 = (name = xmlRef.getNamespace()) != null ? name.getIdentifier() : null) != null) {
            this.decompiler.addName(string2);
            this.decompiler.addToken(144);
        }
        if (xmlRef instanceof XmlPropRef) {
            String string3 = ((XmlPropRef)xmlRef).getPropName().getIdentifier();
            this.decompiler.addName(string3);
            return this.createPropertyGet(node, string2, string3, n);
        }
        this.decompiler.addToken(83);
        Node node2 = this.transform(((XmlElemRef)xmlRef).getExpression());
        this.decompiler.addToken(84);
        return this.createElementGet(node, string2, node2, n);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Node transformXmlRef(XmlRef xmlRef) {
        int n;
        if (xmlRef.isAttributeAccess()) {
            n = 2;
            do {
                return this.transformXmlRef(null, xmlRef, n);
                break;
            } while (true);
        }
        n = 0;
        return this.transformXmlRef(null, xmlRef, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Node transformYield(Yield yield) {
        this.decompiler.addToken(72);
        Node node = yield.getValue() == null ? null : this.transform(yield.getValue());
        if (node != null) {
            return new Node(72, node, yield.getLineno());
        }
        return new Node(72, yield.getLineno());
    }

    void decompile(AstNode astNode) {
        switch (astNode.getType()) {
            default: {
                Kit.codeBug("unexpected token: " + Token.typeToName(astNode.getType()));
            }
            case 128: {
                return;
            }
            case 65: {
                this.decompileArrayLiteral((ArrayLiteral)astNode);
                return;
            }
            case 66: {
                this.decompileObjectLiteral((ObjectLiteral)astNode);
                return;
            }
            case 41: {
                this.decompiler.addString(((StringLiteral)astNode).getValue());
                return;
            }
            case 39: {
                this.decompiler.addName(((Name)astNode).getIdentifier());
                return;
            }
            case 40: {
                this.decompiler.addNumber(((NumberLiteral)astNode).getNumber());
                return;
            }
            case 33: {
                this.decompilePropertyGet((PropertyGet)astNode);
                return;
            }
            case 36: {
                this.decompileElementGet((ElementGet)astNode);
                return;
            }
            case 43: 
        }
        this.decompiler.addToken(astNode.getType());
    }

    void decompileArrayLiteral(ArrayLiteral arrayLiteral) {
        this.decompiler.addToken(83);
        List<AstNode> list = arrayLiteral.getElements();
        int n = list.size();
        for (int i = 0; i < n; ++i) {
            this.decompile((AstNode)list.get(i));
            if (i >= n - 1) continue;
            this.decompiler.addToken(89);
        }
        this.decompiler.addToken(84);
    }

    void decompileElementGet(ElementGet elementGet) {
        this.decompile(elementGet.getTarget());
        this.decompiler.addToken(83);
        this.decompile(elementGet.getElement());
        this.decompiler.addToken(84);
    }

    /*
     * Enabled aggressive block sorting
     */
    Node decompileFunctionHeader(FunctionNode functionNode) {
        Node node = null;
        if (functionNode.getFunctionName() != null) {
            this.decompiler.addName(functionNode.getName());
        } else {
            AstNode astNode = functionNode.getMemberExprNode();
            node = null;
            if (astNode != null) {
                node = this.transform(functionNode.getMemberExprNode());
            }
        }
        this.decompiler.addToken(87);
        List<AstNode> list = functionNode.getParams();
        for (int i = 0; i < list.size(); ++i) {
            this.decompile((AstNode)list.get(i));
            if (i >= -1 + list.size()) continue;
            this.decompiler.addToken(89);
        }
        this.decompiler.addToken(88);
        if (!functionNode.isExpressionClosure()) {
            this.decompiler.addEOL(85);
        }
        return node;
    }

    void decompileObjectLiteral(ObjectLiteral objectLiteral) {
        this.decompiler.addToken(85);
        List<ObjectProperty> list = objectLiteral.getElements();
        int n = list.size();
        for (int i = 0; i < n; ++i) {
            ObjectProperty objectProperty = (ObjectProperty)list.get(i);
            boolean bl = Boolean.TRUE.equals(objectProperty.getProp(26));
            this.decompile(objectProperty.getLeft());
            if (!bl) {
                this.decompiler.addToken(103);
                this.decompile(objectProperty.getRight());
            }
            if (i >= n - 1) continue;
            this.decompiler.addToken(89);
        }
        this.decompiler.addToken(86);
    }

    void decompilePropertyGet(PropertyGet propertyGet) {
        this.decompile(propertyGet.getTarget());
        this.decompiler.addToken(108);
        this.decompile(propertyGet.getProperty());
    }

    boolean isDestructuring(Node node) {
        return node instanceof DestructuringForm && ((DestructuringForm)((Object)node)).isDestructuring();
    }

    public Node transform(AstNode node) {
        switch (node.getType()) {
            default: {
                if (!(node instanceof ExpressionStatement)) break;
                node = this.transformExprStmt((ExpressionStatement)node);
            }
            case 128: {
                return node;
            }
            case 157: {
                return this.transformArrayComp((ArrayComprehension)node);
            }
            case 65: {
                return this.transformArrayLiteral((ArrayLiteral)node);
            }
            case 129: {
                return this.transformBlock((AstNode)node);
            }
            case 120: {
                return this.transformBreak((BreakStatement)node);
            }
            case 38: {
                return this.transformFunctionCall((FunctionCall)node);
            }
            case 121: {
                return this.transformContinue((ContinueStatement)node);
            }
            case 118: {
                return this.transformDoLoop((DoLoop)node);
            }
            case 119: {
                if (node instanceof ForInLoop) {
                    return this.transformForInLoop((ForInLoop)node);
                }
                return this.transformForLoop((ForLoop)node);
            }
            case 109: {
                return this.transformFunction((FunctionNode)node);
            }
            case 162: {
                return this.transformGenExpr((GeneratorExpression)node);
            }
            case 36: {
                return this.transformElementGet((ElementGet)node);
            }
            case 33: {
                return this.transformPropertyGet((PropertyGet)node);
            }
            case 102: {
                return this.transformCondExpr((ConditionalExpression)node);
            }
            case 112: {
                return this.transformIf((IfStatement)node);
            }
            case 42: 
            case 43: 
            case 44: 
            case 45: 
            case 160: {
                return this.transformLiteral((AstNode)node);
            }
            case 39: {
                return this.transformName((Name)node);
            }
            case 40: {
                return this.transformNumber((NumberLiteral)node);
            }
            case 30: {
                return this.transformNewExpr((NewExpression)node);
            }
            case 66: {
                return this.transformObjectLiteral((ObjectLiteral)node);
            }
            case 48: {
                return this.transformRegExp((RegExpLiteral)node);
            }
            case 4: {
                return this.transformReturn((ReturnStatement)node);
            }
            case 136: {
                return this.transformScript((ScriptNode)node);
            }
            case 41: {
                return this.transformString((StringLiteral)node);
            }
            case 114: {
                return this.transformSwitch((SwitchStatement)node);
            }
            case 50: {
                return this.transformThrow((ThrowStatement)node);
            }
            case 81: {
                return this.transformTry((TryStatement)node);
            }
            case 117: {
                return this.transformWhileLoop((WhileLoop)node);
            }
            case 123: {
                return this.transformWith((WithStatement)node);
            }
            case 72: {
                return this.transformYield((Yield)node);
            }
        }
        if (node instanceof Assignment) {
            return this.transformAssignment((Assignment)node);
        }
        if (node instanceof UnaryExpression) {
            return this.transformUnary((UnaryExpression)node);
        }
        if (node instanceof XmlMemberGet) {
            return this.transformXmlMemberGet((XmlMemberGet)node);
        }
        if (node instanceof InfixExpression) {
            return this.transformInfix((InfixExpression)node);
        }
        if (node instanceof VariableDeclaration) {
            return this.transformVariables((VariableDeclaration)node);
        }
        if (node instanceof ParenthesizedExpression) {
            return this.transformParenExpr((ParenthesizedExpression)node);
        }
        if (node instanceof LabeledStatement) {
            return this.transformLabeledStatement((LabeledStatement)node);
        }
        if (node instanceof LetNode) {
            return this.transformLetNode((LetNode)node);
        }
        if (node instanceof XmlRef) {
            return this.transformXmlRef((XmlRef)node);
        }
        if (node instanceof XmlLiteral) {
            return this.transformXmlLiteral((XmlLiteral)node);
        }
        throw new IllegalArgumentException("Can't transform: " + node);
    }

    public ScriptNode transformTree(AstRoot astRoot) {
        this.currentScriptOrFn = astRoot;
        this.inUseStrictDirective = astRoot.isInStrictMode();
        int n = this.decompiler.getCurrentOffset();
        ScriptNode scriptNode = (ScriptNode)this.transform(astRoot);
        scriptNode.setEncodedSourceBounds(n, this.decompiler.getCurrentOffset());
        if (this.compilerEnv.isGeneratingSource()) {
            scriptNode.setEncodedSource(this.decompiler.getEncodedSource());
        }
        this.decompiler = null;
        return scriptNode;
    }
}

