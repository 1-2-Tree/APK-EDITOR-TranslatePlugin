/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.SecurityManager
 *  java.lang.String
 *  java.lang.System
 *  java.security.AccessController
 *  java.security.PrivilegedAction
 *  java.security.ProtectionDomain
 */
package org.mozilla.javascript;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.ProtectionDomain;
import org.mozilla.javascript.RhinoSecurityManager;

public class SecurityUtilities {
    public static ProtectionDomain getProtectionDomain(final Class<?> class_) {
        return (ProtectionDomain)AccessController.doPrivileged((PrivilegedAction)new PrivilegedAction<ProtectionDomain>(){

            public ProtectionDomain run() {
                return class_.getProtectionDomain();
            }
        });
    }

    public static ProtectionDomain getScriptProtectionDomain() {
        final SecurityManager securityManager = System.getSecurityManager();
        if (securityManager instanceof RhinoSecurityManager) {
            return (ProtectionDomain)AccessController.doPrivileged((PrivilegedAction)new PrivilegedAction<ProtectionDomain>(){

                public ProtectionDomain run() {
                    Class<?> class_ = ((RhinoSecurityManager)securityManager).getCurrentScriptClass();
                    if (class_ == null) {
                        return null;
                    }
                    return class_.getProtectionDomain();
                }
            });
        }
        return null;
    }

    public static String getSystemProperty(final String string2) {
        return (String)AccessController.doPrivileged((PrivilegedAction)new PrivilegedAction<String>(){

            public String run() {
                return System.getProperty((String)string2);
            }
        });
    }

}

