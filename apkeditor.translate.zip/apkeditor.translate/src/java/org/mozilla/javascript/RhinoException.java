/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.CharArrayWriter
 *  java.io.FilenameFilter
 *  java.io.PrintStream
 *  java.io.PrintWriter
 *  java.io.Writer
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package org.mozilla.javascript;

import java.io.CharArrayWriter;
import java.io.FilenameFilter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Evaluator;
import org.mozilla.javascript.Interpreter;
import org.mozilla.javascript.ScriptStackElement;
import org.mozilla.javascript.SecurityUtilities;
import org.mozilla.javascript.StackStyle;

public abstract class RhinoException
extends RuntimeException {
    private static final Pattern JAVA_STACK_PATTERN = Pattern.compile((String)"_c_(.*)_\\d+");
    static final long serialVersionUID = 1883500631321581169L;
    private static StackStyle stackStyle = StackStyle.RHINO;
    private int columnNumber;
    int[] interpreterLineData;
    Object interpreterStackInfo;
    private int lineNumber;
    private String lineSource;
    private String sourceName;

    /*
     * Enabled aggressive block sorting
     */
    static {
        String string2 = System.getProperty((String)"rhino.stack.style");
        if (string2 == null) return;
        {
            if ("Rhino".equalsIgnoreCase(string2)) {
                stackStyle = StackStyle.RHINO;
                return;
            } else {
                if ("Mozilla".equalsIgnoreCase(string2)) {
                    stackStyle = StackStyle.MOZILLA;
                    return;
                }
                if (!"V8".equalsIgnoreCase(string2)) return;
                {
                    stackStyle = StackStyle.V8;
                    return;
                }
            }
        }
    }

    RhinoException() {
        Evaluator evaluator = Context.createInterpreter();
        if (evaluator != null) {
            evaluator.captureStackInfo(this);
        }
    }

    RhinoException(String string2) {
        super(string2);
        Evaluator evaluator = Context.createInterpreter();
        if (evaluator != null) {
            evaluator.captureStackInfo(this);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static String formatStackTrace(ScriptStackElement[] arrscriptStackElement, String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        String string3 = SecurityUtilities.getSystemProperty("line.separator");
        if (stackStyle == StackStyle.V8 && !"null".equals((Object)string2)) {
            stringBuilder.append(string2);
            stringBuilder.append(string3);
        }
        int n = arrscriptStackElement.length;
        int n2 = 0;
        while (n2 < n) {
            ScriptStackElement scriptStackElement = arrscriptStackElement[n2];
            switch (1.$SwitchMap$org$mozilla$javascript$StackStyle[stackStyle.ordinal()]) {
                case 1: {
                    scriptStackElement.renderMozillaStyle(stringBuilder);
                    break;
                }
                case 2: {
                    scriptStackElement.renderV8Style(stringBuilder);
                    break;
                }
                case 3: {
                    scriptStackElement.renderJavaStyle(stringBuilder);
                    break;
                }
            }
            stringBuilder.append(string3);
            ++n2;
        }
        return stringBuilder.toString();
    }

    private String generateStackTrace() {
        CharArrayWriter charArrayWriter = new CharArrayWriter();
        super.printStackTrace(new PrintWriter((Writer)charArrayWriter));
        String string2 = charArrayWriter.toString();
        Evaluator evaluator = Context.createInterpreter();
        if (evaluator != null) {
            return evaluator.getPatchedStack(this, string2);
        }
        return null;
    }

    public static StackStyle getStackStyle() {
        return stackStyle;
    }

    public static void setStackStyle(StackStyle stackStyle) {
        RhinoException.stackStyle = stackStyle;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void useMozillaStackStyle(boolean bl) {
        StackStyle stackStyle = bl ? StackStyle.MOZILLA : StackStyle.RHINO;
        RhinoException.stackStyle = stackStyle;
    }

    public static boolean usesMozillaStackStyle() {
        return stackStyle == StackStyle.MOZILLA;
    }

    public final int columnNumber() {
        return this.columnNumber;
    }

    public String details() {
        return super.getMessage();
    }

    public final String getMessage() {
        String string2 = this.details();
        if (this.sourceName == null || this.lineNumber <= 0) {
            return string2;
        }
        StringBuilder stringBuilder = new StringBuilder(string2);
        stringBuilder.append(" (");
        if (this.sourceName != null) {
            stringBuilder.append(this.sourceName);
        }
        if (this.lineNumber > 0) {
            stringBuilder.append('#');
            stringBuilder.append(this.lineNumber);
        }
        stringBuilder.append(')');
        return stringBuilder.toString();
    }

    public ScriptStackElement[] getScriptStack() {
        return this.getScriptStack(-1, null);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public ScriptStackElement[] getScriptStack(int var1_1, String var2_2) {
        block13 : {
            var3_3 = new ArrayList();
            var4_4 = null;
            if (this.interpreterStackInfo != null && (var25_5 = Context.createInterpreter()) instanceof Interpreter) {
                var4_4 = ((Interpreter)var25_5).getScriptStackElements(this);
            }
            var5_6 = this.getStackTrace();
            var6_7 = 0;
            var7_8 = var2_2 == null;
            var8_9 = var5_6.length;
            var9_10 = 0;
            var10_11 = 0;
            block0 : while (var9_10 < var8_9) {
                var11_12 = var5_6[var9_10];
                var12_13 = var11_12.getFileName();
                if (var11_12.getMethodName().startsWith("_c_") && var11_12.getLineNumber() > -1 && var12_13 != null && !var12_13.endsWith(".java")) {
                    var19_19 = var11_12.getMethodName();
                    var20_20 = RhinoException.JAVA_STACK_PATTERN.matcher((CharSequence)var19_19);
                    var21_21 = "_c_script_0".equals((Object)var19_19) == false && var20_20.find() != false ? var20_20.group(1) : null;
                    if (!var7_8 && var2_2.equals((Object)var21_21)) {
                        var7_8 = true;
                    } else if (var7_8 && (var1_1 < 0 || var6_7 < var1_1)) {
                        var22_22 = var11_12.getLineNumber();
                        var23_23 = new ScriptStackElement(var12_13, var21_21, var22_22);
                        var3_3.add((Object)var23_23);
                        ++var6_7;
                    }
                    var13_14 = var10_11;
                } else {
                    if ("org.mozilla.javascript.Interpreter".equals((Object)var11_12.getClassName()) && "interpretLoop".equals((Object)var11_12.getMethodName()) && var4_4 != null && var4_4.length > var10_11) {
                        var13_14 = var10_11 + 1;
                        var14_15 = var4_4[var10_11];
                        var15_16 = var14_15.length;
                        var16_17 = 0;
                        break block13;
                    }
                    var13_14 = var10_11;
                }
                do {
                    ++var9_10;
                    var10_11 = var13_14;
                    continue block0;
                    break;
                } while (true);
            }
            return (ScriptStackElement[])var3_3.toArray((Object[])new ScriptStackElement[var3_3.size()]);
        }
        do {
            if (var16_17 >= var15_16) ** continue;
            var17_18 = var14_15[var16_17];
            if (!var7_8 && var2_2.equals((Object)var17_18.functionName)) {
                var7_8 = true;
            } else if (var7_8 && (var1_1 < 0 || var6_7 < var1_1)) {
                var3_3.add((Object)var17_18);
                ++var6_7;
            }
            ++var16_17;
        } while (true);
    }

    public String getScriptStackTrace() {
        return this.getScriptStackTrace(-1, null);
    }

    public String getScriptStackTrace(int n, String string2) {
        return RhinoException.formatStackTrace(this.getScriptStack(n, string2), this.details());
    }

    @Deprecated
    public String getScriptStackTrace(FilenameFilter filenameFilter) {
        return this.getScriptStackTrace();
    }

    public final void initColumnNumber(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException(String.valueOf((int)n));
        }
        if (this.columnNumber > 0) {
            throw new IllegalStateException();
        }
        this.columnNumber = n;
    }

    public final void initLineNumber(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException(String.valueOf((int)n));
        }
        if (this.lineNumber > 0) {
            throw new IllegalStateException();
        }
        this.lineNumber = n;
    }

    public final void initLineSource(String string2) {
        if (string2 == null) {
            throw new IllegalArgumentException();
        }
        if (this.lineSource != null) {
            throw new IllegalStateException();
        }
        this.lineSource = string2;
    }

    public final void initSourceName(String string2) {
        if (string2 == null) {
            throw new IllegalArgumentException();
        }
        if (this.sourceName != null) {
            throw new IllegalStateException();
        }
        this.sourceName = string2;
    }

    public final int lineNumber() {
        return this.lineNumber;
    }

    public final String lineSource() {
        return this.lineSource;
    }

    public void printStackTrace(PrintStream printStream) {
        if (this.interpreterStackInfo == null) {
            super.printStackTrace(printStream);
            return;
        }
        printStream.print(this.generateStackTrace());
    }

    public void printStackTrace(PrintWriter printWriter) {
        if (this.interpreterStackInfo == null) {
            super.printStackTrace(printWriter);
            return;
        }
        printWriter.print(this.generateStackTrace());
    }

    final void recordErrorOrigin(String string2, int n, String string3, int n2) {
        if (n == -1) {
            n = 0;
        }
        if (string2 != null) {
            this.initSourceName(string2);
        }
        if (n != 0) {
            this.initLineNumber(n);
        }
        if (string3 != null) {
            this.initLineSource(string3);
        }
        if (n2 != 0) {
            this.initColumnNumber(n2);
        }
    }

    public final String sourceName() {
        return this.sourceName;
    }

}

