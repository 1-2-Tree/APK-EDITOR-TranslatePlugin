/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;

public class Delegator
implements Function {
    protected Scriptable obj = null;

    public Delegator() {
    }

    public Delegator(Scriptable scriptable) {
        this.obj = scriptable;
    }

    @Override
    public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        return ((Function)this.obj).call(context, scriptable, scriptable2, arrobject);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Scriptable construct(Context context, Scriptable scriptable, Object[] arrobject) {
        void var5_6;
        if (this.obj != null) {
            return ((Function)this.obj).construct(context, scriptable, arrobject);
        }
        Delegator delegator = this.newInstance();
        if (arrobject.length == 0) {
            NativeObject nativeObject = new NativeObject();
        } else {
            Scriptable scriptable2 = ScriptRuntime.toObject(context, scriptable, arrobject[0]);
        }
        delegator.setDelegee((Scriptable)var5_6);
        return delegator;
    }

    @Override
    public void delete(int n) {
        this.obj.delete(n);
    }

    @Override
    public void delete(String string2) {
        this.obj.delete(string2);
    }

    @Override
    public Object get(int n, Scriptable scriptable) {
        return this.obj.get(n, scriptable);
    }

    @Override
    public Object get(String string2, Scriptable scriptable) {
        return this.obj.get(string2, scriptable);
    }

    @Override
    public String getClassName() {
        return this.obj.getClassName();
    }

    @Override
    public Object getDefaultValue(Class<?> class_) {
        if (class_ == null || class_ == ScriptRuntime.ScriptableClass || class_ == ScriptRuntime.FunctionClass) {
            return this;
        }
        return this.obj.getDefaultValue(class_);
    }

    public Scriptable getDelegee() {
        return this.obj;
    }

    @Override
    public Object[] getIds() {
        return this.obj.getIds();
    }

    @Override
    public Scriptable getParentScope() {
        return this.obj.getParentScope();
    }

    @Override
    public Scriptable getPrototype() {
        return this.obj.getPrototype();
    }

    @Override
    public boolean has(int n, Scriptable scriptable) {
        return this.obj.has(n, scriptable);
    }

    @Override
    public boolean has(String string2, Scriptable scriptable) {
        return this.obj.has(string2, scriptable);
    }

    @Override
    public boolean hasInstance(Scriptable scriptable) {
        return this.obj.hasInstance(scriptable);
    }

    protected Delegator newInstance() {
        try {
            Delegator delegator = (Delegator)this.getClass().newInstance();
            return delegator;
        }
        catch (Exception exception) {
            throw Context.throwAsScriptRuntimeEx(exception);
        }
    }

    @Override
    public void put(int n, Scriptable scriptable, Object object) {
        this.obj.put(n, scriptable, object);
    }

    @Override
    public void put(String string2, Scriptable scriptable, Object object) {
        this.obj.put(string2, scriptable, object);
    }

    public void setDelegee(Scriptable scriptable) {
        this.obj = scriptable;
    }

    @Override
    public void setParentScope(Scriptable scriptable) {
        this.obj.setParentScope(scriptable);
    }

    @Override
    public void setPrototype(Scriptable scriptable) {
        this.obj.setPrototype(scriptable);
    }
}

