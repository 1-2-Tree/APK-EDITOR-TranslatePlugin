/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.ClassNotFoundException
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashSet
 *  java.util.Set
 */
package org.mozilla.javascript;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.HashSet;
import java.util.Set;
import org.mozilla.javascript.ClassShutter;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.WrapFactory;

public class NativeJavaPackage
extends ScriptableObject {
    static final long serialVersionUID = 7445054382212031523L;
    private transient ClassLoader classLoader;
    private Set<String> negativeCache = null;
    private String packageName;

    @Deprecated
    public NativeJavaPackage(String string2) {
        this(false, string2, Context.getCurrentContext().getApplicationClassLoader());
    }

    @Deprecated
    public NativeJavaPackage(String string2, ClassLoader classLoader) {
        this(false, string2, classLoader);
    }

    NativeJavaPackage(boolean bl, String string2, ClassLoader classLoader) {
        this.packageName = string2;
        this.classLoader = classLoader;
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        this.classLoader = Context.getCurrentContext().getApplicationClassLoader();
    }

    public boolean equals(Object object) {
        boolean bl = object instanceof NativeJavaPackage;
        boolean bl2 = false;
        if (bl) {
            NativeJavaPackage nativeJavaPackage = (NativeJavaPackage)object;
            boolean bl3 = this.packageName.equals((Object)nativeJavaPackage.packageName);
            bl2 = false;
            if (bl3) {
                ClassLoader classLoader = this.classLoader;
                ClassLoader classLoader2 = nativeJavaPackage.classLoader;
                bl2 = false;
                if (classLoader == classLoader2) {
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    /*
     * Enabled aggressive block sorting
     */
    NativeJavaPackage forcePackage(String string2, Scriptable scriptable) {
        Object object = super.get(string2, (Scriptable)this);
        if (object != null && object instanceof NativeJavaPackage) {
            return (NativeJavaPackage)object;
        }
        String string3 = this.packageName.length() == 0 ? string2 : this.packageName + "." + string2;
        NativeJavaPackage nativeJavaPackage = new NativeJavaPackage(true, string3, this.classLoader);
        ScriptRuntime.setObjectProtoAndParent(nativeJavaPackage, scriptable);
        super.put(string2, (Scriptable)this, (Object)nativeJavaPackage);
        return nativeJavaPackage;
    }

    @Override
    public Object get(int n, Scriptable scriptable) {
        return NOT_FOUND;
    }

    @Override
    public Object get(String string2, Scriptable scriptable) {
        return this.getPkgProperty(string2, scriptable, true);
    }

    @Override
    public String getClassName() {
        return "JavaPackage";
    }

    @Override
    public Object getDefaultValue(Class<?> class_) {
        return this.toString();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    Object getPkgProperty(String string2, Scriptable scriptable, boolean bl) {
        NativeJavaPackage nativeJavaPackage = this;
        synchronized (nativeJavaPackage) {
            Scriptable scriptable2;
            String string3;
            block13 : {
                Context context;
                block12 : {
                    Object object = super.get(string2, scriptable);
                    Object object2 = NOT_FOUND;
                    if (object != object2) return object;
                    if (this.negativeCache != null && this.negativeCache.contains((Object)string2)) {
                        return null;
                    }
                    string3 = this.packageName.length() == 0 ? string2 : this.packageName + '.' + string2;
                    context = Context.getContext();
                    ClassShutter classShutter = context.getClassShutter();
                    if (classShutter == null) break block12;
                    boolean bl2 = classShutter.visibleToScripts(string3);
                    scriptable2 = null;
                    if (!bl2) break block13;
                }
                Class<?> class_ = this.classLoader != null ? Kit.classOrNull(this.classLoader, string3) : Kit.classOrNull(string3);
                scriptable2 = null;
                if (class_ != null) {
                    scriptable2 = context.getWrapFactory().wrapJavaClass(context, NativeJavaPackage.getTopLevelScope(this), class_);
                    scriptable2.setPrototype(this.getPrototype());
                }
            }
            if (scriptable2 == null) {
                if (bl) {
                    NativeJavaPackage nativeJavaPackage2 = new NativeJavaPackage(true, string3, this.classLoader);
                    ScriptRuntime.setObjectProtoAndParent(nativeJavaPackage2, this.getParentScope());
                    scriptable2 = nativeJavaPackage2;
                } else {
                    if (this.negativeCache == null) {
                        this.negativeCache = new HashSet();
                    }
                    this.negativeCache.add((Object)string2);
                }
            }
            if (scriptable2 == null) return scriptable2;
            super.put(string2, scriptable, scriptable2);
            return scriptable2;
        }
    }

    @Override
    public boolean has(int n, Scriptable scriptable) {
        return false;
    }

    @Override
    public boolean has(String string2, Scriptable scriptable) {
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public int hashCode() {
        int n;
        int n2 = this.packageName.hashCode();
        if (this.classLoader == null) {
            n = 0;
            do {
                return n ^ n2;
                break;
            } while (true);
        }
        n = this.classLoader.hashCode();
        return n ^ n2;
    }

    @Override
    public void put(int n, Scriptable scriptable, Object object) {
        throw Context.reportRuntimeError0("msg.pkg.int");
    }

    @Override
    public void put(String string2, Scriptable scriptable, Object object) {
    }

    public String toString() {
        return "[JavaPackage " + this.packageName + "]";
    }
}

