/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.DToA;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.NativeGlobal;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;

final class NativeNumber
extends IdScriptableObject {
    private static final int ConstructorId_isFinite = -1;
    private static final int ConstructorId_isInteger = -3;
    private static final int ConstructorId_isNaN = -2;
    private static final int ConstructorId_isSafeInteger = -4;
    private static final int ConstructorId_parseFloat = -5;
    private static final int ConstructorId_parseInt = -6;
    private static final int Id_constructor = 1;
    private static final int Id_toExponential = 7;
    private static final int Id_toFixed = 6;
    private static final int Id_toLocaleString = 3;
    private static final int Id_toPrecision = 8;
    private static final int Id_toSource = 4;
    private static final int Id_toString = 2;
    private static final int Id_valueOf = 5;
    private static final int MAX_PRECISION = 100;
    private static final int MAX_PROTOTYPE_ID = 8;
    private static final double MAX_SAFE_INTEGER = 0.0;
    private static final double MIN_SAFE_INTEGER = 0.0;
    private static final Object NUMBER_TAG = "Number";
    static final long serialVersionUID = 3504516769741512101L;
    private double doubleValue;

    static {
        MAX_SAFE_INTEGER = Math.pow((double)2.0, (double)53.0) - 1.0;
        MIN_SAFE_INTEGER = -MAX_SAFE_INTEGER;
    }

    NativeNumber(double d) {
        this.doubleValue = d;
    }

    private Double doubleVal(Number number) {
        if (number instanceof Double) {
            return (Double)number;
        }
        return number.doubleValue();
    }

    private Object execConstructorCall(int n, Object[] arrobject) {
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case -1: {
                if (arrobject.length == 0 || Undefined.instance == arrobject[0]) {
                    return false;
                }
                if (arrobject[0] instanceof Number) {
                    return NativeNumber.isFinite(arrobject[0]);
                }
                return false;
            }
            case -2: {
                if (arrobject.length == 0 || Undefined.instance == arrobject[0]) {
                    return false;
                }
                if (arrobject[0] instanceof Number) {
                    return this.isNaN((Number)arrobject[0]);
                }
                return false;
            }
            case -3: {
                if (arrobject.length == 0 || Undefined.instance == arrobject[0]) {
                    return false;
                }
                if (arrobject[0] instanceof Number) {
                    return this.isInteger((Number)arrobject[0]);
                }
                return false;
            }
            case -4: {
                if (arrobject.length == 0 || Undefined.instance == arrobject[0]) {
                    return false;
                }
                if (arrobject[0] instanceof Number) {
                    return this.isSafeInteger((Number)arrobject[0]);
                }
                return false;
            }
            case -5: {
                return NativeGlobal.js_parseFloat(arrobject);
            }
            case -6: 
        }
        return NativeGlobal.js_parseInt(arrobject);
    }

    static void init(Scriptable scriptable, boolean bl) {
        new NativeNumber(0.0).exportAsJSClass(8, scriptable, bl);
    }

    private boolean isDoubleInteger(Double d) {
        return !d.isInfinite() && !d.isNaN() && Math.floor((double)d) == d;
    }

    private boolean isDoubleNan(Double d) {
        return d.isNaN();
    }

    private boolean isDoubleSafeInteger(Double d) {
        return this.isDoubleInteger(d) && d <= MAX_SAFE_INTEGER && d >= MIN_SAFE_INTEGER;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static Object isFinite(Object object) {
        boolean bl;
        Double d = ScriptRuntime.toNumber(object);
        if (!d.isInfinite() && !d.isNaN()) {
            bl = true;
            do {
                return ScriptRuntime.wrapBoolean(bl);
                break;
            } while (true);
        }
        bl = false;
        return ScriptRuntime.wrapBoolean(bl);
    }

    private boolean isInteger(Number number) {
        return ScriptRuntime.toBoolean(this.isDoubleInteger(this.doubleVal(number)));
    }

    private Object isNaN(Number number) {
        return ScriptRuntime.toBoolean(this.isDoubleNan(this.doubleVal(number)));
    }

    private boolean isSafeInteger(Number number) {
        return ScriptRuntime.toBoolean(this.isDoubleSafeInteger(this.doubleVal(number)));
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String num_to(double d, Object[] arrobject, int n, int n2, int n3, int n4) {
        int n5;
        if (arrobject.length == 0) {
            n5 = 0;
            n2 = n;
        } else {
            double d2 = ScriptRuntime.toInteger(arrobject[0]);
            if (d2 < (double)n3 || d2 > 100.0) {
                throw ScriptRuntime.constructError("RangeError", ScriptRuntime.getMessage1("msg.bad.precision", ScriptRuntime.toString(arrobject[0])));
            }
            n5 = ScriptRuntime.toInt32(d2);
        }
        StringBuilder stringBuilder = new StringBuilder();
        DToA.JS_dtostr(stringBuilder, n2, n5 + n4, d);
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(NUMBER_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        if (n == 1) {
            double d = arrobject.length >= 1 ? ScriptRuntime.toNumber(arrobject[0]) : 0.0;
            if (scriptable2 != null) return ScriptRuntime.wrapNumber(d);
            return new NativeNumber(d);
        }
        if (n < 1) {
            return this.execConstructorCall(n, arrobject);
        }
        if (!(scriptable2 instanceof NativeNumber)) {
            throw NativeNumber.incompatibleCallError(idFunctionObject);
        }
        double d = ((NativeNumber)scriptable2).doubleValue;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 2: 
            case 3: {
                int n2;
                if (arrobject.length != 0 && arrobject[0] != Undefined.instance) {
                    n2 = ScriptRuntime.toInt32(arrobject[0]);
                    return ScriptRuntime.numberToString(d, n2);
                }
                n2 = 10;
                return ScriptRuntime.numberToString(d, n2);
            }
            case 4: {
                return "(new Number(" + ScriptRuntime.toString(d) + "))";
            }
            case 5: {
                return ScriptRuntime.wrapNumber(d);
            }
            case 6: {
                return NativeNumber.num_to(d, arrobject, 2, 2, -20, 0);
            }
            case 7: {
                if (Double.isNaN((double)d)) {
                    return "NaN";
                }
                if (!Double.isInfinite((double)d)) return NativeNumber.num_to(d, arrobject, 1, 3, 0, 1);
                if (!(d >= 0.0)) return "-Infinity";
                return "Infinity";
            }
            case 8: 
        }
        if (arrobject.length == 0) return ScriptRuntime.numberToString(d, 10);
        if (arrobject[0] == Undefined.instance) {
            return ScriptRuntime.numberToString(d, 10);
        }
        if (Double.isNaN((double)d)) {
            return "NaN";
        }
        if (!Double.isInfinite((double)d)) return NativeNumber.num_to(d, arrobject, 0, 4, 1, 0);
        if (!(d >= 0.0)) return "-Infinity";
        return "Infinity";
    }

    @Override
    protected void fillConstructorProperties(IdFunctionObject idFunctionObject) {
        idFunctionObject.defineProperty("NaN", (Object)ScriptRuntime.NaNobj, 7);
        idFunctionObject.defineProperty("POSITIVE_INFINITY", (Object)ScriptRuntime.wrapNumber(Double.POSITIVE_INFINITY), 7);
        idFunctionObject.defineProperty("NEGATIVE_INFINITY", (Object)ScriptRuntime.wrapNumber(Double.NEGATIVE_INFINITY), 7);
        idFunctionObject.defineProperty("MAX_VALUE", (Object)ScriptRuntime.wrapNumber(Double.MAX_VALUE), 7);
        idFunctionObject.defineProperty("MIN_VALUE", (Object)ScriptRuntime.wrapNumber(Double.MIN_VALUE), 7);
        idFunctionObject.defineProperty("MAX_SAFE_INTEGER", (Object)ScriptRuntime.wrapNumber(MAX_SAFE_INTEGER), 7);
        idFunctionObject.defineProperty("MIN_SAFE_INTEGER", (Object)ScriptRuntime.wrapNumber(MIN_SAFE_INTEGER), 7);
        this.addIdFunctionProperty(idFunctionObject, NUMBER_TAG, -1, "isFinite", 1);
        this.addIdFunctionProperty(idFunctionObject, NUMBER_TAG, -2, "isNaN", 1);
        this.addIdFunctionProperty(idFunctionObject, NUMBER_TAG, -3, "isInteger", 1);
        this.addIdFunctionProperty(idFunctionObject, NUMBER_TAG, -4, "isSafeInteger", 1);
        this.addIdFunctionProperty(idFunctionObject, NUMBER_TAG, -5, "parseFloat", 1);
        this.addIdFunctionProperty(idFunctionObject, NUMBER_TAG, -6, "parseInt", 1);
        super.fillConstructorProperties(idFunctionObject);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        switch (n) {
            case 7: {
                char c = string2.charAt(0);
                if (c == 't') {
                    string3 = "toFixed";
                    n2 = 6;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'v') break;
                string3 = "valueOf";
                n2 = 5;
                break;
            }
            case 8: {
                char c = string2.charAt(3);
                if (c == 'o') {
                    string3 = "toSource";
                    n2 = 4;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "toString";
                n2 = 2;
                break;
            }
            case 11: {
                char c = string2.charAt(0);
                if (c == 'c') {
                    string3 = "constructor";
                    n2 = 1;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "toPrecision";
                n2 = 8;
                break;
            }
            case 13: {
                string3 = "toExponential";
                n2 = 7;
                break;
            }
            case 14: {
                string3 = "toLocaleString";
                n2 = 3;
                break;
            }
        }
        if (string3 == null) return n2;
        if (string3 == string2) return n2;
        if (string3.equals((Object)string2)) return n2;
        return 0;
    }

    @Override
    public String getClassName() {
        return "Number";
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 1;
                string2 = "constructor";
                break;
            }
            case 2: {
                n2 = 1;
                string2 = "toString";
                break;
            }
            case 3: {
                n2 = 1;
                string2 = "toLocaleString";
                break;
            }
            case 4: {
                string2 = "toSource";
                n2 = 0;
                break;
            }
            case 5: {
                string2 = "valueOf";
                n2 = 0;
                break;
            }
            case 6: {
                n2 = 1;
                string2 = "toFixed";
                break;
            }
            case 7: {
                n2 = 1;
                string2 = "toExponential";
                break;
            }
            case 8: {
                n2 = 1;
                string2 = "toPrecision";
            }
        }
        this.initPrototypeMethod(NUMBER_TAG, n, string2, n2);
    }

    public String toString() {
        return ScriptRuntime.numberToString(this.doubleValue, 10);
    }
}

