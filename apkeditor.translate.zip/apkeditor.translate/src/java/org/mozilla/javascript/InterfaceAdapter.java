/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.lang.reflect.Method
 */
package org.mozilla.javascript;

import java.lang.reflect.Method;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.ClassCache;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextAction;
import org.mozilla.javascript.ContextFactory;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.VMBridge;
import org.mozilla.javascript.WrapFactory;

public class InterfaceAdapter {
    private final Object proxyHelper;

    private InterfaceAdapter(ContextFactory contextFactory, Class<?> class_) {
        this.proxyHelper = VMBridge.instance.getInterfaceProxyHelper(contextFactory, new Class[]{class_});
    }

    static Object create(Context context, Class<?> class_, ScriptableObject scriptableObject) {
        if (!class_.isInterface()) {
            throw new IllegalArgumentException();
        }
        Scriptable scriptable = ScriptRuntime.getTopCallScope(context);
        ClassCache classCache = ClassCache.get(scriptable);
        InterfaceAdapter interfaceAdapter = (InterfaceAdapter)classCache.getInterfaceAdapter(class_);
        ContextFactory contextFactory = context.getFactory();
        if (interfaceAdapter == null) {
            Method[] arrmethod = class_.getMethods();
            if (scriptableObject instanceof Callable) {
                int n = arrmethod.length;
                if (n == 0) {
                    throw Context.reportRuntimeError1("msg.no.empty.interface.conversion", class_.getName());
                }
                if (n > 1) {
                    String string2 = arrmethod[0].getName();
                    for (int i = 1; i < n; ++i) {
                        if (string2.equals((Object)arrmethod[i].getName())) continue;
                        throw Context.reportRuntimeError1("msg.no.function.interface.conversion", class_.getName());
                    }
                }
            }
            interfaceAdapter = new InterfaceAdapter(contextFactory, class_);
            classCache.cacheInterfaceAdapter(class_, interfaceAdapter);
        }
        return VMBridge.instance.newInterfaceProxy(interfaceAdapter.proxyHelper, contextFactory, interfaceAdapter, scriptableObject, scriptable);
    }

    public Object invoke(ContextFactory contextFactory, final Object object, final Scriptable scriptable, final Object object2, final Method method, final Object[] arrobject) {
        return contextFactory.call(new ContextAction(){

            @Override
            public Object run(Context context) {
                return InterfaceAdapter.this.invokeImpl(context, object, scriptable, object2, method, arrobject);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     */
    Object invokeImpl(Context context, Object object, Scriptable scriptable, Object object2, Method method, Object[] arrobject) {
        Callable callable;
        if (object instanceof Callable) {
            callable = (Callable)object;
        } else {
            Scriptable scriptable2 = (Scriptable)object;
            String string2 = method.getName();
            Object object3 = ScriptableObject.getProperty(scriptable2, string2);
            if (object3 == ScriptableObject.NOT_FOUND) {
                Context.reportWarning(ScriptRuntime.getMessage1("msg.undefined.function.interface", string2));
                Class class_ = method.getReturnType();
                if (class_ == Void.TYPE) {
                    return null;
                }
                return Context.jsToJava(null, class_);
            }
            if (!(object3 instanceof Callable)) {
                throw Context.reportRuntimeError1("msg.not.function.interface", string2);
            }
            callable = (Callable)object3;
        }
        WrapFactory wrapFactory = context.getWrapFactory();
        if (arrobject == null) {
            arrobject = ScriptRuntime.emptyArgs;
        } else {
            int n = arrobject.length;
            for (int i = 0; i != n; ++i) {
                Object object4 = arrobject[i];
                if (object4 instanceof String || object4 instanceof Number || object4 instanceof Boolean) continue;
                arrobject[i] = wrapFactory.wrap(context, scriptable, object4, null);
            }
        }
        Object object5 = callable.call(context, scriptable, wrapFactory.wrapAsJavaObject(context, scriptable, object2, null), arrobject);
        Class class_ = method.getReturnType();
        if (class_ == Void.TYPE) {
            return null;
        }
        return Context.jsToJava(object5, class_);
    }

}

