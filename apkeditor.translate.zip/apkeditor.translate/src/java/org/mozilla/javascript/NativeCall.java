/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Arguments;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.NativeFunction;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;

public final class NativeCall
extends IdScriptableObject {
    private static final Object CALL_TAG = "Call";
    private static final int Id_constructor = 1;
    private static final int MAX_PROTOTYPE_ID = 1;
    static final long serialVersionUID = -7471457301304454454L;
    NativeFunction function;
    Object[] originalArgs;
    transient NativeCall parentActivationCall;

    NativeCall() {
    }

    /*
     * Enabled aggressive block sorting
     */
    NativeCall(NativeFunction nativeFunction, Scriptable scriptable, Object[] arrobject) {
        this.function = nativeFunction;
        this.setParentScope(scriptable);
        Object[] arrobject2 = arrobject == null ? ScriptRuntime.emptyArgs : arrobject;
        this.originalArgs = arrobject2;
        int n = nativeFunction.getParamAndVarCount();
        int n2 = nativeFunction.getParamCount();
        if (n != 0) {
            for (int i = 0; i < n2; ++i) {
                String string2 = nativeFunction.getParamOrVarName(i);
                Object object = i < arrobject.length ? arrobject[i] : Undefined.instance;
                this.defineProperty(string2, object, 4);
            }
        }
        if (!super.has("arguments", this)) {
            this.defineProperty("arguments", new Arguments(this), 4);
        }
        if (n != 0) {
            for (int i = n2; i < n; ++i) {
                String string3 = nativeFunction.getParamOrVarName(i);
                if (super.has(string3, this)) continue;
                if (nativeFunction.getParamOrVarConst(i)) {
                    this.defineProperty(string3, Undefined.instance, 13);
                    continue;
                }
                this.defineProperty(string3, Undefined.instance, 4);
            }
        }
    }

    static void init(Scriptable scriptable, boolean bl) {
        new NativeCall().exportAsJSClass(1, scriptable, bl);
    }

    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(CALL_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        if (n == 1) {
            if (scriptable2 != null) {
                throw Context.reportRuntimeError1("msg.only.from.new", "Call");
            }
            ScriptRuntime.checkDeprecated(context, "Call");
            NativeCall nativeCall = new NativeCall();
            nativeCall.setPrototype(NativeCall.getObjectPrototype(scriptable));
            return nativeCall;
        }
        throw new IllegalArgumentException(String.valueOf((int)n));
    }

    @Override
    protected int findPrototypeId(String string2) {
        return string2.equals((Object)"constructor");
    }

    @Override
    public String getClassName() {
        return "Call";
    }

    @Override
    protected void initPrototypeId(int n) {
        if (n == 1) {
            this.initPrototypeMethod(CALL_TAG, n, "constructor", 1);
            return;
        }
        throw new IllegalArgumentException(String.valueOf((int)n));
    }
}

