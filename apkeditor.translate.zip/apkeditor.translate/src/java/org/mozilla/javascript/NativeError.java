/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 */
package org.mozilla.javascript;

import java.io.Serializable;
import java.lang.reflect.Method;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.EvaluatorException;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.NativeCallSite;
import org.mozilla.javascript.RhinoException;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.ScriptStackElement;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;

final class NativeError
extends IdScriptableObject {
    private static final int ConstructorId_captureStackTrace = -1;
    public static final int DEFAULT_STACK_LIMIT = -1;
    private static final Method ERROR_DELEGATE_GET_STACK;
    private static final Method ERROR_DELEGATE_SET_STACK;
    private static final Object ERROR_TAG;
    private static final int Id_constructor = 1;
    private static final int Id_toSource = 3;
    private static final int Id_toString = 2;
    private static final int MAX_PROTOTYPE_ID = 3;
    private static final String STACK_HIDE_KEY = "_stackHide";
    static final long serialVersionUID = -5338413581437645187L;
    private RhinoException stackProvider;

    static {
        ERROR_TAG = "Error";
        try {
            ERROR_DELEGATE_GET_STACK = NativeError.class.getMethod("getStackDelegated", new Class[]{Scriptable.class});
            ERROR_DELEGATE_SET_STACK = NativeError.class.getMethod("setStackDelegated", new Class[]{Scriptable.class, Object.class});
            return;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new RuntimeException((Throwable)noSuchMethodException);
        }
    }

    NativeError() {
    }

    private Object callPrepareStack(Function function, ScriptStackElement[] arrscriptStackElement) {
        Context context = Context.getCurrentContext();
        Object[] arrobject = new Object[arrscriptStackElement.length];
        for (int i = 0; i < arrscriptStackElement.length; ++i) {
            NativeCallSite nativeCallSite = (NativeCallSite)context.newObject(this, "CallSite");
            nativeCallSite.setElement(arrscriptStackElement[i]);
            arrobject[i] = nativeCallSite;
        }
        return function.call(context, function, this, new Object[]{this, context.newArray((Scriptable)this, arrobject)});
    }

    static void init(Scriptable scriptable, boolean bl) {
        NativeError nativeError = new NativeError();
        ScriptableObject.putProperty((Scriptable)nativeError, "name", (Object)"Error");
        ScriptableObject.putProperty((Scriptable)nativeError, "message", (Object)"");
        ScriptableObject.putProperty((Scriptable)nativeError, "fileName", (Object)"");
        ScriptableObject.putProperty((Scriptable)nativeError, "lineNumber", (Object)0);
        nativeError.setAttributes("name", 2);
        nativeError.setAttributes("message", 2);
        nativeError.exportAsJSClass(3, scriptable, bl);
        NativeCallSite.init(nativeError, bl);
    }

    private static void js_captureStackTrace(Context context, Scriptable scriptable, Object[] arrobject) {
        Object object;
        ScriptableObject scriptableObject = (ScriptableObject)ScriptRuntime.toObjectOrNull(context, arrobject[0], scriptable);
        int n = arrobject.length;
        Function function = null;
        if (n > 1) {
            function = (Function)ScriptRuntime.toObjectOrNull(context, arrobject[1], scriptable);
        }
        NativeError nativeError = (NativeError)context.newObject(scriptable, "Error");
        nativeError.setStackProvider(new EvaluatorException("[object Object]"));
        if (function != null && (object = function.get("name", (Scriptable)function)) != null && !Undefined.instance.equals(object)) {
            nativeError.associateValue(STACK_HIDE_KEY, Context.toString(object));
        }
        scriptableObject.defineProperty("stack", nativeError, ERROR_DELEGATE_GET_STACK, ERROR_DELEGATE_SET_STACK, 0);
    }

    private static String js_toSource(Context context, Scriptable scriptable, Scriptable scriptable2) {
        Object object = ScriptableObject.getProperty(scriptable2, "name");
        Object object2 = ScriptableObject.getProperty(scriptable2, "message");
        Object object3 = ScriptableObject.getProperty(scriptable2, "fileName");
        Object object4 = ScriptableObject.getProperty(scriptable2, "lineNumber");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("(new ");
        if (object == NOT_FOUND) {
            object = Undefined.instance;
        }
        stringBuilder.append(ScriptRuntime.toString(object));
        stringBuilder.append("(");
        if (object2 != NOT_FOUND || object3 != NOT_FOUND || object4 != NOT_FOUND) {
            if (object2 == NOT_FOUND) {
                object2 = "";
            }
            stringBuilder.append(ScriptRuntime.uneval(context, scriptable, object2));
            if (object3 != NOT_FOUND || object4 != NOT_FOUND) {
                int n;
                stringBuilder.append(", ");
                if (object3 == NOT_FOUND) {
                    object3 = "";
                }
                stringBuilder.append(ScriptRuntime.uneval(context, scriptable, object3));
                if (object4 != NOT_FOUND && (n = ScriptRuntime.toInt32(object4)) != 0) {
                    stringBuilder.append(", ");
                    stringBuilder.append(ScriptRuntime.toString(n));
                }
            }
        }
        stringBuilder.append("))");
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object js_toString(Scriptable scriptable) {
        Object object = ScriptableObject.getProperty(scriptable, "name");
        String string2 = object == NOT_FOUND || object == Undefined.instance ? "Error" : ScriptRuntime.toString(object);
        Object object2 = ScriptableObject.getProperty(scriptable, "message");
        String string3 = object2 == NOT_FOUND || object2 == Undefined.instance ? "" : ScriptRuntime.toString(object2);
        if (string2.toString().length() == 0) {
            return string3;
        }
        if (string3.toString().length() == 0) {
            return string2;
        }
        return string2 + ": " + string3;
    }

    static NativeError make(Context context, Scriptable scriptable, IdFunctionObject idFunctionObject, Object[] arrobject) {
        Scriptable scriptable2 = (Scriptable)idFunctionObject.get("prototype", idFunctionObject);
        NativeError nativeError = new NativeError();
        nativeError.setPrototype(scriptable2);
        nativeError.setParentScope(scriptable);
        int n = arrobject.length;
        if (n >= 1) {
            if (arrobject[0] != Undefined.instance) {
                ScriptableObject.putProperty((Scriptable)nativeError, "message", (Object)ScriptRuntime.toString(arrobject[0]));
            }
            if (n >= 2) {
                ScriptableObject.putProperty((Scriptable)nativeError, "fileName", arrobject[1]);
                if (n >= 3) {
                    ScriptableObject.putProperty((Scriptable)nativeError, "lineNumber", (Object)ScriptRuntime.toInt32(arrobject[2]));
                }
            }
        }
        return nativeError;
    }

    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(ERROR_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                return NativeError.make(context, scriptable, idFunctionObject, arrobject);
            }
            case 2: {
                return NativeError.js_toString(scriptable2);
            }
            case 3: {
                return NativeError.js_toSource(context, scriptable, scriptable2);
            }
            case -1: 
        }
        NativeError.js_captureStackTrace(context, scriptable2, arrobject);
        return Undefined.instance;
    }

    @Override
    protected void fillConstructorProperties(IdFunctionObject idFunctionObject) {
        this.addIdFunctionProperty(idFunctionObject, ERROR_TAG, -1, "captureStackTrace", 2);
        ProtoProps protoProps = new ProtoProps();
        this.associateValue("_ErrorPrototypeProps", protoProps);
        idFunctionObject.defineProperty("stackTraceLimit", protoProps, ProtoProps.GET_STACK_LIMIT, ProtoProps.SET_STACK_LIMIT, 0);
        idFunctionObject.defineProperty("prepareStackTrace", protoProps, ProtoProps.GET_PREPARE_STACK, ProtoProps.SET_PREPARE_STACK, 0);
        super.fillConstructorProperties(idFunctionObject);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        String string3;
        int n;
        int n2 = string2.length();
        if (n2 == 8) {
            char c = string2.charAt(3);
            if (c == 'o') {
                string3 = "toSource";
                n = 3;
            } else {
                string3 = null;
                n = 0;
                if (c == 't') {
                    string3 = "toString";
                    n = 2;
                }
            }
        } else {
            string3 = null;
            n = 0;
            if (n2 == 11) {
                string3 = "constructor";
                n = 1;
            }
        }
        if (string3 == null) return n;
        if (string3 == string2) return n;
        if (string3.equals((Object)string2)) return n;
        return 0;
    }

    @Override
    public String getClassName() {
        return "Error";
    }

    /*
     * Enabled aggressive block sorting
     */
    public Object getStackDelegated(Scriptable scriptable) {
        if (this.stackProvider == null) {
            return NOT_FOUND;
        }
        int n = -1;
        ProtoProps protoProps = (ProtoProps)((NativeError)this.getPrototype()).getAssociatedValue("_ErrorPrototypeProps");
        Function function = null;
        if (protoProps != null) {
            n = protoProps.getStackTraceLimit();
            function = protoProps.getPrepareStackTrace();
        }
        String string2 = (String)this.getAssociatedValue(STACK_HIDE_KEY);
        ScriptStackElement[] arrscriptStackElement = this.stackProvider.getScriptStack(n, string2);
        Object object = function == null ? RhinoException.formatStackTrace(arrscriptStackElement, this.stackProvider.details()) : this.callPrepareStack(function, arrscriptStackElement);
        this.setStackDelegated(scriptable, object);
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        int n2;
        String string2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 1;
                string2 = "constructor";
                break;
            }
            case 2: {
                string2 = "toString";
                n2 = 0;
                break;
            }
            case 3: {
                string2 = "toSource";
                n2 = 0;
            }
        }
        this.initPrototypeMethod(ERROR_TAG, n, string2, n2);
    }

    public void setStackDelegated(Scriptable scriptable, Object object) {
        scriptable.delete("stack");
        this.stackProvider = null;
        scriptable.put("stack", scriptable, object);
    }

    public void setStackProvider(RhinoException rhinoException) {
        if (this.stackProvider == null) {
            this.stackProvider = rhinoException;
            this.defineProperty("stack", this, ERROR_DELEGATE_GET_STACK, ERROR_DELEGATE_SET_STACK, 2);
        }
    }

    public String toString() {
        Object object = NativeError.js_toString(this);
        if (object instanceof String) {
            return (String)object;
        }
        return Object.super.toString();
    }

    private static final class ProtoProps
    implements Serializable {
        static final Method GET_PREPARE_STACK;
        static final Method GET_STACK_LIMIT;
        static final String KEY = "_ErrorPrototypeProps";
        static final Method SET_PREPARE_STACK;
        static final Method SET_STACK_LIMIT;
        private static final long serialVersionUID = 1907180507775337939L;
        private Function prepareStackTrace;
        private int stackTraceLimit = -1;

        static {
            try {
                GET_STACK_LIMIT = ProtoProps.class.getMethod("getStackTraceLimit", new Class[]{Scriptable.class});
                SET_STACK_LIMIT = ProtoProps.class.getMethod("setStackTraceLimit", new Class[]{Scriptable.class, Object.class});
                GET_PREPARE_STACK = ProtoProps.class.getMethod("getPrepareStackTrace", new Class[]{Scriptable.class});
                SET_PREPARE_STACK = ProtoProps.class.getMethod("setPrepareStackTrace", new Class[]{Scriptable.class, Object.class});
                return;
            }
            catch (NoSuchMethodException noSuchMethodException) {
                throw new RuntimeException((Throwable)noSuchMethodException);
            }
        }

        private ProtoProps() {
        }

        public Object getPrepareStackTrace(Scriptable scriptable) {
            Object object = this.getPrepareStackTrace();
            if (object == null) {
                object = Undefined.instance;
            }
            return object;
        }

        public Function getPrepareStackTrace() {
            return this.prepareStackTrace;
        }

        public int getStackTraceLimit() {
            return this.stackTraceLimit;
        }

        public Object getStackTraceLimit(Scriptable scriptable) {
            if (this.stackTraceLimit >= 0) {
                return this.stackTraceLimit;
            }
            return Double.POSITIVE_INFINITY;
        }

        /*
         * Enabled aggressive block sorting
         */
        public void setPrepareStackTrace(Scriptable scriptable, Object object) {
            if (object == null || Undefined.instance.equals(object)) {
                this.prepareStackTrace = null;
                return;
            } else {
                if (!(object instanceof Function)) return;
                {
                    this.prepareStackTrace = (Function)object;
                    return;
                }
            }
        }

        public void setStackTraceLimit(Scriptable scriptable, Object object) {
            double d = Context.toNumber(object);
            if (Double.isNaN((double)d) || Double.isInfinite((double)d)) {
                this.stackTraceLimit = -1;
                return;
            }
            this.stackTraceLimit = (int)d;
        }
    }

}

