/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.EvaluatorException;
import org.mozilla.javascript.Kit;

public class WrappedException
extends EvaluatorException {
    static final long serialVersionUID = -1551979216966520648L;
    private Throwable exception;

    public WrappedException(Throwable throwable) {
        super("Wrapped " + throwable.toString());
        this.exception = throwable;
        Kit.initCause(this, throwable);
        int[] arrn = new int[]{0};
        String string2 = Context.getSourcePositionFromStack(arrn);
        int n = arrn[0];
        if (string2 != null) {
            this.initSourceName(string2);
        }
        if (n != 0) {
            this.initLineNumber(n);
        }
    }

    public Throwable getWrappedException() {
        return this.exception;
    }

    @Deprecated
    public Object unwrap() {
        return this.getWrappedException();
    }
}

