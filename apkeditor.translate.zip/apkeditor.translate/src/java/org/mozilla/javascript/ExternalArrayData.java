/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.mozilla.javascript;

public interface ExternalArrayData {
    public Object getArrayElement(int var1);

    public int getArrayLength();

    public void setArrayElement(int var1, Object var2);
}

