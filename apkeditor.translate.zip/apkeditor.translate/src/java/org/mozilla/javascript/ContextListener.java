/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextFactory;

@Deprecated
public interface ContextListener
extends ContextFactory.Listener {
    @Deprecated
    public void contextEntered(Context var1);

    @Deprecated
    public void contextExited(Context var1);
}

