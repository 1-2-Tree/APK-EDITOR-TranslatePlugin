/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.InstantiationException
 *  java.lang.Long
 *  java.lang.NoSuchFieldException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Void
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Field
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.lang.reflect.Modifier
 *  java.security.CodeSource
 *  java.security.ProtectionDomain
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.HashSet
 *  java.util.Map
 */
package org.mozilla.javascript;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import org.mozilla.classfile.ClassFileWriter;
import org.mozilla.javascript.ClassCache;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextAction;
import org.mozilla.javascript.ContextFactory;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.GeneratedClassLoader;
import org.mozilla.javascript.IdFunctionCall;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.JavaMembers;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.MemberBox;
import org.mozilla.javascript.NativeJavaClass;
import org.mozilla.javascript.NativeJavaMethod;
import org.mozilla.javascript.NativeJavaObject;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.ObjToIntMap;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.SecurityController;
import org.mozilla.javascript.SecurityUtilities;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.WrapFactory;
import org.mozilla.javascript.Wrapper;

public final class JavaAdapter
implements IdFunctionCall {
    private static final Object FTAG = "JavaAdapter";
    private static final int Id_JavaAdapter = 1;

    static int appendMethodSignature(Class<?>[] arrclass, Class<?> class_, StringBuilder stringBuilder) {
        stringBuilder.append('(');
        int n = 1 + arrclass.length;
        for (Class<?> class_2 : arrclass) {
            JavaAdapter.appendTypeString(stringBuilder, class_2);
            if (class_2 != Long.TYPE && class_2 != Double.TYPE) continue;
            ++n;
        }
        stringBuilder.append(')');
        JavaAdapter.appendTypeString(stringBuilder, class_);
        return n;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void appendOverridableMethods(Class<?> class_, ArrayList<Method> arrayList, HashSet<String> hashSet) {
        Method[] arrmethod = class_.getDeclaredMethods();
        int n = 0;
        while (n < arrmethod.length) {
            int n2;
            String string2 = arrmethod[n].getName() + JavaAdapter.getMethodSignature(arrmethod[n], arrmethod[n].getParameterTypes());
            if (!hashSet.contains((Object)string2) && !Modifier.isStatic((int)(n2 = arrmethod[n].getModifiers()))) {
                if (Modifier.isFinal((int)n2)) {
                    hashSet.add((Object)string2);
                } else if (Modifier.isPublic((int)n2) || Modifier.isProtected((int)n2)) {
                    arrayList.add((Object)arrmethod[n]);
                    hashSet.add((Object)string2);
                }
            }
            ++n;
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static StringBuilder appendTypeString(StringBuilder stringBuilder, Class<?> class_) {
        while (class_.isArray()) {
            stringBuilder.append('[');
            class_ = class_.getComponentType();
        }
        if (!class_.isPrimitive()) {
            stringBuilder.append('L');
            stringBuilder.append(class_.getName().replace('.', '/'));
            stringBuilder.append(';');
            return stringBuilder;
        }
        int n = class_ == Boolean.TYPE ? 90 : (class_ == Long.TYPE ? 74 : (int)Character.toUpperCase((char)class_.getName().charAt(0)));
        stringBuilder.append((char)n);
        return stringBuilder;
    }

    public static Object callMethod(ContextFactory contextFactory, final Scriptable scriptable, final Function function, final Object[] arrobject, final long l) {
        if (function == null) {
            return null;
        }
        if (contextFactory == null) {
            contextFactory = ContextFactory.getGlobal();
        }
        final Scriptable scriptable2 = function.getParentScope();
        if (l == 0L) {
            return Context.call(contextFactory, function, scriptable2, scriptable, arrobject);
        }
        Context context = Context.getCurrentContext();
        if (context != null) {
            return JavaAdapter.doCall(context, scriptable2, scriptable, function, arrobject, l);
        }
        return contextFactory.call(new ContextAction(){

            @Override
            public Object run(Context context) {
                return JavaAdapter.doCall(context, scriptable2, scriptable, function, arrobject, l);
            }
        });
    }

    public static Object convertResult(Object object, Class<?> class_) {
        if (object == Undefined.instance && class_ != ScriptRuntime.ObjectClass && class_ != ScriptRuntime.StringClass) {
            return null;
        }
        return Context.jsToJava(object, class_);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static byte[] createAdapterCode(ObjToIntMap objToIntMap, String string2, Class<?> class_, Class<?>[] arrclass, String string3) {
        ClassFileWriter classFileWriter = new ClassFileWriter(string2, class_.getName(), "<adapter>");
        classFileWriter.addField("factory", "Lorg/mozilla/javascript/ContextFactory;", (short)17);
        classFileWriter.addField("delegee", "Lorg/mozilla/javascript/Scriptable;", (short)17);
        classFileWriter.addField("self", "Lorg/mozilla/javascript/Scriptable;", (short)17);
        int n = arrclass == null ? 0 : arrclass.length;
        for (int i = 0; i < n; ++i) {
            if (arrclass[i] == null) continue;
            classFileWriter.addInterface(arrclass[i].getName());
        }
        String string4 = class_.getName().replace('.', '/');
        for (Constructor constructor : class_.getDeclaredConstructors()) {
            int n2 = constructor.getModifiers();
            if (!Modifier.isPublic((int)n2) && !Modifier.isProtected((int)n2)) continue;
            JavaAdapter.generateCtor(classFileWriter, string2, string4, constructor);
        }
        JavaAdapter.generateSerialCtor(classFileWriter, string2, string4);
        if (string3 != null) {
            JavaAdapter.generateEmptyCtor(classFileWriter, string2, string4, string3);
        }
        ObjToIntMap objToIntMap2 = new ObjToIntMap();
        ObjToIntMap objToIntMap3 = new ObjToIntMap();
        int n3 = 0;
        do {
            int n4;
            Method[] arrmethod;
            if (n3 < n) {
                arrmethod = arrclass[n3].getMethods();
            } else {
                int n5;
                Method[] arrmethod2 = JavaAdapter.getOverridableMethods(class_);
                for (int i = 0; i < (n5 = arrmethod2.length); ++i) {
                    Method method = arrmethod2[i];
                    boolean bl = Modifier.isAbstract((int)method.getModifiers());
                    String string5 = method.getName();
                    if (!bl && !objToIntMap.has(string5)) continue;
                    Class[] arrclass2 = method.getParameterTypes();
                    String string6 = JavaAdapter.getMethodSignature(method, arrclass2);
                    String string7 = string5 + string6;
                    if (objToIntMap2.has(string7)) continue;
                    JavaAdapter.generateMethod(classFileWriter, string2, string5, arrclass2, method.getReturnType(), true);
                    objToIntMap2.put(string7, 0);
                    objToIntMap3.put(string5, 0);
                    if (bl) continue;
                    JavaAdapter.generateSuper(classFileWriter, string2, string4, string5, string6, arrclass2, method.getReturnType());
                }
                break;
            }
            for (int i = 0; i < (n4 = arrmethod.length); ++i) {
                Method method = arrmethod[i];
                int n6 = method.getModifiers();
                if (Modifier.isStatic((int)n6) || Modifier.isFinal((int)n6)) continue;
                String string8 = method.getName();
                Class[] arrclass3 = method.getParameterTypes();
                if (!objToIntMap.has(string8)) {
                    try {
                        class_.getMethod(string8, arrclass3);
                        continue;
                    }
                    catch (NoSuchMethodException noSuchMethodException) {
                        // empty catch block
                    }
                }
                String string9 = JavaAdapter.getMethodSignature(method, arrclass3);
                String string10 = string8 + string9;
                if (objToIntMap2.has(string10)) continue;
                JavaAdapter.generateMethod(classFileWriter, string2, string8, arrclass3, method.getReturnType(), true);
                objToIntMap2.put(string10, 0);
                objToIntMap3.put(string8, 0);
            }
            ++n3;
        } while (true);
        ObjToIntMap.Iterator iterator = new ObjToIntMap.Iterator(objToIntMap);
        iterator.start();
        while (!iterator.done()) {
            String string11 = (String)iterator.getKey();
            if (!objToIntMap3.has(string11)) {
                int n7 = iterator.getValue();
                Class[] arrclass4 = new Class[n7];
                for (int i = 0; i < n7; ++i) {
                    arrclass4[i] = ScriptRuntime.ObjectClass;
                }
                JavaAdapter.generateMethod(classFileWriter, string2, string11, arrclass4, ScriptRuntime.ObjectClass, false);
            }
            iterator.next();
        }
        return classFileWriter.toByteArray();
    }

    public static Scriptable createAdapterWrapper(Scriptable scriptable, Object object) {
        NativeJavaObject nativeJavaObject = new NativeJavaObject(ScriptableObject.getTopLevelScope(scriptable), object, null, true);
        nativeJavaObject.setPrototype(scriptable);
        return nativeJavaObject;
    }

    private static Object doCall(Context context, Scriptable scriptable, Scriptable scriptable2, Function function, Object[] arrobject, long l) {
        for (int i = 0; i != arrobject.length; ++i) {
            Object object;
            if (0L == (l & (long)(1 << i)) || (object = arrobject[i]) instanceof Scriptable) continue;
            arrobject[i] = context.getWrapFactory().wrap(context, scriptable, object, null);
        }
        return function.call(context, scriptable, scriptable2, arrobject);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void generateCtor(ClassFileWriter classFileWriter, String string2, String string3, Constructor<?> constructor) {
        short s = 3;
        Class[] arrclass = constructor.getParameterTypes();
        if (arrclass.length == 0) {
            classFileWriter.startMethod("<init>", "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/ContextFactory;)V", (short)1);
            classFileWriter.add(42);
            classFileWriter.addInvoke(183, string3, "<init>", "()V");
        } else {
            StringBuilder stringBuilder = new StringBuilder("(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/ContextFactory;");
            int n = stringBuilder.length();
            int n2 = arrclass.length;
            for (int i = 0; i < n2; ++i) {
                JavaAdapter.appendTypeString(stringBuilder, arrclass[i]);
            }
            stringBuilder.append(")V");
            classFileWriter.startMethod("<init>", stringBuilder.toString(), (short)1);
            classFileWriter.add(42);
            short s2 = 3;
            int n3 = arrclass.length;
            for (int i = 0; i < n3; ++i) {
                s2 = (short)(s2 + JavaAdapter.generatePushParam(classFileWriter, s2, arrclass[i]));
            }
            s = s2;
            stringBuilder.delete(1, n);
            classFileWriter.addInvoke(183, string3, "<init>", stringBuilder.toString());
        }
        classFileWriter.add(42);
        classFileWriter.add(43);
        classFileWriter.add(181, string2, "delegee", "Lorg/mozilla/javascript/Scriptable;");
        classFileWriter.add(42);
        classFileWriter.add(44);
        classFileWriter.add(181, string2, "factory", "Lorg/mozilla/javascript/ContextFactory;");
        classFileWriter.add(42);
        classFileWriter.add(43);
        classFileWriter.add(42);
        classFileWriter.addInvoke(184, "org/mozilla/javascript/JavaAdapter", "createAdapterWrapper", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
        classFileWriter.add(181, string2, "self", "Lorg/mozilla/javascript/Scriptable;");
        classFileWriter.add(177);
        classFileWriter.stopMethod(s);
    }

    private static void generateEmptyCtor(ClassFileWriter classFileWriter, String string2, String string3, String string4) {
        classFileWriter.startMethod("<init>", "()V", (short)1);
        classFileWriter.add(42);
        classFileWriter.addInvoke(183, string3, "<init>", "()V");
        classFileWriter.add(42);
        classFileWriter.add(1);
        classFileWriter.add(181, string2, "factory", "Lorg/mozilla/javascript/ContextFactory;");
        classFileWriter.add(187, string4);
        classFileWriter.add(89);
        classFileWriter.addInvoke(183, string4, "<init>", "()V");
        classFileWriter.addInvoke(184, "org/mozilla/javascript/JavaAdapter", "runScript", "(Lorg/mozilla/javascript/Script;)Lorg/mozilla/javascript/Scriptable;");
        classFileWriter.add(76);
        classFileWriter.add(42);
        classFileWriter.add(43);
        classFileWriter.add(181, string2, "delegee", "Lorg/mozilla/javascript/Scriptable;");
        classFileWriter.add(42);
        classFileWriter.add(43);
        classFileWriter.add(42);
        classFileWriter.addInvoke(184, "org/mozilla/javascript/JavaAdapter", "createAdapterWrapper", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
        classFileWriter.add(181, string2, "self", "Lorg/mozilla/javascript/Scriptable;");
        classFileWriter.add(177);
        classFileWriter.stopMethod((short)2);
    }

    private static void generateMethod(ClassFileWriter classFileWriter, String string2, String string3, Class<?>[] arrclass, Class<?> class_, boolean bl) {
        StringBuilder stringBuilder = new StringBuilder();
        int n = JavaAdapter.appendMethodSignature(arrclass, class_, stringBuilder);
        classFileWriter.startMethod(string3, stringBuilder.toString(), (short)1);
        classFileWriter.add(42);
        classFileWriter.add(180, string2, "factory", "Lorg/mozilla/javascript/ContextFactory;");
        classFileWriter.add(42);
        classFileWriter.add(180, string2, "self", "Lorg/mozilla/javascript/Scriptable;");
        classFileWriter.add(42);
        classFileWriter.add(180, string2, "delegee", "Lorg/mozilla/javascript/Scriptable;");
        classFileWriter.addPush(string3);
        classFileWriter.addInvoke(184, "org/mozilla/javascript/JavaAdapter", "getFunction", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Lorg/mozilla/javascript/Function;");
        JavaAdapter.generatePushWrappedArgs(classFileWriter, arrclass, arrclass.length);
        if (arrclass.length > 64) {
            throw Context.reportRuntimeError0("JavaAdapter can not subclass methods with more then 64 arguments.");
        }
        long l = 0L;
        for (int i = 0; i != arrclass.length; ++i) {
            if (arrclass[i].isPrimitive()) continue;
            l |= (long)(1 << i);
        }
        classFileWriter.addPush(l);
        classFileWriter.addInvoke(184, "org/mozilla/javascript/JavaAdapter", "callMethod", "(Lorg/mozilla/javascript/ContextFactory;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Function;[Ljava/lang/Object;J)Ljava/lang/Object;");
        JavaAdapter.generateReturnResult(classFileWriter, class_, bl);
        classFileWriter.stopMethod((short)n);
    }

    private static void generatePopResult(ClassFileWriter classFileWriter, Class<?> class_) {
        if (class_.isPrimitive()) {
            switch (class_.getName().charAt(0)) {
                default: {
                    return;
                }
                case 'b': 
                case 'c': 
                case 'i': 
                case 's': 
                case 'z': {
                    classFileWriter.add(172);
                    return;
                }
                case 'l': {
                    classFileWriter.add(173);
                    return;
                }
                case 'f': {
                    classFileWriter.add(174);
                    return;
                }
                case 'd': 
            }
            classFileWriter.add(175);
            return;
        }
        classFileWriter.add(176);
    }

    private static int generatePushParam(ClassFileWriter classFileWriter, int n, Class<?> class_) {
        if (!class_.isPrimitive()) {
            classFileWriter.addALoad(n);
            return 1;
        }
        switch (class_.getName().charAt(0)) {
            default: {
                throw Kit.codeBug();
            }
            case 'b': 
            case 'c': 
            case 'i': 
            case 's': 
            case 'z': {
                classFileWriter.addILoad(n);
                return 1;
            }
            case 'l': {
                classFileWriter.addLLoad(n);
                return 2;
            }
            case 'f': {
                classFileWriter.addFLoad(n);
                return 1;
            }
            case 'd': 
        }
        classFileWriter.addDLoad(n);
        return 2;
    }

    static void generatePushWrappedArgs(ClassFileWriter classFileWriter, Class<?>[] arrclass, int n) {
        classFileWriter.addPush(n);
        classFileWriter.add(189, "java/lang/Object");
        int n2 = 1;
        for (int i = 0; i != arrclass.length; ++i) {
            classFileWriter.add(89);
            classFileWriter.addPush(i);
            n2 += JavaAdapter.generateWrapArg(classFileWriter, n2, arrclass[i]);
            classFileWriter.add(83);
        }
    }

    static void generateReturnResult(ClassFileWriter classFileWriter, Class<?> class_, boolean bl) {
        if (class_ == Void.TYPE) {
            classFileWriter.add(87);
            classFileWriter.add(177);
            return;
        }
        if (class_ == Boolean.TYPE) {
            classFileWriter.addInvoke(184, "org/mozilla/javascript/Context", "toBoolean", "(Ljava/lang/Object;)Z");
            classFileWriter.add(172);
            return;
        }
        if (class_ == Character.TYPE) {
            classFileWriter.addInvoke(184, "org/mozilla/javascript/Context", "toString", "(Ljava/lang/Object;)Ljava/lang/String;");
            classFileWriter.add(3);
            classFileWriter.addInvoke(182, "java/lang/String", "charAt", "(I)C");
            classFileWriter.add(172);
            return;
        }
        if (class_.isPrimitive()) {
            classFileWriter.addInvoke(184, "org/mozilla/javascript/Context", "toNumber", "(Ljava/lang/Object;)D");
            switch (class_.getName().charAt(0)) {
                default: {
                    throw new RuntimeException("Unexpected return type " + class_.toString());
                }
                case 'b': 
                case 'i': 
                case 's': {
                    classFileWriter.add(142);
                    classFileWriter.add(172);
                    return;
                }
                case 'l': {
                    classFileWriter.add(143);
                    classFileWriter.add(173);
                    return;
                }
                case 'f': {
                    classFileWriter.add(144);
                    classFileWriter.add(174);
                    return;
                }
                case 'd': 
            }
            classFileWriter.add(175);
            return;
        }
        String string2 = class_.getName();
        if (bl) {
            classFileWriter.addLoadConstant(string2);
            classFileWriter.addInvoke(184, "java/lang/Class", "forName", "(Ljava/lang/String;)Ljava/lang/Class;");
            classFileWriter.addInvoke(184, "org/mozilla/javascript/JavaAdapter", "convertResult", "(Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;");
        }
        classFileWriter.add(192, string2);
        classFileWriter.add(176);
    }

    private static void generateSerialCtor(ClassFileWriter classFileWriter, String string2, String string3) {
        classFileWriter.startMethod("<init>", "(Lorg/mozilla/javascript/ContextFactory;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;)V", (short)1);
        classFileWriter.add(42);
        classFileWriter.addInvoke(183, string3, "<init>", "()V");
        classFileWriter.add(42);
        classFileWriter.add(43);
        classFileWriter.add(181, string2, "factory", "Lorg/mozilla/javascript/ContextFactory;");
        classFileWriter.add(42);
        classFileWriter.add(44);
        classFileWriter.add(181, string2, "delegee", "Lorg/mozilla/javascript/Scriptable;");
        classFileWriter.add(42);
        classFileWriter.add(45);
        classFileWriter.add(181, string2, "self", "Lorg/mozilla/javascript/Scriptable;");
        classFileWriter.add(177);
        classFileWriter.stopMethod((short)4);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void generateSuper(ClassFileWriter classFileWriter, String string2, String string3, String string4, String string5, Class<?>[] arrclass, Class<?> class_) {
        classFileWriter.startMethod("super$" + string4, string5, (short)1);
        classFileWriter.add(25, 0);
        int n = 1;
        int n2 = arrclass.length;
        for (int i = 0; i < n2; n += JavaAdapter.generatePushParam((ClassFileWriter)classFileWriter, (int)n, arrclass[i]), ++i) {
        }
        classFileWriter.addInvoke(183, string3, string4, string5);
        if (!class_.equals((Object)Void.TYPE)) {
            JavaAdapter.generatePopResult(classFileWriter, class_);
        } else {
            classFileWriter.add(177);
        }
        classFileWriter.stopMethod((short)(n + 1));
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int generateWrapArg(ClassFileWriter classFileWriter, int n, Class<?> class_) {
        int n2 = 1;
        if (!class_.isPrimitive()) {
            classFileWriter.add(25, n);
            return n2;
        }
        if (class_ == Boolean.TYPE) {
            classFileWriter.add(187, "java/lang/Boolean");
            classFileWriter.add(89);
            classFileWriter.add(21, n);
            classFileWriter.addInvoke(183, "java/lang/Boolean", "<init>", "(Z)V");
            return n2;
        }
        if (class_ == Character.TYPE) {
            classFileWriter.add(21, n);
            classFileWriter.addInvoke(184, "java/lang/String", "valueOf", "(C)Ljava/lang/String;");
            return n2;
        }
        classFileWriter.add(187, "java/lang/Double");
        classFileWriter.add(89);
        switch (class_.getName().charAt(0)) {
            case 'b': 
            case 'i': 
            case 's': {
                classFileWriter.add(21, n);
                classFileWriter.add(135);
                break;
            }
            case 'l': {
                classFileWriter.add(22, n);
                classFileWriter.add(138);
                n2 = 2;
                break;
            }
            case 'f': {
                classFileWriter.add(23, n);
                classFileWriter.add(141);
                break;
            }
            case 'd': {
                classFileWriter.add(24, n);
                n2 = 2;
                break;
            }
        }
        classFileWriter.addInvoke(183, "java/lang/Double", "<init>", "(D)V");
        return n2;
    }

    private static Class<?> getAdapterClass(Scriptable scriptable, Class<?> class_, Class<?>[] arrclass, Scriptable scriptable2) {
        JavaAdapterSignature javaAdapterSignature;
        ObjToIntMap objToIntMap;
        ClassCache classCache = ClassCache.get(scriptable);
        Map<JavaAdapterSignature, Class<?>> map = classCache.getInterfaceAdapterCacheMap();
        Class<?> class_2 = (Class<?>)map.get((Object)(javaAdapterSignature = new JavaAdapterSignature(class_, arrclass, objToIntMap = JavaAdapter.getObjectFunctionNames(scriptable2))));
        if (class_2 == null) {
            String string2 = "adapter" + classCache.newClassSerialNumber();
            class_2 = JavaAdapter.loadAdapterClass(string2, JavaAdapter.createAdapterCode(objToIntMap, string2, class_, arrclass, null));
            if (classCache.isCachingEnabled()) {
                map.put((Object)javaAdapterSignature, class_2);
            }
        }
        return class_2;
    }

    public static Object getAdapterSelf(Class<?> class_, Object object) throws NoSuchFieldException, IllegalAccessException {
        return class_.getDeclaredField("self").get(object);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static int[] getArgsToConvert(Class<?>[] arrclass) {
        int n = 0;
        for (int i = 0; i != arrclass.length; ++i) {
            if (arrclass[i].isPrimitive()) continue;
            ++n;
        }
        if (n == 0) {
            return null;
        }
        int[] arrn = new int[n];
        int n2 = 0;
        int n3 = 0;
        while (n3 != arrclass.length) {
            if (!arrclass[n3].isPrimitive()) {
                int n4 = n2 + 1;
                arrn[n2] = n3;
                n2 = n4;
            }
            ++n3;
        }
        return arrn;
    }

    public static Function getFunction(Scriptable scriptable, String string2) {
        Object object = ScriptableObject.getProperty(scriptable, string2);
        if (object == Scriptable.NOT_FOUND) {
            return null;
        }
        if (!(object instanceof Function)) {
            throw ScriptRuntime.notFunctionError(object, string2);
        }
        return (Function)object;
    }

    private static String getMethodSignature(Method method, Class<?>[] arrclass) {
        StringBuilder stringBuilder = new StringBuilder();
        JavaAdapter.appendMethodSignature(arrclass, method.getReturnType(), stringBuilder);
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    private static ObjToIntMap getObjectFunctionNames(Scriptable scriptable) {
        Object[] arrobject = ScriptableObject.getPropertyIds(scriptable);
        ObjToIntMap objToIntMap = new ObjToIntMap(arrobject.length);
        int n = 0;
        while (n != arrobject.length) {
            String string2;
            Object object;
            if (arrobject[n] instanceof String && (object = ScriptableObject.getProperty(scriptable, string2 = (String)arrobject[n])) instanceof Function) {
                int n2 = ScriptRuntime.toInt32(ScriptableObject.getProperty((Scriptable)((Function)object), "length"));
                if (n2 < 0) {
                    n2 = 0;
                }
                objToIntMap.put(string2, n2);
            }
            ++n;
        }
        return objToIntMap;
    }

    static Method[] getOverridableMethods(Class<?> class_) {
        ArrayList arrayList = new ArrayList();
        HashSet hashSet = new HashSet();
        for (Class class_2 = class_; class_2 != null; class_2 = class_2.getSuperclass()) {
            JavaAdapter.appendOverridableMethods(class_2, (ArrayList<Method>)arrayList, (HashSet<String>)hashSet);
        }
        for (Class class_3 = class_; class_3 != null; class_3 = class_3.getSuperclass()) {
            Class[] arrclass = class_3.getInterfaces();
            int n = arrclass.length;
            for (int i = 0; i < n; ++i) {
                JavaAdapter.appendOverridableMethods(arrclass[i], (ArrayList<Method>)arrayList, (HashSet<String>)hashSet);
            }
        }
        return (Method[])arrayList.toArray((Object[])new Method[arrayList.size()]);
    }

    public static void init(Context context, Scriptable scriptable, boolean bl) {
        IdFunctionObject idFunctionObject = new IdFunctionObject(new JavaAdapter(), FTAG, 1, "JavaAdapter", 1, scriptable);
        idFunctionObject.markAsConstructor(null);
        if (bl) {
            idFunctionObject.sealObject();
        }
        idFunctionObject.exportAsScopeProperty();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static Object js_createAdapter(Context var0, Scriptable var1_1, Object[] var2_2) {
        var3_3 = var2_2.length;
        if (var3_3 == 0) {
            throw ScriptRuntime.typeError0("msg.adapter.zero.args");
        }
        var4_4 = 0;
        do {
            if (var4_4 >= var3_3 - 1 || (var27_5 = var2_2[var4_4]) instanceof NativeObject) {
                var5_6 = null;
                var6_7 = new Class[var4_4];
                var8_9 = 0;
                break;
            }
            if (!(var27_5 instanceof NativeJavaClass)) {
                throw ScriptRuntime.typeError2("msg.not.java.class.arg", String.valueOf((int)var4_4), ScriptRuntime.toString(var27_5));
            }
            ++var4_4;
        } while (true);
        for (var7_8 = 0; var7_8 < var4_4; ++var7_8) {
            var25_10 = ((NativeJavaClass)var2_2[var7_8]).getClassObject();
            if (!var25_10.isInterface()) {
                if (var5_6 != null) {
                    throw ScriptRuntime.typeError2("msg.only.one.super", var5_6.getName(), var25_10.getName());
                }
                var5_6 = var25_10;
                var26_11 = var8_9;
            } else {
                var26_11 = var8_9 + 1;
                var6_7[var8_9] = var25_10;
            }
            var8_9 = var26_11;
        }
        if (var5_6 == null) {
            var5_6 = ScriptRuntime.ObjectClass;
        }
        var9_12 = new Class[var8_9];
        System.arraycopy((Object)var6_7, (int)0, (Object)var9_12, (int)0, (int)var8_9);
        var10_13 = ScriptableObject.ensureScriptable(var2_2[var4_4]);
        var11_14 = JavaAdapter.getAdapterClass(var1_1, var5_6, var9_12, var10_13);
        var12_15 = -1 + (var3_3 - var4_4);
        if (var12_15 > 0) {
            var20_16 = var12_15 + 2;
            try {
                var21_17 = new Object[var20_16];
                var21_17[0] = var10_13;
                var21_17[1] = var0.getFactory();
                System.arraycopy((Object)var2_2, (int)(var4_4 + 1), (Object)var21_17, (int)2, (int)var12_15);
                var22_18 = new NativeJavaClass((Scriptable)var1_1, var11_14, (boolean)true).members.ctors;
                var23_19 = var22_18.findCachedFunction(var0, var21_17);
                if (var23_19 < 0) {
                    var24_20 = NativeJavaMethod.scriptSignature(var2_2);
                    throw Context.reportRuntimeError2("msg.no.java.ctor", var11_14.getName(), var24_20);
                }
                var16_22 = NativeJavaClass.constructInternal(var21_17, var22_18.methods[var23_19]);
            }
            catch (Exception var19_21) {
                throw Context.throwAsScriptRuntimeEx(var19_21);
            }
lbl50: // 2 sources:
            do {
                var17_23 = JavaAdapter.getAdapterSelf(var11_14, var16_22);
                if (var17_23 instanceof Wrapper == false) return var17_23;
                var18_24 = ((Wrapper)var17_23).unwrap();
                if (var18_24 instanceof Scriptable == false) return var17_23;
                if (var18_24 instanceof ScriptableObject == false) return var18_24;
                ScriptRuntime.setObjectProtoAndParent((ScriptableObject)var18_24, var1_1);
                return var18_24;
                break;
            } while (true);
        }
        var13_25 = new Class[]{ScriptRuntime.ScriptableClass, ScriptRuntime.ContextFactoryClass};
        var14_26 = new Object[]{var10_13, var0.getFactory()};
        var16_22 = var15_27 = var11_14.getConstructor(var13_25).newInstance(var14_26);
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     */
    static Class<?> loadAdapterClass(String string2, byte[] arrby) {
        Object object;
        Class<?> class_ = SecurityController.getStaticSecurityDomainClass();
        if (class_ == CodeSource.class || class_ == ProtectionDomain.class) {
            ProtectionDomain protectionDomain = SecurityUtilities.getScriptProtectionDomain();
            if (protectionDomain == null) {
                protectionDomain = JavaAdapter.class.getProtectionDomain();
            }
            object = class_ == CodeSource.class ? (protectionDomain == null ? null : protectionDomain.getCodeSource()) : protectionDomain;
        } else {
            object = null;
        }
        GeneratedClassLoader generatedClassLoader = SecurityController.createLoader(null, object);
        Class<?> class_2 = generatedClassLoader.defineClass(string2, arrby);
        generatedClassLoader.linkClass(class_2);
        return class_2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Object readAdapterObject(Scriptable scriptable, ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        Context context = Context.getCurrentContext();
        ContextFactory contextFactory = context != null ? context.getFactory() : null;
        Class class_ = Class.forName((String)((String)objectInputStream.readObject()));
        String[] arrstring = (String[])objectInputStream.readObject();
        Class[] arrclass = new Class[arrstring.length];
        for (int i = 0; i < arrstring.length; ++i) {
            arrclass[i] = Class.forName((String)arrstring[i]);
        }
        Scriptable scriptable2 = (Scriptable)objectInputStream.readObject();
        Class<?> class_2 = JavaAdapter.getAdapterClass(scriptable, class_, arrclass, scriptable2);
        Class[] arrclass2 = new Class[]{ScriptRuntime.ContextFactoryClass, ScriptRuntime.ScriptableClass, ScriptRuntime.ScriptableClass};
        Object[] arrobject = new Object[]{contextFactory, scriptable2, scriptable};
        try {
            return class_2.getConstructor(arrclass2).newInstance(arrobject);
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new ClassNotFoundException("adapter");
        }
        catch (InvocationTargetException invocationTargetException) {
            throw new ClassNotFoundException("adapter");
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new ClassNotFoundException("adapter");
        }
        catch (InstantiationException instantiationException) {
            throw new ClassNotFoundException("adapter");
        }
    }

    public static Scriptable runScript(final Script script) {
        return (Scriptable)ContextFactory.getGlobal().call(new ContextAction(){

            @Override
            public Object run(Context context) {
                ScriptableObject scriptableObject = ScriptRuntime.getGlobal(context);
                script.exec(context, scriptableObject);
                return scriptableObject;
            }
        });
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void writeAdapterObject(Object object, ObjectOutputStream objectOutputStream) throws IOException {
        Class class_ = object.getClass();
        objectOutputStream.writeObject((Object)class_.getSuperclass().getName());
        Class[] arrclass = class_.getInterfaces();
        String[] arrstring = new String[arrclass.length];
        for (int i = 0; i < arrclass.length; ++i) {
            arrstring[i] = arrclass[i].getName();
        }
        objectOutputStream.writeObject((Object)arrstring);
        try {
            objectOutputStream.writeObject(class_.getField("delegee").get(object));
            return;
        }
        catch (NoSuchFieldException noSuchFieldException) {
            do {
                throw new IOException();
                break;
            } while (true);
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new IOException();
        }
    }

    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (idFunctionObject.hasTag(FTAG) && idFunctionObject.methodId() == 1) {
            return JavaAdapter.js_createAdapter(context, scriptable, arrobject);
        }
        throw idFunctionObject.unknown();
    }

    static class JavaAdapterSignature {
        Class<?>[] interfaces;
        ObjToIntMap names;
        Class<?> superClass;

        JavaAdapterSignature(Class<?> class_, Class<?>[] arrclass, ObjToIntMap objToIntMap) {
            this.superClass = class_;
            this.interfaces = arrclass;
            this.names = objToIntMap;
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean equals(Object object) {
            if (!(object instanceof JavaAdapterSignature)) return false;
            JavaAdapterSignature javaAdapterSignature = (JavaAdapterSignature)object;
            if (this.superClass != javaAdapterSignature.superClass) return false;
            if (this.interfaces != javaAdapterSignature.interfaces) {
                if (this.interfaces.length != javaAdapterSignature.interfaces.length) return false;
                for (int i = 0; i < this.interfaces.length; ++i) {
                    if (this.interfaces[i] != javaAdapterSignature.interfaces[i]) return false;
                    {
                        continue;
                    }
                }
            }
            if (this.names.size() != javaAdapterSignature.names.size()) return false;
            ObjToIntMap.Iterator iterator = new ObjToIntMap.Iterator(this.names);
            iterator.start();
            while (!iterator.done()) {
                String string2 = (String)iterator.getKey();
                int n = iterator.getValue();
                if (n != javaAdapterSignature.names.get(string2, n + 1)) {
                    return false;
                }
                iterator.next();
            }
            return true;
        }

        public int hashCode() {
            return this.superClass.hashCode() + Arrays.hashCode((Object[])this.interfaces) ^ this.names.size();
        }
    }

}

