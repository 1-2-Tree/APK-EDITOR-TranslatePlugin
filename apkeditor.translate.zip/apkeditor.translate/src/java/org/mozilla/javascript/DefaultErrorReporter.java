/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript;

import org.mozilla.javascript.ErrorReporter;
import org.mozilla.javascript.EvaluatorException;
import org.mozilla.javascript.ScriptRuntime;

class DefaultErrorReporter
implements ErrorReporter {
    static final DefaultErrorReporter instance = new DefaultErrorReporter();
    private ErrorReporter chainedReporter;
    private boolean forEval;

    private DefaultErrorReporter() {
    }

    static ErrorReporter forEval(ErrorReporter errorReporter) {
        DefaultErrorReporter defaultErrorReporter = new DefaultErrorReporter();
        defaultErrorReporter.forEval = true;
        defaultErrorReporter.chainedReporter = errorReporter;
        return defaultErrorReporter;
    }

    @Override
    public void error(String string2, String string3, int n, String string4, int n2) {
        if (this.forEval) {
            String string5 = "SyntaxError";
            if (string2.startsWith("TypeError: ")) {
                string5 = "TypeError";
                string2 = string2.substring("TypeError: ".length());
            }
            throw ScriptRuntime.constructError(string5, string2, string3, n, string4, n2);
        }
        if (this.chainedReporter != null) {
            this.chainedReporter.error(string2, string3, n, string4, n2);
            return;
        }
        throw this.runtimeError(string2, string3, n, string4, n2);
    }

    @Override
    public EvaluatorException runtimeError(String string2, String string3, int n, String string4, int n2) {
        if (this.chainedReporter != null) {
            return this.chainedReporter.runtimeError(string2, string3, n, string4, n2);
        }
        return new EvaluatorException(string2, string3, n, string4, n2);
    }

    @Override
    public void warning(String string2, String string3, int n, String string4, int n2) {
        if (this.chainedReporter != null) {
            this.chainedReporter.warning(string2, string3, n, string4, n2);
        }
    }
}

