/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.IdFunctionCall;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.NativeJavaPackage;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Wrapper;

public class NativeJavaTopPackage
extends NativeJavaPackage
implements Function,
IdFunctionCall {
    private static final Object FTAG;
    private static final int Id_getClass = 1;
    private static final String[][] commonPackages;
    static final long serialVersionUID = -1455787259477709999L;

    static {
        commonPackages = new String[][]{{"java", "lang", "reflect"}, {"java", "io"}, {"java", "math"}, {"java", "net"}, {"java", "util", "zip"}, {"java", "text", "resources"}, {"java", "applet"}, {"javax", "swing"}};
        FTAG = "JavaTopPackage";
    }

    NativeJavaTopPackage(ClassLoader classLoader) {
        super(true, "", classLoader);
    }

    public static void init(Context context, Scriptable scriptable, boolean bl) {
        NativeJavaTopPackage nativeJavaTopPackage = new NativeJavaTopPackage(context.getApplicationClassLoader());
        nativeJavaTopPackage.setPrototype(NativeJavaTopPackage.getObjectPrototype(scriptable));
        nativeJavaTopPackage.setParentScope(scriptable);
        for (int i = 0; i != commonPackages.length; ++i) {
            NativeJavaPackage nativeJavaPackage = nativeJavaTopPackage;
            for (int j = 0; j != commonPackages[i].length; ++j) {
                nativeJavaPackage = nativeJavaPackage.forcePackage(commonPackages[i][j], scriptable);
            }
        }
        IdFunctionObject idFunctionObject = new IdFunctionObject(nativeJavaTopPackage, FTAG, 1, "getClass", 1, scriptable);
        String[] arrstring = ScriptRuntime.getTopPackageNames();
        NativeJavaPackage[] arrnativeJavaPackage = new NativeJavaPackage[arrstring.length];
        for (int i = 0; i < arrstring.length; ++i) {
            arrnativeJavaPackage[i] = (NativeJavaPackage)nativeJavaTopPackage.get(arrstring[i], (Scriptable)nativeJavaTopPackage);
        }
        ScriptableObject scriptableObject = (ScriptableObject)scriptable;
        if (bl) {
            idFunctionObject.sealObject();
        }
        idFunctionObject.exportAsScopeProperty();
        scriptableObject.defineProperty("Packages", nativeJavaTopPackage, 2);
        for (int i = 0; i < arrstring.length; ++i) {
            scriptableObject.defineProperty(arrstring[i], arrnativeJavaPackage[i], 2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private Scriptable js_getClass(Context context, Scriptable scriptable, Object[] arrobject) {
        if (arrobject.length > 0 && arrobject[0] instanceof Wrapper) {
            Object object;
            String string2;
            int n;
            void var4_5;
            NativeJavaTopPackage nativeJavaTopPackage = this;
            String string3 = ((Wrapper)arrobject[0]).unwrap().getClass().getName();
            int n2 = 0;
            while ((object = var4_5.get(string2 = (n = string3.indexOf(46, n2)) == -1 ? string3.substring(n2) : string3.substring(n2, n), (Scriptable)var4_5)) instanceof Scriptable) {
                Scriptable scriptable2 = (Scriptable)object;
                if (n == -1) {
                    return scriptable2;
                }
                n2 = n + 1;
            }
        }
        throw Context.reportRuntimeError0("msg.not.java.obj");
    }

    @Override
    public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        return this.construct(context, scriptable, arrobject);
    }

    @Override
    public Scriptable construct(Context context, Scriptable scriptable, Object[] arrobject) {
        int n = arrobject.length;
        ClassLoader classLoader = null;
        if (n != 0) {
            Object object = arrobject[0];
            if (object instanceof Wrapper) {
                object = ((Wrapper)object).unwrap();
            }
            boolean bl = object instanceof ClassLoader;
            classLoader = null;
            if (bl) {
                classLoader = (ClassLoader)object;
            }
        }
        if (classLoader == null) {
            Context.reportRuntimeError0("msg.not.classloader");
            return null;
        }
        NativeJavaPackage nativeJavaPackage = new NativeJavaPackage(true, "", classLoader);
        ScriptRuntime.setObjectProtoAndParent(nativeJavaPackage, scriptable);
        return nativeJavaPackage;
    }

    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (idFunctionObject.hasTag(FTAG) && idFunctionObject.methodId() == 1) {
            return this.js_getClass(context, scriptable, arrobject);
        }
        throw idFunctionObject.unknown();
    }
}

