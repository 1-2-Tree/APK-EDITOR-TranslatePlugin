/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 */
package org.mozilla.javascript.json;

import java.util.ArrayList;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;

public class JsonParser {
    static final /* synthetic */ boolean $assertionsDisabled;
    private Context cx;
    private int length;
    private int pos;
    private Scriptable scope;
    private String src;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !JsonParser.class.desiredAssertionStatus();
        $assertionsDisabled = bl;
    }

    public JsonParser(Context context, Scriptable scriptable) {
        this.cx = context;
        this.scope = scriptable;
    }

    private void consume(char c) throws ParseException {
        this.consumeWhitespace();
        if (this.pos >= this.length) {
            throw new ParseException("Expected " + c + " but reached end of stream");
        }
        String string2 = this.src;
        int n = this.pos;
        this.pos = n + 1;
        char c2 = string2.charAt(n);
        if (c2 == c) {
            return;
        }
        throw new ParseException("Expected " + c + " found " + c2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void consumeWhitespace() {
        while (this.pos < this.length) {
            switch (this.src.charAt(this.pos)) {
                default: {
                    return;
                }
                case '\t': 
                case '\n': 
                case '\r': 
                case ' ': 
            }
            this.pos = 1 + this.pos;
        }
    }

    private int fromHex(char c) {
        if (c >= '0' && c <= '9') {
            return c - 48;
        }
        if (c >= 'A' && c <= 'F') {
            return 10 + (c - 65);
        }
        if (c >= 'a' && c <= 'f') {
            return 10 + (c - 97);
        }
        return -1;
    }

    private char nextOrNumberError(int n) throws ParseException {
        if (this.pos >= this.length) {
            throw this.numberError(n, this.length);
        }
        String string2 = this.src;
        int n2 = this.pos;
        this.pos = n2 + 1;
        return string2.charAt(n2);
    }

    private ParseException numberError(int n, int n2) {
        return new ParseException("Unsupported number format: " + this.src.substring(n, n2));
    }

    /*
     * Enabled aggressive block sorting
     */
    private Object readArray() throws ParseException {
        this.consumeWhitespace();
        if (this.pos < this.length && this.src.charAt(this.pos) == ']') {
            this.pos = 1 + this.pos;
            return this.cx.newArray(this.scope, 0);
        }
        ArrayList arrayList = new ArrayList();
        boolean bl = false;
        do {
            block9 : {
                if (this.pos >= this.length) {
                    throw new ParseException("Unterminated array literal");
                }
                switch (this.src.charAt(this.pos)) {
                    default: {
                        if (!bl) break;
                        throw new ParseException("Missing comma in array literal");
                    }
                    case ']': {
                        if (!bl) {
                            throw new ParseException("Unexpected comma in array literal");
                        }
                        this.pos = 1 + this.pos;
                        return this.cx.newArray(this.scope, arrayList.toArray());
                    }
                    case ',': {
                        if (!bl) {
                            throw new ParseException("Unexpected comma in array literal");
                        }
                        bl = false;
                        this.pos = 1 + this.pos;
                        break block9;
                    }
                }
                arrayList.add(this.readValue());
                bl = true;
            }
            this.consumeWhitespace();
        } while (true);
    }

    private void readDigits() {
        char c;
        while (this.pos < this.length && (c = this.src.charAt(this.pos)) >= '0' && c <= '9') {
            this.pos = 1 + this.pos;
        }
        return;
    }

    private Boolean readFalse() throws ParseException {
        if (this.length - this.pos < 4 || this.src.charAt(this.pos) != 'a' || this.src.charAt(1 + this.pos) != 'l' || this.src.charAt(2 + this.pos) != 's' || this.src.charAt(3 + this.pos) != 'e') {
            throw new ParseException("Unexpected token: f");
        }
        this.pos = 4 + this.pos;
        return Boolean.FALSE;
    }

    private Object readNull() throws ParseException {
        if (this.length - this.pos < 3 || this.src.charAt(this.pos) != 'u' || this.src.charAt(1 + this.pos) != 'l' || this.src.charAt(2 + this.pos) != 'l') {
            throw new ParseException("Unexpected token: n");
        }
        this.pos = 3 + this.pos;
        return null;
    }

    private Number readNumber(char c) throws ParseException {
        int n;
        double d;
        char c2;
        if (!($assertionsDisabled || c == '-' || c >= '0' && c <= '9')) {
            throw new AssertionError();
        }
        int n2 = -1 + this.pos;
        if (c == '-' && ((c = this.nextOrNumberError(n2)) < '0' || c > '9')) {
            throw this.numberError(n2, this.pos);
        }
        if (c != '0') {
            this.readDigits();
        }
        if (this.pos < this.length && this.src.charAt(this.pos) == '.') {
            this.pos = 1 + this.pos;
            char c3 = this.nextOrNumberError(n2);
            if (c3 < '0' || c3 > '9') {
                throw this.numberError(n2, this.pos);
            }
            this.readDigits();
        }
        if (this.pos < this.length && ((c2 = this.src.charAt(this.pos)) == 'e' || c2 == 'E')) {
            this.pos = 1 + this.pos;
            char c4 = this.nextOrNumberError(n2);
            if (c4 == '-' || c4 == '+') {
                c4 = this.nextOrNumberError(n2);
            }
            if (c4 < '0' || c4 > '9') {
                throw this.numberError(n2, this.pos);
            }
            this.readDigits();
        }
        if ((double)(n = (int)(d = Double.parseDouble((String)this.src.substring(n2, this.pos)))) == d) {
            return n;
        }
        return d;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private Object readObject() throws ParseException {
        this.consumeWhitespace();
        Scriptable scriptable = this.cx.newObject(this.scope);
        if (this.pos < this.length && this.src.charAt(this.pos) == '}') {
            this.pos = 1 + this.pos;
            return scriptable;
        }
        boolean bl = false;
        while (this.pos < this.length) {
            String string2 = this.src;
            int n = this.pos;
            this.pos = n + 1;
            switch (string2.charAt(n)) {
                default: {
                    throw new ParseException("Unexpected token in object literal");
                }
                case '}': {
                    if (bl) return scriptable;
                    throw new ParseException("Unexpected comma in object literal");
                }
                case ',': {
                    if (!bl) {
                        throw new ParseException("Unexpected comma in object literal");
                    }
                    bl = false;
                    break;
                }
                case '\"': {
                    if (bl) {
                        throw new ParseException("Missing comma in object literal");
                    }
                    String string3 = this.readString();
                    this.consume(':');
                    Object object = this.readValue();
                    long l = ScriptRuntime.indexFromString(string3);
                    if (l < 0L) {
                        scriptable.put(string3, scriptable, object);
                    } else {
                        scriptable.put((int)l, scriptable, object);
                    }
                    bl = true;
                }
            }
            this.consumeWhitespace();
        }
        throw new ParseException("Unterminated object literal");
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private String readString() throws ParseException {
        block21 : {
            var1_1 = this.pos;
            do {
                if (this.pos < this.length) {
                    var21_2 = this.src;
                    var22_3 = this.pos;
                    this.pos = var22_3 + 1;
                    var23_4 = var21_2.charAt(var22_3);
                    if (var23_4 <= '\u001f') {
                        throw new ParseException("String contains control character");
                    }
                    if (var23_4 != '\\') continue;
                }
                var2_5 = new StringBuilder();
lbl12: // 3 sources:
                while (this.pos < this.length) {
                    if (!JsonParser.$assertionsDisabled && this.src.charAt(-1 + this.pos) != '\\') {
                        throw new AssertionError();
                    }
                    break block21;
                }
                throw new ParseException("Unterminated string literal");
            } while (var23_4 != '\"');
            return this.src.substring(var1_1, -1 + this.pos);
        }
        var2_5.append((CharSequence)this.src, var1_1, -1 + this.pos);
        if (this.pos >= this.length) {
            throw new ParseException("Unterminated string");
        }
        var4_6 = this.src;
        var5_7 = this.pos;
        this.pos = var5_7 + 1;
        var6_8 = var4_6.charAt(var5_7);
        block0 : switch (var6_8) {
            default: {
                throw new ParseException("Unexpected character in string: '\\" + var6_8 + "'");
            }
            case '\"': {
                var2_5.append('\"');
lbl32: // 9 sources:
                do {
                    var1_1 = this.pos;
lbl34: // 2 sources:
                    while (this.pos < this.length) {
                        var9_10 = this.src;
                        var10_11 = this.pos;
                        this.pos = var10_11 + 1;
                        var11_12 = var9_10.charAt(var10_11);
                        if (var11_12 > '\u001f') break block0;
                        throw new ParseException("String contains control character");
                    }
                    ** GOTO lbl12
                    break;
                } while (true);
            }
            case '\\': {
                var2_5.append('\\');
                ** GOTO lbl32
            }
            case '/': {
                var2_5.append('/');
                ** GOTO lbl32
            }
            case 'b': {
                var2_5.append('\b');
                ** GOTO lbl32
            }
            case 'f': {
                var2_5.append('\f');
                ** GOTO lbl32
            }
            case 'n': {
                var2_5.append('\n');
                ** GOTO lbl32
            }
            case 'r': {
                var2_5.append('\r');
                ** GOTO lbl32
            }
            case 't': {
                var2_5.append('\t');
                ** GOTO lbl32
            }
            case 'u': {
                if (this.length - this.pos < 5) {
                    throw new ParseException("Invalid character code: \\u" + this.src.substring(this.pos));
                }
                var7_9 = this.fromHex(this.src.charAt(0 + this.pos)) << 12 | this.fromHex(this.src.charAt(1 + this.pos)) << 8 | this.fromHex(this.src.charAt(2 + this.pos)) << 4 | this.fromHex(this.src.charAt(3 + this.pos));
                if (var7_9 < 0) {
                    throw new ParseException("Invalid character code: " + this.src.substring(this.pos, 4 + this.pos));
                }
                this.pos = 4 + this.pos;
                var2_5.append((char)var7_9);
                ** continue;
            }
        }
        if (var11_12 == '\\') ** GOTO lbl12
        if (var11_12 != '\"') ** GOTO lbl34
        var2_5.append((CharSequence)this.src, var1_1, -1 + this.pos);
        return var2_5.toString();
    }

    private Boolean readTrue() throws ParseException {
        if (this.length - this.pos < 3 || this.src.charAt(this.pos) != 'r' || this.src.charAt(1 + this.pos) != 'u' || this.src.charAt(2 + this.pos) != 'e') {
            throw new ParseException("Unexpected token: t");
        }
        this.pos = 3 + this.pos;
        return Boolean.TRUE;
    }

    private Object readValue() throws ParseException {
        this.consumeWhitespace();
        if (this.pos < this.length) {
            String string2 = this.src;
            int n = this.pos;
            this.pos = n + 1;
            char c = string2.charAt(n);
            switch (c) {
                default: {
                    throw new ParseException("Unexpected token: " + c);
                }
                case '{': {
                    return this.readObject();
                }
                case '[': {
                    return this.readArray();
                }
                case 't': {
                    return this.readTrue();
                }
                case 'f': {
                    return this.readFalse();
                }
                case '\"': {
                    return this.readString();
                }
                case 'n': {
                    return this.readNull();
                }
                case '-': 
                case '0': 
                case '1': 
                case '2': 
                case '3': 
                case '4': 
                case '5': 
                case '6': 
                case '7': 
                case '8': 
                case '9': 
            }
            return this.readNumber(c);
        }
        throw new ParseException("Empty JSON string");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Object parseValue(String string2) throws ParseException {
        JsonParser jsonParser = this;
        synchronized (jsonParser) {
            if (string2 == null) {
                throw new ParseException("Input string may not be null");
            }
            this.pos = 0;
            this.length = string2.length();
            this.src = string2;
            Object object = this.readValue();
            this.consumeWhitespace();
            if (this.pos < this.length) {
                throw new ParseException("Expected end of stream at char " + this.pos);
            }
            return object;
        }
    }

    public static class ParseException
    extends Exception {
        static final long serialVersionUID = 4804542791749920772L;

        ParseException(Exception exception) {
            super((Throwable)exception);
        }

        ParseException(String string2) {
            super(string2);
        }
    }

}

