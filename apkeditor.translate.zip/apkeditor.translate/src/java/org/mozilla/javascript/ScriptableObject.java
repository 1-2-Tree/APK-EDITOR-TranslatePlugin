/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.Serializable
 *  java.lang.AssertionError
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.InstantiationException
 *  java.lang.Integer
 *  java.lang.NoSuchMethodException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.AccessibleObject
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Member
 *  java.lang.reflect.Method
 *  java.lang.reflect.Modifier
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Map
 */
package org.mozilla.javascript;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.ConstProperties;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ExternalArrayData;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.FunctionObject;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.LazilyLoadedCtor;
import org.mozilla.javascript.MemberBox;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.ObjToIntMap;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.TopLevel;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.Wrapper;
import org.mozilla.javascript.annotations.JSConstructor;
import org.mozilla.javascript.annotations.JSFunction;
import org.mozilla.javascript.annotations.JSGetter;
import org.mozilla.javascript.annotations.JSSetter;
import org.mozilla.javascript.annotations.JSStaticFunction;
import org.mozilla.javascript.debug.DebuggableObject;

public abstract class ScriptableObject
implements Scriptable,
Serializable,
DebuggableObject,
ConstProperties {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    public static final int CONST = 13;
    public static final int DONTENUM = 2;
    public static final int EMPTY = 0;
    private static final Method GET_ARRAY_LENGTH;
    private static final int INITIAL_SLOT_SIZE = 4;
    public static final int PERMANENT = 4;
    public static final int READONLY = 1;
    private static final int SLOT_CONVERT_ACCESSOR_TO_DATA = 5;
    private static final int SLOT_MODIFY = 2;
    private static final int SLOT_MODIFY_CONST = 3;
    private static final int SLOT_MODIFY_GETTER_SETTER = 4;
    private static final int SLOT_QUERY = 1;
    public static final int UNINITIALIZED_CONST = 8;
    static final long serialVersionUID = 2829861078851942586L;
    private volatile Map<Object, Object> associatedValues;
    private int count;
    private transient ExternalArrayData externalData;
    private transient Slot firstAdded;
    private boolean isExtensible = true;
    private transient Slot lastAdded;
    private Scriptable parentScopeObject;
    private Scriptable prototypeObject;
    private transient Slot[] slots;

    static {
        boolean bl = ScriptableObject.class.desiredAssertionStatus();
        boolean bl2 = false;
        if (!bl) {
            bl2 = true;
        }
        $assertionsDisabled = bl2;
        try {
            GET_ARRAY_LENGTH = ScriptableObject.class.getMethod("getExternalArrayLength", new Class[0]);
            return;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new RuntimeException((Throwable)noSuchMethodException);
        }
    }

    public ScriptableObject() {
    }

    public ScriptableObject(Scriptable scriptable, Scriptable scriptable2) {
        if (scriptable == null) {
            throw new IllegalArgumentException();
        }
        this.parentScopeObject = scriptable;
        this.prototypeObject = scriptable2;
    }

    private static void addKnownAbsentSlot(Slot[] arrslot, Slot slot, int n) {
        if (arrslot[n] == null) {
            arrslot[n] = slot;
            return;
        }
        Slot slot2 = arrslot[n];
        Slot slot3 = slot2.next;
        while (slot3 != null) {
            slot2 = slot3;
            slot3 = slot2.next;
        }
        slot2.next = slot;
    }

    /*
     * Enabled aggressive block sorting
     */
    static <T extends Scriptable> BaseFunction buildClassCtor(Scriptable scriptable, Class<T> class_, boolean bl, boolean bl2) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        Method[] arrmethod;
        Object object;
        Constructor constructor;
        FunctionObject functionObject;
        Constructor[] arrconstructor;
        block46 : {
            int n;
            arrmethod = FunctionObject.getMethodList(class_);
            for (int i = 0; i < (n = arrmethod.length); ++i) {
                Method method = arrmethod[i];
                if (!method.getName().equals((Object)"init")) continue;
                Class[] arrclass = method.getParameterTypes();
                if (arrclass.length == 3 && arrclass[0] == ScriptRuntime.ContextClass && arrclass[1] == ScriptRuntime.ScriptableClass && arrclass[2] == Boolean.TYPE && Modifier.isStatic((int)method.getModifiers())) {
                    Object[] arrobject = new Object[3];
                    arrobject[0] = Context.getContext();
                    arrobject[1] = scriptable;
                    Boolean bl3 = bl ? Boolean.TRUE : Boolean.FALSE;
                    arrobject[2] = bl3;
                    method.invoke(null, arrobject);
                    return null;
                }
                if (arrclass.length != 1 || arrclass[0] != ScriptRuntime.ScriptableClass || !Modifier.isStatic((int)method.getModifiers())) continue;
                method.invoke(null, new Object[]{scriptable});
                return null;
            }
            arrconstructor = class_.getConstructors();
            int n2 = 0;
            do {
                int n3 = arrconstructor.length;
                int n4 = ++n2;
                constructor = null;
                if (n4 >= n3) break block46;
            } while (arrconstructor[n2].getParameterTypes().length != 0);
            constructor = arrconstructor[n2];
        }
        if (constructor == null) {
            throw Context.reportRuntimeError1("msg.zero.arg.ctor", class_.getName());
        }
        Object[] arrobject = ScriptRuntime.emptyArgs;
        Scriptable scriptable2 = (Scriptable)constructor.newInstance(arrobject);
        String string2 = scriptable2.getClassName();
        Object object2 = ScriptableObject.getProperty(ScriptableObject.getTopLevelScope(scriptable), string2);
        if (object2 instanceof BaseFunction && (object = ((BaseFunction)object2).getPrototypeProperty()) != null && class_.equals((Object)object.getClass())) {
            return (BaseFunction)object2;
        }
        Scriptable scriptable3 = null;
        if (bl2) {
            Class class_2 = class_.getSuperclass();
            boolean bl4 = ScriptRuntime.ScriptableClass.isAssignableFrom(class_2);
            scriptable3 = null;
            if (bl4) {
                boolean bl5 = Modifier.isAbstract((int)class_2.getModifiers());
                scriptable3 = null;
                if (!bl5) {
                    String string3 = ScriptableObject.defineClass(scriptable, ScriptableObject.extendsScriptable(class_2), bl, bl2);
                    scriptable3 = null;
                    if (string3 != null) {
                        scriptable3 = ScriptableObject.getClassPrototype(scriptable, string3);
                    }
                }
            }
        }
        if (scriptable3 == null) {
            scriptable3 = ScriptableObject.getObjectPrototype(scriptable);
        }
        scriptable2.setPrototype(scriptable3);
        Member member = ScriptableObject.findAnnotatedMember((AccessibleObject[])arrmethod, JSConstructor.class);
        if (member == null) {
            member = ScriptableObject.findAnnotatedMember((AccessibleObject[])arrconstructor, JSConstructor.class);
        }
        if (member == null) {
            member = FunctionObject.findSingleMethod(arrmethod, "jsConstructor");
        }
        if (member == null) {
            if (arrconstructor.length == 1) {
                member = arrconstructor[0];
            } else if (arrconstructor.length == 2) {
                if (arrconstructor[0].getParameterTypes().length == 0) {
                    member = arrconstructor[1];
                } else if (arrconstructor[1].getParameterTypes().length == 0) {
                    member = arrconstructor[0];
                }
            }
            if (member == null) {
                throw Context.reportRuntimeError1("msg.ctor.multiple.parms", class_.getName());
            }
        }
        if ((functionObject = new FunctionObject(string2, member, scriptable)).isVarArgsMethod()) {
            throw Context.reportRuntimeError1("msg.varargs.ctor", member.getName());
        }
        functionObject.initAsConstructor(scriptable, scriptable2);
        Method method = null;
        HashSet hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        int n = arrmethod.length;
        for (int i = 0; i < n; ++i) {
            Class[] arrclass;
            Annotation annotation;
            void var39_45;
            HashSet hashSet3;
            String string4;
            boolean bl6;
            Method method2 = arrmethod[i];
            if (method2 == member) continue;
            String string5 = method2.getName();
            if (string5.equals((Object)"finishInit") && (arrclass = method2.getParameterTypes()).length == 3 && arrclass[0] == ScriptRuntime.ScriptableClass && arrclass[1] == FunctionObject.class && arrclass[2] == ScriptRuntime.ScriptableClass && Modifier.isStatic((int)method2.getModifiers())) {
                method = method2;
                continue;
            }
            if (string5.indexOf(36) != -1 || string5.equals((Object)"jsConstructor")) continue;
            if (method2.isAnnotationPresent(JSFunction.class)) {
                annotation = method2.getAnnotation(JSFunction.class);
            } else if (method2.isAnnotationPresent(JSStaticFunction.class)) {
                annotation = method2.getAnnotation(JSStaticFunction.class);
            } else if (method2.isAnnotationPresent(JSGetter.class)) {
                annotation = method2.getAnnotation(JSGetter.class);
            } else {
                boolean bl7 = method2.isAnnotationPresent(JSSetter.class);
                annotation = null;
                if (bl7) continue;
            }
            String string6 = null;
            if (annotation == null) {
                if (string5.startsWith("jsFunction_")) {
                    string6 = "jsFunction_";
                } else if (string5.startsWith("jsStaticFunction_")) {
                    string6 = "jsStaticFunction_";
                } else if (string5.startsWith("jsGet_")) {
                    string6 = "jsGet_";
                } else {
                    string6 = null;
                    if (annotation == null) continue;
                }
            }
            if ((hashSet3 = (bl6 = annotation instanceof JSStaticFunction || string6 == "jsStaticFunction_") ? hashSet : hashSet2).contains((Object)(string4 = ScriptableObject.getPropertyName(string5, string6, annotation)))) {
                throw Context.reportRuntimeError2("duplicate.defineClass.name", string5, string4);
            }
            hashSet3.add((Object)string4);
            if (annotation instanceof JSGetter || string6 == "jsGet_") {
                if (!(scriptable2 instanceof ScriptableObject)) {
                    throw Context.reportRuntimeError2("msg.extend.scriptable", scriptable2.getClass().toString(), string4);
                }
                Method method3 = ScriptableObject.findSetterMethod(arrmethod, string4, "jsSet_");
                int n5 = method3 != null ? 0 : 1;
                int n6 = n5 | 6;
                ((ScriptableObject)scriptable2).defineProperty(string4, null, method2, method3, n6);
                continue;
            }
            if (bl6 && !Modifier.isStatic((int)method2.getModifiers())) {
                throw Context.reportRuntimeError("jsStaticFunction must be used with static method.");
            }
            FunctionObject functionObject2 = new FunctionObject(string4, (Member)method2, scriptable2);
            if (functionObject2.isVarArgsConstructor()) {
                throw Context.reportRuntimeError1("msg.varargs.fun", member.getName());
            }
            if (bl6) {
                FunctionObject functionObject3 = functionObject;
            } else {
                Scriptable scriptable4 = scriptable2;
            }
            ScriptableObject.defineProperty((Scriptable)var39_45, string4, functionObject2, 2);
            if (!bl) continue;
            functionObject2.sealObject();
        }
        if (method != null) {
            Object[] arrobject2 = new Object[]{scriptable, functionObject, scriptable2};
            method.invoke(null, arrobject2);
        }
        if (bl) {
            functionObject.sealObject();
            if (scriptable2 instanceof ScriptableObject) {
                ((ScriptableObject)scriptable2).sealObject();
            }
        }
        return functionObject;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected static ScriptableObject buildDataDescriptor(Scriptable scriptable, Object object, int n) {
        boolean bl = true;
        NativeObject nativeObject = new NativeObject();
        ScriptRuntime.setBuiltinProtoAndParent(nativeObject, scriptable, TopLevel.Builtins.Object);
        nativeObject.defineProperty("value", object, 0);
        boolean bl2 = (n & 1) == 0 ? bl : false;
        nativeObject.defineProperty("writable", bl2, 0);
        boolean bl3 = (n & 2) == 0 ? bl : false;
        nativeObject.defineProperty("enumerable", bl3, 0);
        if ((n & 4) != 0) {
            bl = false;
        }
        nativeObject.defineProperty("configurable", bl, 0);
        return nativeObject;
    }

    public static Object callMethod(Context context, Scriptable scriptable, String string2, Object[] arrobject) {
        Object object = ScriptableObject.getProperty(scriptable, string2);
        if (!(object instanceof Function)) {
            throw ScriptRuntime.notFunctionError(scriptable, string2);
        }
        Function function = (Function)object;
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        if (context != null) {
            return function.call(context, scriptable2, scriptable, arrobject);
        }
        return Context.call(null, function, scriptable2, scriptable, arrobject);
    }

    public static Object callMethod(Scriptable scriptable, String string2, Object[] arrobject) {
        return ScriptableObject.callMethod(null, scriptable, string2, arrobject);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void checkNotSealed(String string2, int n) {
        String string3;
        if (!this.isSealed()) {
            return;
        }
        if (string2 != null) {
            string3 = string2;
            do {
                throw Context.reportRuntimeError1("msg.modify.sealed", string3);
                break;
            } while (true);
        }
        string3 = Integer.toString((int)n);
        throw Context.reportRuntimeError1("msg.modify.sealed", string3);
    }

    static void checkValidAttributes(int n) {
        if ((n & -16) != 0) {
            throw new IllegalArgumentException(String.valueOf((int)n));
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void copyTable(Slot[] arrslot, Slot[] arrslot2, int n) {
        if (n == 0) {
            throw Kit.codeBug();
        }
        int n2 = arrslot2.length;
        int n3 = arrslot.length;
        block0 : do {
            Slot slot = arrslot[--n3];
            do {
                if (slot == null) continue block0;
                int n4 = ScriptableObject.getSlotIndex(n2, slot.indexOrHash);
                Slot slot2 = slot.next == null ? slot : new RelinkedSlot(slot);
                ScriptableObject.addKnownAbsentSlot(arrslot2, slot2, n4);
                slot = slot.next;
            } while (--n != 0);
            break;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private Slot createSlot(String var1_1, int var2_2, int var3_3) {
        block19 : {
            block17 : {
                block18 : {
                    var11_4 = this;
                    // MONITORENTER : var11_4
                    var5_5 = this.slots;
                    if (this.count == 0) {
                        var5_5 = new Slot[4];
                        this.slots = var5_5;
                        var6_6 = ScriptableObject.getSlotIndex(var5_5.length, var2_2);
lbl8: // 3 sources:
                        do {
                            var10_7 = var3_3 == 4 ? new GetterSlot(var1_1, var2_2, 0) : new Slot(var1_1, var2_2, 0);
                            if (var3_3 == 3) {
                                var10_7.setAttributes(13);
                            }
                            this.count = 1 + this.count;
                            if (this.lastAdded != null) {
                                this.lastAdded.orderedNext = var10_7;
                            }
                            if (this.firstAdded == null) {
                                this.firstAdded = var10_7;
                            }
                            this.lastAdded = var10_7;
                            ScriptableObject.addKnownAbsentSlot(var5_5, var10_7, var6_6);
                            // MONITOREXIT : var11_4
                            return var10_7;
                            break;
                        } while (true);
                    }
                    var6_6 = ScriptableObject.getSlotIndex(var5_5.length, var2_2);
                    var8_9 = var7_8 = var5_5[var6_6];
                    do {
                        if (var8_9 == null || var8_9.indexOrHash == var2_2 && (var8_9.name == var1_1 || var1_1 != null && var1_1.equals((Object)var8_9.name))) {
                            if (var8_9 == null) break block17;
                            var9_10 = ScriptableObject.unwrapSlot(var8_9);
                            if (var3_3 != 4 || var9_10 instanceof GetterSlot) break;
                            var10_7 = new GetterSlot(var1_1, var2_2, var9_10.getAttributes());
                            break block18;
                        }
                        var7_8 = var8_9;
                        var8_9 = var8_9.next;
                    } while (true);
                    if (var3_3 != 5 || !(var9_10 instanceof GetterSlot)) break block19;
                    var10_7 = new Slot(var1_1, var2_2, var9_10.getAttributes());
                }
                var10_7.value = var9_10.value;
                var10_7.next = var8_9.next;
                if (this.lastAdded != null) {
                    this.lastAdded.orderedNext = var10_7;
                }
                if (this.firstAdded == null) {
                    this.firstAdded = var10_7;
                }
                this.lastAdded = var10_7;
                if (var7_8 == var8_9) {
                    var5_5[var6_6] = var10_7;
                } else {
                    var7_8.next = var10_7;
                }
                var8_9.markDeleted();
                return var10_7;
            }
            if (4 * (1 + this.count) <= 3 * var5_5.length) ** GOTO lbl8
            var5_5 = new Slot[2 * var5_5.length];
            ScriptableObject.copyTable(this.slots, var5_5, this.count);
            this.slots = var5_5;
            var6_6 = ScriptableObject.getSlotIndex(var5_5.length, var2_2);
            ** while (true)
        }
        if (var3_3 != 3) return var9_10;
        return null;
    }

    public static <T extends Scriptable> String defineClass(Scriptable scriptable, Class<T> class_, boolean bl, boolean bl2) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        BaseFunction baseFunction = ScriptableObject.buildClassCtor(scriptable, class_, bl, bl2);
        if (baseFunction == null) {
            return null;
        }
        String string2 = baseFunction.getClassPrototype().getClassName();
        ScriptableObject.defineProperty(scriptable, string2, baseFunction, 2);
        return string2;
    }

    public static <T extends Scriptable> void defineClass(Scriptable scriptable, Class<T> class_) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        ScriptableObject.defineClass(scriptable, class_, false, false);
    }

    public static <T extends Scriptable> void defineClass(Scriptable scriptable, Class<T> class_, boolean bl) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        ScriptableObject.defineClass(scriptable, class_, bl, false);
    }

    public static void defineConstProperty(Scriptable scriptable, String string2) {
        if (scriptable instanceof ConstProperties) {
            ((ConstProperties)((Object)scriptable)).defineConst(string2, scriptable);
            return;
        }
        ScriptableObject.defineProperty(scriptable, string2, Undefined.instance, 13);
    }

    public static void defineProperty(Scriptable scriptable, String string2, Object object, int n) {
        if (!(scriptable instanceof ScriptableObject)) {
            scriptable.put(string2, scriptable, object);
            return;
        }
        ((ScriptableObject)scriptable).defineProperty(string2, object, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean deleteProperty(Scriptable scriptable, int n) {
        block3 : {
            block2 : {
                Scriptable scriptable2 = ScriptableObject.getBase(scriptable, n);
                if (scriptable2 == null) break block2;
                scriptable2.delete(n);
                if (scriptable2.has(n, scriptable)) break block3;
            }
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean deleteProperty(Scriptable scriptable, String string2) {
        block3 : {
            block2 : {
                Scriptable scriptable2 = ScriptableObject.getBase(scriptable, string2);
                if (scriptable2 == null) break block2;
                scriptable2.delete(string2);
                if (scriptable2.has(string2, scriptable)) break block3;
            }
            return true;
        }
        return false;
    }

    protected static Scriptable ensureScriptable(Object object) {
        if (!(object instanceof Scriptable)) {
            throw ScriptRuntime.typeError1("msg.arg.not.object", ScriptRuntime.typeof(object));
        }
        return (Scriptable)object;
    }

    protected static ScriptableObject ensureScriptableObject(Object object) {
        if (!(object instanceof ScriptableObject)) {
            throw ScriptRuntime.typeError1("msg.arg.not.object", ScriptRuntime.typeof(object));
        }
        return (ScriptableObject)object;
    }

    private static <T extends Scriptable> Class<T> extendsScriptable(Class<?> class_) {
        if (ScriptRuntime.ScriptableClass.isAssignableFrom(class_)) {
            return class_;
        }
        return null;
    }

    private static Member findAnnotatedMember(AccessibleObject[] arraccessibleObject, Class<? extends Annotation> class_) {
        for (AccessibleObject accessibleObject : arraccessibleObject) {
            if (!accessibleObject.isAnnotationPresent(class_)) continue;
            return (Member)accessibleObject;
        }
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Slot findAttributeSlot(String string2, int n, int n2) {
        String string3;
        Slot slot = this.getSlot(string2, n, n2);
        if (slot != null) return slot;
        if (string2 != null) {
            string3 = string2;
            do {
                throw Context.reportRuntimeError1("msg.prop.not.found", string3);
                break;
            } while (true);
        }
        string3 = Integer.toString((int)n);
        throw Context.reportRuntimeError1("msg.prop.not.found", string3);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Method findSetterMethod(Method[] arrmethod, String string2, String string3) {
        Method method;
        String string4 = "set" + Character.toUpperCase((char)string2.charAt(0)) + string2.substring(1);
        int n = arrmethod.length;
        for (int i = 0; i < n; ++i) {
            method = arrmethod[i];
            JSSetter jSSetter = (JSSetter)method.getAnnotation(JSSetter.class);
            if (jSSetter != null && (string2.equals((Object)jSSetter.value()) || "".equals((Object)jSSetter.value()) && string4.equals((Object)method.getName()))) return method;
            {
                continue;
            }
        }
        String string5 = string3 + string2;
        int n2 = arrmethod.length;
        int n3 = 0;
        while (n3 < n2) {
            method = arrmethod[n3];
            if (string5.equals((Object)method.getName())) {
                return method;
            }
            ++n3;
        }
        return null;
    }

    public static Scriptable getArrayPrototype(Scriptable scriptable) {
        return TopLevel.getBuiltinPrototype(ScriptableObject.getTopLevelScope(scriptable), TopLevel.Builtins.Array);
    }

    private static Scriptable getBase(Scriptable scriptable, int n) {
        do {
            if (!scriptable.has(n, scriptable)) continue;
            return scriptable;
        } while ((scriptable = scriptable.getPrototype()) != null);
        return scriptable;
    }

    private static Scriptable getBase(Scriptable scriptable, String string2) {
        do {
            if (!scriptable.has(string2, scriptable)) continue;
            return scriptable;
        } while ((scriptable = scriptable.getPrototype()) != null);
        return scriptable;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Scriptable getClassPrototype(Scriptable scriptable, String string2) {
        Object object;
        Object object2 = ScriptableObject.getProperty(ScriptableObject.getTopLevelScope(scriptable), string2);
        if (object2 instanceof BaseFunction) {
            object = ((BaseFunction)object2).getPrototypeProperty();
        } else {
            if (!(object2 instanceof Scriptable)) {
                return null;
            }
            Scriptable scriptable2 = (Scriptable)object2;
            object = scriptable2.get("prototype", scriptable2);
        }
        if (object instanceof Scriptable) {
            return (Scriptable)object;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Object getDefaultValue(Scriptable scriptable, Class<?> class_) {
        String string2;
        Context context = null;
        for (int i = 0; i < 2; ++i) {
            Object object;
            String string3;
            Object[] arrobject;
            Object object2;
            Object object3;
            boolean bl = class_ == ScriptRuntime.StringClass ? i == 0 : i == 1;
            if (bl) {
                string3 = "toString";
                arrobject = ScriptRuntime.emptyArgs;
            } else {
                String string4;
                string3 = "valueOf";
                arrobject = new Object[1];
                if (class_ == null) {
                    string4 = "undefined";
                } else if (class_ == ScriptRuntime.StringClass) {
                    string4 = "string";
                } else if (class_ == ScriptRuntime.ScriptableClass) {
                    string4 = "object";
                } else if (class_ == ScriptRuntime.FunctionClass) {
                    string4 = "function";
                } else if (class_ == ScriptRuntime.BooleanClass || class_ == Boolean.TYPE) {
                    string4 = "boolean";
                } else {
                    if (class_ != ScriptRuntime.NumberClass && class_ != ScriptRuntime.ByteClass && class_ != Byte.TYPE && class_ != ScriptRuntime.ShortClass && class_ != Short.TYPE && class_ != ScriptRuntime.IntegerClass && class_ != Integer.TYPE && class_ != ScriptRuntime.FloatClass && class_ != Float.TYPE && class_ != ScriptRuntime.DoubleClass) {
                        if (class_ != Double.TYPE) throw Context.reportRuntimeError1("msg.invalid.type", class_.toString());
                    }
                    string4 = "number";
                }
                arrobject[0] = string4;
            }
            if (!((object3 = ScriptableObject.getProperty(scriptable, string3)) instanceof Function)) continue;
            Function function = (Function)object3;
            if (context == null) {
                context = Context.getContext();
            }
            if ((object2 = function.call(context, function.getParentScope(), scriptable, arrobject)) == null) continue;
            if (!(object2 instanceof Scriptable)) {
                return object2;
            }
            if (class_ == ScriptRuntime.ScriptableClass) return object2;
            if (class_ == ScriptRuntime.FunctionClass) return object2;
            if (!bl || !(object2 instanceof Wrapper) || !((object = ((Wrapper)object2).unwrap()) instanceof String)) continue;
            return object;
        }
        if (class_ == null) {
            string2 = "undefined";
            throw ScriptRuntime.typeError1("msg.default.value", string2);
        }
        string2 = class_.getName();
        throw ScriptRuntime.typeError1("msg.default.value", string2);
    }

    public static Scriptable getFunctionPrototype(Scriptable scriptable) {
        return TopLevel.getBuiltinPrototype(ScriptableObject.getTopLevelScope(scriptable), TopLevel.Builtins.Function);
    }

    public static Scriptable getObjectPrototype(Scriptable scriptable) {
        return TopLevel.getBuiltinPrototype(ScriptableObject.getTopLevelScope(scriptable), TopLevel.Builtins.Object);
    }

    public static Object getProperty(Scriptable scriptable, int n) {
        Object object;
        Scriptable scriptable2 = scriptable;
        do {
            if ((object = scriptable.get(n, scriptable2)) == Scriptable.NOT_FOUND) continue;
            return object;
        } while ((scriptable = scriptable.getPrototype()) != null);
        return object;
    }

    public static Object getProperty(Scriptable scriptable, String string2) {
        Object object;
        Scriptable scriptable2 = scriptable;
        do {
            if ((object = scriptable.get(string2, scriptable2)) == Scriptable.NOT_FOUND) continue;
            return object;
        } while ((scriptable = scriptable.getPrototype()) != null);
        return object;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static Object[] getPropertyIds(Scriptable var0) {
        if (var0 == null) {
            return ScriptRuntime.emptyArgs;
        }
        var1_1 = var0.getIds();
        var2_2 = null;
        block0 : do {
            if ((var0 = var0.getPrototype()) == null) {
                if (var2_2 == null) return var1_1;
                return var2_2.getKeys();
            }
            var3_3 = var0.getIds();
            if (var3_3.length == 0) continue;
            if (var2_2 == null) {
                if (var1_1.length == 0) {
                    var1_1 = var3_3;
                    continue;
                }
                var2_2 = new ObjToIntMap(var1_1.length + var3_3.length);
                for (var6_5 = 0; var6_5 != var1_1.length; ++var6_5) {
                    var2_2.intern(var1_1[var6_5]);
                }
                var1_1 = null;
            }
            var4_4 = 0;
            do {
                if (var4_4 != var3_3.length) ** break;
                continue block0;
                var2_2.intern(var3_3[var4_4]);
                ++var4_4;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String getPropertyName(String string2, String string3, Annotation annotation) {
        String string4;
        if (string3 != null) {
            return string2.substring(string3.length());
        }
        if (annotation instanceof JSGetter) {
            string4 = ((JSGetter)annotation).value();
            if ((string4 == null || string4.length() == 0) && string2.length() > 3 && string2.startsWith("get") && Character.isUpperCase((char)(string4 = string2.substring(3)).charAt(0))) {
                if (string4.length() == 1) {
                    string4 = string4.toLowerCase();
                } else if (!Character.isUpperCase((char)string4.charAt(1))) {
                    string4 = Character.toLowerCase((char)string4.charAt(0)) + string4.substring(1);
                }
            }
        } else if (annotation instanceof JSFunction) {
            string4 = ((JSFunction)annotation).value();
        } else {
            boolean bl = annotation instanceof JSStaticFunction;
            string4 = null;
            if (bl) {
                string4 = ((JSStaticFunction)annotation).value();
            }
        }
        if (string4 == null) return string2;
        if (string4.length() != 0) return string4;
        return string2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private Slot getSlot(String var1_1, int var2_2, int var3_3) {
        var4_4 = this.slots;
        if (var4_4 == null && var3_3 == 1) {
            return null;
        }
        var5_6 = var1_1 != null ? var1_1.hashCode() : var2_2;
        if (var4_4 == null) return this.createSlot(var1_1, var5_6, var3_3);
        var6_5 = var4_4[ScriptableObject.getSlotIndex(var4_4.length, var5_6)];
        block6 : do {
            block8 : {
                if (var6_5 == null) break block8;
                var9_7 = var6_5.name;
                if (var5_6 != var6_5.indexOrHash || var9_7 != var1_1 && (var1_1 == null || !var1_1.equals((Object)var9_7))) ** GOTO lbl17
            }
            switch (var3_3) {
                case 1: {
                    return var6_5;
                }
                default: {
                    return this.createSlot(var1_1, var5_6, var3_3);
                }
lbl17: // 1 sources:
                var6_5 = var6_5.next;
                continue block6;
                case 2: 
                case 3: {
                    if (var6_5 == null) return this.createSlot(var1_1, var5_6, var3_3);
                    return var6_5;
                }
                case 4: {
                    var8_8 = ScriptableObject.unwrapSlot(var6_5);
                    if (var8_8 instanceof GetterSlot == false) return this.createSlot(var1_1, var5_6, var3_3);
                    return var8_8;
                }
                case 5: 
            }
            break;
        } while (true);
        var7_9 = ScriptableObject.unwrapSlot(var6_5);
        if (var7_9 instanceof GetterSlot != false) return this.createSlot(var1_1, var5_6, var3_3);
        return var7_9;
    }

    private static int getSlotIndex(int n, int n2) {
        return n2 & n - 1;
    }

    public static Scriptable getTopLevelScope(Scriptable scriptable) {
        Scriptable scriptable2;
        while ((scriptable2 = scriptable.getParentScope()) != null) {
            scriptable = scriptable2;
        }
        return scriptable;
    }

    public static Object getTopScopeValue(Scriptable scriptable, Object object) {
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        do {
            Object object2;
            if (!(scriptable2 instanceof ScriptableObject) || (object2 = ((ScriptableObject)scriptable2).getAssociatedValue(object)) == null) continue;
            return object2;
        } while ((scriptable2 = scriptable2.getPrototype()) != null);
        return null;
    }

    public static <T> T getTypedProperty(Scriptable scriptable, int n, Class<T> class_) {
        Object object = ScriptableObject.getProperty(scriptable, n);
        if (object == Scriptable.NOT_FOUND) {
            object = null;
        }
        return (T)class_.cast(Context.jsToJava(object, class_));
    }

    public static <T> T getTypedProperty(Scriptable scriptable, String string2, Class<T> class_) {
        Object object = ScriptableObject.getProperty(scriptable, string2);
        if (object == Scriptable.NOT_FOUND) {
            object = null;
        }
        return (T)class_.cast(Context.jsToJava(object, class_));
    }

    public static boolean hasProperty(Scriptable scriptable, int n) {
        return ScriptableObject.getBase(scriptable, n) != null;
    }

    public static boolean hasProperty(Scriptable scriptable, String string2) {
        return ScriptableObject.getBase(scriptable, string2) != null;
    }

    protected static boolean isFalse(Object object) {
        return !ScriptableObject.isTrue(object);
    }

    protected static boolean isTrue(Object object) {
        return object != NOT_FOUND && ScriptRuntime.toBoolean(object);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean putConstImpl(String string2, int n, Scriptable scriptable, Object object, int n2) {
        Slot slot;
        boolean bl = true;
        if (!$assertionsDisabled && n2 == 0) {
            throw new AssertionError();
        }
        if (this != scriptable) {
            slot = this.getSlot(string2, n, (int)bl);
            if (slot != null) return slot.setValue(object, this, scriptable);
            return false;
        }
        if (!this.isExtensible()) {
            slot = this.getSlot(string2, n, (int)bl);
            if (slot == null) return bl;
            return slot.setValue(object, this, scriptable);
        }
        this.checkNotSealed(string2, n);
        Slot slot2 = ScriptableObject.unwrapSlot(this.getSlot(string2, n, 3));
        int n3 = slot2.getAttributes();
        if ((n3 & 1) == 0) {
            throw Context.reportRuntimeError1("msg.var.redecl", string2);
        }
        if ((n3 & 8) == 0) return bl;
        slot2.value = object;
        if (n2 == 8) return bl;
        slot2.setAttributes(n3 & -9);
        return bl;
    }

    public static void putConstProperty(Scriptable scriptable, String string2, Object object) {
        Scriptable scriptable2 = ScriptableObject.getBase(scriptable, string2);
        if (scriptable2 == null) {
            scriptable2 = scriptable;
        }
        if (scriptable2 instanceof ConstProperties) {
            ((ConstProperties)((Object)scriptable2)).putConst(string2, scriptable, object);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean putImpl(String string2, int n, Scriptable scriptable, Object object) {
        Slot slot;
        boolean bl = true;
        if (this != scriptable) {
            slot = this.getSlot(string2, n, (int)bl);
            if (slot != null) return slot.setValue(object, this, scriptable);
            return false;
        }
        if (!this.isExtensible) {
            slot = this.getSlot(string2, n, (int)bl);
            if (slot == null) return bl;
            do {
                return slot.setValue(object, this, scriptable);
                break;
            } while (true);
        }
        if (this.count < 0) {
            this.checkNotSealed(string2, n);
        }
        slot = this.getSlot(string2, n, 2);
        return slot.setValue(object, this, scriptable);
    }

    public static void putProperty(Scriptable scriptable, int n, Object object) {
        Scriptable scriptable2 = ScriptableObject.getBase(scriptable, n);
        if (scriptable2 == null) {
            scriptable2 = scriptable;
        }
        scriptable2.put(n, scriptable, object);
    }

    public static void putProperty(Scriptable scriptable, String string2, Object object) {
        Scriptable scriptable2 = ScriptableObject.getBase(scriptable, string2);
        if (scriptable2 == null) {
            scriptable2 = scriptable;
        }
        scriptable2.put(string2, scriptable, object);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        int n = objectInputStream.readInt();
        if (n != 0) {
            if ((n & n - 1) != 0) {
                int n2;
                if (n > 1073741824) {
                    throw new RuntimeException("Property table overflow");
                }
                for (n2 = 4; n2 < n; n2 <<= 1) {
                }
                n = n2;
            }
            this.slots = new Slot[n];
            int n3 = this.count;
            if (n3 < 0) {
                n3 ^= -1;
            }
            Slot slot = null;
            for (int i = 0; i != n3; ++i) {
                this.lastAdded = (Slot)objectInputStream.readObject();
                if (i == 0) {
                    this.firstAdded = this.lastAdded;
                } else {
                    slot.orderedNext = this.lastAdded;
                }
                int n4 = ScriptableObject.getSlotIndex(n, this.lastAdded.indexOrHash);
                ScriptableObject.addKnownAbsentSlot(this.slots, this.lastAdded, n4);
                slot = this.lastAdded;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void redefineProperty(Scriptable scriptable, String string2, boolean bl) {
        block5 : {
            block4 : {
                Scriptable scriptable2 = ScriptableObject.getBase(scriptable, string2);
                if (scriptable2 == null) break block4;
                if (scriptable2 instanceof ConstProperties && ((ConstProperties)((Object)scriptable2)).isConst(string2)) {
                    throw ScriptRuntime.typeError1("msg.const.redecl", string2);
                }
                if (bl) break block5;
            }
            return;
        }
        throw ScriptRuntime.typeError1("msg.var.redecl", string2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void removeSlot(String string2, int n) {
        ScriptableObject scriptableObject = this;
        synchronized (scriptableObject) {
            block11 : {
                int n2 = string2 != null ? string2.hashCode() : n;
                Slot[] arrslot = this.slots;
                if (this.count != 0) {
                    Slot slot;
                    Slot slot2;
                    Slot slot3;
                    block12 : {
                        Slot slot4;
                        int n3 = ScriptableObject.getSlotIndex(arrslot.length, n2);
                        slot3 = slot4 = arrslot[n3];
                        do {
                            if (slot3 == null || slot3.indexOrHash == n2 && (slot3.name == string2 || string2 != null && string2.equals((Object)slot3.name))) {
                                if (slot3 == null || (4 & slot3.getAttributes()) != 0) break block11;
                                this.count = -1 + this.count;
                                if (slot4 == slot3) {
                                    arrslot[n3] = slot3.next;
                                } else {
                                    slot4.next = slot3.next;
                                }
                                if ((slot = ScriptableObject.unwrapSlot(slot3)) != this.firstAdded) break;
                                slot2 = null;
                                this.firstAdded = slot.orderedNext;
                                break block12;
                            }
                            slot4 = slot3;
                            slot3 = slot3.next;
                        } while (true);
                        slot2 = this.firstAdded;
                        while (slot2.orderedNext != slot) {
                            slot2 = slot2.orderedNext;
                        }
                        slot2.orderedNext = slot.orderedNext;
                    }
                    if (slot == this.lastAdded) {
                        this.lastAdded = slot2;
                    }
                    slot3.markDeleted();
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void setGetterOrSetter(String string2, int n, Callable callable, boolean bl, boolean bl2) {
        GetterSlot getterSlot;
        if (string2 != null && n != 0) {
            throw new IllegalArgumentException(string2);
        }
        if (!bl2) {
            this.checkNotSealed(string2, n);
        }
        if (this.isExtensible()) {
            getterSlot = (GetterSlot)this.getSlot(string2, n, 4);
        } else {
            Slot slot = ScriptableObject.unwrapSlot(this.getSlot(string2, n, 1));
            if (!(slot instanceof GetterSlot)) {
                return;
            }
            getterSlot = (GetterSlot)slot;
        }
        if (!bl2 && (1 & getterSlot.getAttributes()) != 0) {
            throw Context.reportRuntimeError1("msg.modify.readonly", string2);
        }
        if (bl) {
            getterSlot.setter = callable;
        } else {
            getterSlot.getter = callable;
        }
        getterSlot.value = Undefined.instance;
    }

    private static Slot unwrapSlot(Slot slot) {
        if (slot instanceof RelinkedSlot) {
            slot = ((RelinkedSlot)slot).slot;
        }
        return slot;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        ScriptableObject scriptableObject = this;
        // MONITORENTER : scriptableObject
        objectOutputStream.defaultWriteObject();
        int n = this.count;
        if (n < 0) {
            n ^= -1;
        }
        if (n == 0) {
            objectOutputStream.writeInt(0);
            return;
        }
        objectOutputStream.writeInt(this.slots.length);
        Slot slot = this.firstAdded;
        while (slot != null && slot.wasDeleted) {
            slot = slot.orderedNext;
        }
        this.firstAdded = slot;
        do {
            if (slot == null) {
                // MONITOREXIT : scriptableObject
                return;
            }
            objectOutputStream.writeObject((Object)slot);
            Slot slot2 = slot.orderedNext;
            while (slot2 != null && slot2.wasDeleted) {
                slot2 = slot2.orderedNext;
            }
            slot.orderedNext = slot2;
            slot = slot2;
        } while (true);
    }

    void addLazilyInitializedValue(String string2, int n, LazilyLoadedCtor lazilyLoadedCtor, int n2) {
        if (string2 != null && n != 0) {
            throw new IllegalArgumentException(string2);
        }
        this.checkNotSealed(string2, n);
        GetterSlot getterSlot = (GetterSlot)this.getSlot(string2, n, 4);
        getterSlot.setAttributes(n2);
        getterSlot.getter = null;
        getterSlot.setter = null;
        getterSlot.value = lazilyLoadedCtor;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected int applyDescriptorToAttributeBitset(int n, ScriptableObject scriptableObject) {
        Object object;
        Object object2;
        Object object3 = ScriptableObject.getProperty((Scriptable)scriptableObject, "enumerable");
        if (object3 != NOT_FOUND) {
            n = ScriptRuntime.toBoolean(object3) ? (n &= -3) : (n |= 2);
        }
        if ((object = ScriptableObject.getProperty((Scriptable)scriptableObject, "writable")) != NOT_FOUND) {
            n = ScriptRuntime.toBoolean(object) ? (n &= -2) : (n |= 1);
        }
        if ((object2 = ScriptableObject.getProperty((Scriptable)scriptableObject, "configurable")) != NOT_FOUND) {
            if (!ScriptRuntime.toBoolean(object2)) {
                return n | 4;
            }
            n &= -5;
        }
        return n;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final Object associateValue(Object object, Object object2) {
        ScriptableObject scriptableObject = this;
        synchronized (scriptableObject) {
            if (object2 == null) {
                throw new IllegalArgumentException();
            }
            HashMap hashMap = this.associatedValues;
            if (hashMap != null) return Kit.initHash((Map<Object, Object>)hashMap, object, object2);
            this.associatedValues = hashMap = new HashMap();
            return Kit.initHash((Map<Object, Object>)hashMap, object, object2);
        }
    }

    public boolean avoidObjectDetection() {
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void checkPropertyChange(String string2, ScriptableObject scriptableObject, ScriptableObject scriptableObject2) {
        if (scriptableObject == null) {
            if (this.isExtensible()) return;
            {
                throw ScriptRuntime.typeError0("msg.not.extensible");
            }
        }
        if (!ScriptableObject.isFalse(scriptableObject.get("configurable", (Scriptable)scriptableObject))) return;
        if (ScriptableObject.isTrue(ScriptableObject.getProperty((Scriptable)scriptableObject2, "configurable"))) {
            throw ScriptRuntime.typeError1("msg.change.configurable.false.to.true", string2);
        }
        if (ScriptableObject.isTrue(scriptableObject.get("enumerable", (Scriptable)scriptableObject)) != ScriptableObject.isTrue(ScriptableObject.getProperty((Scriptable)scriptableObject2, "enumerable"))) {
            throw ScriptRuntime.typeError1("msg.change.enumerable.with.configurable.false", string2);
        }
        boolean bl = this.isDataDescriptor(scriptableObject2);
        boolean bl2 = this.isAccessorDescriptor(scriptableObject2);
        if (!bl && !bl2) return;
        if (bl && this.isDataDescriptor(scriptableObject)) {
            if (!ScriptableObject.isFalse(scriptableObject.get("writable", (Scriptable)scriptableObject))) return;
            {
                if (ScriptableObject.isTrue(ScriptableObject.getProperty((Scriptable)scriptableObject2, "writable"))) {
                    throw ScriptRuntime.typeError1("msg.change.writable.false.to.true.with.configurable.false", string2);
                }
                if (this.sameValue(ScriptableObject.getProperty((Scriptable)scriptableObject2, "value"), scriptableObject.get("value", (Scriptable)scriptableObject))) return;
                {
                    throw ScriptRuntime.typeError1("msg.change.value.with.writable.false", string2);
                }
            }
        }
        if (bl2 && this.isAccessorDescriptor(scriptableObject)) {
            if (!this.sameValue(ScriptableObject.getProperty((Scriptable)scriptableObject2, "set"), scriptableObject.get("set", (Scriptable)scriptableObject))) {
                throw ScriptRuntime.typeError1("msg.change.setter.with.configurable.false", string2);
            }
            if (!this.sameValue(ScriptableObject.getProperty((Scriptable)scriptableObject2, "get"), scriptableObject.get("get", (Scriptable)scriptableObject))) throw ScriptRuntime.typeError1("msg.change.getter.with.configurable.false", string2);
            return;
        }
        if (!this.isDataDescriptor(scriptableObject)) throw ScriptRuntime.typeError1("msg.change.property.accessor.to.data.with.configurable.false", string2);
        {
            throw ScriptRuntime.typeError1("msg.change.property.data.to.accessor.with.configurable.false", string2);
        }
    }

    protected void checkPropertyDefinition(ScriptableObject scriptableObject) {
        Object object = ScriptableObject.getProperty((Scriptable)scriptableObject, "get");
        if (object != NOT_FOUND && object != Undefined.instance && !(object instanceof Callable)) {
            throw ScriptRuntime.notFunctionError(object);
        }
        Object object2 = ScriptableObject.getProperty((Scriptable)scriptableObject, "set");
        if (object2 != NOT_FOUND && object2 != Undefined.instance && !(object2 instanceof Callable)) {
            throw ScriptRuntime.notFunctionError(object2);
        }
        if (this.isDataDescriptor(scriptableObject) && this.isAccessorDescriptor(scriptableObject)) {
            throw ScriptRuntime.typeError0("msg.both.data.and.accessor.desc");
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void defineConst(String string2, Scriptable scriptable) {
        block5 : {
            block4 : {
                if (this.putConstImpl(string2, 0, scriptable, Undefined.instance, 8)) break block4;
                if (scriptable == this) {
                    throw Kit.codeBug();
                }
                if (scriptable instanceof ConstProperties) break block5;
            }
            return;
        }
        ((ConstProperties)((Object)scriptable)).defineConst(string2, scriptable);
    }

    public void defineFunctionProperties(String[] arrstring, Class<?> class_, int n) {
        Method[] arrmethod = FunctionObject.getMethodList(class_);
        for (int i = 0; i < arrstring.length; ++i) {
            String string2 = arrstring[i];
            Method method = FunctionObject.findSingleMethod(arrmethod, string2);
            if (method == null) {
                throw Context.reportRuntimeError2("msg.method.not.found", string2, class_.getName());
            }
            this.defineProperty(string2, new FunctionObject(string2, (Member)method, this), n);
        }
    }

    public void defineOwnProperties(Context context, ScriptableObject scriptableObject) {
        Object[] arrobject = scriptableObject.getIds();
        ScriptableObject[] arrscriptableObject = new ScriptableObject[arrobject.length];
        int n = arrobject.length;
        for (int i = 0; i < n; ++i) {
            ScriptableObject scriptableObject2 = ScriptableObject.ensureScriptableObject(ScriptRuntime.getObjectElem(scriptableObject, arrobject[i], context));
            this.checkPropertyDefinition(scriptableObject2);
            arrscriptableObject[i] = scriptableObject2;
        }
        int n2 = arrobject.length;
        for (int i = 0; i < n2; ++i) {
            this.defineOwnProperty(context, arrobject[i], arrscriptableObject[i]);
        }
    }

    public void defineOwnProperty(Context context, Object object, ScriptableObject scriptableObject) {
        this.checkPropertyDefinition(scriptableObject);
        this.defineOwnProperty(context, object, scriptableObject, true);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void defineOwnProperty(Context context, Object object, ScriptableObject scriptableObject, boolean bl) {
        Object object2;
        int n;
        Slot slot = this.getSlot(context, object, 1);
        boolean bl2 = slot == null;
        if (bl) {
            ScriptableObject scriptableObject2 = slot == null ? null : slot.getPropertyDescriptor(context, this);
            this.checkPropertyChange(ScriptRuntime.toString(object), scriptableObject2, scriptableObject);
        }
        boolean bl3 = this.isAccessorDescriptor(scriptableObject);
        if (slot == null) {
            int n2 = bl3 ? 4 : 2;
            slot = this.getSlot(context, object, n2);
            n = this.applyDescriptorToAttributeBitset(7, scriptableObject);
        } else {
            n = this.applyDescriptorToAttributeBitset(slot.getAttributes(), scriptableObject);
        }
        Slot slot2 = ScriptableObject.unwrapSlot(slot);
        if (bl3) {
            Object object3;
            if (!(slot2 instanceof GetterSlot)) {
                slot2 = this.getSlot(context, object, 4);
            }
            GetterSlot getterSlot = (GetterSlot)slot2;
            Object object4 = ScriptableObject.getProperty((Scriptable)scriptableObject, "get");
            if (object4 != NOT_FOUND) {
                getterSlot.getter = object4;
            }
            if ((object3 = ScriptableObject.getProperty((Scriptable)scriptableObject, "set")) != NOT_FOUND) {
                getterSlot.setter = object3;
            }
            getterSlot.value = Undefined.instance;
            getterSlot.setAttributes(n);
            return;
        }
        if (slot2 instanceof GetterSlot && this.isDataDescriptor(scriptableObject)) {
            slot2 = this.getSlot(context, object, 5);
        }
        if ((object2 = ScriptableObject.getProperty((Scriptable)scriptableObject, "value")) != NOT_FOUND) {
            slot2.value = object2;
        } else if (bl2) {
            slot2.value = Undefined.instance;
        }
        slot2.setAttributes(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void defineProperty(String string2, Class<?> class_, int n) {
        int n2 = string2.length();
        if (n2 == 0) {
            throw new IllegalArgumentException();
        }
        char[] arrc = new char[n2 + 3];
        string2.getChars(0, n2, arrc, 3);
        arrc[3] = Character.toUpperCase((char)arrc[3]);
        arrc[0] = 103;
        arrc[1] = 101;
        arrc[2] = 116;
        String string3 = new String(arrc);
        arrc[0] = 115;
        String string4 = new String(arrc);
        Method[] arrmethod = FunctionObject.getMethodList(class_);
        Method method = FunctionObject.findSingleMethod(arrmethod, string3);
        Method method2 = FunctionObject.findSingleMethod(arrmethod, string4);
        if (method2 == null) {
            n |= 1;
        }
        Method method3 = method2 == null ? null : method2;
        this.defineProperty(string2, null, method, method3, n);
    }

    public void defineProperty(String string2, Object object, int n) {
        this.checkNotSealed(string2, 0);
        this.put(string2, (Scriptable)this, object);
        this.setAttributes(string2, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void defineProperty(String string2, Object object, Method method, Method method2, int n) {
        MemberBox memberBox = null;
        if (method != null) {
            boolean bl;
            String string3;
            Class[] arrclass;
            memberBox = new MemberBox(method);
            if (!Modifier.isStatic((int)method.getModifiers())) {
                bl = object != null;
                memberBox.delegateTo = object;
            } else {
                bl = true;
                memberBox.delegateTo = Void.TYPE;
            }
            if ((arrclass = method.getParameterTypes()).length == 0) {
                string3 = null;
                if (bl) {
                    string3 = "msg.obj.getter.parms";
                }
            } else if (arrclass.length == 1) {
                Class class_ = arrclass[0];
                if (class_ != ScriptRuntime.ScriptableClass && class_ != ScriptRuntime.ScriptableObjectClass) {
                    string3 = "msg.bad.getter.parms";
                } else {
                    string3 = null;
                    if (!bl) {
                        string3 = "msg.bad.getter.parms";
                    }
                }
            } else {
                string3 = "msg.bad.getter.parms";
            }
            if (string3 != null) {
                throw Context.reportRuntimeError1(string3, method.toString());
            }
        }
        MemberBox memberBox2 = null;
        if (method2 != null) {
            boolean bl;
            Class[] arrclass;
            String string4;
            if (method2.getReturnType() != Void.TYPE) {
                throw Context.reportRuntimeError1("msg.setter.return", method2.toString());
            }
            memberBox2 = new MemberBox(method2);
            if (!Modifier.isStatic((int)method2.getModifiers())) {
                bl = object != null;
                memberBox2.delegateTo = object;
            } else {
                bl = true;
                memberBox2.delegateTo = Void.TYPE;
            }
            if ((arrclass = method2.getParameterTypes()).length == 1) {
                string4 = null;
                if (bl) {
                    string4 = "msg.setter2.expected";
                }
            } else if (arrclass.length == 2) {
                Class class_ = arrclass[0];
                if (class_ != ScriptRuntime.ScriptableClass && class_ != ScriptRuntime.ScriptableObjectClass) {
                    string4 = "msg.setter2.parms";
                } else {
                    string4 = null;
                    if (!bl) {
                        string4 = "msg.setter1.parms";
                    }
                }
            } else {
                string4 = "msg.setter.parms";
            }
            if (string4 != null) {
                throw Context.reportRuntimeError1(string4, method2.toString());
            }
        }
        GetterSlot getterSlot = (GetterSlot)this.getSlot(string2, 0, 4);
        getterSlot.setAttributes(n);
        getterSlot.getter = memberBox;
        getterSlot.setter = memberBox2;
    }

    @Override
    public void delete(int n) {
        this.checkNotSealed(null, n);
        this.removeSlot(null, n);
    }

    @Override
    public void delete(String string2) {
        this.checkNotSealed(string2, 0);
        this.removeSlot(string2, 0);
    }

    protected Object equivalentValues(Object object) {
        if (this == object) {
            return Boolean.TRUE;
        }
        return Scriptable.NOT_FOUND;
    }

    @Override
    public Object get(int n, Scriptable scriptable) {
        if (this.externalData != null) {
            if (n < this.externalData.getArrayLength()) {
                return this.externalData.getArrayElement(n);
            }
            return Scriptable.NOT_FOUND;
        }
        Slot slot = this.getSlot((String)null, n, 1);
        if (slot == null) {
            return Scriptable.NOT_FOUND;
        }
        return slot.getValue(scriptable);
    }

    /*
     * Enabled aggressive block sorting
     */
    public Object get(Object object) {
        Object object2;
        if (object instanceof String) {
            object2 = this.get((String)object, (Scriptable)this);
        } else {
            boolean bl = object instanceof Number;
            object2 = null;
            if (bl) {
                object2 = this.get(((Number)object).intValue(), (Scriptable)this);
            }
        }
        if (object2 == Scriptable.NOT_FOUND) return null;
        if (object2 == Undefined.instance) {
            return null;
        }
        if (!(object2 instanceof Wrapper)) return object2;
        return ((Wrapper)object2).unwrap();
    }

    @Override
    public Object get(String string2, Scriptable scriptable) {
        Slot slot = this.getSlot(string2, 0, 1);
        if (slot == null) {
            return Scriptable.NOT_FOUND;
        }
        return slot.getValue(scriptable);
    }

    @Override
    public Object[] getAllIds() {
        return this.getIds(true);
    }

    public final Object getAssociatedValue(Object object) {
        Map<Object, Object> map = this.associatedValues;
        if (map == null) {
            return null;
        }
        return map.get(object);
    }

    public int getAttributes(int n) {
        return this.findAttributeSlot(null, n, 1).getAttributes();
    }

    @Deprecated
    public final int getAttributes(int n, Scriptable scriptable) {
        return this.getAttributes(n);
    }

    public int getAttributes(String string2) {
        return this.findAttributeSlot(string2, 0, 1).getAttributes();
    }

    @Deprecated
    public final int getAttributes(String string2, Scriptable scriptable) {
        return this.getAttributes(string2);
    }

    @Override
    public abstract String getClassName();

    @Override
    public Object getDefaultValue(Class<?> class_) {
        return ScriptableObject.getDefaultValue(this, class_);
    }

    public ExternalArrayData getExternalArrayData() {
        return this.externalData;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public Object getExternalArrayLength() {
        int n;
        if (this.externalData == null) {
            n = 0;
            do {
                return n;
                break;
            } while (true);
        }
        n = this.externalData.getArrayLength();
        return n;
    }

    /*
     * Enabled aggressive block sorting
     */
    public Object getGetterOrSetter(String string2, int n, boolean bl) {
        if (string2 != null && n != 0) {
            throw new IllegalArgumentException(string2);
        }
        Slot slot = ScriptableObject.unwrapSlot(this.getSlot(string2, n, 1));
        if (slot == null) {
            return null;
        }
        if (!(slot instanceof GetterSlot)) {
            return Undefined.instance;
        }
        GetterSlot getterSlot = (GetterSlot)slot;
        Object object = bl ? getterSlot.setter : getterSlot.getter;
        if (object != null) return object;
        return Undefined.instance;
    }

    @Override
    public Object[] getIds() {
        return this.getIds(false);
    }

    /*
     * Enabled aggressive block sorting
     */
    Object[] getIds(boolean bl) {
        Object[] arrobject;
        Slot[] arrslot = this.slots;
        int n = this.externalData == null ? 0 : this.externalData.getArrayLength();
        if (n == 0) {
            arrobject = ScriptRuntime.emptyArgs;
        } else {
            arrobject = new Object[n];
            for (int i = 0; i < n; ++i) {
                arrobject[i] = i;
            }
        }
        if (arrslot == null) {
            return arrobject;
        }
        int n2 = n;
        Slot slot = this.firstAdded;
        while (slot != null && slot.wasDeleted) {
            slot = slot.orderedNext;
        }
        block2 : do {
            block12 : {
                int n3;
                block11 : {
                    block10 : {
                        n3 = n2;
                        if (slot == null) break block10;
                        if (!bl && (2 & slot.getAttributes()) != 0) break block11;
                        if (n3 == n) {
                            Object[] arrobject2 = arrobject;
                            arrobject = new Object[n + arrslot.length];
                            if (arrobject2 != null) {
                                System.arraycopy((Object)arrobject2, (int)0, (Object)arrobject, (int)0, (int)n);
                            }
                        }
                        n2 = n3 + 1;
                        String string2 = slot.name != null ? slot.name : Integer.valueOf((int)slot.indexOrHash);
                        arrobject[n3] = string2;
                        break block12;
                    }
                    if (n3 == n + arrobject.length) {
                        return arrobject;
                    }
                    Object[] arrobject3 = new Object[n3];
                    System.arraycopy((Object)arrobject, (int)0, (Object)arrobject3, (int)0, (int)n3);
                    return arrobject3;
                }
                n2 = n3;
            }
            slot = slot.orderedNext;
            do {
                if (slot == null || !slot.wasDeleted) continue block2;
                slot = slot.orderedNext;
            } while (true);
            break;
        } while (true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected ScriptableObject getOwnPropertyDescriptor(Context context, Object object) {
        void var0_1;
        void var2_4;
        void var1_3;
        Slot slot = this.getSlot((Context)var1_3, var2_4, 1);
        if (slot == null) {
            return null;
        }
        Scriptable scriptable = this.getParentScope();
        if (scriptable == null) {
            do {
                return slot.getPropertyDescriptor((Context)var1_3, (Scriptable)var0_1);
                break;
            } while (true);
        }
        Scriptable scriptable2 = scriptable;
        return slot.getPropertyDescriptor((Context)var1_3, (Scriptable)var0_1);
    }

    @Override
    public Scriptable getParentScope() {
        return this.parentScopeObject;
    }

    @Override
    public Scriptable getPrototype() {
        return this.prototypeObject;
    }

    protected Slot getSlot(Context context, Object object, int n) {
        String string2 = ScriptRuntime.toStringIdOrIndex(context, object);
        if (string2 == null) {
            return this.getSlot((String)null, ScriptRuntime.lastIndexResult(context), n);
        }
        return this.getSlot(string2, 0, n);
    }

    public String getTypeOf() {
        if (this.avoidObjectDetection()) {
            return "undefined";
        }
        return "object";
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean has(int n, Scriptable scriptable) {
        if (this.externalData != null) {
            if (n < this.externalData.getArrayLength()) return true;
            return false;
        }
        if (this.getSlot((String)null, n, 1) == null) return false;
        return true;
    }

    @Override
    public boolean has(String string2, Scriptable scriptable) {
        return this.getSlot(string2, 0, 1) != null;
    }

    @Override
    public boolean hasInstance(Scriptable scriptable) {
        return ScriptRuntime.jsDelegatesTo(scriptable, this);
    }

    protected boolean isAccessorDescriptor(ScriptableObject scriptableObject) {
        return ScriptableObject.hasProperty((Scriptable)scriptableObject, "get") || ScriptableObject.hasProperty((Scriptable)scriptableObject, "set");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean isConst(String string2) {
        boolean bl = true;
        Slot slot = this.getSlot(string2, 0, (int)bl);
        if (slot == null) {
            return false;
        }
        if ((5 & slot.getAttributes()) != 5) return false;
        return bl;
    }

    protected boolean isDataDescriptor(ScriptableObject scriptableObject) {
        return ScriptableObject.hasProperty((Scriptable)scriptableObject, "value") || ScriptableObject.hasProperty((Scriptable)scriptableObject, "writable");
    }

    public boolean isEmpty() {
        return this.count == 0 || this.count == -1;
    }

    public boolean isExtensible() {
        return this.isExtensible;
    }

    protected boolean isGenericDescriptor(ScriptableObject scriptableObject) {
        return !this.isDataDescriptor(scriptableObject) && !this.isAccessorDescriptor(scriptableObject);
    }

    protected boolean isGetterOrSetter(String string2, int n, boolean bl) {
        Slot slot = ScriptableObject.unwrapSlot(this.getSlot(string2, n, 1));
        if (slot instanceof GetterSlot) {
            if (bl && ((GetterSlot)slot).setter != null) {
                return true;
            }
            if (!bl && ((GetterSlot)slot).getter != null) {
                return true;
            }
        }
        return false;
    }

    public final boolean isSealed() {
        return this.count < 0;
    }

    public void preventExtensions() {
        this.isExtensible = false;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void put(int n, Scriptable scriptable, Object object) {
        if (this.externalData != null) {
            if (n >= this.externalData.getArrayLength()) {
                throw new JavaScriptException(ScriptRuntime.newNativeError(Context.getCurrentContext(), this, TopLevel.NativeErrors.RangeError, new Object[]{"External array index out of bounds "}), null, 0);
            }
            this.externalData.setArrayElement(n, object);
            return;
        }
        if (this.putImpl(null, n, scriptable, object)) return;
        {
            if (scriptable == this) {
                throw Kit.codeBug();
            }
        }
        scriptable.put(n, scriptable, object);
    }

    @Override
    public void put(String string2, Scriptable scriptable, Object object) {
        if (this.putImpl(string2, 0, scriptable, object)) {
            return;
        }
        if (scriptable == this) {
            throw Kit.codeBug();
        }
        scriptable.put(string2, scriptable, object);
    }

    @Override
    public void putConst(String string2, Scriptable scriptable, Object object) {
        if (this.putConstImpl(string2, 0, scriptable, object, 1)) {
            return;
        }
        if (scriptable == this) {
            throw Kit.codeBug();
        }
        if (scriptable instanceof ConstProperties) {
            ((ConstProperties)((Object)scriptable)).putConst(string2, scriptable, object);
            return;
        }
        scriptable.put(string2, scriptable, object);
    }

    protected boolean sameValue(Object object, Object object2) {
        if (object == NOT_FOUND) {
            return true;
        }
        if (object2 == NOT_FOUND) {
            object2 = Undefined.instance;
        }
        if (object2 instanceof Number && object instanceof Number) {
            double d = ((Number)object2).doubleValue();
            double d2 = ((Number)object).doubleValue();
            if (Double.isNaN((double)d) && Double.isNaN((double)d2)) {
                return true;
            }
            if (d == 0.0 && Double.doubleToLongBits((double)d) != Double.doubleToLongBits((double)d2)) {
                return false;
            }
        }
        return ScriptRuntime.shallowEq(object2, object);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void sealObject() {
        ScriptableObject scriptableObject = this;
        synchronized (scriptableObject) {
            if (this.count >= 0) {
                Slot slot = this.firstAdded;
                while (slot != null) {
                    LazilyLoadedCtor lazilyLoadedCtor;
                    Object object = slot.value;
                    if (object instanceof LazilyLoadedCtor) {
                        lazilyLoadedCtor = (LazilyLoadedCtor)object;
                        lazilyLoadedCtor.init();
                    }
                    slot = slot.orderedNext;
                    continue;
                    finally {
                        slot.value = lazilyLoadedCtor.getValue();
                    }
                }
                this.count = -1 ^ this.count;
            }
            return;
        }
    }

    public void setAttributes(int n, int n2) {
        this.checkNotSealed(null, n);
        this.findAttributeSlot(null, n, 2).setAttributes(n2);
    }

    @Deprecated
    public void setAttributes(int n, Scriptable scriptable, int n2) {
        this.setAttributes(n, n2);
    }

    public void setAttributes(String string2, int n) {
        this.checkNotSealed(string2, 0);
        this.findAttributeSlot(string2, 0, 2).setAttributes(n);
    }

    @Deprecated
    public final void setAttributes(String string2, Scriptable scriptable, int n) {
        this.setAttributes(string2, n);
    }

    public void setExternalArrayData(ExternalArrayData externalArrayData) {
        this.externalData = externalArrayData;
        if (externalArrayData == null) {
            this.delete("length");
            return;
        }
        this.defineProperty("length", null, GET_ARRAY_LENGTH, null, 3);
    }

    public void setGetterOrSetter(String string2, int n, Callable callable, boolean bl) {
        this.setGetterOrSetter(string2, n, callable, bl, false);
    }

    @Override
    public void setParentScope(Scriptable scriptable) {
        this.parentScopeObject = scriptable;
    }

    @Override
    public void setPrototype(Scriptable scriptable) {
        this.prototypeObject = scriptable;
    }

    public int size() {
        if (this.count < 0) {
            return -1 ^ this.count;
        }
        return this.count;
    }

    private static final class GetterSlot
    extends Slot {
        static final long serialVersionUID = -4900574849788797588L;
        Object getter;
        Object setter;

        GetterSlot(String string2, int n, int n2) {
            super(string2, n, n2);
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        ScriptableObject getPropertyDescriptor(Context context, Scriptable scriptable) {
            boolean bl = true;
            int n = this.getAttributes();
            NativeObject nativeObject = new NativeObject();
            ScriptRuntime.setBuiltinProtoAndParent(nativeObject, scriptable, TopLevel.Builtins.Object);
            boolean bl2 = (n & 2) == 0 ? bl : false;
            nativeObject.defineProperty("enumerable", bl2, 0);
            if ((n & 4) != 0) {
                bl = false;
            }
            nativeObject.defineProperty("configurable", bl, 0);
            if (this.getter != null) {
                nativeObject.defineProperty("get", this.getter, 0);
            }
            if (this.setter != null) {
                nativeObject.defineProperty("set", this.setter, 0);
            }
            return nativeObject;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        Object getValue(Scriptable scriptable) {
            Object object;
            Object object2;
            if (this.getter != null) {
                if (this.getter instanceof MemberBox) {
                    Object[] arrobject;
                    Object object3;
                    MemberBox memberBox = (MemberBox)this.getter;
                    if (memberBox.delegateTo == null) {
                        object3 = scriptable;
                        arrobject = ScriptRuntime.emptyArgs;
                        do {
                            return memberBox.invoke(object3, arrobject);
                            break;
                        } while (true);
                    }
                    object3 = memberBox.delegateTo;
                    arrobject = new Object[]{scriptable};
                    return memberBox.invoke(object3, arrobject);
                }
                if (this.getter instanceof Function) {
                    Function function = (Function)this.getter;
                    return function.call(Context.getContext(), function.getParentScope(), scriptable, ScriptRuntime.emptyArgs);
                }
            }
            if (!((object2 = this.value) instanceof LazilyLoadedCtor)) return object2;
            LazilyLoadedCtor lazilyLoadedCtor = (LazilyLoadedCtor)object2;
            try {
                lazilyLoadedCtor.init();
            }
            catch (Throwable throwable) {
                this.value = lazilyLoadedCtor.getValue();
                throw throwable;
            }
            this.value = object = lazilyLoadedCtor.getValue();
            return object;
        }

        @Override
        void markDeleted() {
            super.markDeleted();
            this.getter = null;
            this.setter = null;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        boolean setValue(Object object, Scriptable scriptable, Scriptable scriptable2) {
            Object object2;
            Object[] arrobject;
            if (this.setter == null) {
                if (this.getter == null) return super.setValue(object, scriptable, scriptable2);
                if (!Context.getContext().hasFeature(11)) return true;
                throw ScriptRuntime.typeError1("msg.set.prop.no.setter", this.name);
            }
            Context context = Context.getContext();
            if (!(this.setter instanceof MemberBox)) {
                if (!(this.setter instanceof Function)) return true;
                Function function = (Function)this.setter;
                function.call(context, function.getParentScope(), scriptable2, new Object[]{object});
                return true;
            }
            MemberBox memberBox = (MemberBox)this.setter;
            Class<?>[] arrclass = memberBox.argTypes;
            Object object3 = FunctionObject.convertArg(context, scriptable2, object, FunctionObject.getTypeTag(arrclass[-1 + arrclass.length]));
            if (memberBox.delegateTo == null) {
                object2 = scriptable2;
                arrobject = new Object[]{object3};
            } else {
                object2 = memberBox.delegateTo;
                arrobject = new Object[]{scriptable2, object3};
            }
            memberBox.invoke(object2, arrobject);
            return true;
        }
    }

    private static class RelinkedSlot
    extends Slot {
        final Slot slot;

        RelinkedSlot(Slot slot) {
            super(slot.name, slot.indexOrHash, slot.attributes);
            this.slot = ScriptableObject.unwrapSlot(slot);
        }

        private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
            objectOutputStream.writeObject((Object)this.slot);
        }

        @Override
        int getAttributes() {
            return this.slot.getAttributes();
        }

        @Override
        ScriptableObject getPropertyDescriptor(Context context, Scriptable scriptable) {
            return this.slot.getPropertyDescriptor(context, scriptable);
        }

        @Override
        Object getValue(Scriptable scriptable) {
            return this.slot.getValue(scriptable);
        }

        @Override
        void markDeleted() {
            super.markDeleted();
            this.slot.markDeleted();
        }

        @Override
        void setAttributes(int n) {
            this.slot.setAttributes(n);
        }

        @Override
        boolean setValue(Object object, Scriptable scriptable, Scriptable scriptable2) {
            return this.slot.setValue(object, scriptable, scriptable2);
        }
    }

    private static class Slot
    implements Serializable {
        private static final long serialVersionUID = -6090581677123995491L;
        private volatile short attributes;
        int indexOrHash;
        String name;
        transient Slot next;
        volatile transient Slot orderedNext;
        volatile Object value;
        volatile transient boolean wasDeleted;

        Slot(String string2, int n, int n2) {
            this.name = string2;
            this.indexOrHash = n;
            this.attributes = (short)n2;
        }

        private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
            objectInputStream.defaultReadObject();
            if (this.name != null) {
                this.indexOrHash = this.name.hashCode();
            }
        }

        int getAttributes() {
            return this.attributes;
        }

        ScriptableObject getPropertyDescriptor(Context context, Scriptable scriptable) {
            return ScriptableObject.buildDataDescriptor(scriptable, this.value, this.attributes);
        }

        Object getValue(Scriptable scriptable) {
            return this.value;
        }

        void markDeleted() {
            this.wasDeleted = true;
            this.value = null;
            this.name = null;
        }

        void setAttributes(int n) {
            Slot slot = this;
            synchronized (slot) {
                ScriptableObject.checkValidAttributes(n);
                this.attributes = (short)n;
                return;
            }
        }

        boolean setValue(Object object, Scriptable scriptable, Scriptable scriptable2) {
            if ((1 & this.attributes) != 0) {
                return true;
            }
            if (scriptable == scriptable2) {
                this.value = object;
                return true;
            }
            return false;
        }
    }

}

