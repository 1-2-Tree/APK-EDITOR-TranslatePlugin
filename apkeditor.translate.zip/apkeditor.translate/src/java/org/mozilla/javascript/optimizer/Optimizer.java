/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.mozilla.javascript.optimizer;

import org.mozilla.javascript.Node;
import org.mozilla.javascript.ObjArray;
import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.ast.ScriptNode;
import org.mozilla.javascript.optimizer.Block;
import org.mozilla.javascript.optimizer.OptFunctionNode;

class Optimizer {
    static final int AnyType = 3;
    static final int NoType = 0;
    static final int NumberType = 1;
    private boolean inDirectCallFunction;
    private boolean parameterUsedInNumberContext;
    OptFunctionNode theFunction;

    Optimizer() {
    }

    private static void buildStatementList_r(Node node, ObjArray objArray) {
        int n = node.getType();
        if (n == 129 || n == 141 || n == 132 || n == 109) {
            for (Node node2 = node.getFirstChild(); node2 != null; node2 = node2.getNext()) {
                Optimizer.buildStatementList_r(node2, objArray);
            }
        } else {
            objArray.add(node);
        }
    }

    private boolean convertParameter(Node node) {
        int n;
        if (this.inDirectCallFunction && node.getType() == 55 && this.theFunction.isParameter(n = this.theFunction.getVarIndex(node))) {
            node.removeProp(8);
            return true;
        }
        return false;
    }

    private void markDCPNumberContext(Node node) {
        int n;
        if (this.inDirectCallFunction && node.getType() == 55 && this.theFunction.isParameter(n = this.theFunction.getVarIndex(node))) {
            this.parameterUsedInNumberContext = true;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void optimizeFunction(OptFunctionNode optFunctionNode) {
        Object[] arrobject;
        block6 : {
            block5 : {
                if (optFunctionNode.fnode.requiresActivation()) break block5;
                this.inDirectCallFunction = optFunctionNode.isTargetOfDirectCall();
                this.theFunction = optFunctionNode;
                ObjArray objArray = new ObjArray();
                Optimizer.buildStatementList_r(optFunctionNode.fnode, objArray);
                arrobject = new Node[objArray.size()];
                objArray.toArray(arrobject);
                Block.runFlowAnalyzes(optFunctionNode, (Node[])arrobject);
                if (!optFunctionNode.fnode.requiresActivation()) break block6;
            }
            return;
        }
        this.parameterUsedInNumberContext = false;
        int n = arrobject.length;
        int n2 = 0;
        do {
            if (n2 >= n) {
                optFunctionNode.setParameterNumberContext(this.parameterUsedInNumberContext);
                return;
            }
            this.rewriteForNumberVariables((Node)arrobject[n2], 1);
            ++n2;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void rewriteAsObjectChildren(Node node, Node node2) {
        while (node2 != null) {
            Node node3 = node2.getNext();
            if (this.rewriteForNumberVariables(node2, 0) == 1 && !this.convertParameter(node2)) {
                node.removeChild(node2);
                Node node4 = new Node(149, node2);
                if (node3 == null) {
                    node.addChildToBack(node4);
                } else {
                    node.addChildBefore(node4, node3);
                }
            }
            node2 = node3;
        }
        return;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int rewriteForNumberVariables(Node node, int n) {
        switch (node.getType()) {
            default: {
                this.rewriteAsObjectChildren(node, node.getFirstChild());
                return 0;
            }
            case 133: {
                if (this.rewriteForNumberVariables(node.getFirstChild(), 1) != 1) return 0;
                node.putIntProp(8, 0);
                return 0;
            }
            case 40: {
                node.putIntProp(8, 0);
                return 1;
            }
            case 55: {
                int n2 = this.theFunction.getVarIndex(node);
                if (this.inDirectCallFunction && this.theFunction.isParameter(n2) && n == 1) {
                    node.putIntProp(8, 0);
                    return 1;
                }
                if (!this.theFunction.isNumberVar(n2)) return 0;
                node.putIntProp(8, 0);
                return 1;
            }
            case 106: 
            case 107: {
                Node node2 = node.getFirstChild();
                int n3 = this.rewriteForNumberVariables(node2, 1);
                if (node2.getType() == 55) {
                    if (n3 != 1) return 0;
                    if (this.convertParameter(node2)) return 0;
                    node.putIntProp(8, 0);
                    this.markDCPNumberContext(node2);
                    return 1;
                }
                if (node2.getType() == 36) return n3;
                if (node2.getType() == 33) return n3;
                return 0;
            }
            case 56: 
            case 156: {
                Node node3 = node.getFirstChild().getNext();
                int n4 = this.rewriteForNumberVariables(node3, 1);
                int n5 = this.theFunction.getVarIndex(node);
                if (this.inDirectCallFunction && this.theFunction.isParameter(n5)) {
                    if (n4 != 1) return n4;
                    if (!this.convertParameter(node3)) {
                        node.putIntProp(8, 0);
                        return 1;
                    }
                    this.markDCPNumberContext(node3);
                    return 0;
                }
                if (this.theFunction.isNumberVar(n5)) {
                    if (n4 != 1) {
                        node.removeChild(node3);
                        Node node4 = new Node(150, node3);
                        node.addChildToBack(node4);
                    }
                    node.putIntProp(8, 0);
                    this.markDCPNumberContext(node3);
                    return 1;
                }
                if (n4 != 1) return 0;
                if (this.convertParameter(node3)) return 0;
                node.removeChild(node3);
                Node node5 = new Node(149, node3);
                node.addChildToBack(node5);
                return 0;
            }
            case 14: 
            case 15: 
            case 16: 
            case 17: {
                Node node6 = node.getFirstChild();
                Node node7 = node6.getNext();
                int n6 = this.rewriteForNumberVariables(node6, 1);
                int n7 = this.rewriteForNumberVariables(node7, 1);
                this.markDCPNumberContext(node6);
                this.markDCPNumberContext(node7);
                if (this.convertParameter(node6)) {
                    if (this.convertParameter(node7)) {
                        return 0;
                    }
                    if (n7 != 1) return 0;
                    node.putIntProp(8, 2);
                    do {
                        return 0;
                        break;
                    } while (true);
                }
                if (this.convertParameter(node7)) {
                    if (n6 != 1) return 0;
                    node.putIntProp(8, 1);
                    return 0;
                }
                if (n6 == 1) {
                    if (n7 == 1) {
                        node.putIntProp(8, 0);
                        return 0;
                    }
                    node.putIntProp(8, 1);
                    return 0;
                }
                if (n7 != 1) return 0;
                node.putIntProp(8, 2);
                return 0;
            }
            case 21: {
                Node node8 = node.getFirstChild();
                Node node9 = node8.getNext();
                int n8 = this.rewriteForNumberVariables(node8, 1);
                int n9 = this.rewriteForNumberVariables(node9, 1);
                if (this.convertParameter(node8)) {
                    if (this.convertParameter(node9)) {
                        return 0;
                    }
                    if (n9 != 1) return 0;
                    node.putIntProp(8, 2);
                    do {
                        return 0;
                        break;
                    } while (true);
                }
                if (this.convertParameter(node9)) {
                    if (n8 != 1) return 0;
                    node.putIntProp(8, 1);
                    return 0;
                }
                if (n8 == 1) {
                    if (n9 == 1) {
                        node.putIntProp(8, 0);
                        return 1;
                    }
                    node.putIntProp(8, 1);
                    return 0;
                }
                if (n9 != 1) return 0;
                node.putIntProp(8, 2);
                return 0;
            }
            case 9: 
            case 10: 
            case 11: 
            case 18: 
            case 19: 
            case 22: 
            case 23: 
            case 24: 
            case 25: {
                Node node10 = node.getFirstChild();
                Node node11 = node10.getNext();
                int n10 = this.rewriteForNumberVariables(node10, 1);
                int n11 = this.rewriteForNumberVariables(node11, 1);
                this.markDCPNumberContext(node10);
                this.markDCPNumberContext(node11);
                if (n10 == 1) {
                    if (n11 == 1) {
                        node.putIntProp(8, 0);
                        return 1;
                    }
                    if (this.convertParameter(node11)) return 1;
                    node.removeChild(node11);
                    Node node12 = new Node(150, node11);
                    node.addChildToBack(node12);
                    node.putIntProp(8, 0);
                    return 1;
                }
                if (n11 == 1) {
                    if (this.convertParameter(node10)) return 1;
                    node.removeChild(node10);
                    Node node13 = new Node(150, node10);
                    node.addChildToFront(node13);
                    node.putIntProp(8, 0);
                    return 1;
                }
                if (!this.convertParameter(node10)) {
                    node.removeChild(node10);
                    Node node14 = new Node(150, node10);
                    node.addChildToFront(node14);
                }
                if (!this.convertParameter(node11)) {
                    node.removeChild(node11);
                    Node node15 = new Node(150, node11);
                    node.addChildToBack(node15);
                }
                node.putIntProp(8, 0);
                return 1;
            }
            case 37: 
            case 140: {
                Node node16 = node.getFirstChild();
                Node node17 = node16.getNext();
                Node node18 = node17.getNext();
                if (this.rewriteForNumberVariables(node16, 1) == 1 && !this.convertParameter(node16)) {
                    node.removeChild(node16);
                    Node node19 = new Node(149, node16);
                    node.addChildToFront(node19);
                }
                if (this.rewriteForNumberVariables(node17, 1) == 1 && !this.convertParameter(node17)) {
                    node.putIntProp(8, 1);
                }
                if (this.rewriteForNumberVariables(node18, 1) != 1) return 0;
                if (this.convertParameter(node18)) return 0;
                node.removeChild(node18);
                Node node20 = new Node(149, node18);
                node.addChildToBack(node20);
                return 0;
            }
            case 36: {
                Node node21 = node.getFirstChild();
                Node node22 = node21.getNext();
                if (this.rewriteForNumberVariables(node21, 1) == 1 && !this.convertParameter(node21)) {
                    node.removeChild(node21);
                    Node node23 = new Node(149, node21);
                    node.addChildToFront(node23);
                }
                if (this.rewriteForNumberVariables(node22, 1) != 1) return 0;
                if (this.convertParameter(node22)) return 0;
                node.putIntProp(8, 2);
                return 0;
            }
            case 38: 
        }
        Node node24 = node.getFirstChild();
        this.rewriteAsObjectChildren(node24, node24.getFirstChild());
        Node node25 = node24.getNext();
        if ((OptFunctionNode)node.getProp(9) != null) {
            while (node25 != null) {
                if (this.rewriteForNumberVariables(node25, 1) == 1) {
                    this.markDCPNumberContext(node25);
                }
                node25 = node25.getNext();
            }
            return 0;
        }
        this.rewriteAsObjectChildren(node, node25);
        return 0;
    }

    void optimize(ScriptNode scriptNode) {
        int n = scriptNode.getFunctionCount();
        for (int i = 0; i != n; ++i) {
            this.optimizeFunction(OptFunctionNode.get(scriptNode, i));
        }
    }
}

