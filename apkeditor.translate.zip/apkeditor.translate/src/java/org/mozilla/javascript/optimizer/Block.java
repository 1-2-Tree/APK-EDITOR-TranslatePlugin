/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.BitSet
 *  java.util.HashMap
 */
package org.mozilla.javascript.optimizer;

import java.util.BitSet;
import java.util.HashMap;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.ObjArray;
import org.mozilla.javascript.ObjToIntMap;
import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.ast.Jump;
import org.mozilla.javascript.optimizer.OptFunctionNode;

class Block {
    static final boolean DEBUG;
    private static int debug_blockCount;
    private int itsBlockID;
    private int itsEndNodeIndex;
    private BitSet itsLiveOnEntrySet;
    private BitSet itsLiveOnExitSet;
    private BitSet itsNotDefSet;
    private Block[] itsPredecessors;
    private int itsStartNodeIndex;
    private Block[] itsSuccessors;
    private BitSet itsUseBeforeDefSet;

    Block(int n, int n2) {
        this.itsStartNodeIndex = n;
        this.itsEndNodeIndex = n2;
    }

    private static boolean assignType(int[] arrn, int n, int n2) {
        int n3;
        int n4 = arrn[n];
        arrn[n] = n3 = n2 | arrn[n];
        return n4 != n3;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Block[] buildBlocks(Node[] arrnode) {
        HashMap hashMap = new HashMap();
        ObjArray objArray = new ObjArray();
        int n = 0;
        block4 : for (int i = 0; i < arrnode.length; ++i) {
            switch (arrnode[i].getType()) {
                case 131: {
                    if (i != n) {
                        FatBlock fatBlock = Block.newFatBlock(n, i - 1);
                        if (arrnode[n].getType() == 131) {
                            hashMap.put((Object)arrnode[n], (Object)fatBlock);
                        }
                        objArray.add(fatBlock);
                        n = i;
                    }
                }
                default: {
                    continue block4;
                }
                case 5: 
                case 6: 
                case 7: {
                    FatBlock fatBlock = Block.newFatBlock(n, i);
                    if (arrnode[n].getType() == 131) {
                        hashMap.put((Object)arrnode[n], (Object)fatBlock);
                    }
                    objArray.add(fatBlock);
                    n = i + 1;
                }
            }
        }
        if (n != arrnode.length) {
            FatBlock fatBlock = Block.newFatBlock(n, -1 + arrnode.length);
            if (arrnode[n].getType() == 131) {
                hashMap.put((Object)arrnode[n], (Object)fatBlock);
            }
            objArray.add(fatBlock);
        }
        for (int i = 0; i < objArray.size(); ++i) {
            FatBlock fatBlock = (FatBlock)objArray.get(i);
            Node node = arrnode[fatBlock.realBlock.itsEndNodeIndex];
            int n2 = node.getType();
            if (n2 != 5 && i < -1 + objArray.size()) {
                FatBlock fatBlock2 = (FatBlock)objArray.get(i + 1);
                fatBlock.addSuccessor(fatBlock2);
                fatBlock2.addPredecessor(fatBlock);
            }
            if (n2 != 7 && n2 != 6 && n2 != 5) continue;
            Node node2 = ((Jump)node).target;
            FatBlock fatBlock3 = (FatBlock)hashMap.get((Object)node2);
            node2.putProp(6, fatBlock3.realBlock);
            fatBlock.addSuccessor(fatBlock3);
            fatBlock3.addPredecessor(fatBlock);
        }
        Block[] arrblock = new Block[objArray.size()];
        int n3 = 0;
        while (n3 < objArray.size()) {
            FatBlock fatBlock = (FatBlock)objArray.get(n3);
            Block block = fatBlock.realBlock;
            block.itsSuccessors = fatBlock.getSuccessors();
            block.itsPredecessors = fatBlock.getPredecessors();
            block.itsBlockID = n3++;
            arrblock[n3] = block;
        }
        return arrblock;
    }

    private boolean doReachedUseDataFlow() {
        this.itsLiveOnExitSet.clear();
        if (this.itsSuccessors != null) {
            for (int i = 0; i < this.itsSuccessors.length; ++i) {
                this.itsLiveOnExitSet.or(this.itsSuccessors[i].itsLiveOnEntrySet);
            }
        }
        return this.updateEntrySet(this.itsLiveOnEntrySet, this.itsLiveOnExitSet, this.itsUseBeforeDefSet, this.itsNotDefSet);
    }

    private boolean doTypeFlow(OptFunctionNode optFunctionNode, Node[] arrnode, int[] arrn) {
        boolean bl = false;
        for (int i = this.itsStartNodeIndex; i <= this.itsEndNodeIndex; ++i) {
            Node node = arrnode[i];
            if (node == null) continue;
            bl |= Block.findDefPoints(optFunctionNode, node, arrn);
        }
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean findDefPoints(OptFunctionNode optFunctionNode, Node node, int[] arrn) {
        Node node2;
        boolean bl = false;
        for (Node node3 = node2 = node.getFirstChild(); node3 != null; bl |= Block.findDefPoints((OptFunctionNode)optFunctionNode, (Node)node3, (int[])arrn), node3 = node3.getNext()) {
        }
        switch (node.getType()) {
            case 106: 
            case 107: {
                if (node2.getType() != 55) return bl;
                {
                    int n = optFunctionNode.getVarIndex(node2);
                    if (optFunctionNode.fnode.getParamAndVarConst()[n]) return bl;
                    return bl | Block.assignType(arrn, n, 1);
                }
            }
            default: {
                return bl;
            }
            case 56: 
            case 156: {
                int n = Block.findExpressionType(optFunctionNode, node2.getNext(), arrn);
                int n2 = optFunctionNode.getVarIndex(node);
                if (node.getType() == 56 && optFunctionNode.fnode.getParamAndVarConst()[n2]) return bl;
                return bl | Block.assignType(arrn, n2, n);
            }
        }
    }

    private static int findExpressionType(OptFunctionNode optFunctionNode, Node node, int[] arrn) {
        int n = 1;
        switch (node.getType()) {
            default: {
                n = 3;
            }
            case 9: 
            case 10: 
            case 11: 
            case 18: 
            case 19: 
            case 20: 
            case 22: 
            case 23: 
            case 24: 
            case 25: 
            case 27: 
            case 28: 
            case 29: 
            case 40: 
            case 106: 
            case 107: {
                return n;
            }
            case 30: 
            case 38: 
            case 70: {
                return 3;
            }
            case 33: 
            case 36: 
            case 39: 
            case 43: {
                return 3;
            }
            case 55: {
                return arrn[optFunctionNode.getVarIndex(node)];
            }
            case 126: {
                return 3;
            }
            case 12: 
            case 13: 
            case 14: 
            case 15: 
            case 16: 
            case 17: 
            case 26: 
            case 31: 
            case 44: 
            case 45: 
            case 46: 
            case 47: 
            case 52: 
            case 53: 
            case 69: {
                return 3;
            }
            case 32: 
            case 41: 
            case 137: {
                return 3;
            }
            case 42: 
            case 48: 
            case 65: 
            case 66: 
            case 157: {
                return 3;
            }
            case 21: {
                Node node2 = node.getFirstChild();
                return Block.findExpressionType(optFunctionNode, node2, arrn) | Block.findExpressionType(optFunctionNode, node2.getNext(), arrn);
            }
            case 102: {
                Node node3 = node.getFirstChild().getNext();
                Node node4 = node3.getNext();
                return Block.findExpressionType(optFunctionNode, node3, arrn) | Block.findExpressionType(optFunctionNode, node4, arrn);
            }
            case 8: 
            case 35: 
            case 37: 
            case 56: 
            case 89: 
            case 156: {
                return Block.findExpressionType(optFunctionNode, node.getLastChild(), arrn);
            }
            case 104: 
            case 105: 
        }
        Node node5 = node.getFirstChild();
        return Block.findExpressionType(optFunctionNode, node5, arrn) | Block.findExpressionType(optFunctionNode, node5.getNext(), arrn);
    }

    private void initLiveOnEntrySets(OptFunctionNode optFunctionNode, Node[] arrnode) {
        int n = optFunctionNode.getVarCount();
        this.itsUseBeforeDefSet = new BitSet(n);
        this.itsNotDefSet = new BitSet(n);
        this.itsLiveOnEntrySet = new BitSet(n);
        this.itsLiveOnExitSet = new BitSet(n);
        for (int i = this.itsStartNodeIndex; i <= this.itsEndNodeIndex; ++i) {
            this.lookForVariableAccess(optFunctionNode, arrnode[i]);
        }
        this.itsNotDefSet.flip(0, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void lookForVariableAccess(OptFunctionNode optFunctionNode, Node node) {
        switch (node.getType()) {
            default: {
                for (Node node2 = node.getFirstChild(); node2 != null; node2 = node2.getNext()) {
                    this.lookForVariableAccess(optFunctionNode, node2);
                }
                return;
            }
            case 137: {
                int n = optFunctionNode.fnode.getIndexForNameNode(node);
                if (n <= -1 || this.itsNotDefSet.get(n)) return;
                this.itsUseBeforeDefSet.set(n);
                return;
            }
            case 106: 
            case 107: {
                Node node3 = node.getFirstChild();
                if (node3.getType() != 55) {
                    this.lookForVariableAccess(optFunctionNode, node3);
                    return;
                }
                int n = optFunctionNode.getVarIndex(node3);
                if (!this.itsNotDefSet.get(n)) {
                    this.itsUseBeforeDefSet.set(n);
                }
                this.itsNotDefSet.set(n);
                return;
            }
            case 56: 
            case 156: {
                this.lookForVariableAccess(optFunctionNode, node.getFirstChild().getNext());
                this.itsNotDefSet.set(optFunctionNode.getVarIndex(node));
                return;
            }
            case 55: {
                int n = optFunctionNode.getVarIndex(node);
                if (this.itsNotDefSet.get(n)) return;
                this.itsUseBeforeDefSet.set(n);
                return;
            }
        }
    }

    private void markAnyTypeVariables(int[] arrn) {
        for (int i = 0; i != arrn.length; ++i) {
            if (!this.itsLiveOnEntrySet.get(i)) continue;
            Block.assignType(arrn, i, 3);
        }
    }

    private static FatBlock newFatBlock(int n, int n2) {
        FatBlock fatBlock = new FatBlock();
        fatBlock.realBlock = new Block(n, n2);
        return fatBlock;
    }

    private void printLiveOnEntrySet(OptFunctionNode optFunctionNode) {
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void reachingDefDataFlow(OptFunctionNode optFunctionNode, Node[] arrnode, Block[] arrblock, int[] arrn) {
        for (int i = 0; i < arrblock.length; ++i) {
            arrblock[i].initLiveOnEntrySets(optFunctionNode, arrnode);
        }
        boolean[] arrbl = new boolean[arrblock.length];
        boolean[] arrbl2 = new boolean[arrblock.length];
        int n = -1 + arrblock.length;
        boolean bl = false;
        arrbl[n] = true;
        do {
            if (arrbl[n] || !arrbl2[n]) {
                Block[] arrblock2;
                arrbl2[n] = true;
                arrbl[n] = false;
                if (arrblock[n].doReachedUseDataFlow() && (arrblock2 = arrblock[n].itsPredecessors) != null) {
                    boolean bl2;
                    for (int i = 0; i < arrblock2.length; bl |= bl2, ++i) {
                        int n2 = arrblock2[i].itsBlockID;
                        arrbl[n2] = true;
                        bl2 = n2 > n;
                    }
                }
            }
            if (n == 0) {
                if (!bl) {
                    arrblock[0].markAnyTypeVariables(arrn);
                    return;
                }
                n = -1 + arrblock.length;
                bl = false;
                continue;
            }
            --n;
        } while (true);
    }

    static void runFlowAnalyzes(OptFunctionNode optFunctionNode, Node[] arrnode) {
        int n = optFunctionNode.fnode.getParamCount();
        int n2 = optFunctionNode.fnode.getParamAndVarCount();
        int[] arrn = new int[n2];
        for (int i = 0; i != n; ++i) {
            arrn[i] = 3;
        }
        for (int i = n; i != n2; ++i) {
            arrn[i] = 0;
        }
        Block[] arrblock = Block.buildBlocks(arrnode);
        Block.reachingDefDataFlow(optFunctionNode, arrnode, arrblock, arrn);
        Block.typeFlow(optFunctionNode, arrnode, arrblock, arrn);
        for (int i = n; i != n2; ++i) {
            if (arrn[i] != 1) continue;
            optFunctionNode.setIsNumberVar(i);
        }
    }

    private static String toString(Block[] arrblock, Node[] arrnode) {
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void typeFlow(OptFunctionNode optFunctionNode, Node[] arrnode, Block[] arrblock, int[] arrn) {
        boolean[] arrbl = new boolean[arrblock.length];
        boolean[] arrbl2 = new boolean[arrblock.length];
        int n = 0;
        boolean bl = false;
        arrbl[0] = true;
        do {
            if (arrbl[n] || !arrbl2[n]) {
                Block[] arrblock2;
                arrbl2[n] = true;
                arrbl[n] = false;
                if (arrblock[n].doTypeFlow(optFunctionNode, arrnode, arrn) && (arrblock2 = arrblock[n].itsSuccessors) != null) {
                    boolean bl2;
                    for (int i = 0; i < arrblock2.length; bl |= bl2, ++i) {
                        int n2 = arrblock2[i].itsBlockID;
                        arrbl[n2] = true;
                        bl2 = n2 < n;
                    }
                }
            }
            if (n == -1 + arrblock.length) {
                if (!bl) {
                    return;
                }
                bl = false;
                n = 0;
                continue;
            }
            ++n;
        } while (true);
    }

    private boolean updateEntrySet(BitSet bitSet, BitSet bitSet2, BitSet bitSet3, BitSet bitSet4) {
        int n = bitSet.cardinality();
        bitSet.or(bitSet2);
        bitSet.and(bitSet4);
        bitSet.or(bitSet3);
        return bitSet.cardinality() != n;
    }

    private static class FatBlock {
        private ObjToIntMap predecessors = new ObjToIntMap();
        Block realBlock;
        private ObjToIntMap successors = new ObjToIntMap();

        private FatBlock() {
        }

        private static Block[] reduceToArray(ObjToIntMap objToIntMap) {
            boolean bl = objToIntMap.isEmpty();
            Block[] arrblock = null;
            if (!bl) {
                arrblock = new Block[objToIntMap.size()];
                int n = 0;
                ObjToIntMap.Iterator iterator = objToIntMap.newIterator();
                iterator.start();
                while (!iterator.done()) {
                    FatBlock fatBlock = (FatBlock)iterator.getKey();
                    int n2 = n + 1;
                    arrblock[n] = fatBlock.realBlock;
                    iterator.next();
                    n = n2;
                }
            }
            return arrblock;
        }

        void addPredecessor(FatBlock fatBlock) {
            this.predecessors.put(fatBlock, 0);
        }

        void addSuccessor(FatBlock fatBlock) {
            this.successors.put(fatBlock, 0);
        }

        Block[] getPredecessors() {
            return FatBlock.reduceToArray(this.predecessors);
        }

        Block[] getSuccessors() {
            return FatBlock.reduceToArray(this.successors);
        }
    }

}

