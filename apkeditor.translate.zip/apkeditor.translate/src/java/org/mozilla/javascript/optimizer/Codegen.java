/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.lang.reflect.Constructor
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package org.mozilla.javascript.optimizer;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.mozilla.classfile.ClassFileWriter;
import org.mozilla.javascript.CompilerEnvirons;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Evaluator;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.GeneratedClassLoader;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.NativeFunction;
import org.mozilla.javascript.ObjArray;
import org.mozilla.javascript.ObjToIntMap;
import org.mozilla.javascript.RhinoException;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.SecurityController;
import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.ast.Name;
import org.mozilla.javascript.ast.ScriptNode;
import org.mozilla.javascript.optimizer.BodyCodegen;
import org.mozilla.javascript.optimizer.OptFunctionNode;
import org.mozilla.javascript.optimizer.OptTransformer;
import org.mozilla.javascript.optimizer.Optimizer;

public class Codegen
implements Evaluator {
    static final String DEFAULT_MAIN_METHOD_CLASS = "org.mozilla.javascript.optimizer.OptRuntime";
    static final String FUNCTION_CONSTRUCTOR_SIGNATURE = "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;I)V";
    static final String FUNCTION_INIT_SIGNATURE = "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)V";
    static final String ID_FIELD_NAME = "_id";
    static final String REGEXP_INIT_METHOD_NAME = "_reInit";
    static final String REGEXP_INIT_METHOD_SIGNATURE = "(Lorg/mozilla/javascript/Context;)V";
    private static final String SUPER_CLASS_NAME = "org.mozilla.javascript.NativeFunction";
    private static final Object globalLock = new Object();
    private static int globalSerialClassCounter;
    private CompilerEnvirons compilerEnv;
    private ObjArray directCallTargets;
    private double[] itsConstantList;
    private int itsConstantListSize;
    String mainClassName;
    String mainClassSignature;
    private String mainMethodClass = "org.mozilla.javascript.optimizer.OptRuntime";
    private ObjToIntMap scriptOrFnIndexes;
    ScriptNode[] scriptOrFnNodes;

    private static void addDoubleWrap(ClassFileWriter classFileWriter) {
        classFileWriter.addInvoke(184, "org/mozilla/javascript/optimizer/OptRuntime", "wrapDouble", "(D)Ljava/lang/Double;");
    }

    static RuntimeException badTree() {
        throw new RuntimeException("Bad tree in codegen");
    }

    private static void collectScriptNodes_r(ScriptNode scriptNode, ObjArray objArray) {
        objArray.add(scriptNode);
        int n = scriptNode.getFunctionCount();
        for (int i = 0; i != n; ++i) {
            Codegen.collectScriptNodes_r(scriptNode.getFunctionNode(i), objArray);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Class<?> defineClass(Object object, Object object2) {
        Throwable throwable;
        Object[] arrobject = (Object[])object;
        String string2 = (String)arrobject[0];
        byte[] arrby = (byte[])arrobject[1];
        GeneratedClassLoader generatedClassLoader = SecurityController.createLoader(this.getClass().getClassLoader(), object2);
        try {
            Class<?> class_ = generatedClassLoader.defineClass(string2, arrby);
            generatedClassLoader.linkClass(class_);
            return class_;
        }
        catch (SecurityException securityException) {
            throwable = securityException;
            do {
                throw new RuntimeException("Malformed optimizer package " + throwable);
                break;
            } while (true);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            throwable = illegalArgumentException;
            throw new RuntimeException("Malformed optimizer package " + throwable);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void emitConstantDudeInitializers(ClassFileWriter classFileWriter) {
        int n = this.itsConstantListSize;
        if (n == 0) {
            return;
        }
        classFileWriter.startMethod("<clinit>", "()V", (short)24);
        double[] arrd = this.itsConstantList;
        int n2 = 0;
        do {
            if (n2 == n) {
                classFileWriter.add(177);
                classFileWriter.stopMethod((short)0);
                return;
            }
            double d = arrd[n2];
            String string2 = "_k" + n2;
            String string3 = Codegen.getStaticConstantWrapperType(d);
            classFileWriter.addField(string2, string3, (short)10);
            int n3 = (int)d;
            if ((double)n3 == d) {
                classFileWriter.addPush(n3);
                classFileWriter.addInvoke(184, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;");
            } else {
                classFileWriter.addPush(d);
                Codegen.addDoubleWrap(classFileWriter);
            }
            classFileWriter.add(179, this.mainClassName, string2, string3);
            ++n2;
        } while (true);
    }

    private void emitDirectConstructor(ClassFileWriter classFileWriter, OptFunctionNode optFunctionNode) {
        classFileWriter.startMethod(this.getDirectCtorName(optFunctionNode.fnode), this.getBodyMethodSignature(optFunctionNode.fnode), (short)10);
        int n = optFunctionNode.fnode.getParamCount();
        int n2 = 1 + (4 + n * 3);
        classFileWriter.addALoad(0);
        classFileWriter.addALoad(1);
        classFileWriter.addALoad(2);
        classFileWriter.addInvoke(182, "org/mozilla/javascript/BaseFunction", "createObject", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
        classFileWriter.addAStore(n2);
        classFileWriter.addALoad(0);
        classFileWriter.addALoad(1);
        classFileWriter.addALoad(2);
        classFileWriter.addALoad(n2);
        for (int i = 0; i < n; ++i) {
            classFileWriter.addALoad(4 + i * 3);
            classFileWriter.addDLoad(5 + i * 3);
        }
        classFileWriter.addALoad(4 + n * 3);
        classFileWriter.addInvoke(184, this.mainClassName, this.getBodyMethodName(optFunctionNode.fnode), this.getBodyMethodSignature(optFunctionNode.fnode));
        int n3 = classFileWriter.acquireLabel();
        classFileWriter.add(89);
        classFileWriter.add(193, "org/mozilla/javascript/Scriptable");
        classFileWriter.add(153, n3);
        classFileWriter.add(192, "org/mozilla/javascript/Scriptable");
        classFileWriter.add(176);
        classFileWriter.markLabel(n3);
        classFileWriter.addALoad(n2);
        classFileWriter.add(176);
        classFileWriter.stopMethod((short)(n2 + 1));
    }

    /*
     * Enabled aggressive block sorting
     */
    private void emitRegExpInit(ClassFileWriter classFileWriter) {
        int n = 0;
        for (int i = 0; i != this.scriptOrFnNodes.length; n += this.scriptOrFnNodes[i].getRegexpCount(), ++i) {
        }
        if (n == 0) {
            return;
        }
        classFileWriter.startMethod(REGEXP_INIT_METHOD_NAME, REGEXP_INIT_METHOD_SIGNATURE, (short)10);
        classFileWriter.addField("_reInitDone", "Z", (short)74);
        classFileWriter.add(178, this.mainClassName, "_reInitDone", "Z");
        int n2 = classFileWriter.acquireLabel();
        classFileWriter.add(153, n2);
        classFileWriter.add(177);
        classFileWriter.markLabel(n2);
        classFileWriter.addALoad(0);
        classFileWriter.addInvoke(184, "org/mozilla/javascript/ScriptRuntime", "checkRegExpProxy", "(Lorg/mozilla/javascript/Context;)Lorg/mozilla/javascript/RegExpProxy;");
        classFileWriter.addAStore(1);
        int n3 = 0;
        do {
            if (n3 == this.scriptOrFnNodes.length) {
                classFileWriter.addPush(1);
                classFileWriter.add(179, this.mainClassName, "_reInitDone", "Z");
                classFileWriter.add(177);
                classFileWriter.stopMethod((short)2);
                return;
            }
            ScriptNode scriptNode = this.scriptOrFnNodes[n3];
            int n4 = scriptNode.getRegexpCount();
            for (int i = 0; i != n4; ++i) {
                String string2 = this.getCompiledRegexpName(scriptNode, i);
                String string3 = scriptNode.getRegexpString(i);
                String string4 = scriptNode.getRegexpFlags(i);
                classFileWriter.addField(string2, "Ljava/lang/Object;", (short)10);
                classFileWriter.addALoad(1);
                classFileWriter.addALoad(0);
                classFileWriter.addPush(string3);
                if (string4 == null) {
                    classFileWriter.add(1);
                } else {
                    classFileWriter.addPush(string4);
                }
                classFileWriter.addInvoke(185, "org/mozilla/javascript/RegExpProxy", "compileRegExp", "(Lorg/mozilla/javascript/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;");
                classFileWriter.add(179, this.mainClassName, string2, "Ljava/lang/Object;");
            }
            ++n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void generateCallMethod(ClassFileWriter classFileWriter) {
        classFileWriter.startMethod("call", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;", (short)17);
        int n = classFileWriter.acquireLabel();
        classFileWriter.addALoad(1);
        classFileWriter.addInvoke(184, "org/mozilla/javascript/ScriptRuntime", "hasTopCall", "(Lorg/mozilla/javascript/Context;)Z");
        classFileWriter.add(154, n);
        classFileWriter.addALoad(0);
        classFileWriter.addALoad(1);
        classFileWriter.addALoad(2);
        classFileWriter.addALoad(3);
        classFileWriter.addALoad(4);
        classFileWriter.addInvoke(184, "org/mozilla/javascript/ScriptRuntime", "doTopCall", "(Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;");
        classFileWriter.add(176);
        classFileWriter.markLabel(n);
        classFileWriter.addALoad(0);
        classFileWriter.addALoad(1);
        classFileWriter.addALoad(2);
        classFileWriter.addALoad(3);
        classFileWriter.addALoad(4);
        int n2 = this.scriptOrFnNodes.length;
        boolean bl = 2 <= n2;
        short s = 0;
        int n3 = 0;
        if (bl) {
            classFileWriter.addLoadThis();
            classFileWriter.add(180, classFileWriter.getClassName(), ID_FIELD_NAME, "I");
            n3 = classFileWriter.addTableSwitch(1, n2 - 1);
        }
        int n4 = 0;
        do {
            int n5;
            OptFunctionNode optFunctionNode;
            if (n4 == n2) {
                classFileWriter.stopMethod((short)5);
                return;
            }
            ScriptNode scriptNode = this.scriptOrFnNodes[n4];
            if (bl) {
                if (n4 == 0) {
                    classFileWriter.markTableSwitchDefault(n3);
                    s = classFileWriter.getStackTop();
                } else {
                    int n6 = n4 - 1;
                    classFileWriter.markTableSwitchCase(n3, n6, s);
                }
            }
            if (scriptNode.getType() == 109 && (optFunctionNode = OptFunctionNode.get(scriptNode)).isTargetOfDirectCall() && (n5 = optFunctionNode.fnode.getParamCount()) != 0) {
                for (int i = 0; i != n5; ++i) {
                    classFileWriter.add(190);
                    classFileWriter.addPush(i);
                    int n7 = classFileWriter.acquireLabel();
                    int n8 = classFileWriter.acquireLabel();
                    classFileWriter.add(164, n7);
                    classFileWriter.addALoad(4);
                    classFileWriter.addPush(i);
                    classFileWriter.add(50);
                    classFileWriter.add(167, n8);
                    classFileWriter.markLabel(n7);
                    Codegen.pushUndefined(classFileWriter);
                    classFileWriter.markLabel(n8);
                    classFileWriter.adjustStackTop(-1);
                    classFileWriter.addPush(0.0);
                    classFileWriter.addALoad(4);
                }
            }
            classFileWriter.addInvoke(184, this.mainClassName, this.getBodyMethodName(scriptNode), this.getBodyMethodSignature(scriptNode));
            classFileWriter.add(176);
            ++n4;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private byte[] generateCode(String var1_1) {
        var2_2 = this.scriptOrFnNodes[0].getType() == 136;
        var3_3 = this.scriptOrFnNodes.length > 1 || var2_2 == false;
        var4_4 = this.compilerEnv.isGenerateDebugInfo();
        var5_5 = null;
        if (var4_4) {
            var5_5 = this.scriptOrFnNodes[0].getSourceName();
        }
        var6_6 = new ClassFileWriter(this.mainClassName, "org.mozilla.javascript.NativeFunction", var5_5);
        var6_6.addField("_id", "I", (short)2);
        if (var3_3) {
            this.generateFunctionConstructor(var6_6);
        }
        if (var2_2) {
            var6_6.addInterface("org/mozilla/javascript/Script");
            this.generateScriptCtor(var6_6);
            this.generateMain(var6_6);
            this.generateExecute(var6_6);
        }
        this.generateCallMethod(var6_6);
        this.generateResumeGenerator(var6_6);
        this.generateNativeFunctionOverrides(var6_6, var1_1);
        var7_7 = this.scriptOrFnNodes.length;
        var8_8 = 0;
        do lbl-1000: // 2 sources:
        {
            if (var8_8 == var7_7) {
                this.emitRegExpInit(var6_6);
                this.emitConstantDudeInitializers(var6_6);
                return var6_6.toByteArray();
            }
            var9_9 = this.scriptOrFnNodes[var8_8];
            var10_10 = new BodyCodegen();
            var10_10.cfw = var6_6;
            var10_10.codegen = this;
            var10_10.compilerEnv = this.compilerEnv;
            var10_10.scriptOrFn = var9_9;
            var10_10.scriptOrFnIndex = var8_8;
            var10_10.generateBodyCode();
            break;
        } while (true);
        catch (ClassFileWriter.ClassFileFormatException var11_12) {
            throw this.reportClassFileFormatException(var9_9, var11_12.getMessage());
        }
        {
            if (var9_9.getType() == 109) {
                var12_11 = OptFunctionNode.get(var9_9);
                this.generateFunctionInit(var6_6, var12_11);
                if (var12_11.isTargetOfDirectCall()) {
                    this.emitDirectConstructor(var6_6, var12_11);
                }
            }
            ++var8_8;
            ** while (true)
        }
    }

    private void generateExecute(ClassFileWriter classFileWriter) {
        classFileWriter.startMethod("exec", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;", (short)17);
        classFileWriter.addLoadThis();
        classFileWriter.addALoad(1);
        classFileWriter.addALoad(2);
        classFileWriter.add(89);
        classFileWriter.add(1);
        classFileWriter.addInvoke(182, classFileWriter.getClassName(), "call", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;");
        classFileWriter.add(176);
        classFileWriter.stopMethod((short)3);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void generateFunctionConstructor(ClassFileWriter classFileWriter) {
        classFileWriter.startMethod("<init>", FUNCTION_CONSTRUCTOR_SIGNATURE, (short)1);
        classFileWriter.addALoad(0);
        classFileWriter.addInvoke(183, SUPER_CLASS_NAME, "<init>", "()V");
        classFileWriter.addLoadThis();
        classFileWriter.addILoad(3);
        classFileWriter.add(181, classFileWriter.getClassName(), ID_FIELD_NAME, "I");
        classFileWriter.addLoadThis();
        classFileWriter.addALoad(2);
        classFileWriter.addALoad(1);
        int n = this.scriptOrFnNodes[0].getType() == 136 ? 1 : 0;
        int n2 = this.scriptOrFnNodes.length;
        if (n == n2) {
            throw Codegen.badTree();
        }
        boolean bl = 2 <= n2 - n;
        short s = 0;
        int n3 = 0;
        if (bl) {
            classFileWriter.addILoad(3);
            n3 = classFileWriter.addTableSwitch(n + 1, n2 - 1);
        }
        int n4 = n;
        do {
            if (n4 == n2) {
                classFileWriter.stopMethod((short)4);
                return;
            }
            if (bl) {
                if (n4 == n) {
                    classFileWriter.markTableSwitchDefault(n3);
                    s = classFileWriter.getStackTop();
                } else {
                    classFileWriter.markTableSwitchCase(n3, n4 - 1 - n, s);
                }
            }
            OptFunctionNode optFunctionNode = OptFunctionNode.get(this.scriptOrFnNodes[n4]);
            classFileWriter.addInvoke(183, this.mainClassName, this.getFunctionInitMethodName(optFunctionNode), FUNCTION_INIT_SIGNATURE);
            classFileWriter.add(177);
            ++n4;
        } while (true);
    }

    private void generateFunctionInit(ClassFileWriter classFileWriter, OptFunctionNode optFunctionNode) {
        classFileWriter.startMethod(this.getFunctionInitMethodName(optFunctionNode), FUNCTION_INIT_SIGNATURE, (short)18);
        classFileWriter.addLoadThis();
        classFileWriter.addALoad(1);
        classFileWriter.addALoad(2);
        classFileWriter.addInvoke(182, "org/mozilla/javascript/NativeFunction", "initScriptFunction", FUNCTION_INIT_SIGNATURE);
        if (optFunctionNode.fnode.getRegexpCount() != 0) {
            classFileWriter.addALoad(1);
            classFileWriter.addInvoke(184, this.mainClassName, REGEXP_INIT_METHOD_NAME, REGEXP_INIT_METHOD_SIGNATURE);
        }
        classFileWriter.add(177);
        classFileWriter.stopMethod((short)3);
    }

    private void generateMain(ClassFileWriter classFileWriter) {
        classFileWriter.startMethod("main", "([Ljava/lang/String;)V", (short)9);
        classFileWriter.add(187, classFileWriter.getClassName());
        classFileWriter.add(89);
        classFileWriter.addInvoke(183, classFileWriter.getClassName(), "<init>", "()V");
        classFileWriter.add(42);
        classFileWriter.addInvoke(184, this.mainMethodClass, "main", "(Lorg/mozilla/javascript/Script;[Ljava/lang/String;)V");
        classFileWriter.add(177);
        classFileWriter.stopMethod((short)1);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void generateNativeFunctionOverrides(ClassFileWriter var1_1, String var2_2) {
        block38 : {
            var1_1.startMethod("getLanguageVersion", "()I", (short)1);
            var1_1.addPush(this.compilerEnv.getLanguageVersion());
            var1_1.add(172);
            var1_1.stopMethod((short)1);
            var3_3 = 0;
            block16 : while (var3_3 != 6) {
                if (var3_3 != 4 || var2_2 != null) {
                    switch (var3_3) {
                        default: {
                            throw Kit.codeBug();
                        }
                        case 0: {
                            var4_4 = 1;
                            var1_1.startMethod("getFunctionName", "()Ljava/lang/String;", (short)1);
                            break;
                        }
                        case 1: {
                            var4_4 = 1;
                            var1_1.startMethod("getParamCount", "()I", (short)1);
                            break;
                        }
                        case 2: {
                            var4_4 = 1;
                            var1_1.startMethod("getParamAndVarCount", "()I", (short)1);
                            break;
                        }
                        case 3: {
                            var4_4 = 2;
                            var1_1.startMethod("getParamOrVarName", "(I)Ljava/lang/String;", (short)1);
                            break;
                        }
                        case 5: {
                            var4_4 = 3;
                            var1_1.startMethod("getParamOrVarConst", "(I)Z", (short)1);
                            break;
                        }
                        case 4: {
                            var4_4 = 1;
                            var1_1.startMethod("getEncodedSource", "()Ljava/lang/String;", (short)1);
                            var1_1.addPush(var2_2);
                        }
                    }
                    var5_5 = this.scriptOrFnNodes.length;
                    var6_6 = 0;
                    var7_7 = 0;
                    if (var5_5 > 1) {
                        var1_1.addLoadThis();
                        var1_1.add(180, var1_1.getClassName(), "_id", "I");
                        var7_7 = var1_1.addTableSwitch(1, var5_5 - 1);
                    }
                    break block38;
                }
lbl43: // 3 sources:
                do {
                    ++var3_3;
                    continue block16;
                    break;
                } while (true);
            }
            return;
        }
        block18 : for (var8_8 = 0; var8_8 != var5_5; ++var8_8) {
            var9_9 = this.scriptOrFnNodes[var8_8];
            if (var8_8 == 0) {
                if (var5_5 > 1) {
                    var1_1.markTableSwitchDefault(var7_7);
                    var6_6 = var1_1.getStackTop();
                }
            } else {
                var10_10 = var8_8 - 1;
                var1_1.markTableSwitchCase(var7_7, var10_10, var6_6);
            }
            switch (var3_3) {
                default: {
                    throw Kit.codeBug();
                }
                case 0: {
                    if (var9_9.getType() == 136) {
                        var1_1.addPush("");
                    } else {
                        var1_1.addPush(((FunctionNode)var9_9).getName());
                    }
                    var1_1.add(176);
                    continue block18;
                }
                case 1: {
                    var1_1.addPush(var9_9.getParamCount());
                    var1_1.add(172);
                    continue block18;
                }
                case 2: {
                    var1_1.addPush(var9_9.getParamAndVarCount());
                    var1_1.add(172);
                    continue block18;
                }
                case 3: {
                    var16_15 = var9_9.getParamAndVarCount();
                    if (var16_15 == 0) {
                        var1_1.add(1);
                        var1_1.add(176);
                        continue block18;
                    }
                    if (var16_15 == 1) {
                        var1_1.addPush(var9_9.getParamOrVarName(0));
                        var1_1.add(176);
                        continue block18;
                    }
                    var1_1.addILoad(1);
                    var17_16 = var1_1.addTableSwitch(1, var16_15 - 1);
                    for (var18_17 = 0; var18_17 != var16_15; ++var18_17) {
                        if (var1_1.getStackTop() != 0) {
                            Kit.codeBug();
                        }
                        var19_18 = var9_9.getParamOrVarName(var18_17);
                        if (var18_17 == 0) {
                            var1_1.markTableSwitchDefault(var17_16);
                        } else {
                            var1_1.markTableSwitchCase(var17_16, var18_17 - 1, 0);
                        }
                        var1_1.addPush(var19_18);
                        var1_1.add(176);
                    }
                    continue block18;
                }
                case 5: {
                    var11_11 = var9_9.getParamAndVarCount();
                    var12_12 = var9_9.getParamAndVarConst();
                    if (var11_11 == 0) {
                        var1_1.add(3);
                        var1_1.add(172);
                        continue block18;
                    }
                    if (var11_11 == 1) {
                        var1_1.addPush(var12_12[0]);
                        var1_1.add(172);
                        continue block18;
                    }
                    var1_1.addILoad(1);
                    var13_13 = var1_1.addTableSwitch(1, var11_11 - 1);
                    for (var14_14 = 0; var14_14 != var11_11; ++var14_14) {
                        if (var1_1.getStackTop() != 0) {
                            Kit.codeBug();
                        }
                        if (var14_14 == 0) {
                            var1_1.markTableSwitchDefault(var13_13);
                        } else {
                            var1_1.markTableSwitchCase(var13_13, var14_14 - 1, 0);
                        }
                        var1_1.addPush(var12_12[var14_14]);
                        var1_1.add(172);
                    }
                    continue block18;
                }
                case 4: {
                    var1_1.addPush(var9_9.getEncodedSourceStart());
                    var1_1.addPush(var9_9.getEncodedSourceEnd());
                    var1_1.addInvoke(182, "java/lang/String", "substring", "(II)Ljava/lang/String;");
                    var1_1.add(176);
                }
            }
        }
        var1_1.stopMethod(var4_4);
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     */
    private void generateResumeGenerator(ClassFileWriter classFileWriter) {
        boolean bl = false;
        for (int i = 0; i < this.scriptOrFnNodes.length; ++i) {
            if (!Codegen.isGenerator(this.scriptOrFnNodes[i])) continue;
            bl = true;
        }
        if (!bl) {
            return;
        }
        classFileWriter.startMethod("resumeGenerator", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", (short)17);
        classFileWriter.addALoad(0);
        classFileWriter.addALoad(1);
        classFileWriter.addALoad(2);
        classFileWriter.addALoad(4);
        classFileWriter.addALoad(5);
        classFileWriter.addILoad(3);
        classFileWriter.addLoadThis();
        classFileWriter.add(180, classFileWriter.getClassName(), ID_FIELD_NAME, "I");
        int n = classFileWriter.addTableSwitch(0, -1 + this.scriptOrFnNodes.length);
        classFileWriter.markTableSwitchDefault(n);
        int n2 = classFileWriter.acquireLabel();
        int n3 = 0;
        do {
            if (n3 >= this.scriptOrFnNodes.length) {
                classFileWriter.markLabel(n2);
                Codegen.pushUndefined(classFileWriter);
                classFileWriter.add(176);
                classFileWriter.stopMethod((short)6);
                return;
            }
            ScriptNode scriptNode = this.scriptOrFnNodes[n3];
            classFileWriter.markTableSwitchCase(n, n3, 6);
            if (Codegen.isGenerator(scriptNode)) {
                String string2 = "(" + this.mainClassSignature + "Lorg/mozilla/javascript/Context;" + "Lorg/mozilla/javascript/Scriptable;" + "Ljava/lang/Object;" + "Ljava/lang/Object;I)Ljava/lang/Object;";
                classFileWriter.addInvoke(184, this.mainClassName, this.getBodyMethodName(scriptNode) + "_gen", string2);
                classFileWriter.add(176);
            } else {
                classFileWriter.add(167, n2);
            }
            ++n3;
        } while (true);
    }

    private void generateScriptCtor(ClassFileWriter classFileWriter) {
        classFileWriter.startMethod("<init>", "()V", (short)1);
        classFileWriter.addLoadThis();
        classFileWriter.addInvoke(183, SUPER_CLASS_NAME, "<init>", "()V");
        classFileWriter.addLoadThis();
        classFileWriter.addPush(0);
        classFileWriter.add(181, classFileWriter.getClassName(), ID_FIELD_NAME, "I");
        classFileWriter.add(177);
        classFileWriter.stopMethod((short)1);
    }

    private static String getStaticConstantWrapperType(double d) {
        if ((double)((int)d) == d) {
            return "Ljava/lang/Integer;";
        }
        return "Ljava/lang/Double;";
    }

    private static void initOptFunctions_r(ScriptNode scriptNode) {
        int n = scriptNode.getFunctionCount();
        for (int i = 0; i != n; ++i) {
            FunctionNode functionNode = scriptNode.getFunctionNode(i);
            new OptFunctionNode(functionNode);
            Codegen.initOptFunctions_r(functionNode);
        }
    }

    private void initScriptNodesData(ScriptNode scriptNode) {
        ObjArray objArray = new ObjArray();
        Codegen.collectScriptNodes_r(scriptNode, objArray);
        int n = objArray.size();
        this.scriptOrFnNodes = new ScriptNode[n];
        objArray.toArray(this.scriptOrFnNodes);
        this.scriptOrFnIndexes = new ObjToIntMap(n);
        for (int i = 0; i != n; ++i) {
            this.scriptOrFnIndexes.put(this.scriptOrFnNodes[i], i);
        }
    }

    static boolean isGenerator(ScriptNode scriptNode) {
        return scriptNode.getType() == 109 && ((FunctionNode)scriptNode).isGenerator();
    }

    static void pushUndefined(ClassFileWriter classFileWriter) {
        classFileWriter.add(178, "org/mozilla/javascript/Undefined", "instance", "Ljava/lang/Object;");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private RuntimeException reportClassFileFormatException(ScriptNode scriptNode, String string2) {
        String string3;
        if (scriptNode instanceof FunctionNode) {
            string3 = ScriptRuntime.getMessage2("msg.while.compiling.fn", ((FunctionNode)scriptNode).getFunctionName(), string2);
            do {
                return Context.reportRuntimeError(string3, scriptNode.getSourceName(), scriptNode.getLineno(), null, 0);
                break;
            } while (true);
        }
        string3 = ScriptRuntime.getMessage1("msg.while.compiling.script", string2);
        return Context.reportRuntimeError(string3, scriptNode.getSourceName(), scriptNode.getLineno(), null, 0);
    }

    private void transform(ScriptNode scriptNode) {
        Codegen.initOptFunctions_r(scriptNode);
        int n = this.compilerEnv.getOptimizationLevel();
        HashMap hashMap = null;
        if (n > 0) {
            int n2 = scriptNode.getType();
            hashMap = null;
            if (n2 == 136) {
                int n3 = scriptNode.getFunctionCount();
                for (int i = 0; i != n3; ++i) {
                    String string2;
                    OptFunctionNode optFunctionNode = OptFunctionNode.get(scriptNode, i);
                    if (optFunctionNode.fnode.getFunctionType() != 1 || (string2 = optFunctionNode.fnode.getName()).length() == 0) continue;
                    if (hashMap == null) {
                        hashMap = new HashMap();
                    }
                    hashMap.put((Object)string2, (Object)optFunctionNode);
                }
            }
        }
        if (hashMap != null) {
            this.directCallTargets = new ObjArray();
        }
        new OptTransformer((Map<String, OptFunctionNode>)hashMap, this.directCallTargets).transform(scriptNode);
        if (n > 0) {
            new Optimizer().optimize(scriptNode);
        }
    }

    @Override
    public void captureStackInfo(RhinoException rhinoException) {
        throw new UnsupportedOperationException();
    }

    String cleanName(ScriptNode scriptNode) {
        if (scriptNode instanceof FunctionNode) {
            Name name = ((FunctionNode)scriptNode).getFunctionName();
            if (name == null) {
                return "anonymous";
            }
            return name.getIdentifier();
        }
        return "script";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object compile(CompilerEnvirons compilerEnvirons, ScriptNode scriptNode, String string2, boolean bl) {
        int n;
        Object object;
        Object object2 = object = globalLock;
        synchronized (object2) {
            globalSerialClassCounter = n = 1 + globalSerialClassCounter;
        }
        String string3 = "c";
        if (scriptNode.getSourceName().length() > 0 && !Character.isJavaIdentifierStart((char)(string3 = scriptNode.getSourceName().replaceAll("\\W", "_")).charAt(0))) {
            string3 = "_" + string3;
        }
        String string4 = "org.mozilla.javascript.gen." + string3 + "_" + n;
        return new Object[]{string4, this.compileToClassFile(compilerEnvirons, string4, scriptNode, string2, bl)};
    }

    public byte[] compileToClassFile(CompilerEnvirons compilerEnvirons, String string2, ScriptNode scriptNode, String string3, boolean bl) {
        this.compilerEnv = compilerEnvirons;
        this.transform(scriptNode);
        if (bl) {
            scriptNode = scriptNode.getFunctionNode(0);
        }
        this.initScriptNodesData(scriptNode);
        this.mainClassName = string2;
        this.mainClassSignature = ClassFileWriter.classNameToSignature(string2);
        try {
            byte[] arrby = this.generateCode(string3);
            return arrby;
        }
        catch (ClassFileWriter.ClassFileFormatException classFileFormatException) {
            throw this.reportClassFileFormatException(scriptNode, classFileFormatException.getMessage());
        }
    }

    @Override
    public Function createFunctionObject(Context context, Scriptable scriptable, Object object, Object object2) {
        Class<?> class_ = this.defineClass(object, object2);
        try {
            Constructor constructor = class_.getConstructors()[0];
            Object[] arrobject = new Object[]{scriptable, context, 0};
            NativeFunction nativeFunction = (NativeFunction)constructor.newInstance(arrobject);
            return nativeFunction;
        }
        catch (Exception exception) {
            throw new RuntimeException("Unable to instantiate compiled class:" + exception.toString());
        }
    }

    @Override
    public Script createScriptObject(Object object, Object object2) {
        Class<?> class_ = this.defineClass(object, object2);
        try {
            Script script = (Script)class_.newInstance();
            return script;
        }
        catch (Exception exception) {
            throw new RuntimeException("Unable to instantiate compiled class:" + exception.toString());
        }
    }

    String getBodyMethodName(ScriptNode scriptNode) {
        return "_c_" + this.cleanName(scriptNode) + "_" + this.getIndex(scriptNode);
    }

    String getBodyMethodSignature(ScriptNode scriptNode) {
        OptFunctionNode optFunctionNode;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('(');
        stringBuilder.append(this.mainClassSignature);
        stringBuilder.append("Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;");
        if (scriptNode.getType() == 109 && (optFunctionNode = OptFunctionNode.get(scriptNode)).isTargetOfDirectCall()) {
            int n = optFunctionNode.fnode.getParamCount();
            for (int i = 0; i != n; ++i) {
                stringBuilder.append("Ljava/lang/Object;D");
            }
        }
        stringBuilder.append("[Ljava/lang/Object;)Ljava/lang/Object;");
        return stringBuilder.toString();
    }

    String getCompiledRegexpName(ScriptNode scriptNode, int n) {
        return "_re" + this.getIndex(scriptNode) + "_" + n;
    }

    String getDirectCtorName(ScriptNode scriptNode) {
        return "_n" + this.getIndex(scriptNode);
    }

    String getFunctionInitMethodName(OptFunctionNode optFunctionNode) {
        return "_i" + this.getIndex(optFunctionNode.fnode);
    }

    int getIndex(ScriptNode scriptNode) {
        return this.scriptOrFnIndexes.getExisting(scriptNode);
    }

    @Override
    public String getPatchedStack(RhinoException rhinoException, String string2) {
        throw new UnsupportedOperationException();
    }

    @Override
    public List<String> getScriptStack(RhinoException rhinoException) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String getSourcePositionFromStack(Context context, int[] arrn) {
        throw new UnsupportedOperationException();
    }

    /*
     * Enabled aggressive block sorting
     */
    void pushNumberAsObject(ClassFileWriter classFileWriter, double d) {
        int n;
        if (d == 0.0) {
            if (1.0 / d > 0.0) {
                classFileWriter.add(178, "org/mozilla/javascript/optimizer/OptRuntime", "zeroObj", "Ljava/lang/Double;");
                return;
            }
            classFileWriter.addPush(d);
            Codegen.addDoubleWrap(classFileWriter);
            return;
        }
        if (d == 1.0) {
            classFileWriter.add(178, "org/mozilla/javascript/optimizer/OptRuntime", "oneObj", "Ljava/lang/Double;");
            return;
        }
        if (d == -1.0) {
            classFileWriter.add(178, "org/mozilla/javascript/optimizer/OptRuntime", "minusOneObj", "Ljava/lang/Double;");
            return;
        }
        if (d != d) {
            classFileWriter.add(178, "org/mozilla/javascript/ScriptRuntime", "NaNobj", "Ljava/lang/Double;");
            return;
        }
        if (this.itsConstantListSize >= 2000) {
            classFileWriter.addPush(d);
            Codegen.addDoubleWrap(classFileWriter);
            return;
        }
        int n2 = this.itsConstantListSize;
        if (n2 == 0) {
            this.itsConstantList = new double[64];
        } else {
            double[] arrd = this.itsConstantList;
            for (n = 0; n != n2 && arrd[n] != d; ++n) {
            }
            if (n2 == arrd.length) {
                double[] arrd2 = new double[n2 * 2];
                System.arraycopy((Object)this.itsConstantList, (int)0, (Object)arrd2, (int)0, (int)n2);
                this.itsConstantList = arrd2;
            }
        }
        if (n == n2) {
            this.itsConstantList[n2] = d;
            this.itsConstantListSize = n2 + 1;
        }
        String string2 = "_k" + n;
        String string3 = Codegen.getStaticConstantWrapperType(d);
        classFileWriter.add(178, this.mainClassName, string2, string3);
    }

    @Override
    public void setEvalScriptFlag(Script script) {
        throw new UnsupportedOperationException();
    }

    public void setMainMethodClass(String string2) {
        this.mainMethodClass = string2;
    }
}

