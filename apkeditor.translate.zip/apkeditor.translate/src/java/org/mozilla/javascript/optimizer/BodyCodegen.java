/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.ListIterator
 *  java.util.Map
 *  java.util.Set
 */
package org.mozilla.javascript.optimizer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import org.mozilla.classfile.ClassFileWriter;
import org.mozilla.javascript.CompilerEnvirons;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.Token;
import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.ast.Jump;
import org.mozilla.javascript.ast.ScriptNode;
import org.mozilla.javascript.optimizer.Codegen;
import org.mozilla.javascript.optimizer.OptFunctionNode;
import org.mozilla.javascript.optimizer.OptRuntime;

class BodyCodegen {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    private static final int ECMAERROR_EXCEPTION = 2;
    private static final int EVALUATOR_EXCEPTION = 1;
    private static final int EXCEPTION_MAX = 5;
    private static final int FINALLY_EXCEPTION = 4;
    static final int GENERATOR_START = 0;
    static final int GENERATOR_TERMINATE = -1;
    static final int GENERATOR_YIELD_START = 1;
    private static final int JAVASCRIPT_EXCEPTION = 0;
    private static final int MAX_LOCALS = 1024;
    private static final int THROWABLE_EXCEPTION = 3;
    private short argsLocal;
    ClassFileWriter cfw;
    Codegen codegen;
    CompilerEnvirons compilerEnv;
    private short contextLocal;
    private int enterAreaStartLabel;
    private int epilogueLabel;
    private ExceptionManager exceptionManager = new ExceptionManager();
    private Map<Node, FinallyReturnPoint> finallys;
    private short firstFreeLocal;
    private OptFunctionNode fnCurrent;
    private short funObjLocal;
    private short generatorStateLocal;
    private int generatorSwitch;
    private boolean hasVarsInRegs;
    private boolean inDirectCallFunction;
    private boolean inLocalBlock;
    private boolean isGenerator;
    private boolean itsForcedObjectParameters;
    private int itsLineNumber;
    private short itsOneArgArray;
    private short itsZeroArgArray;
    private List<Node> literals;
    private int[] locals;
    private short localsMax;
    private int maxLocals = 0;
    private int maxStack = 0;
    private short operationLocal;
    private short popvLocal;
    private int savedCodeOffset;
    ScriptNode scriptOrFn;
    public int scriptOrFnIndex;
    private short thisObjLocal;
    private short[] varRegisters;
    private short variableObjectLocal;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !BodyCodegen.class.desiredAssertionStatus();
        $assertionsDisabled = bl;
    }

    BodyCodegen() {
    }

    private void addDoubleWrap() {
        this.addOptRuntimeInvoke("wrapDouble", "(D)Ljava/lang/Double;");
    }

    private void addGoto(Node node, int n) {
        int n2 = this.getTargetLabel(node);
        this.cfw.add(n, n2);
    }

    private void addGotoWithReturn(Node node) {
        FinallyReturnPoint finallyReturnPoint = (FinallyReturnPoint)this.finallys.get((Object)node);
        this.cfw.addLoadConstant(finallyReturnPoint.jsrPoints.size());
        this.addGoto(node, 167);
        int n = this.cfw.acquireLabel();
        this.cfw.markLabel(n);
        finallyReturnPoint.jsrPoints.add((Object)n);
    }

    private void addInstructionCount() {
        this.addInstructionCount(Math.max((int)(this.cfw.getCurrentCodeOffset() - this.savedCodeOffset), (int)1));
    }

    private void addInstructionCount(int n) {
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addPush(n);
        this.addScriptRuntimeInvoke("addInstructionCount", "(Lorg/mozilla/javascript/Context;I)V");
    }

    private void addJumpedBooleanWrap(int n, int n2) {
        this.cfw.markLabel(n2);
        int n3 = this.cfw.acquireLabel();
        this.cfw.add(178, "java/lang/Boolean", "FALSE", "Ljava/lang/Boolean;");
        this.cfw.add(167, n3);
        this.cfw.markLabel(n);
        this.cfw.add(178, "java/lang/Boolean", "TRUE", "Ljava/lang/Boolean;");
        this.cfw.markLabel(n3);
        this.cfw.adjustStackTop(-1);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void addLoadPropertyIds(Object[] arrobject, int n) {
        this.addNewObjectArray(n);
        int n2 = 0;
        while (n2 != n) {
            this.cfw.add(89);
            this.cfw.addPush(n2);
            Object object = arrobject[n2];
            if (object instanceof String) {
                this.cfw.addPush((String)object);
            } else {
                this.cfw.addPush((Integer)object);
                this.addScriptRuntimeInvoke("wrapInt", "(I)Ljava/lang/Integer;");
            }
            this.cfw.add(83);
            ++n2;
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void addLoadPropertyValues(Node node, Node node2, int n) {
        Node node3;
        if (!this.isGenerator) {
            this.addNewObjectArray(n);
            node3 = node2;
        } else {
            for (int n2 = 0; n2 != n; node2 = node2.getNext(), ++n2) {
                int n3 = node2.getType();
                if (n3 == 151 || n3 == 152 || n3 == 163) {
                    this.generateExpression(node2.getFirstChild(), node);
                    continue;
                }
                this.generateExpression(node2, node);
            }
            this.addNewObjectArray(n);
            for (int i = 0; i != n; ++i) {
                this.cfw.add(90);
                this.cfw.add(95);
                this.cfw.addPush(-1 + (n - i));
                this.cfw.add(95);
                this.cfw.add(83);
            }
            return;
        }
        for (int n4 = 0; n4 != n; node3 = node3.getNext(), ++n4) {
            this.cfw.add(89);
            this.cfw.addPush(n4);
            int n5 = node3.getType();
            if (n5 == 151 || n5 == 152 || n5 == 163) {
                this.generateExpression(node3.getFirstChild(), node);
            } else {
                this.generateExpression(node3, node);
            }
            this.cfw.add(83);
        }
    }

    private void addNewObjectArray(int n) {
        if (n == 0) {
            if (this.itsZeroArgArray >= 0) {
                this.cfw.addALoad(this.itsZeroArgArray);
                return;
            }
            this.cfw.add(178, "org/mozilla/javascript/ScriptRuntime", "emptyArgs", "[Ljava/lang/Object;");
            return;
        }
        this.cfw.addPush(n);
        this.cfw.add(189, "java/lang/Object");
    }

    private void addObjectToDouble() {
        this.addScriptRuntimeInvoke("toNumber", "(Ljava/lang/Object;)D");
    }

    private void addOptRuntimeInvoke(String string2, String string3) {
        this.cfw.addInvoke(184, "org/mozilla/javascript/optimizer/OptRuntime", string2, string3);
    }

    private void addScriptRuntimeInvoke(String string2, String string3) {
        this.cfw.addInvoke(184, "org.mozilla.javascript.ScriptRuntime", string2, string3);
    }

    private void dcpLoadAsNumber(int n) {
        this.cfw.addALoad(n);
        this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
        int n2 = this.cfw.acquireLabel();
        this.cfw.add(165, n2);
        short s = this.cfw.getStackTop();
        this.cfw.addALoad(n);
        this.addObjectToDouble();
        int n3 = this.cfw.acquireLabel();
        this.cfw.add(167, n3);
        this.cfw.markLabel(n2, s);
        this.cfw.addDLoad(n + 1);
        this.cfw.markLabel(n3);
    }

    private void dcpLoadAsObject(int n) {
        this.cfw.addALoad(n);
        this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
        int n2 = this.cfw.acquireLabel();
        this.cfw.add(165, n2);
        short s = this.cfw.getStackTop();
        this.cfw.addALoad(n);
        int n3 = this.cfw.acquireLabel();
        this.cfw.add(167, n3);
        this.cfw.markLabel(n2, s);
        this.cfw.addDLoad(n + 1);
        this.addDoubleWrap();
        this.cfw.markLabel(n3);
    }

    private void decReferenceWordLocal(short s) {
        int[] arrn = this.locals;
        arrn[s] = -1 + arrn[s];
    }

    private String exceptionTypeToName(int n) {
        if (n == 0) {
            return "org/mozilla/javascript/JavaScriptException";
        }
        if (n == 1) {
            return "org/mozilla/javascript/EvaluatorException";
        }
        if (n == 2) {
            return "org/mozilla/javascript/EcmaError";
        }
        if (n == 3) {
            return "java/lang/Throwable";
        }
        if (n == 4) {
            return null;
        }
        throw Kit.codeBug();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void genSimpleCompare(int n, int n2, int n3) {
        if (n2 == -1) {
            throw Codegen.badTree();
        }
        switch (n) {
            default: {
                throw Codegen.badTree();
            }
            case 15: {
                this.cfw.add(152);
                this.cfw.add(158, n2);
                break;
            }
            case 17: {
                this.cfw.add(151);
                this.cfw.add(156, n2);
                break;
            }
            case 14: {
                this.cfw.add(152);
                this.cfw.add(155, n2);
                break;
            }
            case 16: {
                this.cfw.add(151);
                this.cfw.add(157, n2);
            }
        }
        if (n3 != -1) {
            this.cfw.add(167, n3);
        }
    }

    private void generateActivationExit() {
        if (this.fnCurrent == null || this.hasVarsInRegs) {
            throw Kit.codeBug();
        }
        this.cfw.addALoad(this.contextLocal);
        this.addScriptRuntimeInvoke("exitActivationFunction", "(Lorg/mozilla/javascript/Context;)V");
    }

    private void generateArrayLiteralFactory(Node node, int n) {
        String string2 = this.codegen.getBodyMethodName(this.scriptOrFn) + "_literal" + n;
        this.initBodyGeneration();
        short s = this.firstFreeLocal;
        this.firstFreeLocal = (short)(s + 1);
        this.argsLocal = s;
        this.localsMax = this.firstFreeLocal;
        this.cfw.startMethod(string2, "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;", (short)2);
        this.visitArrayLiteral(node, node.getFirstChild(), true);
        this.cfw.add(176);
        this.cfw.stopMethod((short)(1 + this.localsMax));
    }

    /*
     * Enabled aggressive block sorting
     */
    private void generateCallArgArray(Node node, Node node2, boolean bl) {
        int n = 0;
        for (Node node3 = node2; node3 != null; ++n, node3 = node3.getNext()) {
        }
        if (n == 1 && this.itsOneArgArray >= 0) {
            this.cfw.addALoad(this.itsOneArgArray);
        } else {
            this.addNewObjectArray(n);
        }
        int n2 = 0;
        while (n2 != n) {
            if (!this.isGenerator) {
                this.cfw.add(89);
                this.cfw.addPush(n2);
            }
            if (!bl) {
                this.generateExpression(node2, node);
            } else {
                int n3 = this.nodeIsDirectCallParameter(node2);
                if (n3 >= 0) {
                    this.dcpLoadAsObject(n3);
                } else {
                    this.generateExpression(node2, node);
                    if (node2.getIntProp(8, -1) == 0) {
                        this.addDoubleWrap();
                    }
                }
            }
            if (this.isGenerator) {
                short s = this.getNewWordLocal();
                this.cfw.addAStore(s);
                this.cfw.add(192, "[Ljava/lang/Object;");
                this.cfw.add(89);
                this.cfw.addPush(n2);
                this.cfw.addALoad(s);
                this.releaseWordLocal(s);
            }
            this.cfw.add(83);
            node2 = node2.getNext();
            ++n2;
        }
        return;
    }

    private void generateCatchBlock(int n, short s, int n2, int n3, int n4) {
        if (n4 == 0) {
            n4 = this.cfw.acquireLabel();
        }
        this.cfw.markHandler(n4);
        this.cfw.addAStore(n3);
        this.cfw.addALoad(s);
        this.cfw.addAStore(this.variableObjectLocal);
        this.exceptionTypeToName(n);
        this.cfw.add(167, n2);
    }

    private void generateCheckForThrowOrClose(int n, boolean bl, int n2) {
        int n3 = this.cfw.acquireLabel();
        int n4 = this.cfw.acquireLabel();
        this.cfw.markLabel(n3);
        this.cfw.addALoad(this.argsLocal);
        this.generateThrowJavaScriptException();
        this.cfw.markLabel(n4);
        this.cfw.addALoad(this.argsLocal);
        this.cfw.add(192, "java/lang/Throwable");
        this.cfw.add(191);
        if (n != -1) {
            this.cfw.markLabel(n);
        }
        if (!bl) {
            this.cfw.markTableSwitchCase(this.generatorSwitch, n2);
        }
        this.cfw.addILoad(this.operationLocal);
        this.cfw.addLoadConstant(2);
        this.cfw.add(159, n4);
        this.cfw.addILoad(this.operationLocal);
        this.cfw.addLoadConstant(1);
        this.cfw.add(159, n3);
    }

    private void generateEpilogue() {
        if (this.compilerEnv.isGenerateObserverCount()) {
            this.addInstructionCount();
        }
        if (this.isGenerator) {
            Map<Node, int[]> map = ((FunctionNode)this.scriptOrFn).getLiveLocals();
            if (map != null) {
                List<Node> list = ((FunctionNode)this.scriptOrFn).getResumptionPoints();
                for (int i = 0; i < list.size(); ++i) {
                    Node node = (Node)list.get(i);
                    int[] arrn = (int[])map.get((Object)node);
                    if (arrn == null) continue;
                    this.cfw.markTableSwitchCase(this.generatorSwitch, this.getNextGeneratorState(node));
                    this.generateGetGeneratorLocalsState();
                    for (int j = 0; j < arrn.length; ++j) {
                        this.cfw.add(89);
                        this.cfw.addLoadConstant(j);
                        this.cfw.add(50);
                        this.cfw.addAStore(arrn[j]);
                    }
                    this.cfw.add(87);
                    this.cfw.add(167, this.getTargetLabel(node));
                }
            }
            if (this.finallys != null) {
                for (Node node : this.finallys.keySet()) {
                    if (node.getType() != 125) continue;
                    FinallyReturnPoint finallyReturnPoint = (FinallyReturnPoint)this.finallys.get((Object)node);
                    this.cfw.markLabel(finallyReturnPoint.tableLabel, (short)1);
                    int n = this.cfw.addTableSwitch(0, -1 + finallyReturnPoint.jsrPoints.size());
                    int n2 = 0;
                    this.cfw.markTableSwitchDefault(n);
                    for (int i = 0; i < finallyReturnPoint.jsrPoints.size(); ++i) {
                        this.cfw.markTableSwitchCase(n, n2);
                        this.cfw.add(167, (Integer)finallyReturnPoint.jsrPoints.get(i));
                        ++n2;
                    }
                }
            }
        }
        if (this.epilogueLabel != -1) {
            this.cfw.markLabel(this.epilogueLabel);
        }
        if (this.hasVarsInRegs) {
            this.cfw.add(176);
            return;
        }
        if (this.isGenerator) {
            if (((FunctionNode)this.scriptOrFn).getResumptionPoints() != null) {
                this.cfw.markTableSwitchDefault(this.generatorSwitch);
            }
            this.generateSetGeneratorResumptionPoint(-1);
            this.cfw.addALoad(this.variableObjectLocal);
            this.addOptRuntimeInvoke("throwStopIteration", "(Ljava/lang/Object;)V");
            Codegen.pushUndefined(this.cfw);
            this.cfw.add(176);
            return;
        }
        if (this.fnCurrent == null) {
            this.cfw.addALoad(this.popvLocal);
            this.cfw.add(176);
            return;
        }
        this.generateActivationExit();
        this.cfw.add(176);
        int n = this.cfw.acquireLabel();
        this.cfw.markHandler(n);
        short s = this.getNewWordLocal();
        this.cfw.addAStore(s);
        this.generateActivationExit();
        this.cfw.addALoad(s);
        this.releaseWordLocal(s);
        this.cfw.add(191);
        this.cfw.addExceptionHandler(this.enterAreaStartLabel, this.epilogueLabel, n, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void generateExpression(Node node, Node node2) {
        int n = node.getType();
        Node node3 = node.getFirstChild();
        switch (n) {
            default: {
                throw new RuntimeException("Unexpected node type " + n);
            }
            case 109: {
                if (this.fnCurrent != null || node2.getType() != 136) {
                    int n2 = node.getExistingIntProp(1);
                    OptFunctionNode optFunctionNode = OptFunctionNode.get(this.scriptOrFn, n2);
                    int n3 = optFunctionNode.fnode.getFunctionType();
                    if (n3 != 2) {
                        throw Codegen.badTree();
                    }
                    this.visitFunction(optFunctionNode, n3);
                }
            }
            case 138: {
                return;
            }
            case 39: {
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                this.cfw.addPush(node.getString());
                this.addScriptRuntimeInvoke("name", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Ljava/lang/Object;");
                return;
            }
            case 30: 
            case 38: {
                int n4 = node.getIntProp(10, 0);
                if (n4 != 0) {
                    this.visitSpecialCall(node, n, n4, node3);
                    return;
                }
                OptFunctionNode optFunctionNode = (OptFunctionNode)node.getProp(9);
                if (optFunctionNode != null) {
                    this.visitOptimizedCall(node, optFunctionNode, n, node3);
                    return;
                }
                if (n == 38) {
                    this.visitStandardCall(node, node3);
                    return;
                }
                this.visitStandardNew(node, node3);
                return;
            }
            case 70: {
                this.generateFunctionAndThisObj(node3, node);
                this.generateCallArgArray(node, node3.getNext(), false);
                this.cfw.addALoad(this.contextLocal);
                this.addScriptRuntimeInvoke("callRef", "(Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Lorg/mozilla/javascript/Ref;");
                return;
            }
            case 40: {
                double d = node.getDouble();
                if (node.getIntProp(8, -1) != -1) {
                    this.cfw.addPush(d);
                    return;
                }
                this.codegen.pushNumberAsObject(this.cfw, d);
                return;
            }
            case 41: {
                this.cfw.addPush(node.getString());
                return;
            }
            case 43: {
                this.cfw.addALoad(this.thisObjLocal);
                return;
            }
            case 63: {
                this.cfw.add(42);
                return;
            }
            case 42: {
                this.cfw.add(1);
                return;
            }
            case 45: {
                this.cfw.add(178, "java/lang/Boolean", "TRUE", "Ljava/lang/Boolean;");
                return;
            }
            case 44: {
                this.cfw.add(178, "java/lang/Boolean", "FALSE", "Ljava/lang/Boolean;");
                return;
            }
            case 48: {
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                int n5 = node.getExistingIntProp(4);
                this.cfw.add(178, this.codegen.mainClassName, this.codegen.getCompiledRegexpName(this.scriptOrFn, n5), "Ljava/lang/Object;");
                this.cfw.addInvoke(184, "org/mozilla/javascript/ScriptRuntime", "wrapRegExp", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
                return;
            }
            case 89: {
                Node node4 = node3.getNext();
                do {
                    if (node4 == null) {
                        this.generateExpression(node3, node);
                        return;
                    }
                    this.generateExpression(node3, node);
                    this.cfw.add(87);
                    node3 = node4;
                    node4 = node4.getNext();
                } while (true);
            }
            case 61: 
            case 62: {
                int n6 = this.getLocalBlockRegister(node);
                this.cfw.addALoad(n6);
                if (n == 61) {
                    this.addScriptRuntimeInvoke("enumNext", "(Ljava/lang/Object;)Ljava/lang/Boolean;");
                    return;
                }
                this.cfw.addALoad(this.contextLocal);
                this.addScriptRuntimeInvoke("enumId", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
                return;
            }
            case 65: {
                this.visitArrayLiteral(node, node3, false);
                return;
            }
            case 66: {
                this.visitObjectLiteral(node, node3, false);
                return;
            }
            case 26: {
                int n7 = this.cfw.acquireLabel();
                int n8 = this.cfw.acquireLabel();
                int n9 = this.cfw.acquireLabel();
                this.generateIfJump(node3, node, n7, n8);
                this.cfw.markLabel(n7);
                this.cfw.add(178, "java/lang/Boolean", "FALSE", "Ljava/lang/Boolean;");
                this.cfw.add(167, n9);
                this.cfw.markLabel(n8);
                this.cfw.add(178, "java/lang/Boolean", "TRUE", "Ljava/lang/Boolean;");
                this.cfw.markLabel(n9);
                this.cfw.adjustStackTop(-1);
                return;
            }
            case 27: {
                this.generateExpression(node3, node);
                this.addScriptRuntimeInvoke("toInt32", "(Ljava/lang/Object;)I");
                this.cfw.addPush(-1);
                this.cfw.add(130);
                this.cfw.add(135);
                this.addDoubleWrap();
                return;
            }
            case 126: {
                this.generateExpression(node3, node);
                this.cfw.add(87);
                Codegen.pushUndefined(this.cfw);
                return;
            }
            case 32: {
                this.generateExpression(node3, node);
                this.addScriptRuntimeInvoke("typeof", "(Ljava/lang/Object;)Ljava/lang/String;");
                return;
            }
            case 137: {
                this.visitTypeofname(node);
                return;
            }
            case 106: 
            case 107: {
                this.visitIncDec(node);
                return;
            }
            case 104: 
            case 105: {
                this.generateExpression(node3, node);
                this.cfw.add(89);
                this.addScriptRuntimeInvoke("toBoolean", "(Ljava/lang/Object;)Z");
                int n10 = this.cfw.acquireLabel();
                if (n == 105) {
                    this.cfw.add(153, n10);
                } else {
                    this.cfw.add(154, n10);
                }
                this.cfw.add(87);
                this.generateExpression(node3.getNext(), node);
                this.cfw.markLabel(n10);
                return;
            }
            case 102: {
                Node node5 = node3.getNext();
                Node node6 = node5.getNext();
                this.generateExpression(node3, node);
                this.addScriptRuntimeInvoke("toBoolean", "(Ljava/lang/Object;)Z");
                int n11 = this.cfw.acquireLabel();
                this.cfw.add(153, n11);
                short s = this.cfw.getStackTop();
                this.generateExpression(node5, node);
                int n12 = this.cfw.acquireLabel();
                this.cfw.add(167, n12);
                this.cfw.markLabel(n11, s);
                this.generateExpression(node6, node);
                this.cfw.markLabel(n12);
                return;
            }
            case 21: {
                this.generateExpression(node3, node);
                this.generateExpression(node3.getNext(), node);
                switch (node.getIntProp(8, -1)) {
                    default: {
                        if (node3.getType() != 41) break;
                        this.addScriptRuntimeInvoke("add", "(Ljava/lang/CharSequence;Ljava/lang/Object;)Ljava/lang/CharSequence;");
                        return;
                    }
                    case 0: {
                        this.cfw.add(99);
                        return;
                    }
                    case 1: {
                        this.addOptRuntimeInvoke("add", "(DLjava/lang/Object;)Ljava/lang/Object;");
                        return;
                    }
                    case 2: {
                        this.addOptRuntimeInvoke("add", "(Ljava/lang/Object;D)Ljava/lang/Object;");
                        return;
                    }
                }
                if (node3.getNext().getType() == 41) {
                    this.addScriptRuntimeInvoke("add", "(Ljava/lang/Object;Ljava/lang/CharSequence;)Ljava/lang/CharSequence;");
                    return;
                }
                this.cfw.addALoad(this.contextLocal);
                this.addScriptRuntimeInvoke("add", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
                return;
            }
            case 23: {
                this.visitArithmetic(node, 107, node3, node2);
                return;
            }
            case 22: {
                this.visitArithmetic(node, 103, node3, node2);
                return;
            }
            case 24: 
            case 25: {
                int n13 = n == 24 ? 111 : 115;
                this.visitArithmetic(node, n13, node3, node2);
                return;
            }
            case 9: 
            case 10: 
            case 11: 
            case 18: 
            case 19: 
            case 20: {
                this.visitBitOp(node, n, node3);
                return;
            }
            case 28: 
            case 29: {
                this.generateExpression(node3, node);
                this.addObjectToDouble();
                if (n == 29) {
                    this.cfw.add(119);
                }
                this.addDoubleWrap();
                return;
            }
            case 150: {
                this.generateExpression(node3, node);
                this.addObjectToDouble();
                return;
            }
            case 149: {
                int n14 = -1;
                if (node3.getType() == 40) {
                    n14 = node3.getIntProp(8, -1);
                }
                if (n14 != -1) {
                    node3.removeProp(8);
                    this.generateExpression(node3, node);
                    node3.putIntProp(8, n14);
                    return;
                }
                this.generateExpression(node3, node);
                this.addDoubleWrap();
                return;
            }
            case 14: 
            case 15: 
            case 16: 
            case 17: 
            case 52: 
            case 53: {
                int n15 = this.cfw.acquireLabel();
                int n16 = this.cfw.acquireLabel();
                this.visitIfJumpRelOp(node, node3, n15, n16);
                this.addJumpedBooleanWrap(n15, n16);
                return;
            }
            case 12: 
            case 13: 
            case 46: 
            case 47: {
                int n17 = this.cfw.acquireLabel();
                int n18 = this.cfw.acquireLabel();
                this.visitIfJumpEqOp(node, node3, n17, n18);
                this.addJumpedBooleanWrap(n17, n18);
                return;
            }
            case 33: 
            case 34: {
                this.visitGetProp(node, node3);
                return;
            }
            case 36: {
                this.generateExpression(node3, node);
                this.generateExpression(node3.getNext(), node);
                this.cfw.addALoad(this.contextLocal);
                if (node.getIntProp(8, -1) != -1) {
                    this.addScriptRuntimeInvoke("getObjectIndex", "(Ljava/lang/Object;DLorg/mozilla/javascript/Context;)Ljava/lang/Object;");
                    return;
                }
                this.cfw.addALoad(this.variableObjectLocal);
                this.addScriptRuntimeInvoke("getObjectElem", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
                return;
            }
            case 67: {
                this.generateExpression(node3, node);
                this.cfw.addALoad(this.contextLocal);
                this.addScriptRuntimeInvoke("refGet", "(Lorg/mozilla/javascript/Ref;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
                return;
            }
            case 55: {
                this.visitGetVar(node);
                return;
            }
            case 56: {
                this.visitSetVar(node, node3, true);
                return;
            }
            case 8: {
                this.visitSetName(node, node3);
                return;
            }
            case 73: {
                this.visitStrictSetName(node, node3);
                return;
            }
            case 155: {
                this.visitSetConst(node, node3);
                return;
            }
            case 156: {
                this.visitSetConstVar(node, node3, true);
                return;
            }
            case 35: 
            case 139: {
                this.visitSetProp(n, node, node3);
                return;
            }
            case 37: 
            case 140: {
                this.visitSetElem(n, node, node3);
                return;
            }
            case 68: 
            case 142: {
                this.generateExpression(node3, node);
                Node node7 = node3.getNext();
                if (n == 142) {
                    this.cfw.add(89);
                    this.cfw.addALoad(this.contextLocal);
                    this.addScriptRuntimeInvoke("refGet", "(Lorg/mozilla/javascript/Ref;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
                }
                this.generateExpression(node7, node);
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                this.addScriptRuntimeInvoke("refSet", "(Lorg/mozilla/javascript/Ref;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
                return;
            }
            case 69: {
                this.generateExpression(node3, node);
                this.cfw.addALoad(this.contextLocal);
                this.addScriptRuntimeInvoke("refDel", "(Lorg/mozilla/javascript/Ref;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
                return;
            }
            case 31: {
                boolean bl = node3.getType() == 49;
                this.generateExpression(node3, node);
                this.generateExpression(node3.getNext(), node);
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addPush(bl);
                this.addScriptRuntimeInvoke("delete", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Z)Ljava/lang/Object;");
                return;
            }
            case 49: {
                do {
                    if (node3 == null) {
                        this.cfw.addALoad(this.contextLocal);
                        this.cfw.addALoad(this.variableObjectLocal);
                        this.cfw.addPush(node.getString());
                        this.addScriptRuntimeInvoke("bind", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Lorg/mozilla/javascript/Scriptable;");
                        return;
                    }
                    this.generateExpression(node3, node);
                    node3 = node3.getNext();
                } while (true);
            }
            case 54: {
                this.cfw.addALoad(this.getLocalBlockRegister(node));
                return;
            }
            case 71: {
                String string2 = (String)node.getProp(17);
                this.generateExpression(node3, node);
                this.cfw.addPush(string2);
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                this.addScriptRuntimeInvoke("specialRef", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Ref;");
                return;
            }
            case 77: 
            case 78: 
            case 79: 
            case 80: {
                String string3;
                String string4;
                int n19 = node.getIntProp(16, 0);
                do {
                    this.generateExpression(node3, node);
                } while ((node3 = node3.getNext()) != null);
                this.cfw.addALoad(this.contextLocal);
                switch (n) {
                    default: {
                        throw Kit.codeBug();
                    }
                    case 77: {
                        string3 = "memberRef";
                        string4 = "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;I)Lorg/mozilla/javascript/Ref;";
                        break;
                    }
                    case 78: {
                        string3 = "memberRef";
                        string4 = "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;I)Lorg/mozilla/javascript/Ref;";
                        break;
                    }
                    case 79: {
                        string3 = "nameRef";
                        string4 = "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Lorg/mozilla/javascript/Ref;";
                        this.cfw.addALoad(this.variableObjectLocal);
                        break;
                    }
                    case 80: {
                        string3 = "nameRef";
                        string4 = "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Lorg/mozilla/javascript/Ref;";
                        this.cfw.addALoad(this.variableObjectLocal);
                    }
                }
                this.cfw.addPush(n19);
                this.addScriptRuntimeInvoke(string3, string4);
                return;
            }
            case 146: {
                this.visitDotQuery(node, node3);
                return;
            }
            case 75: {
                this.generateExpression(node3, node);
                this.cfw.addALoad(this.contextLocal);
                this.addScriptRuntimeInvoke("escapeAttributeValue", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Ljava/lang/String;");
                return;
            }
            case 76: {
                this.generateExpression(node3, node);
                this.cfw.addALoad(this.contextLocal);
                this.addScriptRuntimeInvoke("escapeTextValue", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Ljava/lang/String;");
                return;
            }
            case 74: {
                this.generateExpression(node3, node);
                this.cfw.addALoad(this.contextLocal);
                this.addScriptRuntimeInvoke("setDefaultNamespace", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
                return;
            }
            case 72: {
                this.generateYieldPoint(node, true);
                return;
            }
            case 159: {
                Node node8 = node3;
                Node node9 = node8.getNext();
                Node node10 = node9.getNext();
                this.generateStatement(node8);
                this.generateExpression(node9.getFirstChild(), node9);
                this.generateStatement(node10);
                return;
            }
            case 157: 
        }
        Node node11 = node3;
        Node node12 = node3.getNext();
        this.generateStatement(node11);
        this.generateExpression(node12, node);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void generateFunctionAndThisObj(Node node, Node node2) {
        int n = node.getType();
        switch (node.getType()) {
            default: {
                this.generateExpression(node, node2);
                this.cfw.addALoad(this.contextLocal);
                this.addScriptRuntimeInvoke("getValueFunctionAndThis", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Lorg/mozilla/javascript/Callable;");
                break;
            }
            case 34: {
                throw Kit.codeBug();
            }
            case 33: 
            case 36: {
                Node node3 = node.getFirstChild();
                this.generateExpression(node3, node);
                Node node4 = node3.getNext();
                if (n == 33) {
                    String string2 = node4.getString();
                    this.cfw.addPush(string2);
                    this.cfw.addALoad(this.contextLocal);
                    this.cfw.addALoad(this.variableObjectLocal);
                    this.addScriptRuntimeInvoke("getPropFunctionAndThis", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Callable;");
                    break;
                }
                this.generateExpression(node4, node);
                if (node.getIntProp(8, -1) != -1) {
                    this.addDoubleWrap();
                }
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                this.addScriptRuntimeInvoke("getElemFunctionAndThis", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Callable;");
                break;
            }
            case 39: {
                String string3 = node.getString();
                this.cfw.addPush(string3);
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                this.addScriptRuntimeInvoke("getNameFunctionAndThis", "(Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Callable;");
            }
        }
        this.cfw.addALoad(this.contextLocal);
        this.addScriptRuntimeInvoke("lastStoredScriptable", "(Lorg/mozilla/javascript/Context;)Lorg/mozilla/javascript/Scriptable;");
    }

    private void generateGenerator() {
        this.cfw.startMethod(this.codegen.getBodyMethodName(this.scriptOrFn), this.codegen.getBodyMethodSignature(this.scriptOrFn), (short)10);
        this.initBodyGeneration();
        short s = this.firstFreeLocal;
        this.firstFreeLocal = (short)(s + 1);
        this.argsLocal = s;
        this.localsMax = this.firstFreeLocal;
        if (this.fnCurrent != null) {
            this.cfw.addALoad(this.funObjLocal);
            this.cfw.addInvoke(185, "org/mozilla/javascript/Scriptable", "getParentScope", "()Lorg/mozilla/javascript/Scriptable;");
            this.cfw.addAStore(this.variableObjectLocal);
        }
        this.cfw.addALoad(this.funObjLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        this.cfw.addALoad(this.argsLocal);
        this.addScriptRuntimeInvoke("createFunctionActivation", "(Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
        this.cfw.addAStore(this.variableObjectLocal);
        this.cfw.add(187, this.codegen.mainClassName);
        this.cfw.add(89);
        this.cfw.addALoad(this.variableObjectLocal);
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addPush(this.scriptOrFnIndex);
        this.cfw.addInvoke(183, this.codegen.mainClassName, "<init>", "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;I)V");
        this.generateNestedFunctionInits();
        this.cfw.addALoad(this.variableObjectLocal);
        this.cfw.addALoad(this.thisObjLocal);
        this.cfw.addLoadConstant(this.maxLocals);
        this.cfw.addLoadConstant(this.maxStack);
        this.addOptRuntimeInvoke("createNativeGenerator", "(Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;II)Lorg/mozilla/javascript/Scriptable;");
        this.cfw.add(176);
        this.cfw.stopMethod((short)(1 + this.localsMax));
    }

    private void generateGetGeneratorLocalsState() {
        this.cfw.addALoad(this.generatorStateLocal);
        this.addOptRuntimeInvoke("getGeneratorLocalsState", "(Ljava/lang/Object;)[Ljava/lang/Object;");
    }

    private void generateGetGeneratorResumptionPoint() {
        this.cfw.addALoad(this.generatorStateLocal);
        this.cfw.add(180, "org/mozilla/javascript/optimizer/OptRuntime$GeneratorState", "resumptionPoint", "I");
    }

    private void generateGetGeneratorStackState() {
        this.cfw.addALoad(this.generatorStateLocal);
        this.addOptRuntimeInvoke("getGeneratorStackState", "(Ljava/lang/Object;)[Ljava/lang/Object;");
    }

    /*
     * Enabled aggressive block sorting
     */
    private void generateIfJump(Node node, Node node2, int n, int n2) {
        int n3 = node.getType();
        Node node3 = node.getFirstChild();
        switch (n3) {
            default: {
                this.generateExpression(node, node2);
                this.addScriptRuntimeInvoke("toBoolean", "(Ljava/lang/Object;)Z");
                this.cfw.add(154, n);
                this.cfw.add(167, n2);
                return;
            }
            case 26: {
                this.generateIfJump(node3, node, n2, n);
                return;
            }
            case 104: 
            case 105: {
                int n4 = this.cfw.acquireLabel();
                if (n3 == 105) {
                    this.generateIfJump(node3, node, n4, n2);
                } else {
                    this.generateIfJump(node3, node, n, n4);
                }
                this.cfw.markLabel(n4);
                this.generateIfJump(node3.getNext(), node, n, n2);
                return;
            }
            case 14: 
            case 15: 
            case 16: 
            case 17: 
            case 52: 
            case 53: {
                this.visitIfJumpRelOp(node, node3, n, n2);
                return;
            }
            case 12: 
            case 13: 
            case 46: 
            case 47: 
        }
        this.visitIfJumpEqOp(node, node3, n, n2);
    }

    private void generateIntegerUnwrap() {
        this.cfw.addInvoke(182, "java/lang/Integer", "intValue", "()I");
    }

    private void generateIntegerWrap() {
        this.cfw.addInvoke(184, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;");
    }

    private void generateNestedFunctionInits() {
        int n = this.scriptOrFn.getFunctionCount();
        for (int i = 0; i != n; ++i) {
            OptFunctionNode optFunctionNode = OptFunctionNode.get(this.scriptOrFn, i);
            if (optFunctionNode.fnode.getFunctionType() != 1) continue;
            this.visitFunction(optFunctionNode, 1);
        }
    }

    private void generateObjectLiteralFactory(Node node, int n) {
        String string2 = this.codegen.getBodyMethodName(this.scriptOrFn) + "_literal" + n;
        this.initBodyGeneration();
        short s = this.firstFreeLocal;
        this.firstFreeLocal = (short)(s + 1);
        this.argsLocal = s;
        this.localsMax = this.firstFreeLocal;
        this.cfw.startMethod(string2, "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;", (short)2);
        this.visitObjectLiteral(node, node.getFirstChild(), true);
        this.cfw.add(176);
        this.cfw.stopMethod((short)(1 + this.localsMax));
    }

    /*
     * Enabled aggressive block sorting
     */
    private void generatePrologue() {
        if (this.inDirectCallFunction) {
            int n = this.scriptOrFn.getParamCount();
            if (this.firstFreeLocal != 4) {
                Kit.codeBug();
            }
            for (int n2 = 0; n2 != n; this.firstFreeLocal = (short)(3 + this.firstFreeLocal), ++n2) {
                this.varRegisters[n2] = this.firstFreeLocal;
            }
            if (!this.fnCurrent.getParameterNumberContext()) {
                this.itsForcedObjectParameters = true;
                for (int i = 0; i != n; ++i) {
                    short s = this.varRegisters[i];
                    this.cfw.addALoad(s);
                    this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
                    int n3 = this.cfw.acquireLabel();
                    this.cfw.add(166, n3);
                    this.cfw.addDLoad(s + 1);
                    this.addDoubleWrap();
                    this.cfw.addAStore(s);
                    this.cfw.markLabel(n3);
                }
            }
        }
        if (this.fnCurrent != null) {
            this.cfw.addALoad(this.funObjLocal);
            this.cfw.addInvoke(185, "org/mozilla/javascript/Scriptable", "getParentScope", "()Lorg/mozilla/javascript/Scriptable;");
            this.cfw.addAStore(this.variableObjectLocal);
        }
        short s = this.firstFreeLocal;
        this.firstFreeLocal = (short)(s + 1);
        this.argsLocal = s;
        this.localsMax = this.firstFreeLocal;
        if (this.isGenerator) {
            List<Node> list;
            short s2 = this.firstFreeLocal;
            this.firstFreeLocal = (short)(s2 + 1);
            this.operationLocal = s2;
            this.localsMax = this.firstFreeLocal;
            this.cfw.addALoad(this.thisObjLocal);
            short s3 = this.firstFreeLocal;
            this.firstFreeLocal = (short)(s3 + 1);
            this.generatorStateLocal = s3;
            this.localsMax = this.firstFreeLocal;
            this.cfw.add(192, "org/mozilla/javascript/optimizer/OptRuntime$GeneratorState");
            this.cfw.add(89);
            this.cfw.addAStore(this.generatorStateLocal);
            this.cfw.add(180, "org/mozilla/javascript/optimizer/OptRuntime$GeneratorState", "thisObj", "Lorg/mozilla/javascript/Scriptable;");
            this.cfw.addAStore(this.thisObjLocal);
            if (this.epilogueLabel == -1) {
                this.epilogueLabel = this.cfw.acquireLabel();
            }
            if ((list = ((FunctionNode)this.scriptOrFn).getResumptionPoints()) != null) {
                this.generateGetGeneratorResumptionPoint();
                this.generatorSwitch = this.cfw.addTableSwitch(0, 0 + list.size());
                this.generateCheckForThrowOrClose(-1, false, 0);
            }
        }
        if (this.fnCurrent == null && this.scriptOrFn.getRegexpCount() != 0) {
            this.cfw.addALoad(this.contextLocal);
            this.cfw.addInvoke(184, this.codegen.mainClassName, "_reInit", "(Lorg/mozilla/javascript/Context;)V");
        }
        if (this.compilerEnv.isGenerateObserverCount()) {
            this.saveCurrentCodeOffset();
        }
        if (!this.hasVarsInRegs) {
            if (this.isGenerator) return;
            {
                String string2;
                if (this.fnCurrent != null) {
                    string2 = "activation";
                    this.cfw.addALoad(this.funObjLocal);
                    this.cfw.addALoad(this.variableObjectLocal);
                    this.cfw.addALoad(this.argsLocal);
                    this.addScriptRuntimeInvoke("createFunctionActivation", "(Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
                    this.cfw.addAStore(this.variableObjectLocal);
                    this.cfw.addALoad(this.contextLocal);
                    this.cfw.addALoad(this.variableObjectLocal);
                    this.addScriptRuntimeInvoke("enterActivationFunction", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)V");
                } else {
                    string2 = "global";
                    this.cfw.addALoad(this.funObjLocal);
                    this.cfw.addALoad(this.thisObjLocal);
                    this.cfw.addALoad(this.contextLocal);
                    this.cfw.addALoad(this.variableObjectLocal);
                    this.cfw.addPush(0);
                    this.addScriptRuntimeInvoke("initScript", "(Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Z)V");
                }
                this.enterAreaStartLabel = this.cfw.acquireLabel();
                this.epilogueLabel = this.cfw.acquireLabel();
                this.cfw.markLabel(this.enterAreaStartLabel);
                this.generateNestedFunctionInits();
                if (this.compilerEnv.isGenerateDebugInfo()) {
                    this.cfw.addVariableDescriptor(string2, "Lorg/mozilla/javascript/Scriptable;", this.cfw.getCurrentCodeOffset(), this.variableObjectLocal);
                }
                if (this.fnCurrent == null) {
                    this.popvLocal = this.getNewWordLocal();
                    Codegen.pushUndefined(this.cfw);
                    this.cfw.addAStore(this.popvLocal);
                    int n = this.scriptOrFn.getEndLineno();
                    if (n == -1) return;
                    {
                        this.cfw.addLineNumberEntry((short)n);
                        return;
                    }
                } else {
                    if (this.fnCurrent.itsContainsCalls0) {
                        this.itsZeroArgArray = this.getNewWordLocal();
                        this.cfw.add(178, "org/mozilla/javascript/ScriptRuntime", "emptyArgs", "[Ljava/lang/Object;");
                        this.cfw.addAStore(this.itsZeroArgArray);
                    }
                    if (!this.fnCurrent.itsContainsCalls1) return;
                    {
                        this.itsOneArgArray = this.getNewWordLocal();
                        this.cfw.addPush(1);
                        this.cfw.add(189, "java/lang/Object");
                        this.cfw.addAStore(this.itsOneArgArray);
                        return;
                    }
                }
            }
        } else {
            int n = this.scriptOrFn.getParamCount();
            if (n > 0 && !this.inDirectCallFunction) {
                this.cfw.addALoad(this.argsLocal);
                this.cfw.add(190);
                this.cfw.addPush(n);
                int n4 = this.cfw.acquireLabel();
                this.cfw.add(162, n4);
                this.cfw.addALoad(this.argsLocal);
                this.cfw.addPush(n);
                this.addScriptRuntimeInvoke("padArguments", "([Ljava/lang/Object;I)[Ljava/lang/Object;");
                this.cfw.addAStore(this.argsLocal);
                this.cfw.markLabel(n4);
            }
            int n5 = this.fnCurrent.fnode.getParamCount();
            int n6 = this.fnCurrent.fnode.getParamAndVarCount();
            boolean[] arrbl = this.fnCurrent.fnode.getParamAndVarConst();
            int n7 = -1;
            for (int i = 0; i != n6; ++i) {
                int n8 = -1;
                if (i < n5) {
                    if (!this.inDirectCallFunction) {
                        n8 = this.getNewWordLocal();
                        this.cfw.addALoad(this.argsLocal);
                        this.cfw.addPush(i);
                        this.cfw.add(50);
                        this.cfw.addAStore(n8);
                    }
                } else if (this.fnCurrent.isNumberVar(i)) {
                    n8 = this.getNewWordPairLocal(arrbl[i]);
                    this.cfw.addPush(0.0);
                    this.cfw.addDStore(n8);
                } else {
                    n8 = this.getNewWordLocal(arrbl[i]);
                    if (n7 == -1) {
                        Codegen.pushUndefined(this.cfw);
                        n7 = n8;
                    } else {
                        this.cfw.addALoad(n7);
                    }
                    this.cfw.addAStore(n8);
                }
                if (n8 >= 0) {
                    if (arrbl[i]) {
                        this.cfw.addPush(0);
                        ClassFileWriter classFileWriter = this.cfw;
                        int n9 = this.fnCurrent.isNumberVar(i) ? 2 : 1;
                        classFileWriter.addIStore(n9 + n8);
                    }
                    this.varRegisters[i] = n8;
                }
                if (!this.compilerEnv.isGenerateDebugInfo()) continue;
                String string3 = this.fnCurrent.fnode.getParamOrVarName(i);
                String string4 = this.fnCurrent.isNumberVar(i) ? "D" : "Ljava/lang/Object;";
                int n10 = this.cfw.getCurrentCodeOffset();
                if (n8 < 0) {
                    n8 = this.varRegisters[i];
                }
                this.cfw.addVariableDescriptor(string3, string4, n10, n8);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean generateSaveLocals(Node node) {
        int n = 0;
        for (int i = 0; i < this.firstFreeLocal; ++i) {
            if (this.locals[i] == 0) continue;
            ++n;
        }
        if (n == 0) {
            ((FunctionNode)this.scriptOrFn).addLiveLocals(node, null);
            return false;
        }
        int n2 = this.maxLocals > n ? this.maxLocals : n;
        this.maxLocals = n2;
        int[] arrn = new int[n];
        int n3 = 0;
        for (int i = 0; i < this.firstFreeLocal; ++i) {
            if (this.locals[i] == 0) continue;
            arrn[n3] = i;
            ++n3;
        }
        ((FunctionNode)this.scriptOrFn).addLiveLocals(node, arrn);
        this.generateGetGeneratorLocalsState();
        int n4 = 0;
        do {
            if (n4 >= n) {
                this.cfw.add(87);
                return true;
            }
            this.cfw.add(89);
            this.cfw.addLoadConstant(n4);
            this.cfw.addALoad(arrn[n4]);
            this.cfw.add(83);
            ++n4;
        } while (true);
    }

    private void generateSetGeneratorResumptionPoint(int n) {
        this.cfw.addALoad(this.generatorStateLocal);
        this.cfw.addLoadConstant(n);
        this.cfw.add(181, "org/mozilla/javascript/optimizer/OptRuntime$GeneratorState", "resumptionPoint", "I");
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void generateStatement(Node node) {
        this.updateLineNumber(node);
        int n = node.getType();
        Node node2 = node.getFirstChild();
        switch (n) {
            default: {
                throw Codegen.badTree();
            }
            case 123: 
            case 128: 
            case 129: 
            case 130: 
            case 132: 
            case 136: {
                if (this.compilerEnv.isGenerateObserverCount()) {
                    this.addInstructionCount(1);
                }
                while (node2 != null) {
                    this.generateStatement(node2);
                    node2 = node2.getNext();
                }
                return;
            }
            case 141: {
                boolean bl = this.inLocalBlock;
                this.inLocalBlock = true;
                short s = this.getNewWordLocal();
                if (this.isGenerator) {
                    this.cfw.add(1);
                    this.cfw.addAStore(s);
                }
                node.putIntProp(2, s);
                while (node2 != null) {
                    this.generateStatement(node2);
                    node2 = node2.getNext();
                }
                this.releaseWordLocal(s);
                node.removeProp(2);
                this.inLocalBlock = bl;
            }
            case 160: {
                return;
            }
            case 109: {
                int n2 = node.getExistingIntProp(1);
                OptFunctionNode optFunctionNode = OptFunctionNode.get(this.scriptOrFn, n2);
                int n3 = optFunctionNode.fnode.getFunctionType();
                if (n3 == 3) {
                    this.visitFunction(optFunctionNode, n3);
                    return;
                }
                if (n3 == 1) return;
                throw Codegen.badTree();
            }
            case 81: {
                this.visitTryCatchFinally((Jump)node, node2);
                return;
            }
            case 57: {
                this.cfw.setStackTop((short)0);
                int n4 = this.getLocalBlockRegister(node);
                int n5 = node.getExistingIntProp(14);
                String string2 = node2.getString();
                this.generateExpression(node2.getNext(), node);
                if (n5 == 0) {
                    this.cfw.add(1);
                } else {
                    this.cfw.addALoad(n4);
                }
                this.cfw.addPush(string2);
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                this.addScriptRuntimeInvoke("newCatchScope", "(Ljava/lang/Throwable;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
                this.cfw.addAStore(n4);
                return;
            }
            case 50: {
                this.generateExpression(node2, node);
                if (this.compilerEnv.isGenerateObserverCount()) {
                    this.addInstructionCount();
                }
                this.generateThrowJavaScriptException();
                return;
            }
            case 51: {
                if (this.compilerEnv.isGenerateObserverCount()) {
                    this.addInstructionCount();
                }
                this.cfw.addALoad(this.getLocalBlockRegister(node));
                this.cfw.add(191);
                return;
            }
            case 4: 
            case 64: {
                if (!this.isGenerator) {
                    if (node2 != null) {
                        this.generateExpression(node2, node);
                    } else if (n == 4) {
                        Codegen.pushUndefined(this.cfw);
                    } else {
                        if (this.popvLocal < 0) {
                            throw Codegen.badTree();
                        }
                        this.cfw.addALoad(this.popvLocal);
                    }
                }
                if (this.compilerEnv.isGenerateObserverCount()) {
                    this.addInstructionCount();
                }
                if (this.epilogueLabel == -1) {
                    if (!this.hasVarsInRegs) {
                        throw Codegen.badTree();
                    }
                    this.epilogueLabel = this.cfw.acquireLabel();
                }
                this.cfw.add(167, this.epilogueLabel);
                return;
            }
            case 114: {
                if (this.compilerEnv.isGenerateObserverCount()) {
                    this.addInstructionCount();
                }
                this.visitSwitch((Jump)node, node2);
                return;
            }
            case 2: {
                this.generateExpression(node2, node);
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                this.addScriptRuntimeInvoke("enterWith", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
                this.cfw.addAStore(this.variableObjectLocal);
                this.incReferenceWordLocal(this.variableObjectLocal);
                return;
            }
            case 3: {
                this.cfw.addALoad(this.variableObjectLocal);
                this.addScriptRuntimeInvoke("leaveWith", "(Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
                this.cfw.addAStore(this.variableObjectLocal);
                this.decReferenceWordLocal(this.variableObjectLocal);
                return;
            }
            case 58: 
            case 59: 
            case 60: {
                this.generateExpression(node2, node);
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                int n6 = n == 58 ? 0 : (n == 59 ? 1 : 2);
                this.cfw.addPush(n6);
                this.addScriptRuntimeInvoke("enumInit", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Ljava/lang/Object;");
                this.cfw.addAStore(this.getLocalBlockRegister(node));
                return;
            }
            case 133: {
                if (node2.getType() == 56) {
                    this.visitSetVar(node2, node2.getFirstChild(), false);
                    return;
                }
                if (node2.getType() == 156) {
                    this.visitSetConstVar(node2, node2.getFirstChild(), false);
                    return;
                }
                if (node2.getType() == 72) {
                    this.generateYieldPoint(node2, false);
                    return;
                }
                this.generateExpression(node2, node);
                if (node.getIntProp(8, -1) != -1) {
                    this.cfw.add(88);
                    return;
                }
                this.cfw.add(87);
                return;
            }
            case 134: {
                this.generateExpression(node2, node);
                if (this.popvLocal < 0) {
                    this.popvLocal = this.getNewWordLocal();
                }
                this.cfw.addAStore(this.popvLocal);
                return;
            }
            case 131: {
                if (this.compilerEnv.isGenerateObserverCount()) {
                    this.addInstructionCount();
                }
                int n7 = this.getTargetLabel(node);
                this.cfw.markLabel(n7);
                if (!this.compilerEnv.isGenerateObserverCount()) return;
                this.saveCurrentCodeOffset();
                return;
            }
            case 5: 
            case 6: 
            case 7: 
            case 135: {
                if (this.compilerEnv.isGenerateObserverCount()) {
                    this.addInstructionCount();
                }
                this.visitGoto((Jump)node, n, node2);
                return;
            }
            case 125: 
        }
        if (!this.isGenerator) return;
        if (this.compilerEnv.isGenerateObserverCount()) {
            this.saveCurrentCodeOffset();
        }
        this.cfw.setStackTop((short)1);
        short s = this.getNewWordLocal();
        int n8 = this.cfw.acquireLabel();
        int n9 = this.cfw.acquireLabel();
        this.cfw.markLabel(n8);
        this.generateIntegerWrap();
        this.cfw.addAStore(s);
        do {
            if (node2 == null) {
                this.cfw.addALoad(s);
                this.cfw.add(192, "java/lang/Integer");
                this.generateIntegerUnwrap();
                FinallyReturnPoint finallyReturnPoint = (FinallyReturnPoint)this.finallys.get((Object)node);
                finallyReturnPoint.tableLabel = this.cfw.acquireLabel();
                this.cfw.add(167, finallyReturnPoint.tableLabel);
                this.releaseWordLocal(s);
                this.cfw.markLabel(n9);
                return;
            }
            this.generateStatement(node2);
            node2 = node2.getNext();
        } while (true);
    }

    private void generateThrowJavaScriptException() {
        this.cfw.add(187, "org/mozilla/javascript/JavaScriptException");
        this.cfw.add(90);
        this.cfw.add(95);
        this.cfw.addPush(this.scriptOrFn.getSourceName());
        this.cfw.addPush(this.itsLineNumber);
        this.cfw.addInvoke(183, "org/mozilla/javascript/JavaScriptException", "<init>", "(Ljava/lang/Object;Ljava/lang/String;I)V");
        this.cfw.add(191);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void generateYieldPoint(Node node, boolean bl) {
        Node node2;
        int n = this.cfw.getStackTop();
        int n2 = this.maxStack > n ? this.maxStack : n;
        this.maxStack = n2;
        if (this.cfw.getStackTop() != 0) {
            this.generateGetGeneratorStackState();
            for (int i = 0; i < n; ++i) {
                this.cfw.add(90);
                this.cfw.add(95);
                this.cfw.addLoadConstant(i);
                this.cfw.add(95);
                this.cfw.add(83);
            }
            this.cfw.add(87);
        }
        if ((node2 = node.getFirstChild()) != null) {
            this.generateExpression(node2, node);
        } else {
            Codegen.pushUndefined(this.cfw);
        }
        int n3 = this.getNextGeneratorState(node);
        this.generateSetGeneratorResumptionPoint(n3);
        boolean bl2 = this.generateSaveLocals(node);
        this.cfw.add(176);
        this.generateCheckForThrowOrClose(this.getTargetLabel(node), bl2, n3);
        if (n != 0) {
            this.generateGetGeneratorStackState();
            for (int i = 0; i < n; ++i) {
                this.cfw.add(89);
                this.cfw.addLoadConstant(-1 + (n - i));
                this.cfw.add(50);
                this.cfw.add(95);
            }
            this.cfw.add(87);
        }
        if (bl) {
            this.cfw.addALoad(this.argsLocal);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Node getFinallyAtTarget(Node node) {
        if (node == null) {
            return null;
        }
        if (node.getType() == 125) return node;
        if (node == null) throw Kit.codeBug("bad finally target");
        if (node.getType() != 131) throw Kit.codeBug("bad finally target");
        Node node2 = node.getNext();
        if (node2 == null) throw Kit.codeBug("bad finally target");
        if (node2.getType() != 125) throw Kit.codeBug("bad finally target");
        return node2;
    }

    private int getLocalBlockRegister(Node node) {
        return ((Node)node.getProp(3)).getExistingIntProp(2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private short getNewWordIntern(int n) {
        if (!($assertionsDisabled || n >= 1 && n <= 3)) {
            throw new AssertionError();
        }
        int[] arrn = this.locals;
        short s = -1;
        if (n <= 1) {
            s = this.firstFreeLocal;
        } else {
            int n2 = this.firstFreeLocal;
            block0 : while (n2 + n <= 1024) {
                for (int i = 0; i < n; ++i) {
                    if (arrn[n2 + i] == 0) continue;
                    n2 += i + 1;
                    continue block0;
                }
                s = (short)n2;
                break;
            }
        }
        if (s != -1) {
            arrn[s] = 1;
            if (n > 1) {
                arrn[s + 1] = 1;
            }
            if (n > 2) {
                arrn[s + 2] = 1;
            }
            if (s != this.firstFreeLocal) {
                return s;
            }
            for (int i = s + n; i < 1024; ++i) {
                if (arrn[i] != 0) continue;
                this.firstFreeLocal = (short)i;
                if (this.localsMax < this.firstFreeLocal) {
                    this.localsMax = this.firstFreeLocal;
                }
                return s;
            }
        }
        throw Context.reportRuntimeError("Program too complex (out of locals)");
    }

    private short getNewWordLocal() {
        return this.getNewWordIntern(1);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private short getNewWordLocal(boolean bl) {
        int n;
        if (bl) {
            n = 2;
            do {
                return this.getNewWordIntern(n);
                break;
            } while (true);
        }
        n = 1;
        return this.getNewWordIntern(n);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private short getNewWordPairLocal(boolean bl) {
        int n;
        if (bl) {
            n = 3;
            do {
                return this.getNewWordIntern(n);
                break;
            } while (true);
        }
        n = 2;
        return this.getNewWordIntern(n);
    }

    private int getNextGeneratorState(Node node) {
        return 1 + ((FunctionNode)this.scriptOrFn).getResumptionPoints().indexOf((Object)node);
    }

    private int getTargetLabel(Node node) {
        int n = node.labelId();
        if (n == -1) {
            n = this.cfw.acquireLabel();
            node.labelId(n);
        }
        return n;
    }

    private void incReferenceWordLocal(short s) {
        int[] arrn = this.locals;
        arrn[s] = 1 + arrn[s];
    }

    /*
     * Enabled aggressive block sorting
     */
    private void initBodyGeneration() {
        this.varRegisters = null;
        if (this.scriptOrFn.getType() == 109) {
            int n;
            this.fnCurrent = OptFunctionNode.get(this.scriptOrFn);
            boolean bl = !this.fnCurrent.fnode.requiresActivation();
            this.hasVarsInRegs = bl;
            if (this.hasVarsInRegs && (n = this.fnCurrent.fnode.getParamAndVarCount()) != 0) {
                this.varRegisters = new short[n];
            }
            this.inDirectCallFunction = this.fnCurrent.isTargetOfDirectCall();
            if (this.inDirectCallFunction && !this.hasVarsInRegs) {
                Codegen.badTree();
            }
        } else {
            this.fnCurrent = null;
            this.hasVarsInRegs = false;
            this.inDirectCallFunction = false;
        }
        this.locals = new int[1024];
        this.funObjLocal = 0;
        this.contextLocal = 1;
        this.variableObjectLocal = (short)2;
        this.thisObjLocal = (short)3;
        this.localsMax = (short)4;
        this.firstFreeLocal = (short)4;
        this.popvLocal = (short)-1;
        this.argsLocal = (short)-1;
        this.itsZeroArgArray = (short)-1;
        this.itsOneArgArray = (short)-1;
        this.epilogueLabel = -1;
        this.enterAreaStartLabel = -1;
        this.generatorStateLocal = (short)-1;
    }

    private void inlineFinally(Node node) {
        int n = this.cfw.acquireLabel();
        int n2 = this.cfw.acquireLabel();
        this.cfw.markLabel(n);
        this.inlineFinally(node, n, n2);
        this.cfw.markLabel(n2);
    }

    private void inlineFinally(Node node, int n, int n2) {
        Node node2 = this.getFinallyAtTarget(node);
        node2.resetTargets();
        this.exceptionManager.markInlineFinallyStart(node2, n);
        for (Node node3 = node2.getFirstChild(); node3 != null; node3 = node3.getNext()) {
            this.generateStatement(node3);
        }
        this.exceptionManager.markInlineFinallyEnd(node2, n2);
    }

    private static boolean isArithmeticNode(Node node) {
        int n = node.getType();
        return n == 22 || n == 25 || n == 24 || n == 23;
    }

    private int nodeIsDirectCallParameter(Node node) {
        int n;
        if (node.getType() == 55 && this.inDirectCallFunction && !this.itsForcedObjectParameters && this.fnCurrent.isParameter(n = this.fnCurrent.getVarIndex(node))) {
            return this.varRegisters[n];
        }
        return -1;
    }

    private void releaseWordLocal(short s) {
        if (s < this.firstFreeLocal) {
            this.firstFreeLocal = s;
        }
        this.locals[s] = 0;
    }

    private void saveCurrentCodeOffset() {
        this.savedCodeOffset = this.cfw.getCurrentCodeOffset();
    }

    private void updateLineNumber(Node node) {
        this.itsLineNumber = node.getLineno();
        if (this.itsLineNumber == -1) {
            return;
        }
        this.cfw.addLineNumberEntry((short)this.itsLineNumber);
    }

    private boolean varIsDirectCallParameter(int n) {
        return this.fnCurrent.isParameter(n) && this.inDirectCallFunction && !this.itsForcedObjectParameters;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitArithmetic(Node node, int n, Node node2, Node node3) {
        if (node.getIntProp(8, -1) != -1) {
            this.generateExpression(node2, node);
            this.generateExpression(node2.getNext(), node);
            this.cfw.add(n);
            return;
        } else {
            boolean bl = BodyCodegen.isArithmeticNode(node3);
            this.generateExpression(node2, node);
            if (!BodyCodegen.isArithmeticNode(node2)) {
                this.addObjectToDouble();
            }
            this.generateExpression(node2.getNext(), node);
            if (!BodyCodegen.isArithmeticNode(node2.getNext())) {
                this.addObjectToDouble();
            }
            this.cfw.add(n);
            if (bl) return;
            {
                this.addDoubleWrap();
                return;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitArrayLiteral(Node node, Node node2, boolean bl) {
        int[] arrn;
        int n = 0;
        for (Node node3 = node2; node3 != null; ++n, node3 = node3.getNext()) {
        }
        if (!(bl || n <= 10 && this.cfw.getCurrentCodeOffset() <= 30000 || this.hasVarsInRegs || this.isGenerator || this.inLocalBlock)) {
            if (this.literals == null) {
                this.literals = new LinkedList();
            }
            this.literals.add((Object)node);
            String string2 = this.codegen.getBodyMethodName(this.scriptOrFn) + "_literal" + this.literals.size();
            this.cfw.addALoad(this.funObjLocal);
            this.cfw.addALoad(this.contextLocal);
            this.cfw.addALoad(this.variableObjectLocal);
            this.cfw.addALoad(this.thisObjLocal);
            this.cfw.addALoad(this.argsLocal);
            this.cfw.addInvoke(182, this.codegen.mainClassName, string2, "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
            return;
        }
        if (this.isGenerator) {
            for (int n2 = 0; n2 != n; node2 = node2.getNext(), ++n2) {
                this.generateExpression(node2, node);
            }
            this.addNewObjectArray(n);
            for (int i = 0; i != n; ++i) {
                this.cfw.add(90);
                this.cfw.add(95);
                this.cfw.addPush(-1 + (n - i));
                this.cfw.add(95);
                this.cfw.add(83);
            }
        } else {
            this.addNewObjectArray(n);
            for (int n3 = 0; n3 != n; node2 = node2.getNext(), ++n3) {
                this.cfw.add(89);
                this.cfw.addPush(n3);
                this.generateExpression(node2, node);
                this.cfw.add(83);
            }
        }
        if ((arrn = (int[])node.getProp(11)) == null) {
            this.cfw.add(1);
            this.cfw.add(3);
        } else {
            this.cfw.addPush(OptRuntime.encodeIntArray(arrn));
            this.cfw.addPush(arrn.length);
        }
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        this.addOptRuntimeInvoke("newArrayLiteral", "([Ljava/lang/Object;Ljava/lang/String;ILorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitBitOp(Node node, int n, Node node2) {
        int n2 = node.getIntProp(8, -1);
        this.generateExpression(node2, node);
        if (n == 20) {
            this.addScriptRuntimeInvoke("toUint32", "(Ljava/lang/Object;)J");
            this.generateExpression(node2.getNext(), node);
            this.addScriptRuntimeInvoke("toInt32", "(Ljava/lang/Object;)I");
            this.cfw.addPush(31);
            this.cfw.add(126);
            this.cfw.add(125);
            this.cfw.add(138);
            this.addDoubleWrap();
            return;
        } else {
            if (n2 == -1) {
                this.addScriptRuntimeInvoke("toInt32", "(Ljava/lang/Object;)I");
                this.generateExpression(node2.getNext(), node);
                this.addScriptRuntimeInvoke("toInt32", "(Ljava/lang/Object;)I");
            } else {
                this.addScriptRuntimeInvoke("toInt32", "(D)I");
                this.generateExpression(node2.getNext(), node);
                this.addScriptRuntimeInvoke("toInt32", "(D)I");
            }
            switch (n) {
                default: {
                    throw Codegen.badTree();
                }
                case 9: {
                    this.cfw.add(128);
                    break;
                }
                case 10: {
                    this.cfw.add(130);
                    break;
                }
                case 11: {
                    this.cfw.add(126);
                    break;
                }
                case 19: {
                    this.cfw.add(122);
                    break;
                }
                case 18: {
                    this.cfw.add(120);
                }
            }
            this.cfw.add(135);
            if (n2 != -1) return;
            {
                this.addDoubleWrap();
                return;
            }
        }
    }

    private void visitDotQuery(Node node, Node node2) {
        this.updateLineNumber(node);
        this.generateExpression(node2, node);
        this.cfw.addALoad(this.variableObjectLocal);
        this.addScriptRuntimeInvoke("enterDotQuery", "(Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
        this.cfw.addAStore(this.variableObjectLocal);
        this.cfw.add(1);
        int n = this.cfw.acquireLabel();
        this.cfw.markLabel(n);
        this.cfw.add(87);
        this.generateExpression(node2.getNext(), node);
        this.addScriptRuntimeInvoke("toBoolean", "(Ljava/lang/Object;)Z");
        this.cfw.addALoad(this.variableObjectLocal);
        this.addScriptRuntimeInvoke("updateDotQuery", "(ZLorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
        this.cfw.add(89);
        this.cfw.add(198, n);
        this.cfw.addALoad(this.variableObjectLocal);
        this.addScriptRuntimeInvoke("leaveDotQuery", "(Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
        this.cfw.addAStore(this.variableObjectLocal);
    }

    private void visitFunction(OptFunctionNode optFunctionNode, int n) {
        int n2 = this.codegen.getIndex(optFunctionNode.fnode);
        this.cfw.add(187, this.codegen.mainClassName);
        this.cfw.add(89);
        this.cfw.addALoad(this.variableObjectLocal);
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addPush(n2);
        this.cfw.addInvoke(183, this.codegen.mainClassName, "<init>", "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;I)V");
        if (n == 2) {
            return;
        }
        this.cfw.addPush(n);
        this.cfw.addALoad(this.variableObjectLocal);
        this.cfw.addALoad(this.contextLocal);
        this.addOptRuntimeInvoke("initFunction", "(Lorg/mozilla/javascript/NativeFunction;ILorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;)V");
    }

    private void visitGetProp(Node node, Node node2) {
        this.generateExpression(node2, node);
        Node node3 = node2.getNext();
        this.generateExpression(node3, node);
        if (node.getType() == 34) {
            this.cfw.addALoad(this.contextLocal);
            this.cfw.addALoad(this.variableObjectLocal);
            this.addScriptRuntimeInvoke("getObjectPropNoWarn", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
            return;
        }
        if (node2.getType() == 43 && node3.getType() == 41) {
            this.cfw.addALoad(this.contextLocal);
            this.addScriptRuntimeInvoke("getObjectProp", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
            return;
        }
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        this.addScriptRuntimeInvoke("getObjectProp", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
    }

    private void visitGetVar(Node node) {
        if (!this.hasVarsInRegs) {
            Kit.codeBug();
        }
        int n = this.fnCurrent.getVarIndex(node);
        short s = this.varRegisters[n];
        if (this.varIsDirectCallParameter(n)) {
            if (node.getIntProp(8, -1) != -1) {
                this.dcpLoadAsNumber(s);
                return;
            }
            this.dcpLoadAsObject(s);
            return;
        }
        if (this.fnCurrent.isNumberVar(n)) {
            this.cfw.addDLoad(s);
            return;
        }
        this.cfw.addALoad(s);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitGoto(Jump jump, int n, Node node) {
        Node node2 = jump.target;
        if (n == 6 || n == 7) {
            if (node == null) {
                throw Codegen.badTree();
            }
            int n2 = this.getTargetLabel(node2);
            int n3 = this.cfw.acquireLabel();
            if (n == 6) {
                this.generateIfJump(node, jump, n2, n3);
            } else {
                this.generateIfJump(node, jump, n3, n2);
            }
            this.cfw.markLabel(n3);
            return;
        }
        if (n != 135) {
            this.addGoto(node2, 167);
            return;
        }
        if (this.isGenerator) {
            this.addGotoWithReturn(node2);
            return;
        }
        this.inlineFinally(node2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitIfJumpEqOp(Node node, Node node2, int n, int n2) {
        if (n == -1 || n2 == -1) {
            throw Codegen.badTree();
        }
        short s = this.cfw.getStackTop();
        int n3 = node.getType();
        Node node3 = node2.getNext();
        if (node2.getType() == 42 || node3.getType() == 42) {
            if (node2.getType() == 42) {
                node2 = node3;
            }
            this.generateExpression(node2, node);
            if (n3 == 46 || n3 == 47) {
                int n4 = n3 == 46 ? 198 : 199;
                this.cfw.add(n4, n);
            } else {
                if (n3 != 12) {
                    if (n3 != 13) {
                        throw Codegen.badTree();
                    }
                    int n5 = n;
                    n = n2;
                    n2 = n5;
                }
                this.cfw.add(89);
                int n6 = this.cfw.acquireLabel();
                this.cfw.add(199, n6);
                short s2 = this.cfw.getStackTop();
                this.cfw.add(87);
                this.cfw.add(167, n);
                this.cfw.markLabel(n6, s2);
                Codegen.pushUndefined(this.cfw);
                this.cfw.add(165, n);
            }
            this.cfw.add(167, n2);
        } else {
            int n7;
            Node node4;
            String string2;
            int n8 = this.nodeIsDirectCallParameter(node2);
            if (n8 != -1 && node3.getType() == 149 && (node4 = node3.getFirstChild()).getType() == 40) {
                this.cfw.addALoad(n8);
                this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
                int n9 = this.cfw.acquireLabel();
                this.cfw.add(166, n9);
                this.cfw.addDLoad(n8 + 1);
                this.cfw.addPush(node4.getDouble());
                this.cfw.add(151);
                if (n3 == 12) {
                    this.cfw.add(153, n);
                } else {
                    this.cfw.add(154, n);
                }
                this.cfw.add(167, n2);
                this.cfw.markLabel(n9);
            }
            this.generateExpression(node2, node);
            this.generateExpression(node3, node);
            switch (n3) {
                default: {
                    throw Codegen.badTree();
                }
                case 12: {
                    string2 = "eq";
                    n7 = 154;
                    break;
                }
                case 13: {
                    string2 = "eq";
                    n7 = 153;
                    break;
                }
                case 46: {
                    string2 = "shallowEq";
                    n7 = 154;
                    break;
                }
                case 47: {
                    string2 = "shallowEq";
                    n7 = 153;
                }
            }
            this.addScriptRuntimeInvoke(string2, "(Ljava/lang/Object;Ljava/lang/Object;)Z");
            this.cfw.add(n7, n);
            this.cfw.add(167, n2);
        }
        if (s != this.cfw.getStackTop()) {
            throw Codegen.badTree();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitIfJumpRelOp(Node node, Node node2, int n, int n2) {
        if (n == -1 || n2 == -1) {
            throw Codegen.badTree();
        }
        int n3 = node.getType();
        Node node3 = node2.getNext();
        if (n3 == 53 || n3 == 52) {
            this.generateExpression(node2, node);
            this.generateExpression(node3, node);
            this.cfw.addALoad(this.contextLocal);
            String string2 = n3 == 53 ? "instanceOf" : "in";
            this.addScriptRuntimeInvoke(string2, "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Z");
            this.cfw.add(154, n);
            this.cfw.add(167, n2);
            return;
        }
        int n4 = node.getIntProp(8, -1);
        int n5 = this.nodeIsDirectCallParameter(node2);
        int n6 = this.nodeIsDirectCallParameter(node3);
        if (n4 != -1) {
            if (n4 != 2) {
                this.generateExpression(node2, node);
            } else if (n5 != -1) {
                this.dcpLoadAsNumber(n5);
            } else {
                this.generateExpression(node2, node);
                this.addObjectToDouble();
            }
            if (n4 != 1) {
                this.generateExpression(node3, node);
            } else if (n6 != -1) {
                this.dcpLoadAsNumber(n6);
            } else {
                this.generateExpression(node3, node);
                this.addObjectToDouble();
            }
            this.genSimpleCompare(n3, n, n2);
            return;
        }
        if (n5 != -1 && n6 != -1) {
            short s = this.cfw.getStackTop();
            int n7 = this.cfw.acquireLabel();
            this.cfw.addALoad(n5);
            this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
            this.cfw.add(166, n7);
            this.cfw.addDLoad(n5 + 1);
            this.dcpLoadAsNumber(n6);
            this.genSimpleCompare(n3, n, n2);
            if (s != this.cfw.getStackTop()) {
                throw Codegen.badTree();
            }
            this.cfw.markLabel(n7);
            int n8 = this.cfw.acquireLabel();
            this.cfw.addALoad(n6);
            this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
            this.cfw.add(166, n8);
            this.cfw.addALoad(n5);
            this.addObjectToDouble();
            this.cfw.addDLoad(n6 + 1);
            this.genSimpleCompare(n3, n, n2);
            if (s != this.cfw.getStackTop()) {
                throw Codegen.badTree();
            }
            this.cfw.markLabel(n8);
            this.cfw.addALoad(n5);
            this.cfw.addALoad(n6);
        } else {
            this.generateExpression(node2, node);
            this.generateExpression(node3, node);
        }
        if (n3 == 17 || n3 == 16) {
            this.cfw.add(95);
        }
        String string3 = n3 == 14 || n3 == 16 ? "cmp_LT" : "cmp_LE";
        this.addScriptRuntimeInvoke(string3, "(Ljava/lang/Object;Ljava/lang/Object;)Z");
        this.cfw.add(154, n);
        this.cfw.add(167, n2);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void visitIncDec(Node node) {
        int n = node.getExistingIntProp(13);
        Node node2 = node.getFirstChild();
        switch (node2.getType()) {
            default: {
                Codegen.badTree();
                return;
            }
            case 55: {
                if (!this.hasVarsInRegs) {
                    Kit.codeBug();
                }
                boolean bl = (n & 2) != 0;
                int n2 = this.fnCurrent.getVarIndex(node2);
                short s = this.varRegisters[n2];
                if (this.fnCurrent.fnode.getParamAndVarConst()[n2]) {
                    if (node.getIntProp(8, -1) != -1) {
                        short s2 = this.varIsDirectCallParameter(n2) ? (short)1 : 0;
                        this.cfw.addDLoad(s + s2);
                        if (bl) return;
                        this.cfw.addPush(1.0);
                        if ((n & 1) == 0) {
                            this.cfw.add(99);
                            return;
                        }
                        this.cfw.add(103);
                        return;
                    }
                    if (this.varIsDirectCallParameter(n2)) {
                        this.dcpLoadAsObject(s);
                    } else {
                        this.cfw.addALoad(s);
                    }
                    if (bl) {
                        this.cfw.add(89);
                        this.addObjectToDouble();
                        this.cfw.add(88);
                        return;
                    }
                    this.addObjectToDouble();
                    this.cfw.addPush(1.0);
                    if ((n & 1) == 0) {
                        this.cfw.add(99);
                    } else {
                        this.cfw.add(103);
                    }
                    this.addDoubleWrap();
                    return;
                }
                if (node.getIntProp(8, -1) != -1) {
                    short s3 = this.varIsDirectCallParameter(n2) ? (short)1 : 0;
                    this.cfw.addDLoad(s + s3);
                    if (bl) {
                        this.cfw.add(92);
                    }
                    this.cfw.addPush(1.0);
                    if ((n & 1) == 0) {
                        this.cfw.add(99);
                    } else {
                        this.cfw.add(103);
                    }
                    if (!bl) {
                        this.cfw.add(92);
                    }
                    this.cfw.addDStore(s + s3);
                    return;
                }
                if (this.varIsDirectCallParameter(n2)) {
                    this.dcpLoadAsObject(s);
                } else {
                    this.cfw.addALoad(s);
                }
                if (bl) {
                    this.cfw.add(89);
                }
                this.addObjectToDouble();
                this.cfw.addPush(1.0);
                if ((n & 1) == 0) {
                    this.cfw.add(99);
                } else {
                    this.cfw.add(103);
                }
                this.addDoubleWrap();
                if (!bl) {
                    this.cfw.add(89);
                }
                this.cfw.addAStore(s);
                return;
            }
            case 39: {
                this.cfw.addALoad(this.variableObjectLocal);
                this.cfw.addPush(node2.getString());
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addPush(n);
                this.addScriptRuntimeInvoke("nameIncrDecr", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Context;I)Ljava/lang/Object;");
                return;
            }
            case 34: {
                throw Kit.codeBug();
            }
            case 33: {
                Node node3 = node2.getFirstChild();
                this.generateExpression(node3, node);
                this.generateExpression(node3.getNext(), node);
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                this.cfw.addPush(n);
                this.addScriptRuntimeInvoke("propIncrDecr", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Ljava/lang/Object;");
                return;
            }
            case 36: {
                Node node4 = node2.getFirstChild();
                this.generateExpression(node4, node);
                this.generateExpression(node4.getNext(), node);
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                this.cfw.addPush(n);
                if (node4.getNext().getIntProp(8, -1) != -1) {
                    this.addOptRuntimeInvoke("elemIncrDecr", "(Ljava/lang/Object;DLorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Ljava/lang/Object;");
                    return;
                }
                this.addScriptRuntimeInvoke("elemIncrDecr", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Ljava/lang/Object;");
                return;
            }
            case 67: 
        }
        this.generateExpression(node2.getFirstChild(), node);
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        this.cfw.addPush(n);
        this.addScriptRuntimeInvoke("refIncrDecr", "(Lorg/mozilla/javascript/Ref;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Ljava/lang/Object;");
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitObjectLiteral(Node node, Node node2, boolean bl) {
        block14 : {
            Node node3;
            int n;
            block11 : {
                Object[] arrobject = (Object[])node.getProp(12);
                n = arrobject.length;
                if (!(bl || n <= 10 && this.cfw.getCurrentCodeOffset() <= 30000 || this.hasVarsInRegs || this.isGenerator || this.inLocalBlock)) {
                    if (this.literals == null) {
                        this.literals = new LinkedList();
                    }
                    this.literals.add((Object)node);
                    String string2 = this.codegen.getBodyMethodName(this.scriptOrFn) + "_literal" + this.literals.size();
                    this.cfw.addALoad(this.funObjLocal);
                    this.cfw.addALoad(this.contextLocal);
                    this.cfw.addALoad(this.variableObjectLocal);
                    this.cfw.addALoad(this.thisObjLocal);
                    this.cfw.addALoad(this.argsLocal);
                    this.cfw.addInvoke(182, this.codegen.mainClassName, string2, "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
                    return;
                }
                if (this.isGenerator) {
                    this.addLoadPropertyValues(node, node2, n);
                    this.addLoadPropertyIds(arrobject, n);
                    this.cfw.add(95);
                } else {
                    this.addLoadPropertyIds(arrobject, n);
                    this.addLoadPropertyValues(node, node2, n);
                }
                Node node4 = node2;
                int n2 = 0;
                do {
                    block13 : {
                        boolean bl2;
                        block12 : {
                            bl2 = false;
                            if (n2 == n) break block12;
                            int n3 = node4.getType();
                            if (n3 != 151 && n3 != 152) break block13;
                            bl2 = true;
                        }
                        if (!bl2) break;
                        this.cfw.addPush(n);
                        this.cfw.add(188, 10);
                        node3 = node2;
                        break block11;
                    }
                    node4 = node4.getNext();
                    ++n2;
                } while (true);
                this.cfw.add(1);
                break block14;
            }
            for (int n4 = 0; n4 != n; node3 = node3.getNext(), ++n4) {
                this.cfw.add(89);
                this.cfw.addPush(n4);
                int n5 = node3.getType();
                if (n5 == 151) {
                    this.cfw.add(2);
                } else if (n5 == 152) {
                    this.cfw.add(4);
                } else {
                    this.cfw.add(3);
                }
                this.cfw.add(79);
            }
        }
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        this.addScriptRuntimeInvoke("newObjectLiteral", "([Ljava/lang/Object;[Ljava/lang/Object;[ILorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitOptimizedCall(Node node, OptFunctionNode optFunctionNode, int n, Node node2) {
        Node node3 = node2.getNext();
        String string2 = this.codegen.mainClassName;
        short s = 0;
        if (n == 30) {
            this.generateExpression(node2, node);
        } else {
            this.generateFunctionAndThisObj(node2, node);
            s = this.getNewWordLocal();
            this.cfw.addAStore(s);
        }
        int n2 = this.cfw.acquireLabel();
        int n3 = this.cfw.acquireLabel();
        this.cfw.add(89);
        this.cfw.add(193, string2);
        this.cfw.add(153, n3);
        this.cfw.add(192, string2);
        this.cfw.add(89);
        this.cfw.add(180, string2, "_id", "I");
        this.cfw.addPush(this.codegen.getIndex(optFunctionNode.fnode));
        this.cfw.add(160, n3);
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        if (n == 30) {
            this.cfw.add(1);
        } else {
            this.cfw.addALoad(s);
        }
        for (Node node4 = node3; node4 != null; node4 = node4.getNext()) {
            int n4 = this.nodeIsDirectCallParameter(node4);
            if (n4 >= 0) {
                this.cfw.addALoad(n4);
                this.cfw.addDLoad(n4 + 1);
                continue;
            }
            if (node4.getIntProp(8, -1) == 0) {
                this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
                this.generateExpression(node4, node);
                continue;
            }
            this.generateExpression(node4, node);
            this.cfw.addPush(0.0);
        }
        this.cfw.add(178, "org/mozilla/javascript/ScriptRuntime", "emptyArgs", "[Ljava/lang/Object;");
        ClassFileWriter classFileWriter = this.cfw;
        String string3 = this.codegen.mainClassName;
        String string4 = n == 30 ? this.codegen.getDirectCtorName(optFunctionNode.fnode) : this.codegen.getBodyMethodName(optFunctionNode.fnode);
        classFileWriter.addInvoke(184, string3, string4, this.codegen.getBodyMethodSignature(optFunctionNode.fnode));
        this.cfw.add(167, n2);
        this.cfw.markLabel(n3);
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        if (n != 30) {
            this.cfw.addALoad(s);
            this.releaseWordLocal(s);
        }
        this.generateCallArgArray(node, node3, true);
        if (n == 30) {
            this.addScriptRuntimeInvoke("newObject", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
        } else {
            this.cfw.addInvoke(185, "org/mozilla/javascript/Callable", "call", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;");
        }
        this.cfw.markLabel(n2);
    }

    private void visitSetConst(Node node, Node node2) {
        String string2 = node.getFirstChild().getString();
        while (node2 != null) {
            this.generateExpression(node2, node);
            node2 = node2.getNext();
        }
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addPush(string2);
        this.addScriptRuntimeInvoke("setConst", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Ljava/lang/String;)Ljava/lang/Object;");
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitSetConstVar(Node node, Node node2, boolean bl) {
        if (!this.hasVarsInRegs) {
            Kit.codeBug();
        }
        int n = this.fnCurrent.getVarIndex(node);
        this.generateExpression(node2.getNext(), node);
        boolean bl2 = node.getIntProp(8, -1) != -1;
        short s = this.varRegisters[n];
        int n2 = this.cfw.acquireLabel();
        int n3 = this.cfw.acquireLabel();
        if (bl2) {
            this.cfw.addILoad(s + 2);
            this.cfw.add(154, n3);
            short s2 = this.cfw.getStackTop();
            this.cfw.addPush(1);
            this.cfw.addIStore(s + 2);
            this.cfw.addDStore(s);
            if (bl) {
                this.cfw.addDLoad(s);
                this.cfw.markLabel(n3, s2);
            } else {
                this.cfw.add(167, n2);
                this.cfw.markLabel(n3, s2);
                this.cfw.add(88);
            }
        } else {
            this.cfw.addILoad(s + 1);
            this.cfw.add(154, n3);
            short s3 = this.cfw.getStackTop();
            this.cfw.addPush(1);
            this.cfw.addIStore(s + 1);
            this.cfw.addAStore(s);
            if (bl) {
                this.cfw.addALoad(s);
                this.cfw.markLabel(n3, s3);
            } else {
                this.cfw.add(167, n2);
                this.cfw.markLabel(n3, s3);
                this.cfw.add(87);
            }
        }
        this.cfw.markLabel(n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitSetElem(int n, Node node, Node node2) {
        this.generateExpression(node2, node);
        Node node3 = node2.getNext();
        if (n == 140) {
            this.cfw.add(89);
        }
        this.generateExpression(node3, node);
        Node node4 = node3.getNext();
        boolean bl = node.getIntProp(8, -1) != -1;
        if (n == 140) {
            if (bl) {
                this.cfw.add(93);
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                this.addScriptRuntimeInvoke("getObjectIndex", "(Ljava/lang/Object;DLorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
            } else {
                this.cfw.add(90);
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                this.addScriptRuntimeInvoke("getObjectElem", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
            }
        }
        this.generateExpression(node4, node);
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        if (bl) {
            this.addScriptRuntimeInvoke("setObjectIndex", "(Ljava/lang/Object;DLjava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
            return;
        }
        this.addScriptRuntimeInvoke("setObjectElem", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
    }

    private void visitSetName(Node node, Node node2) {
        String string2 = node.getFirstChild().getString();
        while (node2 != null) {
            this.generateExpression(node2, node);
            node2 = node2.getNext();
        }
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        this.cfw.addPush(string2);
        this.addScriptRuntimeInvoke("setName", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Ljava/lang/Object;");
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitSetProp(int n, Node node, Node node2) {
        this.generateExpression(node2, node);
        Node node3 = node2.getNext();
        if (n == 139) {
            this.cfw.add(89);
        }
        this.generateExpression(node3, node);
        Node node4 = node3.getNext();
        if (n == 139) {
            this.cfw.add(90);
            if (node2.getType() == 43 && node3.getType() == 41) {
                this.cfw.addALoad(this.contextLocal);
                this.addScriptRuntimeInvoke("getObjectProp", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
            } else {
                this.cfw.addALoad(this.contextLocal);
                this.cfw.addALoad(this.variableObjectLocal);
                this.addScriptRuntimeInvoke("getObjectProp", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
            }
        }
        this.generateExpression(node4, node);
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        this.addScriptRuntimeInvoke("setObjectProp", "(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void visitSetVar(Node node, Node node2, boolean bl) {
        if (!this.hasVarsInRegs) {
            Kit.codeBug();
        }
        int n = this.fnCurrent.getVarIndex(node);
        this.generateExpression(node2.getNext(), node);
        boolean bl2 = node.getIntProp(8, -1) != -1;
        short s = this.varRegisters[n];
        if (this.fnCurrent.fnode.getParamAndVarConst()[n]) {
            if (bl) return;
            if (bl2) {
                this.cfw.add(88);
                return;
            }
            this.cfw.add(87);
            return;
        }
        if (this.varIsDirectCallParameter(n)) {
            if (bl2) {
                if (bl) {
                    this.cfw.add(92);
                }
                this.cfw.addALoad(s);
                this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
                int n2 = this.cfw.acquireLabel();
                int n3 = this.cfw.acquireLabel();
                this.cfw.add(165, n2);
                short s2 = this.cfw.getStackTop();
                this.addDoubleWrap();
                this.cfw.addAStore(s);
                this.cfw.add(167, n3);
                this.cfw.markLabel(n2, s2);
                this.cfw.addDStore(s + 1);
                this.cfw.markLabel(n3);
                return;
            }
            if (bl) {
                this.cfw.add(89);
            }
            this.cfw.addAStore(s);
            return;
        }
        boolean bl3 = this.fnCurrent.isNumberVar(n);
        if (bl2) {
            if (bl3) {
                this.cfw.addDStore(s);
                if (!bl) return;
                this.cfw.addDLoad(s);
                return;
            }
            if (bl) {
                this.cfw.add(92);
            }
            this.addDoubleWrap();
            this.cfw.addAStore(s);
            return;
        }
        if (bl3) {
            Kit.codeBug();
        }
        this.cfw.addAStore(s);
        if (!bl) return;
        this.cfw.addALoad(s);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitSpecialCall(Node node, int n, int n2, Node node2) {
        String string2;
        String string3;
        this.cfw.addALoad(this.contextLocal);
        if (n == 30) {
            this.generateExpression(node2, node);
        } else {
            this.generateFunctionAndThisObj(node2, node);
        }
        this.generateCallArgArray(node, node2.getNext(), false);
        if (n == 30) {
            string3 = "newObjectSpecial";
            string2 = "(Lorg/mozilla/javascript/Context;Ljava/lang/Object;[Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;I)Ljava/lang/Object;";
            this.cfw.addALoad(this.variableObjectLocal);
            this.cfw.addALoad(this.thisObjLocal);
            this.cfw.addPush(n2);
        } else {
            string3 = "callSpecial";
            string2 = "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;ILjava/lang/String;I)Ljava/lang/Object;";
            this.cfw.addALoad(this.variableObjectLocal);
            this.cfw.addALoad(this.thisObjLocal);
            this.cfw.addPush(n2);
            String string4 = this.scriptOrFn.getSourceName();
            ClassFileWriter classFileWriter = this.cfw;
            if (string4 == null) {
                string4 = "";
            }
            classFileWriter.addPush(string4);
            this.cfw.addPush(this.itsLineNumber);
        }
        this.addOptRuntimeInvoke(string3, string2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitStandardCall(Node node, Node node2) {
        String string2;
        String string3;
        if (node.getType() != 38) {
            throw Codegen.badTree();
        }
        Node node3 = node2.getNext();
        int n = node2.getType();
        if (node3 == null) {
            if (n == 39) {
                String string4 = node2.getString();
                this.cfw.addPush(string4);
                string2 = "callName0";
                string3 = "(Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
            } else if (n == 33) {
                Node node4 = node2.getFirstChild();
                this.generateExpression(node4, node);
                String string5 = node4.getNext().getString();
                this.cfw.addPush(string5);
                string2 = "callProp0";
                string3 = "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
            } else {
                if (n == 34) {
                    throw Kit.codeBug();
                }
                this.generateFunctionAndThisObj(node2, node);
                string2 = "call0";
                string3 = "(Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
            }
        } else if (n == 39) {
            String string6 = node2.getString();
            this.generateCallArgArray(node, node3, false);
            this.cfw.addPush(string6);
            string2 = "callName";
            string3 = "([Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
        } else {
            int n2 = 0;
            for (Node node5 = node3; node5 != null; ++n2, node5 = node5.getNext()) {
            }
            this.generateFunctionAndThisObj(node2, node);
            if (n2 == 1) {
                this.generateExpression(node3, node);
                string2 = "call1";
                string3 = "(Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
            } else if (n2 == 2) {
                this.generateExpression(node3, node);
                this.generateExpression(node3.getNext(), node);
                string2 = "call2";
                string3 = "(Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
            } else {
                this.generateCallArgArray(node, node3, false);
                string2 = "callN";
                string3 = "(Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
            }
        }
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        this.addOptRuntimeInvoke(string2, string3);
    }

    private void visitStandardNew(Node node, Node node2) {
        if (node.getType() != 30) {
            throw Codegen.badTree();
        }
        Node node3 = node2.getNext();
        this.generateExpression(node2, node);
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        this.generateCallArgArray(node, node3, false);
        this.addScriptRuntimeInvoke("newObject", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
    }

    private void visitStrictSetName(Node node, Node node2) {
        String string2 = node.getFirstChild().getString();
        while (node2 != null) {
            this.generateExpression(node2, node);
            node2 = node2.getNext();
        }
        this.cfw.addALoad(this.contextLocal);
        this.cfw.addALoad(this.variableObjectLocal);
        this.cfw.addPush(string2);
        this.addScriptRuntimeInvoke("strictSetName", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Ljava/lang/Object;");
    }

    private void visitSwitch(Jump jump, Node node) {
        this.generateExpression(node, jump);
        short s = this.getNewWordLocal();
        this.cfw.addAStore(s);
        for (Jump jump2 = (Jump)node.getNext(); jump2 != null; jump2 = (Jump)jump2.getNext()) {
            if (jump2.getType() != 115) {
                throw Codegen.badTree();
            }
            this.generateExpression(jump2.getFirstChild(), jump2);
            this.cfw.addALoad(s);
            this.addScriptRuntimeInvoke("shallowEq", "(Ljava/lang/Object;Ljava/lang/Object;)Z");
            this.addGoto(jump2.target, 154);
        }
        this.releaseWordLocal(s);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitTryCatchFinally(Jump jump, Node node) {
        short s = this.getNewWordLocal();
        this.cfw.addALoad(this.variableObjectLocal);
        this.cfw.addAStore(s);
        int n = this.cfw.acquireLabel();
        this.cfw.markLabel(n, (short)0);
        Node node2 = jump.target;
        Node node3 = jump.getFinally();
        int[] arrn = new int[5];
        this.exceptionManager.pushExceptionInfo(jump);
        if (node2 != null) {
            arrn[0] = this.cfw.acquireLabel();
            arrn[1] = this.cfw.acquireLabel();
            arrn[2] = this.cfw.acquireLabel();
            Context context = Context.getCurrentContext();
            if (context != null && context.hasFeature(13)) {
                arrn[3] = this.cfw.acquireLabel();
            }
        }
        if (node3 != null) {
            arrn[4] = this.cfw.acquireLabel();
        }
        this.exceptionManager.setHandlers(arrn, n);
        if (this.isGenerator && node3 != null) {
            FinallyReturnPoint finallyReturnPoint = new FinallyReturnPoint();
            if (this.finallys == null) {
                this.finallys = new HashMap();
            }
            this.finallys.put((Object)node3, (Object)finallyReturnPoint);
            this.finallys.put((Object)node3.getNext(), (Object)finallyReturnPoint);
        }
        while (node != null) {
            if (node == node2) {
                int n2 = this.getTargetLabel(node2);
                this.exceptionManager.removeHandler(0, n2);
                this.exceptionManager.removeHandler(1, n2);
                this.exceptionManager.removeHandler(2, n2);
                this.exceptionManager.removeHandler(3, n2);
            }
            this.generateStatement(node);
            node = node.getNext();
        }
        int n3 = this.cfw.acquireLabel();
        this.cfw.add(167, n3);
        int n4 = this.getLocalBlockRegister(jump);
        if (node2 != null) {
            int n5 = node2.labelId();
            this.generateCatchBlock(0, s, n5, n4, arrn[0]);
            this.generateCatchBlock(1, s, n5, n4, arrn[1]);
            this.generateCatchBlock(2, s, n5, n4, arrn[2]);
            Context context = Context.getCurrentContext();
            if (context != null && context.hasFeature(13)) {
                this.generateCatchBlock(3, s, n5, n4, arrn[3]);
            }
        }
        if (node3 != null) {
            int n6 = this.cfw.acquireLabel();
            int n7 = this.cfw.acquireLabel();
            this.cfw.markHandler(n6);
            if (!this.isGenerator) {
                this.cfw.markLabel(arrn[4]);
            }
            this.cfw.addAStore(n4);
            this.cfw.addALoad(s);
            this.cfw.addAStore(this.variableObjectLocal);
            int n8 = node3.labelId();
            if (this.isGenerator) {
                this.addGotoWithReturn(node3);
            } else {
                this.inlineFinally(node3, arrn[4], n7);
            }
            this.cfw.addALoad(n4);
            if (this.isGenerator) {
                this.cfw.add(192, "java/lang/Throwable");
            }
            this.cfw.add(191);
            this.cfw.markLabel(n7);
            if (this.isGenerator) {
                this.cfw.addExceptionHandler(n, n8, n6, null);
            }
        }
        this.releaseWordLocal(s);
        this.cfw.markLabel(n3);
        if (!this.isGenerator) {
            this.exceptionManager.popExceptionInfo();
        }
    }

    private void visitTypeofname(Node node) {
        int n;
        if (this.hasVarsInRegs && (n = this.fnCurrent.fnode.getIndexForNameNode(node)) >= 0) {
            if (this.fnCurrent.isNumberVar(n)) {
                this.cfw.addPush("number");
                return;
            }
            if (this.varIsDirectCallParameter(n)) {
                short s = this.varRegisters[n];
                this.cfw.addALoad(s);
                this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
                int n2 = this.cfw.acquireLabel();
                this.cfw.add(165, n2);
                short s2 = this.cfw.getStackTop();
                this.cfw.addALoad(s);
                this.addScriptRuntimeInvoke("typeof", "(Ljava/lang/Object;)Ljava/lang/String;");
                int n3 = this.cfw.acquireLabel();
                this.cfw.add(167, n3);
                this.cfw.markLabel(n2, s2);
                this.cfw.addPush("number");
                this.cfw.markLabel(n3);
                return;
            }
            this.cfw.addALoad(this.varRegisters[n]);
            this.addScriptRuntimeInvoke("typeof", "(Ljava/lang/Object;)Ljava/lang/String;");
            return;
        }
        this.cfw.addALoad(this.variableObjectLocal);
        this.cfw.addPush(node.getString());
        this.addScriptRuntimeInvoke("typeofName", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Ljava/lang/String;");
    }

    /*
     * Enabled aggressive block sorting
     */
    void generateBodyCode() {
        this.isGenerator = Codegen.isGenerator(this.scriptOrFn);
        this.initBodyGeneration();
        if (this.isGenerator) {
            String string2 = "(" + this.codegen.mainClassSignature + "Lorg/mozilla/javascript/Context;" + "Lorg/mozilla/javascript/Scriptable;" + "Ljava/lang/Object;" + "Ljava/lang/Object;I)Ljava/lang/Object;";
            this.cfw.startMethod(this.codegen.getBodyMethodName(this.scriptOrFn) + "_gen", string2, (short)10);
        } else {
            this.cfw.startMethod(this.codegen.getBodyMethodName(this.scriptOrFn), this.codegen.getBodyMethodSignature(this.scriptOrFn), (short)10);
        }
        this.generatePrologue();
        Node node = this.fnCurrent != null ? this.scriptOrFn.getLastChild() : this.scriptOrFn;
        this.generateStatement(node);
        this.generateEpilogue();
        this.cfw.stopMethod((short)(1 + this.localsMax));
        if (this.isGenerator) {
            this.generateGenerator();
        }
        if (this.literals != null) {
            block4 : for (int i = 0; i < this.literals.size(); ++i) {
                Node node2 = (Node)this.literals.get(i);
                int n = node2.getType();
                switch (n) {
                    default: {
                        Kit.codeBug(Token.typeToName(n));
                        continue block4;
                    }
                    case 66: {
                        this.generateObjectLiteralFactory(node2, i + 1);
                        continue block4;
                    }
                    case 65: {
                        this.generateArrayLiteralFactory(node2, i + 1);
                    }
                }
            }
        }
    }

    private class ExceptionManager {
        private LinkedList<ExceptionInfo> exceptionInfo = new LinkedList();

        ExceptionManager() {
        }

        private void endCatch(ExceptionInfo exceptionInfo, int n, int n2) {
            if (exceptionInfo.exceptionStarts[n] == 0) {
                throw new IllegalStateException("bad exception start");
            }
            int n3 = exceptionInfo.exceptionStarts[n];
            if (BodyCodegen.this.cfw.getLabelPC(n3) != BodyCodegen.this.cfw.getLabelPC(n2)) {
                BodyCodegen.this.cfw.addExceptionHandler(exceptionInfo.exceptionStarts[n], n2, exceptionInfo.handlerLabels[n], BodyCodegen.this.exceptionTypeToName(n));
            }
        }

        private ExceptionInfo getTop() {
            return (ExceptionInfo)this.exceptionInfo.getLast();
        }

        void addHandler(int n, int n2, int n3) {
            ExceptionInfo exceptionInfo = this.getTop();
            exceptionInfo.handlerLabels[n] = n2;
            exceptionInfo.exceptionStarts[n] = n3;
        }

        void markInlineFinallyEnd(Node node, int n) {
            ListIterator listIterator = this.exceptionInfo.listIterator(this.exceptionInfo.size());
            while (listIterator.hasPrevious()) {
                ExceptionInfo exceptionInfo = (ExceptionInfo)listIterator.previous();
                for (int i = 0; i < 5; ++i) {
                    if (exceptionInfo.handlerLabels[i] == 0 || exceptionInfo.currentFinally != node) continue;
                    exceptionInfo.exceptionStarts[i] = n;
                    exceptionInfo.currentFinally = null;
                }
                if (exceptionInfo.finallyBlock != node) continue;
            }
        }

        void markInlineFinallyStart(Node node, int n) {
            ListIterator listIterator = this.exceptionInfo.listIterator(this.exceptionInfo.size());
            while (listIterator.hasPrevious()) {
                ExceptionInfo exceptionInfo = (ExceptionInfo)listIterator.previous();
                for (int i = 0; i < 5; ++i) {
                    if (exceptionInfo.handlerLabels[i] == 0 || exceptionInfo.currentFinally != null) continue;
                    this.endCatch(exceptionInfo, i, n);
                    exceptionInfo.exceptionStarts[i] = 0;
                    exceptionInfo.currentFinally = node;
                }
                if (exceptionInfo.finallyBlock != node) continue;
            }
        }

        void popExceptionInfo() {
            this.exceptionInfo.removeLast();
        }

        void pushExceptionInfo(Jump jump) {
            ExceptionInfo exceptionInfo = new ExceptionInfo(jump, BodyCodegen.this.getFinallyAtTarget(jump.getFinally()));
            this.exceptionInfo.add((Object)exceptionInfo);
        }

        int removeHandler(int n, int n2) {
            ExceptionInfo exceptionInfo = this.getTop();
            if (exceptionInfo.handlerLabels[n] != 0) {
                int n3 = exceptionInfo.handlerLabels[n];
                this.endCatch(exceptionInfo, n, n2);
                exceptionInfo.handlerLabels[n] = 0;
                return n3;
            }
            return 0;
        }

        void setHandlers(int[] arrn, int n) {
            this.getTop();
            for (int i = 0; i < arrn.length; ++i) {
                if (arrn[i] == 0) continue;
                this.addHandler(i, arrn[i], n);
            }
        }

        private class ExceptionInfo {
            Node currentFinally;
            int[] exceptionStarts;
            Node finallyBlock;
            int[] handlerLabels;
            Jump node;

            ExceptionInfo(Jump jump, Node node) {
                this.node = jump;
                this.finallyBlock = node;
                this.handlerLabels = new int[5];
                this.exceptionStarts = new int[5];
                this.currentFinally = null;
            }
        }

    }

    static class FinallyReturnPoint {
        public List<Integer> jsrPoints = new ArrayList();
        public int tableLabel = 0;

        FinallyReturnPoint() {
        }
    }

}

