/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript.optimizer;

import org.mozilla.javascript.CompilerEnvirons;
import org.mozilla.javascript.IRFactory;
import org.mozilla.javascript.JavaAdapter;
import org.mozilla.javascript.ObjToIntMap;
import org.mozilla.javascript.Parser;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.ast.AstRoot;
import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.ast.ScriptNode;
import org.mozilla.javascript.optimizer.Codegen;

public class ClassCompiler {
    private CompilerEnvirons compilerEnv;
    private String mainMethodClassName;
    private Class<?> targetExtends;
    private Class<?>[] targetImplements;

    public ClassCompiler(CompilerEnvirons compilerEnvirons) {
        if (compilerEnvirons == null) {
            throw new IllegalArgumentException();
        }
        this.compilerEnv = compilerEnvirons;
        this.mainMethodClassName = "org.mozilla.javascript.optimizer.OptRuntime";
    }

    /*
     * Enabled aggressive block sorting
     */
    public Object[] compileToClassFiles(String string2, String string3, int n, String string4) {
        Parser parser = new Parser(this.compilerEnv);
        AstRoot astRoot = parser.parse(string2, string3, n);
        ScriptNode scriptNode = new IRFactory(this.compilerEnv).transformTree(astRoot);
        Class<?> class_ = this.getTargetExtends();
        Class<?>[] arrclass = this.getTargetImplements();
        boolean bl = arrclass == null && class_ == null;
        String string5 = bl ? string4 : this.makeAuxiliaryClassName(string4, "1");
        Codegen codegen = new Codegen();
        codegen.setMainMethodClass(this.mainMethodClassName);
        byte[] arrby = codegen.compileToClassFile(this.compilerEnv, string5, scriptNode, scriptNode.getEncodedSource(), false);
        if (bl) {
            return new Object[]{string5, arrby};
        }
        int n2 = scriptNode.getFunctionCount();
        ObjToIntMap objToIntMap = new ObjToIntMap(n2);
        for (int i = 0; i != n2; ++i) {
            FunctionNode functionNode = scriptNode.getFunctionNode(i);
            String string6 = functionNode.getName();
            if (string6 == null || string6.length() == 0) continue;
            objToIntMap.put(string6, functionNode.getParamCount());
        }
        if (class_ == null) {
            class_ = ScriptRuntime.ObjectClass;
        }
        return new Object[]{string4, JavaAdapter.createAdapterCode(objToIntMap, string4, class_, arrclass, string5), string5, arrby};
    }

    public CompilerEnvirons getCompilerEnv() {
        return this.compilerEnv;
    }

    public String getMainMethodClass() {
        return this.mainMethodClassName;
    }

    public Class<?> getTargetExtends() {
        return this.targetExtends;
    }

    public Class<?>[] getTargetImplements() {
        if (this.targetImplements == null) {
            return null;
        }
        return (Class[])this.targetImplements.clone();
    }

    protected String makeAuxiliaryClassName(String string2, String string3) {
        return string2 + string3;
    }

    public void setMainMethodClass(String string2) {
        this.mainMethodClassName = string2;
    }

    public void setTargetExtends(Class<?> class_) {
        this.targetExtends = class_;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setTargetImplements(Class<?>[] arrclass) {
        Class[] arrclass2 = arrclass == null ? null : (Class[])arrclass.clone();
        this.targetImplements = arrclass2;
    }
}

