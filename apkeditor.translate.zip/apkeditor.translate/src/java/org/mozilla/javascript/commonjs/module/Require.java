/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.ThreadLocal
 *  java.lang.Throwable
 *  java.net.URI
 *  java.net.URISyntaxException
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package org.mozilla.javascript.commonjs.module;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.commonjs.module.ModuleScope;
import org.mozilla.javascript.commonjs.module.ModuleScript;
import org.mozilla.javascript.commonjs.module.ModuleScriptProvider;

public class Require
extends BaseFunction {
    private static final ThreadLocal<Map<String, Scriptable>> loadingModuleInterfaces = new ThreadLocal();
    private static final long serialVersionUID = 1L;
    private final Map<String, Scriptable> exportedModuleInterfaces = new ConcurrentHashMap();
    private final Object loadLock = new Object();
    private Scriptable mainExports;
    private String mainModuleId = null;
    private final ModuleScriptProvider moduleScriptProvider;
    private final Scriptable nativeScope;
    private final Scriptable paths;
    private final Script postExec;
    private final Script preExec;
    private final boolean sandboxed;

    public Require(Context context, Scriptable scriptable, ModuleScriptProvider moduleScriptProvider, Script script, Script script2, boolean bl) {
        this.moduleScriptProvider = moduleScriptProvider;
        this.nativeScope = scriptable;
        this.sandboxed = bl;
        this.preExec = script;
        this.postExec = script2;
        this.setPrototype(ScriptableObject.getFunctionPrototype(scriptable));
        if (!bl) {
            this.paths = context.newArray(scriptable, 0);
            Require.defineReadOnlyProperty(this, "paths", this.paths);
            return;
        }
        this.paths = null;
    }

    private static void defineReadOnlyProperty(ScriptableObject scriptableObject, String string2, Object object) {
        ScriptableObject.putProperty((Scriptable)scriptableObject, string2, object);
        scriptableObject.setAttributes(string2, 5);
    }

    private Scriptable executeModuleScript(Context context, String string2, Scriptable scriptable, ModuleScript moduleScript, boolean bl) {
        ScriptableObject scriptableObject = (ScriptableObject)context.newObject(this.nativeScope);
        URI uRI = moduleScript.getUri();
        URI uRI2 = moduleScript.getBase();
        Require.defineReadOnlyProperty(scriptableObject, "id", string2);
        if (!this.sandboxed) {
            Require.defineReadOnlyProperty(scriptableObject, "uri", uRI.toString());
        }
        ModuleScope moduleScope = new ModuleScope(this.nativeScope, uRI, uRI2);
        moduleScope.put("exports", (Scriptable)moduleScope, (Object)scriptable);
        moduleScope.put("module", (Scriptable)moduleScope, (Object)scriptableObject);
        scriptableObject.put("exports", (Scriptable)scriptableObject, (Object)scriptable);
        this.install(moduleScope);
        if (bl) {
            Require.defineReadOnlyProperty(this, "main", scriptableObject);
        }
        Require.executeOptionalScript(this.preExec, context, moduleScope);
        moduleScript.getScript().exec(context, moduleScope);
        Require.executeOptionalScript(this.postExec, context, moduleScope);
        return ScriptRuntime.toObject(context, this.nativeScope, ScriptableObject.getProperty((Scriptable)scriptableObject, "exports"));
    }

    private static void executeOptionalScript(Script script, Context context, Scriptable scriptable) {
        if (script != null) {
            script.exec(context, scriptable);
        }
    }

    /*
     * Exception decompiling
     */
    private Scriptable getExportedModuleInterface(Context var1_1, String var2_2, URI var3_3, URI var4_4, boolean var5_5) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private ModuleScript getModule(Context context, String string2, URI uRI, URI uRI2) {
        ModuleScript moduleScript = this.moduleScriptProvider.getModuleScript(context, string2, uRI, uRI2, this.paths);
        if (moduleScript != null) return moduleScript;
        try {
            throw ScriptRuntime.throwError(context, this.nativeScope, "Module \"" + string2 + "\" not found.");
        }
        catch (RuntimeException runtimeException) {
            throw runtimeException;
        }
        catch (Exception exception) {
            throw Context.throwAsScriptRuntimeEx(exception);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        URI uRI;
        URI uRI2;
        if (arrobject == null) throw ScriptRuntime.throwError(context, scriptable, "require() needs one argument");
        if (arrobject.length < 1) {
            throw ScriptRuntime.throwError(context, scriptable, "require() needs one argument");
        }
        String string2 = (String)Context.jsToJava(arrobject[0], String.class);
        if (!string2.startsWith("./")) {
            boolean bl = string2.startsWith("../");
            uRI = null;
            uRI2 = null;
            if (!bl) return this.getExportedModuleInterface(context, string2, uRI, uRI2, false);
        }
        if (!(scriptable2 instanceof ModuleScope)) {
            throw ScriptRuntime.throwError(context, scriptable, "Can't resolve relative module ID \"" + string2 + "\" when require() is used outside of a module");
        }
        ModuleScope moduleScope = (ModuleScope)scriptable2;
        uRI2 = moduleScope.getBase();
        URI uRI3 = moduleScope.getUri();
        uRI = uRI3.resolve(string2);
        if (uRI2 == null) {
            string2 = uRI.toString();
            return this.getExportedModuleInterface(context, string2, uRI, uRI2, false);
        }
        string2 = uRI2.relativize(uRI3).resolve(string2).toString();
        if (string2.charAt(0) != '.') return this.getExportedModuleInterface(context, string2, uRI, uRI2, false);
        if (this.sandboxed) {
            throw ScriptRuntime.throwError(context, scriptable, "Module \"" + string2 + "\" is not contained in sandbox.");
        }
        string2 = uRI.toString();
        return this.getExportedModuleInterface(context, string2, uRI, uRI2, false);
    }

    @Override
    public Scriptable construct(Context context, Scriptable scriptable, Object[] arrobject) {
        throw ScriptRuntime.throwError(context, scriptable, "require() can not be invoked as a constructor");
    }

    @Override
    public int getArity() {
        return 1;
    }

    @Override
    public String getFunctionName() {
        return "require";
    }

    @Override
    public int getLength() {
        return 1;
    }

    public void install(Scriptable scriptable) {
        ScriptableObject.putProperty(scriptable, "require", (Object)this);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Scriptable requireMain(Context context, String string2) {
        block11 : {
            block10 : {
                if (this.mainModuleId != null) {
                    if (!this.mainModuleId.equals((Object)string2)) {
                        throw new IllegalStateException("Main module already set to " + this.mainModuleId);
                    }
                    return this.mainExports;
                }
                try {
                    ModuleScript moduleScript = this.moduleScriptProvider.getModuleScript(context, string2, null, null, this.paths);
                    if (moduleScript == null) break block10;
                }
                catch (RuntimeException runtimeException) {
                    throw runtimeException;
                }
                catch (Exception exception) {
                    throw new RuntimeException((Throwable)exception);
                }
                this.mainExports = this.getExportedModuleInterface(context, string2, null, null, true);
                break block11;
            }
            if (!this.sandboxed) {
                URI uRI;
                try {
                    URI uRI2;
                    uRI = uRI2 = new URI(string2);
                }
                catch (URISyntaxException uRISyntaxException) {
                    uRI = null;
                }
                if (uRI == null || !uRI.isAbsolute()) {
                    File file = new File(string2);
                    if (!file.isFile()) {
                        throw ScriptRuntime.throwError(context, this.nativeScope, "Module \"" + string2 + "\" not found.");
                    }
                    uRI = file.toURI();
                }
                this.mainExports = this.getExportedModuleInterface(context, uRI.toString(), uRI, null, true);
            }
        }
        this.mainModuleId = string2;
        return this.mainExports;
    }
}

