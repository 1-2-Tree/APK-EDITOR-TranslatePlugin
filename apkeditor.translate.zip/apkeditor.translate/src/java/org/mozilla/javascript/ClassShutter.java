/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript;

public interface ClassShutter {
    public boolean visibleToScripts(String var1);
}

