/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Member
 *  java.util.Iterator
 */
package org.mozilla.javascript;

import java.lang.reflect.Member;
import java.util.Iterator;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextFactory;
import org.mozilla.javascript.InterfaceAdapter;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Wrapper;

public abstract class VMBridge {
    static final VMBridge instance = VMBridge.makeInstance();

    private static VMBridge makeInstance() {
        String[] arrstring = new String[]{"org.mozilla.javascript.VMBridge_custom", "org.mozilla.javascript.jdk15.VMBridge_jdk15", "org.mozilla.javascript.jdk13.VMBridge_jdk13", "org.mozilla.javascript.jdk11.VMBridge_jdk11"};
        for (int i = 0; i != arrstring.length; ++i) {
            VMBridge vMBridge;
            Class<?> class_ = Kit.classOrNull(arrstring[i]);
            if (class_ == null || (vMBridge = (VMBridge)Kit.newInstanceOrNull(class_)) == null) continue;
            return vMBridge;
        }
        throw new IllegalStateException("Failed to create VMBridge instance");
    }

    protected abstract Context getContext(Object var1);

    protected abstract ClassLoader getCurrentThreadClassLoader();

    protected Object getInterfaceProxyHelper(ContextFactory contextFactory, Class<?>[] arrclass) {
        throw Context.reportRuntimeError("VMBridge.getInterfaceProxyHelper is not supported");
    }

    public Iterator<?> getJavaIterator(Context context, Scriptable scriptable, Object object) {
        if (object instanceof Wrapper) {
            Object object2 = ((Wrapper)object).unwrap();
            boolean bl = object2 instanceof Iterator;
            Iterator iterator = null;
            if (bl) {
                iterator = (Iterator)object2;
            }
            return iterator;
        }
        return null;
    }

    protected abstract Object getThreadContextHelper();

    protected abstract boolean isVarArgs(Member var1);

    protected Object newInterfaceProxy(Object object, ContextFactory contextFactory, InterfaceAdapter interfaceAdapter, Object object2, Scriptable scriptable) {
        throw Context.reportRuntimeError("VMBridge.newInterfaceProxy is not supported");
    }

    protected abstract void setContext(Object var1, Context var2);

    protected abstract boolean tryToMakeAccessible(Object var1);
}

