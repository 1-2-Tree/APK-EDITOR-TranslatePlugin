/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.NativeJavaArray;
import org.mozilla.javascript.NativeJavaClass;
import org.mozilla.javascript.NativeJavaObject;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;

public class WrapFactory {
    private boolean javaPrimitiveWrap = true;

    public final boolean isJavaPrimitiveWrap() {
        return this.javaPrimitiveWrap;
    }

    public final void setJavaPrimitiveWrap(boolean bl) {
        Context context = Context.getCurrentContext();
        if (context != null && context.isSealed()) {
            Context.onSealedMutation();
        }
        this.javaPrimitiveWrap = bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    public Object wrap(Context context, Scriptable scriptable, Object object, Class<?> class_) {
        if (object == null || object == Undefined.instance || object instanceof Scriptable) return object;
        if (class_ != null && class_.isPrimitive()) {
            if (class_ == Void.TYPE) {
                return Undefined.instance;
            }
            if (class_ != Character.TYPE) return object;
            return (int)((Character)object).charValue();
        }
        if (!this.isJavaPrimitiveWrap()) {
            if (object instanceof String || object instanceof Number || object instanceof Boolean) {
                return object;
            }
            if (object instanceof Character) {
                return String.valueOf((char)((Character)object).charValue());
            }
        }
        if (!object.getClass().isArray()) return this.wrapAsJavaObject(context, scriptable, object, class_);
        return NativeJavaArray.wrap(scriptable, object);
    }

    public Scriptable wrapAsJavaObject(Context context, Scriptable scriptable, Object object, Class<?> class_) {
        return new NativeJavaObject(scriptable, object, class_);
    }

    public Scriptable wrapJavaClass(Context context, Scriptable scriptable, Class<?> class_) {
        return new NativeJavaClass(scriptable, class_);
    }

    public Scriptable wrapNewObject(Context context, Scriptable scriptable, Object object) {
        if (object instanceof Scriptable) {
            return (Scriptable)object;
        }
        if (object.getClass().isArray()) {
            return NativeJavaArray.wrap(scriptable, object);
        }
        return this.wrapAsJavaObject(context, scriptable, object, null);
    }
}

