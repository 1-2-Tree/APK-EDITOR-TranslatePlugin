/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;

public class RegExpLiteral
extends AstNode {
    private String flags;
    private String value;

    public RegExpLiteral() {
        this.type = 48;
    }

    public RegExpLiteral(int n) {
        super(n);
        this.type = 48;
    }

    public RegExpLiteral(int n, int n2) {
        super(n, n2);
        this.type = 48;
    }

    public String getFlags() {
        return this.flags;
    }

    public String getValue() {
        return this.value;
    }

    public void setFlags(String string2) {
        this.flags = string2;
    }

    public void setValue(String string2) {
        this.assertNotNull(string2);
        this.value = string2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public String toSource(int n) {
        String string2;
        StringBuilder stringBuilder = new StringBuilder().append(this.makeIndent(n)).append("/").append(this.value).append("/");
        if (this.flags == null) {
            string2 = "";
            do {
                return stringBuilder.append(string2).toString();
                break;
            } while (true);
        }
        string2 = this.flags;
        return stringBuilder.append(string2).toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        nodeVisitor.visit(this);
    }
}

