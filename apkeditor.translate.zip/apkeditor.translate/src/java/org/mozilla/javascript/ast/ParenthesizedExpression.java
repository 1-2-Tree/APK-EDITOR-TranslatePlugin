/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;

public class ParenthesizedExpression
extends AstNode {
    private AstNode expression;

    public ParenthesizedExpression() {
        this.type = 87;
    }

    public ParenthesizedExpression(int n) {
        super(n);
        this.type = 87;
    }

    public ParenthesizedExpression(int n, int n2) {
        super(n, n2);
        this.type = 87;
    }

    public ParenthesizedExpression(int n, int n2, AstNode astNode) {
        super(n, n2);
        this.type = 87;
        this.setExpression(astNode);
    }

    /*
     * Enabled aggressive block sorting
     */
    public ParenthesizedExpression(AstNode astNode) {
        int n = astNode != null ? astNode.getPosition() : 0;
        int n2 = astNode != null ? astNode.getLength() : 1;
        this(n, n2, astNode);
    }

    public AstNode getExpression() {
        return this.expression;
    }

    public void setExpression(AstNode astNode) {
        this.assertNotNull(astNode);
        this.expression = astNode;
        astNode.setParent(this);
    }

    @Override
    public String toSource(int n) {
        return this.makeIndent(n) + "(" + this.expression.toSource(0) + ")";
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        if (nodeVisitor.visit(this)) {
            this.expression.visit(nodeVisitor);
        }
    }
}

