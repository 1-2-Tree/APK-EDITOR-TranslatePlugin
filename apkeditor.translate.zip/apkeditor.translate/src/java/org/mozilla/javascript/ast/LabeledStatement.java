/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package org.mozilla.javascript.ast;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.Label;
import org.mozilla.javascript.ast.NodeVisitor;

public class LabeledStatement
extends AstNode {
    private List<Label> labels = new ArrayList();
    private AstNode statement;

    public LabeledStatement() {
        this.type = 133;
    }

    public LabeledStatement(int n) {
        super(n);
        this.type = 133;
    }

    public LabeledStatement(int n, int n2) {
        super(n, n2);
        this.type = 133;
    }

    public void addLabel(Label label) {
        this.assertNotNull(label);
        this.labels.add((Object)label);
        label.setParent(this);
    }

    public Label getFirstLabel() {
        return (Label)this.labels.get(0);
    }

    public Label getLabelByName(String string2) {
        for (Label label : this.labels) {
            if (!string2.equals((Object)label.getName())) continue;
            return label;
        }
        return null;
    }

    public List<Label> getLabels() {
        return this.labels;
    }

    public AstNode getStatement() {
        return this.statement;
    }

    @Override
    public boolean hasSideEffects() {
        return true;
    }

    public void setLabels(List<Label> list) {
        this.assertNotNull(list);
        if (this.labels != null) {
            this.labels.clear();
        }
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            this.addLabel((Label)iterator.next());
        }
    }

    public void setStatement(AstNode astNode) {
        this.assertNotNull(astNode);
        this.statement = astNode;
        astNode.setParent(this);
    }

    @Override
    public String toSource(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        Iterator iterator = this.labels.iterator();
        while (iterator.hasNext()) {
            stringBuilder.append(((Label)iterator.next()).toSource(n));
        }
        stringBuilder.append(this.statement.toSource(n + 1));
        return stringBuilder.toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        if (nodeVisitor.visit(this)) {
            Iterator iterator = this.labels.iterator();
            while (iterator.hasNext()) {
                ((AstNode)iterator.next()).visit(nodeVisitor);
            }
            this.statement.visit(nodeVisitor);
        }
    }
}

