/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.Node;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.InfixExpression;

public class ObjectProperty
extends InfixExpression {
    public ObjectProperty() {
        this.type = 103;
    }

    public ObjectProperty(int n) {
        super(n);
        this.type = 103;
    }

    public ObjectProperty(int n, int n2) {
        super(n, n2);
        this.type = 103;
    }

    public boolean isGetterMethod() {
        return this.type == 151;
    }

    public boolean isMethod() {
        return this.isGetterMethod() || this.isSetterMethod() || this.isNormalMethod();
    }

    public boolean isNormalMethod() {
        return this.type == 163;
    }

    public boolean isSetterMethod() {
        return this.type == 152;
    }

    public void setIsGetterMethod() {
        this.type = 151;
    }

    public void setIsNormalMethod() {
        this.type = 163;
    }

    public void setIsSetterMethod() {
        this.type = 152;
    }

    public void setNodeType(int n) {
        if (n != 103 && n != 151 && n != 152 && n != 163) {
            throw new IllegalArgumentException("invalid node type: " + n);
        }
        this.setType(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public String toSource(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("\n");
        stringBuilder.append(this.makeIndent(n + 1));
        if (this.isGetterMethod()) {
            stringBuilder.append("get ");
        } else if (this.isSetterMethod()) {
            stringBuilder.append("set ");
        }
        AstNode astNode = this.left;
        int n2 = this.getType() == 103 ? 0 : n;
        stringBuilder.append(astNode.toSource(n2));
        if (this.type == 103) {
            stringBuilder.append(": ");
        }
        AstNode astNode2 = this.right;
        int n3 = this.getType();
        int n4 = 0;
        if (n3 != 103) {
            n4 = n + 1;
        }
        stringBuilder.append(astNode2.toSource(n4));
        return stringBuilder.toString();
    }
}

