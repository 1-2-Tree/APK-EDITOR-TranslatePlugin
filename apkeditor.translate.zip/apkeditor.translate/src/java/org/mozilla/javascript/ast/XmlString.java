/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;
import org.mozilla.javascript.ast.XmlFragment;

public class XmlString
extends XmlFragment {
    private String xml;

    public XmlString() {
    }

    public XmlString(int n) {
        super(n);
    }

    public XmlString(int n, String string2) {
        super(n);
        this.setXml(string2);
    }

    public String getXml() {
        return this.xml;
    }

    public void setXml(String string2) {
        this.assertNotNull(string2);
        this.xml = string2;
        this.setLength(string2.length());
    }

    @Override
    public String toSource(int n) {
        return this.makeIndent(n) + this.xml;
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        nodeVisitor.visit(this);
    }
}

