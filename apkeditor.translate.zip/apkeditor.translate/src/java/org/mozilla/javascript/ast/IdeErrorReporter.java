/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.ErrorReporter;

public interface IdeErrorReporter
extends ErrorReporter {
    public void error(String var1, String var2, int var3, int var4);

    public void warning(String var1, String var2, int var3, int var4);
}

