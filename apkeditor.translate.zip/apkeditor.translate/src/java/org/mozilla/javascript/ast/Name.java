/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;
import org.mozilla.javascript.ast.Scope;

public class Name
extends AstNode {
    private String identifier;
    private Scope scope;

    public Name() {
        this.type = 39;
    }

    public Name(int n) {
        super(n);
        this.type = 39;
    }

    public Name(int n, int n2) {
        super(n, n2);
        this.type = 39;
    }

    public Name(int n, int n2, String string2) {
        super(n, n2);
        this.type = 39;
        this.setIdentifier(string2);
    }

    public Name(int n, String string2) {
        super(n);
        this.type = 39;
        this.setIdentifier(string2);
        this.setLength(string2.length());
    }

    public Scope getDefiningScope() {
        Scope scope = this.getEnclosingScope();
        String string2 = this.getIdentifier();
        if (scope == null) {
            return null;
        }
        return scope.getDefiningScope(string2);
    }

    public String getIdentifier() {
        return this.identifier;
    }

    @Override
    public Scope getScope() {
        return this.scope;
    }

    public boolean isLocalName() {
        Scope scope = this.getDefiningScope();
        return scope != null && scope.getParentScope() != null;
    }

    public int length() {
        if (this.identifier == null) {
            return 0;
        }
        return this.identifier.length();
    }

    public void setIdentifier(String string2) {
        this.assertNotNull(string2);
        this.identifier = string2;
        this.setLength(string2.length());
    }

    @Override
    public void setScope(Scope scope) {
        this.scope = scope;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public String toSource(int n) {
        String string2;
        StringBuilder stringBuilder = new StringBuilder().append(this.makeIndent(n));
        if (this.identifier == null) {
            string2 = "<null>";
            do {
                return stringBuilder.append(string2).toString();
                break;
            } while (true);
        }
        string2 = this.identifier;
        return stringBuilder.append(string2).toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        nodeVisitor.visit(this);
    }
}

