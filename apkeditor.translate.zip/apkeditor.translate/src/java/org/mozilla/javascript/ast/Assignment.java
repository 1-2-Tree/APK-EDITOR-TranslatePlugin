/*
 * Decompiled with CFR 0.0.
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.InfixExpression;

public class Assignment
extends InfixExpression {
    public Assignment() {
    }

    public Assignment(int n) {
        super(n);
    }

    public Assignment(int n, int n2) {
        super(n, n2);
    }

    public Assignment(int n, int n2, AstNode astNode, AstNode astNode2) {
        super(n, n2, astNode, astNode2);
    }

    public Assignment(int n, AstNode astNode, AstNode astNode2, int n2) {
        super(n, astNode, astNode2, n2);
    }

    public Assignment(AstNode astNode, AstNode astNode2) {
        super(astNode, astNode2);
    }
}

