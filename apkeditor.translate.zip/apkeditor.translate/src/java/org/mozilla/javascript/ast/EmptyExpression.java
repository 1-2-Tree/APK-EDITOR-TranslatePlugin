/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;

public class EmptyExpression
extends AstNode {
    public EmptyExpression() {
        this.type = 128;
    }

    public EmptyExpression(int n) {
        super(n);
        this.type = 128;
    }

    public EmptyExpression(int n, int n2) {
        super(n, n2);
        this.type = 128;
    }

    @Override
    public String toSource(int n) {
        return this.makeIndent(n);
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        nodeVisitor.visit(this);
    }
}

