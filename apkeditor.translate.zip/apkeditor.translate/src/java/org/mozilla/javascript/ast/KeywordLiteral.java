/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.Node;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;

public class KeywordLiteral
extends AstNode {
    public KeywordLiteral() {
    }

    public KeywordLiteral(int n) {
        super(n);
    }

    public KeywordLiteral(int n, int n2) {
        super(n, n2);
    }

    public KeywordLiteral(int n, int n2, int n3) {
        super(n, n2);
        this.setType(n3);
    }

    public boolean isBooleanLiteral() {
        return this.type == 45 || this.type == 44;
    }

    @Override
    public KeywordLiteral setType(int n) {
        if (n != 43 && n != 42 && n != 45 && n != 44 && n != 160) {
            throw new IllegalArgumentException("Invalid node type: " + n);
        }
        this.type = n;
        return this;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public String toSource(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.makeIndent(n));
        switch (this.getType()) {
            default: {
                throw new IllegalStateException("Invalid keyword literal type: " + this.getType());
            }
            case 43: {
                stringBuilder.append("this");
                do {
                    return stringBuilder.toString();
                    break;
                } while (true);
            }
            case 42: {
                stringBuilder.append("null");
                return stringBuilder.toString();
            }
            case 45: {
                stringBuilder.append("true");
                return stringBuilder.toString();
            }
            case 44: {
                stringBuilder.append("false");
                return stringBuilder.toString();
            }
            case 160: 
        }
        stringBuilder.append("debugger;\n");
        return stringBuilder.toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        nodeVisitor.visit(this);
    }
}

