/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.Jump;
import org.mozilla.javascript.ast.NodeVisitor;

public class Label
extends Jump {
    private String name;

    public Label() {
        this.type = 130;
    }

    public Label(int n) {
        this(n, -1);
    }

    public Label(int n, int n2) {
        this.type = 130;
        this.position = n;
        this.length = n2;
    }

    public Label(int n, int n2, String string2) {
        this(n, n2);
        this.setName(string2);
    }

    public String getName() {
        return this.name;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setName(String string2) {
        String string3 = string2 == null ? null : string2.trim();
        if (string3 != null && !"".equals((Object)string3)) {
            this.name = string3;
            return;
        }
        throw new IllegalArgumentException("invalid label name");
    }

    @Override
    public String toSource(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.makeIndent(n));
        stringBuilder.append(this.name);
        stringBuilder.append(":\n");
        return stringBuilder.toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        nodeVisitor.visit(this);
    }
}

