/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;

public class Yield
extends AstNode {
    private AstNode value;

    public Yield() {
        this.type = 72;
    }

    public Yield(int n) {
        super(n);
        this.type = 72;
    }

    public Yield(int n, int n2) {
        super(n, n2);
        this.type = 72;
    }

    public Yield(int n, int n2, AstNode astNode) {
        super(n, n2);
        this.type = 72;
        this.setValue(astNode);
    }

    public AstNode getValue() {
        return this.value;
    }

    public void setValue(AstNode astNode) {
        this.value = astNode;
        if (astNode != null) {
            astNode.setParent(this);
        }
    }

    @Override
    public String toSource(int n) {
        if (this.value == null) {
            return "yield";
        }
        return "yield " + this.value.toSource(0);
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        if (nodeVisitor.visit(this) && this.value != null) {
            this.value.visit(nodeVisitor);
        }
    }
}

