/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package org.mozilla.javascript.ast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.Jump;
import org.mozilla.javascript.ast.NodeVisitor;
import org.mozilla.javascript.ast.ScriptNode;
import org.mozilla.javascript.ast.Symbol;

public class Scope
extends Jump {
    private List<Scope> childScopes;
    protected Scope parentScope;
    protected Map<String, Symbol> symbolTable;
    protected ScriptNode top;

    public Scope() {
        this.type = 129;
    }

    public Scope(int n) {
        this.type = 129;
        this.position = n;
    }

    public Scope(int n, int n2) {
        this(n);
        this.length = n2;
    }

    private Map<String, Symbol> ensureSymbolTable() {
        if (this.symbolTable == null) {
            this.symbolTable = new LinkedHashMap(5);
        }
        return this.symbolTable;
    }

    public static void joinScopes(Scope scope, Scope scope2) {
        Map<String, Symbol> map = scope.ensureSymbolTable();
        Map<String, Symbol> map2 = scope2.ensureSymbolTable();
        if (!Collections.disjoint((Collection)map.keySet(), (Collection)map2.keySet())) {
            Scope.codeBug();
        }
        for (Map.Entry entry : map.entrySet()) {
            Symbol symbol = (Symbol)entry.getValue();
            symbol.setContainingTable(scope2);
            map2.put(entry.getKey(), (Object)symbol);
        }
    }

    public static Scope splitScope(Scope scope) {
        Scope scope2 = new Scope(scope.getType());
        scope2.symbolTable = scope.symbolTable;
        scope.symbolTable = null;
        scope2.parent = scope.parent;
        scope2.setParentScope(scope.getParentScope());
        scope2.setParentScope(scope2);
        scope.parent = scope2;
        scope2.top = scope.top;
        return scope2;
    }

    public void addChildScope(Scope scope) {
        if (this.childScopes == null) {
            this.childScopes = new ArrayList();
        }
        this.childScopes.add((Object)scope);
        scope.setParentScope(this);
    }

    public void clearParentScope() {
        this.parentScope = null;
    }

    public List<Scope> getChildScopes() {
        return this.childScopes;
    }

    public Scope getDefiningScope(String string2) {
        Scope scope = this;
        while (scope != null) {
            Map<String, Symbol> map = scope.getSymbolTable();
            if (map != null && map.containsKey((Object)string2)) {
                return scope;
            }
            scope = scope.parentScope;
        }
        return null;
    }

    public Scope getParentScope() {
        return this.parentScope;
    }

    public List<AstNode> getStatements() {
        ArrayList arrayList = new ArrayList();
        for (Node node = this.getFirstChild(); node != null; node = node.getNext()) {
            arrayList.add((Object)((AstNode)node));
        }
        return arrayList;
    }

    public Symbol getSymbol(String string2) {
        if (this.symbolTable == null) {
            return null;
        }
        return (Symbol)this.symbolTable.get((Object)string2);
    }

    public Map<String, Symbol> getSymbolTable() {
        return this.symbolTable;
    }

    public ScriptNode getTop() {
        return this.top;
    }

    public void putSymbol(Symbol symbol) {
        if (symbol.getName() == null) {
            throw new IllegalArgumentException("null symbol name");
        }
        this.ensureSymbolTable();
        this.symbolTable.put((Object)symbol.getName(), (Object)symbol);
        symbol.setContainingTable(this);
        this.top.addSymbol(symbol);
    }

    public void replaceWith(Scope scope) {
        if (this.childScopes != null) {
            Iterator iterator = this.childScopes.iterator();
            while (iterator.hasNext()) {
                scope.addChildScope((Scope)iterator.next());
            }
            this.childScopes.clear();
            this.childScopes = null;
        }
        if (this.symbolTable != null && !this.symbolTable.isEmpty()) {
            Scope.joinScopes(this, scope);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setParentScope(Scope scope) {
        this.parentScope = scope;
        ScriptNode scriptNode = scope == null ? (ScriptNode)this : scope.top;
        this.top = scriptNode;
    }

    public void setSymbolTable(Map<String, Symbol> map) {
        this.symbolTable = map;
    }

    public void setTop(ScriptNode scriptNode) {
        this.top = scriptNode;
    }

    @Override
    public String toSource(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.makeIndent(n));
        stringBuilder.append("{\n");
        Iterator<Node> iterator = this.iterator();
        while (iterator.hasNext()) {
            stringBuilder.append(((AstNode)((Node)iterator.next())).toSource(n + 1));
        }
        stringBuilder.append(this.makeIndent(n));
        stringBuilder.append("}\n");
        return stringBuilder.toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        if (nodeVisitor.visit(this)) {
            Iterator<Node> iterator = this.iterator();
            while (iterator.hasNext()) {
                ((AstNode)((Node)iterator.next())).visit(nodeVisitor);
            }
        }
    }
}

