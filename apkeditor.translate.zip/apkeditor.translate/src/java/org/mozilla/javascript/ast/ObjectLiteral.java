/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 */
package org.mozilla.javascript.ast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.DestructuringForm;
import org.mozilla.javascript.ast.NodeVisitor;
import org.mozilla.javascript.ast.ObjectProperty;

public class ObjectLiteral
extends AstNode
implements DestructuringForm {
    private static final List<ObjectProperty> NO_ELEMS = Collections.unmodifiableList((List)new ArrayList());
    private List<ObjectProperty> elements;
    boolean isDestructuring;

    public ObjectLiteral() {
        this.type = 66;
    }

    public ObjectLiteral(int n) {
        super(n);
        this.type = 66;
    }

    public ObjectLiteral(int n, int n2) {
        super(n, n2);
        this.type = 66;
    }

    public void addElement(ObjectProperty objectProperty) {
        this.assertNotNull(objectProperty);
        if (this.elements == null) {
            this.elements = new ArrayList();
        }
        this.elements.add((Object)objectProperty);
        objectProperty.setParent(this);
    }

    public List<ObjectProperty> getElements() {
        if (this.elements != null) {
            return this.elements;
        }
        return NO_ELEMS;
    }

    @Override
    public boolean isDestructuring() {
        return this.isDestructuring;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setElements(List<ObjectProperty> list) {
        if (list == null) {
            this.elements = null;
            return;
        } else {
            if (this.elements != null) {
                this.elements.clear();
            }
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                this.addElement((ObjectProperty)iterator.next());
            }
        }
    }

    @Override
    public void setIsDestructuring(boolean bl) {
        this.isDestructuring = bl;
    }

    @Override
    public String toSource(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.makeIndent(n));
        stringBuilder.append("{");
        if (this.elements != null) {
            this.printList(this.elements, stringBuilder);
        }
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        if (nodeVisitor.visit(this)) {
            Iterator iterator = this.getElements().iterator();
            while (iterator.hasNext()) {
                ((ObjectProperty)iterator.next()).visit(nodeVisitor);
            }
        }
    }
}

