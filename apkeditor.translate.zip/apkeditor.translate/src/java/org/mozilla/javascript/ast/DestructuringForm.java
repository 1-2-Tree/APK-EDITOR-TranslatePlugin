/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.mozilla.javascript.ast;

public interface DestructuringForm {
    public boolean isDestructuring();

    public void setIsDestructuring(boolean var1);
}

