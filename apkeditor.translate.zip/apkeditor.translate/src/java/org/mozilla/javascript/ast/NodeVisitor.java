/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.ast.AstNode;

public interface NodeVisitor {
    public boolean visit(AstNode var1);
}

