/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;

public class ErrorNode
extends AstNode {
    private String message;

    public ErrorNode() {
        this.type = -1;
    }

    public ErrorNode(int n) {
        super(n);
        this.type = -1;
    }

    public ErrorNode(int n, int n2) {
        super(n, n2);
        this.type = -1;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String string2) {
        this.message = string2;
    }

    @Override
    public String toSource(int n) {
        return "";
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        nodeVisitor.visit(this);
    }
}

