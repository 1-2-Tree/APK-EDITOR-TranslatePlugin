/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package org.mozilla.javascript.ast;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;

public class SwitchCase
extends AstNode {
    private AstNode expression;
    private List<AstNode> statements;

    public SwitchCase() {
        this.type = 115;
    }

    public SwitchCase(int n) {
        super(n);
        this.type = 115;
    }

    public SwitchCase(int n, int n2) {
        super(n, n2);
        this.type = 115;
    }

    public void addStatement(AstNode astNode) {
        this.assertNotNull(astNode);
        if (this.statements == null) {
            this.statements = new ArrayList();
        }
        this.setLength(astNode.getPosition() + astNode.getLength() - this.getPosition());
        this.statements.add((Object)astNode);
        astNode.setParent(this);
    }

    public AstNode getExpression() {
        return this.expression;
    }

    public List<AstNode> getStatements() {
        return this.statements;
    }

    public boolean isDefault() {
        return this.expression == null;
    }

    public void setExpression(AstNode astNode) {
        this.expression = astNode;
        if (astNode != null) {
            astNode.setParent(this);
        }
    }

    public void setStatements(List<AstNode> list) {
        if (this.statements != null) {
            this.statements.clear();
        }
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            this.addStatement((AstNode)iterator.next());
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public String toSource(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.makeIndent(n));
        if (this.expression == null) {
            stringBuilder.append("default:\n");
        } else {
            stringBuilder.append("case ");
            stringBuilder.append(this.expression.toSource(0));
            stringBuilder.append(":\n");
        }
        if (this.statements != null) {
            Iterator iterator = this.statements.iterator();
            while (iterator.hasNext()) {
                stringBuilder.append(((AstNode)iterator.next()).toSource(n + 1));
            }
        }
        return stringBuilder.toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        if (nodeVisitor.visit(this)) {
            if (this.expression != null) {
                this.expression.visit(nodeVisitor);
            }
            if (this.statements != null) {
                Iterator iterator = this.statements.iterator();
                while (iterator.hasNext()) {
                    ((AstNode)iterator.next()).visit(nodeVisitor);
                }
            }
        }
    }
}

