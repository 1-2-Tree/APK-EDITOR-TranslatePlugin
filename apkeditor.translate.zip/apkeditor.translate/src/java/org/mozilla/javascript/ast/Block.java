/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Iterator
 */
package org.mozilla.javascript.ast;

import java.util.Iterator;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;

public class Block
extends AstNode {
    public Block() {
        this.type = 129;
    }

    public Block(int n) {
        super(n);
        this.type = 129;
    }

    public Block(int n, int n2) {
        super(n, n2);
        this.type = 129;
    }

    public void addStatement(AstNode astNode) {
        this.addChild(astNode);
    }

    @Override
    public String toSource(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.makeIndent(n));
        stringBuilder.append("{\n");
        Iterator<Node> iterator = this.iterator();
        while (iterator.hasNext()) {
            stringBuilder.append(((AstNode)((Node)iterator.next())).toSource(n + 1));
        }
        stringBuilder.append(this.makeIndent(n));
        stringBuilder.append("}\n");
        return stringBuilder.toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        if (nodeVisitor.visit(this)) {
            Iterator<Node> iterator = this.iterator();
            while (iterator.hasNext()) {
                ((AstNode)((Node)iterator.next())).visit(nodeVisitor);
            }
        }
    }
}

