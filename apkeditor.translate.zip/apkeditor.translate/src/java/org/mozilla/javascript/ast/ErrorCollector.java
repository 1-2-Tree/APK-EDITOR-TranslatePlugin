/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.UnsupportedOperationException
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package org.mozilla.javascript.ast;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.mozilla.javascript.EvaluatorException;
import org.mozilla.javascript.ast.IdeErrorReporter;
import org.mozilla.javascript.ast.ParseProblem;

public class ErrorCollector
implements IdeErrorReporter {
    private List<ParseProblem> errors = new ArrayList();

    @Override
    public void error(String string2, String string3, int n, int n2) {
        this.errors.add((Object)new ParseProblem(ParseProblem.Type.Error, string2, string3, n, n2));
    }

    @Override
    public void error(String string2, String string3, int n, String string4, int n2) {
        throw new UnsupportedOperationException();
    }

    public List<ParseProblem> getErrors() {
        return this.errors;
    }

    @Override
    public EvaluatorException runtimeError(String string2, String string3, int n, String string4, int n2) {
        throw new UnsupportedOperationException();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(100 * this.errors.size());
        Iterator iterator = this.errors.iterator();
        while (iterator.hasNext()) {
            stringBuilder.append(((ParseProblem)iterator.next()).toString()).append("\n");
        }
        return stringBuilder.toString();
    }

    @Override
    public void warning(String string2, String string3, int n, int n2) {
        this.errors.add((Object)new ParseProblem(ParseProblem.Type.Warning, string2, string3, n, n2));
    }

    @Override
    public void warning(String string2, String string3, int n, String string4, int n2) {
        throw new UnsupportedOperationException();
    }
}

