/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.Node;
import org.mozilla.javascript.Token;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;

public class InfixExpression
extends AstNode {
    protected AstNode left;
    protected int operatorPosition = -1;
    protected AstNode right;

    public InfixExpression() {
    }

    public InfixExpression(int n) {
        super(n);
    }

    public InfixExpression(int n, int n2) {
        super(n, n2);
    }

    public InfixExpression(int n, int n2, AstNode astNode, AstNode astNode2) {
        super(n, n2);
        this.setLeft(astNode);
        this.setRight(astNode2);
    }

    public InfixExpression(int n, AstNode astNode, AstNode astNode2, int n2) {
        this.setType(n);
        this.setOperatorPosition(n2 - astNode.getPosition());
        this.setLeftAndRight(astNode, astNode2);
    }

    public InfixExpression(AstNode astNode, AstNode astNode2) {
        this.setLeftAndRight(astNode, astNode2);
    }

    public AstNode getLeft() {
        return this.left;
    }

    public int getOperator() {
        return this.getType();
    }

    public int getOperatorPosition() {
        return this.operatorPosition;
    }

    public AstNode getRight() {
        return this.right;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean hasSideEffects() {
        boolean bl = true;
        switch (this.getType()) {
            default: {
                return super.hasSideEffects();
            }
            case 89: {
                if (this.right == null) return false;
                if (this.right.hasSideEffects()) return bl;
                return false;
            }
            case 104: 
            case 105: 
        }
        if (this.left != null) {
            if (this.left.hasSideEffects()) return bl;
        }
        AstNode astNode = this.right;
        boolean bl2 = false;
        if (astNode == null) return bl2;
        boolean bl3 = this.right.hasSideEffects();
        bl2 = false;
        if (!bl3) return bl2;
        return bl;
    }

    public void setLeft(AstNode astNode) {
        this.assertNotNull(astNode);
        this.left = astNode;
        this.setLineno(astNode.getLineno());
        astNode.setParent(this);
    }

    public void setLeftAndRight(AstNode astNode, AstNode astNode2) {
        this.assertNotNull(astNode);
        this.assertNotNull(astNode2);
        this.setBounds(astNode.getPosition(), astNode2.getPosition() + astNode2.getLength());
        this.setLeft(astNode);
        this.setRight(astNode2);
    }

    public void setOperator(int n) {
        if (!Token.isValidToken(n)) {
            throw new IllegalArgumentException("Invalid token: " + n);
        }
        this.setType(n);
    }

    public void setOperatorPosition(int n) {
        this.operatorPosition = n;
    }

    public void setRight(AstNode astNode) {
        this.assertNotNull(astNode);
        this.right = astNode;
        astNode.setParent(this);
    }

    @Override
    public String toSource(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.makeIndent(n));
        stringBuilder.append(this.left.toSource());
        stringBuilder.append(" ");
        stringBuilder.append(InfixExpression.operatorToString(this.getType()));
        stringBuilder.append(" ");
        stringBuilder.append(this.right.toSource());
        return stringBuilder.toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        if (nodeVisitor.visit(this)) {
            this.left.visit(nodeVisitor);
            this.right.visit(nodeVisitor);
        }
    }
}

