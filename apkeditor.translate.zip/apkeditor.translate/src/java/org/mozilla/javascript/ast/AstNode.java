/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Comparable
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Comparator
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 */
package org.mozilla.javascript.ast;

import java.io.Serializable;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.Token;
import org.mozilla.javascript.ast.AstRoot;
import org.mozilla.javascript.ast.EmptyExpression;
import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.ast.Name;
import org.mozilla.javascript.ast.NodeVisitor;
import org.mozilla.javascript.ast.Scope;

public abstract class AstNode
extends Node
implements Comparable<AstNode> {
    private static Map<Integer, String> operatorNames = new HashMap();
    protected int length = 1;
    protected AstNode parent;
    protected int position = -1;

    static {
        operatorNames.put((Object)52, (Object)"in");
        operatorNames.put((Object)32, (Object)"typeof");
        operatorNames.put((Object)53, (Object)"instanceof");
        operatorNames.put((Object)31, (Object)"delete");
        operatorNames.put((Object)89, (Object)",");
        operatorNames.put((Object)103, (Object)":");
        operatorNames.put((Object)104, (Object)"||");
        operatorNames.put((Object)105, (Object)"&&");
        operatorNames.put((Object)106, (Object)"++");
        operatorNames.put((Object)107, (Object)"--");
        operatorNames.put((Object)9, (Object)"|");
        operatorNames.put((Object)10, (Object)"^");
        operatorNames.put((Object)11, (Object)"&");
        operatorNames.put((Object)12, (Object)"==");
        operatorNames.put((Object)13, (Object)"!=");
        operatorNames.put((Object)14, (Object)"<");
        operatorNames.put((Object)16, (Object)">");
        operatorNames.put((Object)15, (Object)"<=");
        operatorNames.put((Object)17, (Object)">=");
        operatorNames.put((Object)18, (Object)"<<");
        operatorNames.put((Object)19, (Object)">>");
        operatorNames.put((Object)20, (Object)">>>");
        operatorNames.put((Object)21, (Object)"+");
        operatorNames.put((Object)22, (Object)"-");
        operatorNames.put((Object)23, (Object)"*");
        operatorNames.put((Object)24, (Object)"/");
        operatorNames.put((Object)25, (Object)"%");
        operatorNames.put((Object)26, (Object)"!");
        operatorNames.put((Object)27, (Object)"~");
        operatorNames.put((Object)28, (Object)"+");
        operatorNames.put((Object)29, (Object)"-");
        operatorNames.put((Object)46, (Object)"===");
        operatorNames.put((Object)47, (Object)"!==");
        operatorNames.put((Object)90, (Object)"=");
        operatorNames.put((Object)91, (Object)"|=");
        operatorNames.put((Object)93, (Object)"&=");
        operatorNames.put((Object)94, (Object)"<<=");
        operatorNames.put((Object)95, (Object)">>=");
        operatorNames.put((Object)96, (Object)">>>=");
        operatorNames.put((Object)97, (Object)"+=");
        operatorNames.put((Object)98, (Object)"-=");
        operatorNames.put((Object)99, (Object)"*=");
        operatorNames.put((Object)100, (Object)"/=");
        operatorNames.put((Object)101, (Object)"%=");
        operatorNames.put((Object)92, (Object)"^=");
        operatorNames.put((Object)126, (Object)"void");
    }

    public AstNode() {
        super(-1);
    }

    public AstNode(int n) {
        this();
        this.position = n;
    }

    public AstNode(int n, int n2) {
        this();
        this.position = n;
        this.length = n2;
    }

    public static RuntimeException codeBug() throws RuntimeException {
        throw Kit.codeBug();
    }

    public static String operatorToString(int n) {
        String string2 = (String)operatorNames.get((Object)n);
        if (string2 == null) {
            throw new IllegalArgumentException("Invalid operator: " + n);
        }
        return string2;
    }

    public void addChild(AstNode astNode) {
        this.assertNotNull(astNode);
        this.setLength(astNode.getPosition() + astNode.getLength() - this.getPosition());
        this.addChildToBack(astNode);
        astNode.setParent(this);
    }

    protected void assertNotNull(Object object) {
        if (object == null) {
            throw new IllegalArgumentException("arg cannot be null");
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public int compareTo(AstNode astNode) {
        int n;
        int n2;
        int n3 = -1;
        if (this.equals((Object)astNode)) {
            return 0;
        }
        int n4 = this.getAbsolutePosition();
        if (n4 < (n2 = astNode.getAbsolutePosition())) return n3;
        if (n2 < n4) {
            return 1;
        }
        int n5 = this.getLength();
        if (n5 < (n = astNode.getLength())) return n3;
        if (n >= n5) return this.hashCode() - astNode.hashCode();
        return 1;
    }

    public String debugPrint() {
        DebugPrintVisitor debugPrintVisitor = new DebugPrintVisitor(new StringBuilder(1000));
        this.visit(debugPrintVisitor);
        return debugPrintVisitor.toString();
    }

    public int depth() {
        if (this.parent == null) {
            return 0;
        }
        return 1 + this.parent.depth();
    }

    public int getAbsolutePosition() {
        int n = this.position;
        for (AstNode astNode = this.parent; astNode != null; astNode = astNode.getParent()) {
            n += astNode.getPosition();
        }
        return n;
    }

    public AstRoot getAstRoot() {
        AstNode astNode;
        for (astNode = this; astNode != null && !(astNode instanceof AstRoot); astNode = astNode.getParent()) {
        }
        return (AstRoot)astNode;
    }

    public FunctionNode getEnclosingFunction() {
        AstNode astNode;
        for (astNode = this.getParent(); astNode != null && !(astNode instanceof FunctionNode); astNode = astNode.getParent()) {
        }
        return (FunctionNode)astNode;
    }

    public Scope getEnclosingScope() {
        AstNode astNode;
        for (astNode = this.getParent(); astNode != null && !(astNode instanceof Scope); astNode = astNode.getParent()) {
        }
        return (Scope)astNode;
    }

    public int getLength() {
        return this.length;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public int getLineno() {
        int n = -1;
        if (this.lineno != n) {
            return this.lineno;
        }
        if (this.parent == null) return n;
        return this.parent.getLineno();
    }

    public AstNode getParent() {
        return this.parent;
    }

    public int getPosition() {
        return this.position;
    }

    @Override
    public boolean hasSideEffects() {
        switch (this.getType()) {
            default: {
                return false;
            }
            case -1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: 
            case 30: 
            case 31: 
            case 35: 
            case 37: 
            case 38: 
            case 50: 
            case 51: 
            case 56: 
            case 57: 
            case 64: 
            case 68: 
            case 69: 
            case 70: 
            case 72: 
            case 81: 
            case 82: 
            case 90: 
            case 91: 
            case 92: 
            case 93: 
            case 94: 
            case 95: 
            case 96: 
            case 97: 
            case 98: 
            case 99: 
            case 100: 
            case 101: 
            case 106: 
            case 107: 
            case 109: 
            case 110: 
            case 111: 
            case 112: 
            case 113: 
            case 114: 
            case 117: 
            case 118: 
            case 119: 
            case 120: 
            case 121: 
            case 122: 
            case 123: 
            case 124: 
            case 125: 
            case 129: 
            case 130: 
            case 131: 
            case 132: 
            case 134: 
            case 135: 
            case 139: 
            case 140: 
            case 141: 
            case 142: 
            case 153: 
            case 154: 
            case 158: 
            case 159: 
        }
        return true;
    }

    public String makeIndent(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < n; ++i) {
            stringBuilder.append("  ");
        }
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    protected <T extends AstNode> void printList(List<T> list, StringBuilder stringBuilder) {
        int n = list.size();
        int n2 = 0;
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            AstNode astNode = (AstNode)iterator.next();
            stringBuilder.append(astNode.toSource(0));
            int n3 = n2 + 1;
            if (n2 < n - 1) {
                stringBuilder.append(", ");
            } else if (astNode instanceof EmptyExpression) {
                stringBuilder.append(",");
            }
            n2 = n3;
        }
        return;
    }

    public void setBounds(int n, int n2) {
        this.setPosition(n);
        this.setLength(n2 - n);
    }

    public void setLength(int n) {
        this.length = n;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setParent(AstNode astNode) {
        block5 : {
            block4 : {
                if (astNode == this.parent) break block4;
                if (this.parent != null) {
                    this.setRelative(-this.parent.getPosition());
                }
                this.parent = astNode;
                if (astNode != null) break block5;
            }
            return;
        }
        this.setRelative(astNode.getPosition());
    }

    public void setPosition(int n) {
        this.position = n;
    }

    public void setRelative(int n) {
        this.position -= n;
    }

    public String shortName() {
        String string2 = this.getClass().getName();
        return string2.substring(1 + string2.lastIndexOf("."));
    }

    public String toSource() {
        return this.toSource(0);
    }

    public abstract String toSource(int var1);

    public abstract void visit(NodeVisitor var1);

    protected static class DebugPrintVisitor
    implements NodeVisitor {
        private static final int DEBUG_INDENT = 2;
        private StringBuilder buffer;

        public DebugPrintVisitor(StringBuilder stringBuilder) {
            this.buffer = stringBuilder;
        }

        private String makeIndent(int n) {
            StringBuilder stringBuilder = new StringBuilder(n * 2);
            for (int i = 0; i < n * 2; ++i) {
                stringBuilder.append(" ");
            }
            return stringBuilder.toString();
        }

        public String toString() {
            return this.buffer.toString();
        }

        @Override
        public boolean visit(AstNode astNode) {
            int n = astNode.getType();
            String string2 = Token.typeToName(n);
            this.buffer.append(astNode.getAbsolutePosition()).append("\t");
            this.buffer.append(this.makeIndent(astNode.depth()));
            this.buffer.append(string2).append(" ");
            this.buffer.append(astNode.getPosition()).append(" ");
            this.buffer.append(astNode.getLength());
            if (n == 39) {
                this.buffer.append(" ").append(((Name)astNode).getIdentifier());
            }
            this.buffer.append("\n");
            return true;
        }
    }

    public static class PositionComparator
    implements Comparator<AstNode>,
    Serializable {
        private static final long serialVersionUID = 1L;

        public int compare(AstNode astNode, AstNode astNode2) {
            return astNode.position - astNode2.position;
        }
    }

}

