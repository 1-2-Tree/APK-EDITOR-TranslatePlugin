/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.lang.UnsupportedOperationException
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.Node;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;

public class Jump
extends AstNode {
    private Jump jumpNode;
    public Node target;
    private Node target2;

    public Jump() {
        this.type = -1;
    }

    public Jump(int n) {
        this.type = n;
    }

    public Jump(int n, int n2) {
        this(n);
        this.setLineno(n2);
    }

    public Jump(int n, Node node) {
        this(n);
        this.addChildToBack(node);
    }

    public Jump(int n, Node node, int n2) {
        this(n, node);
        this.setLineno(n2);
    }

    public Node getContinue() {
        if (this.type != 132) {
            Jump.codeBug();
        }
        return this.target2;
    }

    public Node getDefault() {
        if (this.type != 114) {
            Jump.codeBug();
        }
        return this.target2;
    }

    public Node getFinally() {
        if (this.type != 81) {
            Jump.codeBug();
        }
        return this.target2;
    }

    public Jump getJumpStatement() {
        if (this.type != 120 && this.type != 121) {
            Jump.codeBug();
        }
        return this.jumpNode;
    }

    public Jump getLoop() {
        if (this.type != 130) {
            Jump.codeBug();
        }
        return this.jumpNode;
    }

    public void setContinue(Node node) {
        if (this.type != 132) {
            Jump.codeBug();
        }
        if (node.getType() != 131) {
            Jump.codeBug();
        }
        if (this.target2 != null) {
            Jump.codeBug();
        }
        this.target2 = node;
    }

    public void setDefault(Node node) {
        if (this.type != 114) {
            Jump.codeBug();
        }
        if (node.getType() != 131) {
            Jump.codeBug();
        }
        if (this.target2 != null) {
            Jump.codeBug();
        }
        this.target2 = node;
    }

    public void setFinally(Node node) {
        if (this.type != 81) {
            Jump.codeBug();
        }
        if (node.getType() != 131) {
            Jump.codeBug();
        }
        if (this.target2 != null) {
            Jump.codeBug();
        }
        this.target2 = node;
    }

    public void setJumpStatement(Jump jump) {
        if (this.type != 120 && this.type != 121) {
            Jump.codeBug();
        }
        if (jump == null) {
            Jump.codeBug();
        }
        if (this.jumpNode != null) {
            Jump.codeBug();
        }
        this.jumpNode = jump;
    }

    public void setLoop(Jump jump) {
        if (this.type != 130) {
            Jump.codeBug();
        }
        if (jump == null) {
            Jump.codeBug();
        }
        if (this.jumpNode != null) {
            Jump.codeBug();
        }
        this.jumpNode = jump;
    }

    @Override
    public String toSource(int n) {
        throw new UnsupportedOperationException(this.toString());
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        throw new UnsupportedOperationException(this.toString());
    }
}

