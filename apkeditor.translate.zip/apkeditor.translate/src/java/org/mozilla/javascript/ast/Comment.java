/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.Token;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;

public class Comment
extends AstNode {
    private Token.CommentType commentType;
    private String value;

    public Comment(int n, int n2, Token.CommentType commentType, String string2) {
        super(n, n2);
        this.type = 161;
        this.commentType = commentType;
        this.value = string2;
    }

    public Token.CommentType getCommentType() {
        return this.commentType;
    }

    public String getValue() {
        return this.value;
    }

    public void setCommentType(Token.CommentType commentType) {
        this.commentType = commentType;
    }

    @Override
    public String toSource(int n) {
        StringBuilder stringBuilder = new StringBuilder(10 + this.getLength());
        stringBuilder.append(this.makeIndent(n));
        stringBuilder.append(this.value);
        return stringBuilder.toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        nodeVisitor.visit(this);
    }
}

