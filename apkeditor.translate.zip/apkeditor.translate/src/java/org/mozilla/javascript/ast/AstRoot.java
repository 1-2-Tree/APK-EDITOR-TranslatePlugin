/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Comparator
 *  java.util.Iterator
 *  java.util.SortedSet
 *  java.util.TreeSet
 */
package org.mozilla.javascript.ast;

import java.util.Comparator;
import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.Comment;
import org.mozilla.javascript.ast.NodeVisitor;
import org.mozilla.javascript.ast.ScriptNode;

public class AstRoot
extends ScriptNode {
    private SortedSet<Comment> comments;
    private boolean inStrictMode;

    public AstRoot() {
        this.type = 136;
    }

    public AstRoot(int n) {
        super(n);
        this.type = 136;
    }

    public void addComment(Comment comment) {
        this.assertNotNull(comment);
        if (this.comments == null) {
            this.comments = new TreeSet((Comparator)new AstNode.PositionComparator());
        }
        this.comments.add((Object)comment);
        comment.setParent(this);
    }

    public void checkParentLinks() {
        this.visit(new NodeVisitor(){

            /*
             * Enabled aggressive block sorting
             */
            @Override
            public boolean visit(AstNode astNode) {
                if (astNode.getType() == 136 || astNode.getParent() != null) {
                    return true;
                }
                throw new IllegalStateException("No parent for node: " + astNode + "\n" + astNode.toSource(0));
            }
        });
    }

    @Override
    public String debugPrint() {
        AstNode.DebugPrintVisitor debugPrintVisitor = new AstNode.DebugPrintVisitor(new StringBuilder(1000));
        this.visitAll(debugPrintVisitor);
        return debugPrintVisitor.toString();
    }

    public SortedSet<Comment> getComments() {
        return this.comments;
    }

    public boolean isInStrictMode() {
        return this.inStrictMode;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setComments(SortedSet<Comment> sortedSet) {
        if (sortedSet == null) {
            this.comments = null;
            return;
        } else {
            if (this.comments != null) {
                this.comments.clear();
            }
            Iterator iterator = sortedSet.iterator();
            while (iterator.hasNext()) {
                this.addComment((Comment)iterator.next());
            }
        }
    }

    public void setInStrictMode(boolean bl) {
        this.inStrictMode = bl;
    }

    @Override
    public String toSource(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        Iterator<Node> iterator = this.iterator();
        while (iterator.hasNext()) {
            stringBuilder.append(((AstNode)((Node)iterator.next())).toSource(n));
        }
        return stringBuilder.toString();
    }

    public void visitAll(NodeVisitor nodeVisitor) {
        this.visit(nodeVisitor);
        this.visitComments(nodeVisitor);
    }

    public void visitComments(NodeVisitor nodeVisitor) {
        if (this.comments != null) {
            Iterator iterator = this.comments.iterator();
            while (iterator.hasNext()) {
                nodeVisitor.visit((Comment)iterator.next());
            }
        }
    }

}

