/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 */
package org.mozilla.javascript.ast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.NodeVisitor;

public class FunctionCall
extends AstNode {
    protected static final List<AstNode> NO_ARGS = Collections.unmodifiableList((List)new ArrayList());
    protected List<AstNode> arguments;
    protected int lp = -1;
    protected int rp = -1;
    protected AstNode target;

    public FunctionCall() {
        this.type = 38;
    }

    public FunctionCall(int n) {
        super(n);
        this.type = 38;
    }

    public FunctionCall(int n, int n2) {
        super(n, n2);
        this.type = 38;
    }

    public void addArgument(AstNode astNode) {
        this.assertNotNull(astNode);
        if (this.arguments == null) {
            this.arguments = new ArrayList();
        }
        this.arguments.add((Object)astNode);
        astNode.setParent(this);
    }

    public List<AstNode> getArguments() {
        if (this.arguments != null) {
            return this.arguments;
        }
        return NO_ARGS;
    }

    public int getLp() {
        return this.lp;
    }

    public int getRp() {
        return this.rp;
    }

    public AstNode getTarget() {
        return this.target;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setArguments(List<AstNode> list) {
        if (list == null) {
            this.arguments = null;
            return;
        } else {
            if (this.arguments != null) {
                this.arguments.clear();
            }
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                this.addArgument((AstNode)iterator.next());
            }
        }
    }

    public void setLp(int n) {
        this.lp = n;
    }

    public void setParens(int n, int n2) {
        this.lp = n;
        this.rp = n2;
    }

    public void setRp(int n) {
        this.rp = n;
    }

    public void setTarget(AstNode astNode) {
        this.assertNotNull(astNode);
        this.target = astNode;
        astNode.setParent(this);
    }

    @Override
    public String toSource(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.makeIndent(n));
        stringBuilder.append(this.target.toSource(0));
        stringBuilder.append("(");
        if (this.arguments != null) {
            this.printList(this.arguments, stringBuilder);
        }
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        if (nodeVisitor.visit(this)) {
            this.target.visit(nodeVisitor);
            Iterator iterator = this.getArguments().iterator();
            while (iterator.hasNext()) {
                ((AstNode)iterator.next()).visit(nodeVisitor);
            }
        }
    }
}

