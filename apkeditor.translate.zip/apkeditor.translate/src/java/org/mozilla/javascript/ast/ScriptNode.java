/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 */
package org.mozilla.javascript.ast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.ast.Name;
import org.mozilla.javascript.ast.NodeVisitor;
import org.mozilla.javascript.ast.RegExpLiteral;
import org.mozilla.javascript.ast.Scope;
import org.mozilla.javascript.ast.Symbol;

public class ScriptNode
extends Scope {
    private List<FunctionNode> EMPTY_LIST = Collections.emptyList();
    private Object compilerData;
    private String encodedSource;
    private int encodedSourceEnd = -1;
    private int encodedSourceStart = -1;
    private int endLineno = -1;
    private List<FunctionNode> functions;
    private boolean[] isConsts;
    private int paramCount = 0;
    private List<RegExpLiteral> regexps;
    private String sourceName;
    private List<Symbol> symbols = new ArrayList(4);
    private int tempNumber = 0;
    private String[] variableNames;

    public ScriptNode() {
        this.top = this;
        this.type = 136;
    }

    public ScriptNode(int n) {
        super(n);
        this.top = this;
        this.type = 136;
    }

    public int addFunction(FunctionNode functionNode) {
        if (functionNode == null) {
            ScriptNode.codeBug();
        }
        if (this.functions == null) {
            this.functions = new ArrayList();
        }
        this.functions.add((Object)functionNode);
        return -1 + this.functions.size();
    }

    public void addRegExp(RegExpLiteral regExpLiteral) {
        if (regExpLiteral == null) {
            ScriptNode.codeBug();
        }
        if (this.regexps == null) {
            this.regexps = new ArrayList();
        }
        this.regexps.add((Object)regExpLiteral);
        regExpLiteral.putIntProp(4, -1 + this.regexps.size());
    }

    void addSymbol(Symbol symbol) {
        if (this.variableNames != null) {
            ScriptNode.codeBug();
        }
        if (symbol.getDeclType() == 87) {
            this.paramCount = 1 + this.paramCount;
        }
        this.symbols.add((Object)symbol);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void flattenSymbolTable(boolean bl) {
        if (!bl) {
            ArrayList arrayList = new ArrayList();
            if (this.symbolTable != null) {
                for (int i = 0; i < this.symbols.size(); ++i) {
                    Symbol symbol = (Symbol)this.symbols.get(i);
                    if (symbol.getContainingTable() != this) continue;
                    arrayList.add((Object)symbol);
                }
            }
            this.symbols = arrayList;
        }
        this.variableNames = new String[this.symbols.size()];
        this.isConsts = new boolean[this.symbols.size()];
        int n = 0;
        while (n < this.symbols.size()) {
            Symbol symbol = (Symbol)this.symbols.get(n);
            this.variableNames[n] = symbol.getName();
            boolean[] arrbl = this.isConsts;
            boolean bl2 = symbol.getDeclType() == 154;
            arrbl[n] = bl2;
            symbol.setIndex(n);
            ++n;
        }
        return;
    }

    public int getBaseLineno() {
        return this.lineno;
    }

    public Object getCompilerData() {
        return this.compilerData;
    }

    public String getEncodedSource() {
        return this.encodedSource;
    }

    public int getEncodedSourceEnd() {
        return this.encodedSourceEnd;
    }

    public int getEncodedSourceStart() {
        return this.encodedSourceStart;
    }

    public int getEndLineno() {
        return this.endLineno;
    }

    public int getFunctionCount() {
        if (this.functions == null) {
            return 0;
        }
        return this.functions.size();
    }

    public FunctionNode getFunctionNode(int n) {
        return (FunctionNode)this.functions.get(n);
    }

    public List<FunctionNode> getFunctions() {
        if (this.functions == null) {
            return this.EMPTY_LIST;
        }
        return this.functions;
    }

    /*
     * Enabled aggressive block sorting
     */
    public int getIndexForNameNode(Node node) {
        Scope scope;
        if (this.variableNames == null) {
            ScriptNode.codeBug();
        }
        if ((scope = node.getScope()) == null) {
            return -1;
        }
        Symbol symbol = scope.getSymbol(((Name)node).getIdentifier());
        if (symbol != null) return symbol.getIndex();
        return -1;
    }

    public String getNextTempName() {
        StringBuilder stringBuilder = new StringBuilder().append("$");
        int n = this.tempNumber;
        this.tempNumber = n + 1;
        return stringBuilder.append(n).toString();
    }

    public boolean[] getParamAndVarConst() {
        if (this.variableNames == null) {
            ScriptNode.codeBug();
        }
        return this.isConsts;
    }

    public int getParamAndVarCount() {
        if (this.variableNames == null) {
            ScriptNode.codeBug();
        }
        return this.symbols.size();
    }

    public String[] getParamAndVarNames() {
        if (this.variableNames == null) {
            ScriptNode.codeBug();
        }
        return this.variableNames;
    }

    public int getParamCount() {
        return this.paramCount;
    }

    public String getParamOrVarName(int n) {
        if (this.variableNames == null) {
            ScriptNode.codeBug();
        }
        return this.variableNames[n];
    }

    public int getRegexpCount() {
        if (this.regexps == null) {
            return 0;
        }
        return this.regexps.size();
    }

    public String getRegexpFlags(int n) {
        return ((RegExpLiteral)this.regexps.get(n)).getFlags();
    }

    public String getRegexpString(int n) {
        return ((RegExpLiteral)this.regexps.get(n)).getValue();
    }

    public String getSourceName() {
        return this.sourceName;
    }

    public List<Symbol> getSymbols() {
        return this.symbols;
    }

    public void setBaseLineno(int n) {
        if (n < 0 || this.lineno >= 0) {
            ScriptNode.codeBug();
        }
        this.lineno = n;
    }

    public void setCompilerData(Object object) {
        this.assertNotNull(object);
        if (this.compilerData != null) {
            throw new IllegalStateException();
        }
        this.compilerData = object;
    }

    public void setEncodedSource(String string2) {
        this.encodedSource = string2;
    }

    public void setEncodedSourceBounds(int n, int n2) {
        this.encodedSourceStart = n;
        this.encodedSourceEnd = n2;
    }

    public void setEncodedSourceEnd(int n) {
        this.encodedSourceEnd = n;
    }

    public void setEncodedSourceStart(int n) {
        this.encodedSourceStart = n;
    }

    public void setEndLineno(int n) {
        if (n < 0 || this.endLineno >= 0) {
            ScriptNode.codeBug();
        }
        this.endLineno = n;
    }

    public void setSourceName(String string2) {
        this.sourceName = string2;
    }

    public void setSymbols(List<Symbol> list) {
        this.symbols = list;
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        if (nodeVisitor.visit(this)) {
            Iterator<Node> iterator = this.iterator();
            while (iterator.hasNext()) {
                ((AstNode)((Node)iterator.next())).visit(nodeVisitor);
            }
        }
    }
}

