/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.ast;

public class ParseProblem {
    private int length;
    private String message;
    private int offset;
    private String sourceName;
    private Type type;

    public ParseProblem(Type type, String string2, String string3, int n, int n2) {
        this.setType(type);
        this.setMessage(string2);
        this.setSourceName(string3);
        this.setFileOffset(n);
        this.setLength(n2);
    }

    public int getFileOffset() {
        return this.offset;
    }

    public int getLength() {
        return this.length;
    }

    public String getMessage() {
        return this.message;
    }

    public String getSourceName() {
        return this.sourceName;
    }

    public Type getType() {
        return this.type;
    }

    public void setFileOffset(int n) {
        this.offset = n;
    }

    public void setLength(int n) {
        this.length = n;
    }

    public void setMessage(String string2) {
        this.message = string2;
    }

    public void setSourceName(String string2) {
        this.sourceName = string2;
    }

    public void setType(Type type) {
        this.type = type;
    }

    /*
     * Enabled aggressive block sorting
     */
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(200);
        stringBuilder.append(this.sourceName).append(":");
        stringBuilder.append("offset=").append(this.offset).append(",");
        stringBuilder.append("length=").append(this.length).append(",");
        String string2 = this.type == Type.Error ? "error: " : "warning: ";
        stringBuilder.append(string2);
        stringBuilder.append(this.message);
        return stringBuilder.toString();
    }

    public static final class Type
    extends Enum<Type> {
        private static final /* synthetic */ Type[] $VALUES;
        public static final /* enum */ Type Error = new Type();
        public static final /* enum */ Type Warning = new Type();

        static {
            Type[] arrtype = new Type[]{Error, Warning};
            $VALUES = arrtype;
        }

        public static Type valueOf(String string2) {
            return (Type)Enum.valueOf(Type.class, (String)string2);
        }

        public static Type[] values() {
            return (Type[])$VALUES.clone();
        }
    }

}

