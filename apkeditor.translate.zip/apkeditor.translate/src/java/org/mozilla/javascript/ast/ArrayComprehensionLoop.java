/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.UnsupportedOperationException
 */
package org.mozilla.javascript.ast;

import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.ForInLoop;
import org.mozilla.javascript.ast.NodeVisitor;

public class ArrayComprehensionLoop
extends ForInLoop {
    public ArrayComprehensionLoop() {
    }

    public ArrayComprehensionLoop(int n) {
        super(n);
    }

    public ArrayComprehensionLoop(int n, int n2) {
        super(n, n2);
    }

    @Override
    public AstNode getBody() {
        return null;
    }

    @Override
    public void setBody(AstNode astNode) {
        throw new UnsupportedOperationException("this node type has no body");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public String toSource(int n) {
        String string2;
        StringBuilder stringBuilder = new StringBuilder().append(this.makeIndent(n)).append(" for ");
        if (this.isForEach()) {
            string2 = "each ";
            do {
                return stringBuilder.append(string2).append("(").append(this.iterator.toSource(0)).append(" in ").append(this.iteratedObject.toSource(0)).append(")").toString();
                break;
            } while (true);
        }
        string2 = "";
        return stringBuilder.append(string2).append("(").append(this.iterator.toSource(0)).append(" in ").append(this.iteratedObject.toSource(0)).append(")").toString();
    }

    @Override
    public void visit(NodeVisitor nodeVisitor) {
        if (nodeVisitor.visit(this)) {
            this.iterator.visit(nodeVisitor);
            this.iteratedObject.visit(nodeVisitor);
        }
    }
}

