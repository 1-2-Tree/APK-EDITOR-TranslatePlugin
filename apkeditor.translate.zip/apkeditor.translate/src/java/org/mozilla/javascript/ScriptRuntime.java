/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.PrintStream
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.text.MessageFormat
 *  java.util.Locale
 *  java.util.MissingResourceException
 *  java.util.ResourceBundle
 */
package org.mozilla.javascript;

import java.io.PrintStream;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import org.mozilla.javascript.Arguments;
import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.ClassCache;
import org.mozilla.javascript.ClassShutter;
import org.mozilla.javascript.ConsString;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextFactory;
import org.mozilla.javascript.DToA;
import org.mozilla.javascript.DefaultErrorReporter;
import org.mozilla.javascript.EcmaError;
import org.mozilla.javascript.ErrorReporter;
import org.mozilla.javascript.Evaluator;
import org.mozilla.javascript.EvaluatorException;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.ImporterTopLevel;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.LazilyLoadedCtor;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.NativeBoolean;
import org.mozilla.javascript.NativeCall;
import org.mozilla.javascript.NativeDate;
import org.mozilla.javascript.NativeError;
import org.mozilla.javascript.NativeFunction;
import org.mozilla.javascript.NativeGlobal;
import org.mozilla.javascript.NativeIterator;
import org.mozilla.javascript.NativeJSON;
import org.mozilla.javascript.NativeMath;
import org.mozilla.javascript.NativeNumber;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.NativeScript;
import org.mozilla.javascript.NativeString;
import org.mozilla.javascript.NativeWith;
import org.mozilla.javascript.ObjToIntMap;
import org.mozilla.javascript.Ref;
import org.mozilla.javascript.RefCallable;
import org.mozilla.javascript.RegExpProxy;
import org.mozilla.javascript.RhinoException;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.SpecialRef;
import org.mozilla.javascript.TokenStream;
import org.mozilla.javascript.TopLevel;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.WrapFactory;
import org.mozilla.javascript.WrappedException;
import org.mozilla.javascript.Wrapper;
import org.mozilla.javascript.v8dtoa.DoubleConversion;
import org.mozilla.javascript.v8dtoa.FastDtoa;
import org.mozilla.javascript.xml.XMLLib;
import org.mozilla.javascript.xml.XMLObject;

public class ScriptRuntime {
    public static final Class<?> BooleanClass = Kit.classOrNull("java.lang.Boolean");
    public static final Class<?> ByteClass = Kit.classOrNull("java.lang.Byte");
    public static final Class<?> CharacterClass = Kit.classOrNull("java.lang.Character");
    public static final Class<?> ClassClass = Kit.classOrNull("java.lang.Class");
    public static final Class<?> ContextClass;
    public static final Class<?> ContextFactoryClass;
    private static final String DEFAULT_NS_TAG = "__default_namespace__";
    public static final Class<?> DateClass;
    public static final Class<?> DoubleClass;
    public static final int ENUMERATE_ARRAY = 2;
    public static final int ENUMERATE_ARRAY_NO_ITERATOR = 5;
    public static final int ENUMERATE_KEYS = 0;
    public static final int ENUMERATE_KEYS_NO_ITERATOR = 3;
    public static final int ENUMERATE_VALUES = 1;
    public static final int ENUMERATE_VALUES_NO_ITERATOR = 4;
    public static final Class<?> FloatClass;
    public static final Class<?> FunctionClass;
    public static final Class<?> IntegerClass;
    private static final Object LIBRARY_SCOPE_KEY;
    public static final Class<?> LongClass;
    public static final double NaN;
    public static final Double NaNobj;
    public static final Class<?> NumberClass;
    public static final Class<?> ObjectClass;
    public static Locale ROOT_LOCALE;
    public static final Class<Scriptable> ScriptableClass;
    public static final Class<?> ScriptableObjectClass;
    public static final Class<?> ShortClass;
    public static final Class<?> StringClass;
    public static final Object[] emptyArgs;
    public static final String[] emptyStrings;
    public static MessageProvider messageProvider;
    public static final double negativeZero;

    static {
        DoubleClass = Kit.classOrNull("java.lang.Double");
        FloatClass = Kit.classOrNull("java.lang.Float");
        IntegerClass = Kit.classOrNull("java.lang.Integer");
        LongClass = Kit.classOrNull("java.lang.Long");
        NumberClass = Kit.classOrNull("java.lang.Number");
        ObjectClass = Kit.classOrNull("java.lang.Object");
        ShortClass = Kit.classOrNull("java.lang.Short");
        StringClass = Kit.classOrNull("java.lang.String");
        DateClass = Kit.classOrNull("java.util.Date");
        ContextClass = Kit.classOrNull("org.mozilla.javascript.Context");
        ContextFactoryClass = Kit.classOrNull("org.mozilla.javascript.ContextFactory");
        FunctionClass = Kit.classOrNull("org.mozilla.javascript.Function");
        ScriptableObjectClass = Kit.classOrNull("org.mozilla.javascript.ScriptableObject");
        ScriptableClass = Scriptable.class;
        ROOT_LOCALE = new Locale("");
        LIBRARY_SCOPE_KEY = "LIBRARY_SCOPE";
        NaN = Double.longBitsToDouble((long)9221120237041090560L);
        negativeZero = Double.longBitsToDouble((long)Long.MIN_VALUE);
        NaNobj = new Double(NaN);
        messageProvider = new DefaultMessageProvider();
        emptyArgs = new Object[0];
        emptyStrings = new String[0];
    }

    protected ScriptRuntime() {
    }

    public static CharSequence add(CharSequence charSequence, Object object) {
        return new ConsString(charSequence, ScriptRuntime.toCharSequence(object));
    }

    public static CharSequence add(Object object, CharSequence charSequence) {
        return new ConsString(ScriptRuntime.toCharSequence(object), charSequence);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Object add(Object object, Object object2, Context context) {
        Object object3;
        if (object instanceof Number && object2 instanceof Number) {
            return ScriptRuntime.wrapNumber(((Number)object).doubleValue() + ((Number)object2).doubleValue());
        }
        if (object instanceof XMLObject) {
            object3 = ((XMLObject)object).addValues(context, true, object2);
            if (object3 != Scriptable.NOT_FOUND) return object3;
        }
        if (object2 instanceof XMLObject) {
            object3 = ((XMLObject)object2).addValues(context, false, object);
            if (object3 != Scriptable.NOT_FOUND) return object3;
        }
        if (object instanceof Scriptable) {
            object = ((Scriptable)object).getDefaultValue(null);
        }
        if (object2 instanceof Scriptable) {
            object2 = ((Scriptable)object2).getDefaultValue(null);
        }
        if (object instanceof CharSequence) return new ConsString(ScriptRuntime.toCharSequence(object), ScriptRuntime.toCharSequence(object2));
        if (object2 instanceof CharSequence) return new ConsString(ScriptRuntime.toCharSequence(object), ScriptRuntime.toCharSequence(object2));
        if (!(object instanceof Number)) return ScriptRuntime.wrapNumber(ScriptRuntime.toNumber(object) + ScriptRuntime.toNumber(object2));
        if (!(object2 instanceof Number)) return ScriptRuntime.wrapNumber(ScriptRuntime.toNumber(object) + ScriptRuntime.toNumber(object2));
        return ScriptRuntime.wrapNumber(((Number)object).doubleValue() + ((Number)object2).doubleValue());
    }

    public static void addInstructionCount(Context context, int n) {
        context.instructionCount = n + context.instructionCount;
        if (context.instructionCount > context.instructionThreshold) {
            context.observeInstructionCount(context.instructionCount);
            context.instructionCount = 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Object applyOrCall(boolean bl, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        Object[] arrobject2;
        int n = arrobject.length;
        Callable callable = ScriptRuntime.getCallable(scriptable2);
        Scriptable scriptable3 = null;
        if (n != 0) {
            scriptable3 = ScriptRuntime.toObjectOrNull(context, arrobject[0], scriptable);
        }
        if (scriptable3 == null) {
            scriptable3 = ScriptRuntime.getTopCallScope(context);
        }
        if (bl) {
            if (n <= 1) {
                arrobject2 = emptyArgs;
                do {
                    return callable.call(context, scriptable, scriptable3, arrobject2);
                    break;
                } while (true);
            }
            arrobject2 = ScriptRuntime.getApplyArguments(context, arrobject[1]);
            return callable.call(context, scriptable, scriptable3, arrobject2);
        }
        if (n <= 1) {
            arrobject2 = emptyArgs;
            return callable.call(context, scriptable, scriptable3, arrobject2);
        }
        arrobject2 = new Object[n - 1];
        System.arraycopy((Object)arrobject, (int)1, (Object)arrobject2, (int)0, (int)(n - 1));
        return callable.call(context, scriptable, scriptable3, arrobject2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static Scriptable bind(Context var0, Scriptable var1_1, String var2_2) {
        var3_3 = var1_1.getParentScope();
        var4_4 = null;
        if (var3_3 == null) ** GOTO lbl17
        while (var1_1 instanceof NativeWith) {
            var5_5 = var1_1.getPrototype();
            if (var5_5 instanceof XMLObject) {
                var6_6 = (XMLObject)var5_5;
                if (var6_6.has(var0, var2_2)) {
                    return var6_6;
                }
                if (var4_4 == null) {
                    var4_4 = var6_6;
                }
            } else if (ScriptableObject.hasProperty(var5_5, var2_2)) {
                return var5_5;
            }
            var1_1 = var3_3;
            if ((var3_3 = var3_3.getParentScope()) != null) continue;
lbl17: // 3 sources:
            do {
                if (var0.useDynamicScope) {
                    var1_1 = ScriptRuntime.checkDynamicScope(var0.topCallScope, var1_1);
                }
                if (ScriptableObject.hasProperty(var1_1, var2_2) == false) return var4_4;
                return var1_1;
                break;
            } while (true);
        }
        do {
            if (ScriptableObject.hasProperty(var1_1, var2_2)) {
                return var1_1;
            }
            var1_1 = var3_3;
        } while ((var3_3 = var3_3.getParentScope()) != null);
        ** while (true)
    }

    @Deprecated
    public static Object call(Context context, Object object, Object object2, Object[] arrobject, Scriptable scriptable) {
        if (!(object instanceof Function)) {
            throw ScriptRuntime.notFunctionError(ScriptRuntime.toString(object));
        }
        Function function = (Function)object;
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object2, scriptable);
        if (scriptable2 == null) {
            throw ScriptRuntime.undefCallError(scriptable2, "function");
        }
        return function.call(context, scriptable, scriptable2, arrobject);
    }

    public static Ref callRef(Callable callable, Scriptable scriptable, Object[] arrobject, Context context) {
        Ref ref;
        if (callable instanceof RefCallable) {
            RefCallable refCallable = (RefCallable)callable;
            ref = refCallable.refCall(context, scriptable, arrobject);
            if (ref == null) {
                throw new IllegalStateException(refCallable.getClass().getName() + ".refCall() returned null");
            }
        } else {
            throw ScriptRuntime.constructError("ReferenceError", ScriptRuntime.getMessage1("msg.no.ref.from.function", ScriptRuntime.toString(callable)));
        }
        return ref;
    }

    public static Object callSpecial(Context context, Callable callable, Scriptable scriptable, Object[] arrobject, Scriptable scriptable2, Scriptable scriptable3, int n, String string2, int n2) {
        if (n == 1) {
            if (scriptable.getParentScope() == null && NativeGlobal.isEvalFunction(callable)) {
                return ScriptRuntime.evalSpecial(context, scriptable2, scriptable3, arrobject, string2, n2);
            }
        } else if (n == 2) {
            if (NativeWith.isWithFunction(callable)) {
                throw Context.reportRuntimeError1("msg.only.from.new", "With");
            }
        } else {
            throw Kit.codeBug();
        }
        return callable.call(context, scriptable2, scriptable, arrobject);
    }

    static void checkDeprecated(Context context, String string2) {
        String string3;
        block3 : {
            block2 : {
                int n = context.getLanguageVersion();
                if (n < 140 && n != 0) break block2;
                string3 = ScriptRuntime.getMessage1("msg.deprec.ctor", string2);
                if (n != 0) break block3;
                Context.reportWarning(string3);
            }
            return;
        }
        throw Context.reportRuntimeError(string3);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static Scriptable checkDynamicScope(Scriptable scriptable, Scriptable scriptable2) {
        if (scriptable == scriptable2) {
            return scriptable;
        }
        Scriptable scriptable3 = scriptable;
        do {
            if ((scriptable3 = scriptable3.getPrototype()) == scriptable2) return scriptable;
        } while (scriptable3 != null);
        return scriptable2;
    }

    public static RegExpProxy checkRegExpProxy(Context context) {
        RegExpProxy regExpProxy = ScriptRuntime.getRegExpProxy(context);
        if (regExpProxy == null) {
            throw Context.reportRuntimeError0("msg.no.regexp");
        }
        return regExpProxy;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean cmp_LE(Object object, Object object2) {
        double d;
        double d2;
        boolean bl = true;
        if (object instanceof Number && object2 instanceof Number) {
            d = ((Number)object).doubleValue();
            d2 = ((Number)object2).doubleValue();
        } else {
            if (object instanceof Scriptable) {
                object = ((Scriptable)object).getDefaultValue(NumberClass);
            }
            if (object2 instanceof Scriptable) {
                object2 = ((Scriptable)object2).getDefaultValue(NumberClass);
            }
            if (object instanceof CharSequence && object2 instanceof CharSequence) {
                if (object.toString().compareTo(object2.toString()) > 0) return false;
                return bl;
            }
            d = ScriptRuntime.toNumber(object);
            d2 = ScriptRuntime.toNumber(object2);
        }
        if (!(d <= d2)) return false;
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean cmp_LT(Object object, Object object2) {
        double d;
        double d2;
        boolean bl = true;
        if (object instanceof Number && object2 instanceof Number) {
            d = ((Number)object).doubleValue();
            d2 = ((Number)object2).doubleValue();
        } else {
            if (object instanceof Scriptable) {
                object = ((Scriptable)object).getDefaultValue(NumberClass);
            }
            if (object2 instanceof Scriptable) {
                object2 = ((Scriptable)object2).getDefaultValue(NumberClass);
            }
            if (object instanceof CharSequence && object2 instanceof CharSequence) {
                if (object.toString().compareTo(object2.toString()) >= 0) return false;
                return bl;
            }
            d = ScriptRuntime.toNumber(object);
            d2 = ScriptRuntime.toNumber(object2);
        }
        if (!(d < d2)) return false;
        return bl;
    }

    public static EcmaError constructError(String string2, String string3) {
        int[] arrn = new int[1];
        return ScriptRuntime.constructError(string2, string3, Context.getSourcePositionFromStack(arrn), arrn[0], null, 0);
    }

    public static EcmaError constructError(String string2, String string3, int n) {
        int[] arrn = new int[1];
        String string4 = Context.getSourcePositionFromStack(arrn);
        if (arrn[0] != 0) {
            arrn[0] = n + arrn[0];
        }
        return ScriptRuntime.constructError(string2, string3, string4, arrn[0], null, 0);
    }

    public static EcmaError constructError(String string2, String string3, String string4, int n, String string5, int n2) {
        return new EcmaError(string2, string3, string4, n, string5, n2);
    }

    public static Scriptable createFunctionActivation(NativeFunction nativeFunction, Scriptable scriptable, Object[] arrobject) {
        return new NativeCall(nativeFunction, scriptable, arrobject);
    }

    private static XMLLib currentXMLLib(Context context) {
        if (context.topCallScope == null) {
            throw new IllegalStateException();
        }
        XMLLib xMLLib = context.cachedXMLLib;
        if (xMLLib == null) {
            xMLLib = XMLLib.extractFromScope(context.topCallScope);
            if (xMLLib == null) {
                throw new IllegalStateException();
            }
            context.cachedXMLLib = xMLLib;
        }
        return xMLLib;
    }

    /*
     * Exception decompiling
     */
    static String defaultObjectToSource(Context var0, Scriptable var1_1, Scriptable var2_2, Object[] var3_3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 4[FORLOOP]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    static String defaultObjectToString(Scriptable scriptable) {
        return "[object " + scriptable.getClassName() + ']';
    }

    @Deprecated
    public static Object delete(Object object, Object object2, Context context) {
        return ScriptRuntime.delete(object, object2, context, false);
    }

    public static Object delete(Object object, Object object2, Context context, Scriptable scriptable, boolean bl) {
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 == null) {
            if (bl) {
                return Boolean.TRUE;
            }
            throw ScriptRuntime.undefDeleteError(object, object2);
        }
        return ScriptRuntime.wrapBoolean(ScriptRuntime.deleteObjectElem(scriptable2, object2, context));
    }

    @Deprecated
    public static Object delete(Object object, Object object2, Context context, boolean bl) {
        return ScriptRuntime.delete(object, object2, context, ScriptRuntime.getTopCallScope(context), bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean deleteObjectElem(Scriptable scriptable, Object object, Context context) {
        String string2 = ScriptRuntime.toStringIdOrIndex(context, object);
        if (string2 == null) {
            int n = ScriptRuntime.lastIndexResult(context);
            scriptable.delete(n);
            if (!scriptable.has(n, scriptable)) return true;
            return false;
        }
        scriptable.delete(string2);
        if (scriptable.has(string2, scriptable)) return false;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object doScriptableIncrDecr(Scriptable scriptable, String string2, Scriptable scriptable2, Object object, int n) {
        double d;
        boolean bl = (n & 2) != 0;
        if (object instanceof Number) {
            d = ((Number)object).doubleValue();
        } else {
            d = ScriptRuntime.toNumber(object);
            if (bl) {
                object = ScriptRuntime.wrapNumber(d);
            }
        }
        double d2 = (n & 1) == 0 ? d + 1.0 : d - 1.0;
        Number number = ScriptRuntime.wrapNumber(d2);
        scriptable.put(string2, scriptable2, (Object)number);
        if (bl) {
            return object;
        }
        return number;
    }

    public static Object doTopCall(Callable callable, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        Object object;
        if (scriptable == null) {
            throw new IllegalArgumentException();
        }
        if (context.topCallScope != null) {
            throw new IllegalStateException();
        }
        context.topCallScope = ScriptableObject.getTopLevelScope(scriptable);
        context.useDynamicScope = context.hasFeature(7);
        ContextFactory contextFactory = context.getFactory();
        try {
            object = contextFactory.doTopCall(callable, context, scriptable, scriptable2, arrobject);
        }
        finally {
            context.topCallScope = null;
            context.cachedXMLLib = null;
            if (context.currentActivationCall != null) {
                throw new IllegalStateException();
            }
        }
        return object;
    }

    @Deprecated
    public static Object elemIncrDecr(Object object, Object object2, Context context, int n) {
        return ScriptRuntime.elemIncrDecr(object, object2, context, ScriptRuntime.getTopCallScope(context), n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Object elemIncrDecr(Object object, Object object2, Context context, Scriptable scriptable, int n) {
        double d;
        Object object3 = ScriptRuntime.getObjectElem(object, object2, context, scriptable);
        boolean bl = (n & 2) != 0;
        if (object3 instanceof Number) {
            d = ((Number)object3).doubleValue();
        } else {
            d = ScriptRuntime.toNumber(object3);
            if (bl) {
                object3 = ScriptRuntime.wrapNumber(d);
            }
        }
        double d2 = (n & 1) == 0 ? d + 1.0 : d - 1.0;
        Number number = ScriptRuntime.wrapNumber(d2);
        ScriptRuntime.setObjectElem(object, object2, (Object)number, context, scriptable);
        if (bl) {
            return object3;
        }
        return number;
    }

    public static void enterActivationFunction(Context context, Scriptable scriptable) {
        if (context.topCallScope == null) {
            throw new IllegalStateException();
        }
        NativeCall nativeCall = (NativeCall)scriptable;
        nativeCall.parentActivationCall = context.currentActivationCall;
        context.currentActivationCall = nativeCall;
    }

    public static Scriptable enterDotQuery(Object object, Scriptable scriptable) {
        if (!(object instanceof XMLObject)) {
            throw ScriptRuntime.notXmlError(object);
        }
        return ((XMLObject)object).enterDotQuery(scriptable);
    }

    public static Scriptable enterWith(Object object, Context context, Scriptable scriptable) {
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 == null) {
            throw ScriptRuntime.typeError1("msg.undef.with", ScriptRuntime.toString(object));
        }
        if (scriptable2 instanceof XMLObject) {
            return ((XMLObject)scriptable2).enterWith(scriptable);
        }
        return new NativeWith(scriptable, scriptable2);
    }

    private static void enumChangeObject(IdEnumeration idEnumeration) {
        Object[] arrobject = null;
        do {
            if (idEnumeration.obj == null || (arrobject = idEnumeration.obj.getIds()).length != 0) {
                if (idEnumeration.obj == null || idEnumeration.ids == null) break;
                Object[] arrobject2 = idEnumeration.ids;
                int n = arrobject2.length;
                if (idEnumeration.used == null) {
                    idEnumeration.used = new ObjToIntMap(n);
                }
                for (int i = 0; i != n; ++i) {
                    idEnumeration.used.intern(arrobject2[i]);
                }
                break;
            }
            idEnumeration.obj = idEnumeration.obj.getPrototype();
        } while (true);
        idEnumeration.ids = arrobject;
        idEnumeration.index = 0;
    }

    public static Object enumId(Object object, Context context) {
        IdEnumeration idEnumeration = (IdEnumeration)object;
        if (idEnumeration.iterator != null) {
            return idEnumeration.currentId;
        }
        switch (idEnumeration.enumType) {
            default: {
                throw Kit.codeBug();
            }
            case 0: 
            case 3: {
                return idEnumeration.currentId;
            }
            case 1: 
            case 4: {
                return ScriptRuntime.enumValue(object, context);
            }
            case 2: 
            case 5: 
        }
        Object[] arrobject = new Object[]{idEnumeration.currentId, ScriptRuntime.enumValue(object, context)};
        return context.newArray(ScriptableObject.getTopLevelScope(idEnumeration.obj), arrobject);
    }

    @Deprecated
    public static Object enumInit(Object object, Context context, int n) {
        return ScriptRuntime.enumInit(object, context, ScriptRuntime.getTopCallScope(context), n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Object enumInit(Object object, Context context, Scriptable scriptable, int n) {
        IdEnumeration idEnumeration;
        block5 : {
            block4 : {
                idEnumeration = new IdEnumeration();
                idEnumeration.obj = ScriptRuntime.toObjectOrNull(context, object, scriptable);
                if (idEnumeration.obj == null) break block4;
                idEnumeration.enumType = n;
                idEnumeration.iterator = null;
                if (n != 3 && n != 4 && n != 5) {
                    Scriptable scriptable2 = idEnumeration.obj.getParentScope();
                    Scriptable scriptable3 = idEnumeration.obj;
                    boolean bl = n == 0;
                    idEnumeration.iterator = ScriptRuntime.toIterator(context, scriptable2, scriptable3, bl);
                }
                if (idEnumeration.iterator == null) break block5;
            }
            return idEnumeration;
        }
        ScriptRuntime.enumChangeObject(idEnumeration);
        return idEnumeration;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Deprecated
    public static Object enumInit(Object object, Context context, boolean bl) {
        int n;
        if (bl) {
            n = 1;
            do {
                return ScriptRuntime.enumInit(object, context, n);
                break;
            } while (true);
        }
        n = 0;
        return ScriptRuntime.enumInit(object, context, n);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static Boolean enumNext(Object var0) {
        block7 : {
            block6 : {
                var1_1 = (IdEnumeration)var0;
                if (var1_1.iterator == null) ** GOTO lbl33
                var8_2 = ScriptableObject.getProperty(var1_1.iterator, "next");
                if (!(var8_2 instanceof Callable)) {
                    return Boolean.FALSE;
                }
                var9_3 = (Callable)var8_2;
                var10_4 = Context.getContext();
                try {
                    var1_1.currentId = var9_3.call(var10_4, var1_1.iterator.getParentScope(), var1_1.iterator, ScriptRuntime.emptyArgs);
                    return Boolean.TRUE;
                }
                catch (JavaScriptException var11_6) {
                    if (var11_6.getValue() instanceof NativeIterator.StopIteration == false) throw var11_6;
                    return Boolean.FALSE;
                }
lbl-1000: // 1 sources:
                {
                    if (var1_1.index == var1_1.ids.length) {
                        var1_1.obj = var1_1.obj.getPrototype();
                        ScriptRuntime.enumChangeObject(var1_1);
                        continue;
                    }
                    var2_7 = var1_1.ids;
                    var3_8 = var1_1.index;
                    var1_1.index = var3_8 + 1;
                    var4_9 = var2_7[var3_8];
                    if (var1_1.used != null && var1_1.used.has(var4_9)) continue;
                    if (var4_9 instanceof String) {
                        var7_11 = (String)var4_9;
                        if (!var1_1.obj.has(var7_11, var1_1.obj)) continue;
                        var1_1.currentId = var7_11;
                        return Boolean.TRUE;
                    }
                    var5_10 = ((Number)var4_9).intValue();
                    if (!var1_1.obj.has(var5_10, var1_1.obj)) continue;
                    if (!var1_1.enumNumbers) break block6;
                    var6_12 = var5_10;
                    break block7;
lbl33: // 5 sources:
                    ** while (var1_1.obj != null)
                }
lbl34: // 1 sources:
                return Boolean.FALSE;
            }
            var6_14 = String.valueOf((int)var5_10);
        }
        var1_1.currentId = var6_13;
        return Boolean.TRUE;
    }

    public static Object enumValue(Object object, Context context) {
        IdEnumeration idEnumeration = (IdEnumeration)object;
        String string2 = ScriptRuntime.toStringIdOrIndex(context, idEnumeration.currentId);
        if (string2 == null) {
            int n = ScriptRuntime.lastIndexResult(context);
            return idEnumeration.obj.get(n, idEnumeration.obj);
        }
        return idEnumeration.obj.get(string2, idEnumeration.obj);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean eq(Object object, Object object2) {
        boolean bl;
        boolean bl2 = true;
        if (object == null || object == Undefined.instance) {
            if (object2 == null) return bl2;
            if (object2 == Undefined.instance) {
                return bl2;
            }
            boolean bl3 = object2 instanceof ScriptableObject;
            bl = false;
            if (!bl3) return bl;
            Object object3 = ((ScriptableObject)object2).equivalentValues(object);
            Object object4 = Scriptable.NOT_FOUND;
            bl = false;
            if (object3 == object4) return bl;
            return (Boolean)object3;
        }
        if (object instanceof Number) {
            return ScriptRuntime.eqNumber(((Number)object).doubleValue(), object2);
        }
        if (object == object2) {
            return bl2;
        }
        if (object instanceof CharSequence) {
            return ScriptRuntime.eqString((CharSequence)object, object2);
        }
        if (object instanceof Boolean) {
            Object object5;
            double d;
            boolean bl4 = (Boolean)object;
            if (object2 instanceof Boolean) {
                if (bl4 != (Boolean)object2) return false;
                return bl2;
            }
            if (object2 instanceof ScriptableObject && (object5 = ((ScriptableObject)object2).equivalentValues(object)) != Scriptable.NOT_FOUND) {
                return (Boolean)object5;
            }
            if (bl4) {
                d = 1.0;
                do {
                    return ScriptRuntime.eqNumber(d, object2);
                    break;
                } while (true);
            }
            d = 0.0;
            return ScriptRuntime.eqNumber(d, object2);
        }
        if (object instanceof Scriptable) {
            if (object2 instanceof Scriptable) {
                Object object6;
                Object object7;
                Object object8;
                if (object instanceof ScriptableObject && (object6 = ((ScriptableObject)object).equivalentValues(object2)) != Scriptable.NOT_FOUND) {
                    return (Boolean)object6;
                }
                if (object2 instanceof ScriptableObject && (object7 = ((ScriptableObject)object2).equivalentValues(object)) != Scriptable.NOT_FOUND) {
                    return (Boolean)object7;
                }
                boolean bl5 = object instanceof Wrapper;
                bl = false;
                if (!bl5) return bl;
                boolean bl6 = object2 instanceof Wrapper;
                bl = false;
                if (!bl6) return bl;
                Object object9 = ((Wrapper)object).unwrap();
                if (object9 == (object8 = ((Wrapper)object2).unwrap())) return bl2;
                boolean bl7 = ScriptRuntime.isPrimitive(object9);
                bl = false;
                if (!bl7) return bl;
                boolean bl8 = ScriptRuntime.isPrimitive(object8);
                bl = false;
                if (!bl8) return bl;
                boolean bl9 = ScriptRuntime.eq(object9, object8);
                bl = false;
                if (!bl9) return bl;
                return bl2;
            }
            if (object2 instanceof Boolean) {
                Object object10;
                double d;
                if (object instanceof ScriptableObject && (object10 = ((ScriptableObject)object).equivalentValues(object2)) != Scriptable.NOT_FOUND) {
                    return (Boolean)object10;
                }
                if (((Boolean)object2).booleanValue()) {
                    d = 1.0;
                    do {
                        return ScriptRuntime.eqNumber(d, object);
                        break;
                    } while (true);
                }
                d = 0.0;
                return ScriptRuntime.eqNumber(d, object);
            }
            if (object2 instanceof Number) {
                return ScriptRuntime.eqNumber(((Number)object2).doubleValue(), object);
            }
            boolean bl10 = object2 instanceof CharSequence;
            bl = false;
            if (!bl10) return bl;
            return ScriptRuntime.eqString((CharSequence)object2, object);
        }
        ScriptRuntime.warnAboutNonJSObject(object);
        if (object != object2) return false;
        return bl2;
    }

    /*
     * Enabled aggressive block sorting
     */
    static boolean eqNumber(double d, Object object) {
        boolean bl = true;
        while (object != null) {
            Object object2;
            Number number;
            if (object == Undefined.instance) {
                return false;
            }
            if (object instanceof Number) {
                if (d != ((Number)object).doubleValue()) return false;
                return bl;
            }
            if (object instanceof CharSequence) {
                if (d == ScriptRuntime.toNumber(object)) return bl;
                return false;
            }
            if (object instanceof Boolean) {
                double d2 = (Boolean)object != false ? 1.0 : 0.0;
                if (d == d2) return bl;
                return false;
            }
            if (!(object instanceof Scriptable)) {
                ScriptRuntime.warnAboutNonJSObject(object);
                return false;
            }
            if (object instanceof ScriptableObject && (object2 = ((ScriptableObject)object).equivalentValues((Object)(number = ScriptRuntime.wrapNumber(d)))) != Scriptable.NOT_FOUND) {
                return (Boolean)object2;
            }
            object = ScriptRuntime.toPrimitive(object);
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean eqString(CharSequence charSequence, Object object) {
        boolean bl = true;
        while (object != null) {
            Object object2;
            if (object == Undefined.instance) {
                return false;
            }
            if (object instanceof CharSequence) {
                CharSequence charSequence2 = (CharSequence)object;
                if (charSequence.length() != charSequence2.length()) return false;
                if (!charSequence.toString().equals((Object)charSequence2.toString())) return false;
                return bl;
            }
            if (object instanceof Number) {
                if (ScriptRuntime.toNumber(charSequence.toString()) == ((Number)object).doubleValue()) return bl;
                return false;
            }
            if (object instanceof Boolean) {
                double d = ScriptRuntime.toNumber(charSequence.toString());
                double d2 = (Boolean)object != false ? 1.0 : 0.0;
                if (d == d2) return bl;
                return false;
            }
            if (!(object instanceof Scriptable)) {
                ScriptRuntime.warnAboutNonJSObject(object);
                return false;
            }
            if (object instanceof ScriptableObject && (object2 = ((ScriptableObject)object).equivalentValues(charSequence.toString())) != Scriptable.NOT_FOUND) {
                return (Boolean)object2;
            }
            object = ScriptRuntime.toPrimitive(object);
        }
        return false;
    }

    private static RuntimeException errorWithClassName(String string2, Object object) {
        return Context.reportRuntimeError1(string2, object.getClass().getName());
    }

    public static String escapeAttributeValue(Object object, Context context) {
        return ScriptRuntime.currentXMLLib(context).escapeAttributeValue(object);
    }

    public static String escapeString(String string2) {
        return ScriptRuntime.escapeString(string2, '\"');
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static String escapeString(String var0, char var1_1) {
        if (var1_1 != '\"' && var1_1 != '\'') {
            Kit.codeBug();
        }
        var2_2 = null;
        var3_3 = 0;
        var4_4 = var0.length();
        block10 : do {
            block24 : {
                block23 : {
                    block22 : {
                        if (var3_3 == var4_4) {
                            if (var2_2 != null) return var2_2.toString();
                            return var0;
                        }
                        var5_5 = var0.charAt(var3_3);
                        if (' ' > var5_5 || var5_5 > '~' || var5_5 == var1_1 || var5_5 == '\\') break block22;
                        if (var2_2 != null) {
                            var2_2.append(var5_5);
                        }
                        ** GOTO lbl64
                    }
                    if (var2_2 == null) {
                        var2_2 = new StringBuilder(var4_4 + 3);
                        var2_2.append(var0);
                        var2_2.setLength(var3_3);
                    }
                    var7_6 = -1;
                    switch (var5_5) {
                        case '\b': {
                            var7_6 = 98;
                            break;
                        }
                        case '\f': {
                            var7_6 = 102;
                            break;
                        }
                        case '\n': {
                            var7_6 = 110;
                            break;
                        }
                        case '\r': {
                            var7_6 = 114;
                            break;
                        }
                        case '\t': {
                            var7_6 = 116;
                            break;
                        }
                        case '\u000b': {
                            var7_6 = 118;
                            break;
                        }
                        case ' ': {
                            var7_6 = 32;
                            break;
                        }
                        case '\\': {
                            var7_6 = 92;
                        }
                    }
                    if (var7_6 < 0) break block23;
                    var2_2.append('\\');
                    var2_2.append((char)var7_6);
                    ** GOTO lbl64
                }
                if (var5_5 != var1_1) break block24;
                var2_2.append('\\');
                var2_2.append(var1_1);
                ** GOTO lbl64
            }
            if (var5_5 < '\u0100') {
                var2_2.append("\\x");
                var9_7 = 2;
            } else {
                var2_2.append("\\u");
                var9_7 = 4;
            }
            var10_8 = 4 * (var9_7 - 1);
            do {
                block25 : {
                    if (var10_8 >= 0) break block25;
lbl64: // 4 sources:
                    ++var3_3;
                    continue block10;
                }
                var11_9 = 15 & var5_5 >> var10_8;
                var12_10 = var11_9 < 10 ? var11_9 + 48 : var11_9 + 87;
                var2_2.append((char)var12_10);
                var10_8 -= 4;
            } while (true);
            break;
        } while (true);
    }

    public static String escapeTextValue(Object object, Context context) {
        return ScriptRuntime.currentXMLLib(context).escapeTextValue(object);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Object evalSpecial(Context context, Scriptable scriptable, Object object, Object[] arrobject, String string2, int n) {
        if (arrobject.length < 1) {
            return Undefined.instance;
        }
        Object object2 = arrobject[0];
        if (!(object2 instanceof CharSequence)) {
            if (!context.hasFeature(11) && !context.hasFeature(9)) {
                Context.reportWarning(ScriptRuntime.getMessage0("msg.eval.nonstring"));
                return object2;
            }
            throw Context.reportRuntimeError0("msg.eval.nonstring.strict");
        }
        if (string2 == null) {
            int[] arrn = new int[1];
            string2 = Context.getSourcePositionFromStack(arrn);
            if (string2 != null) {
                n = arrn[0];
            } else {
                string2 = "";
            }
        }
        String string3 = ScriptRuntime.makeUrlForGeneratedScript(true, string2, n);
        ErrorReporter errorReporter = DefaultErrorReporter.forEval(context.getErrorReporter());
        Evaluator evaluator = Context.createInterpreter();
        if (evaluator == null) {
            throw new JavaScriptException("Interpreter not present", string2, n);
        }
        Script script = context.compileString(object2.toString(), evaluator, errorReporter, string3, 1, null);
        evaluator.setEvalScriptFlag(script);
        return ((Callable)((Object)script)).call(context, scriptable, (Scriptable)object, emptyArgs);
    }

    public static void exitActivationFunction(Context context) {
        NativeCall nativeCall = context.currentActivationCall;
        context.currentActivationCall = nativeCall.parentActivationCall;
        nativeCall.parentActivationCall = null;
    }

    static NativeCall findFunctionActivation(Context context, Function function) {
        NativeCall nativeCall = context.currentActivationCall;
        while (nativeCall != null) {
            if (nativeCall.function == function) {
                return nativeCall;
            }
            nativeCall = nativeCall.parentActivationCall;
        }
        return null;
    }

    static Object[] getApplyArguments(Context context, Object object) {
        if (object == null || object == Undefined.instance) {
            return emptyArgs;
        }
        if (object instanceof NativeArray || object instanceof Arguments) {
            return context.getElements((Scriptable)object);
        }
        throw ScriptRuntime.typeError0("msg.arg.isnt.array");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Object[] getArrayElements(Scriptable scriptable) {
        long l = NativeArray.getLengthProperty(Context.getContext(), scriptable);
        if (l > Integer.MAX_VALUE) {
            throw new IllegalArgumentException();
        }
        int n = (int)l;
        if (n == 0) {
            return emptyArgs;
        }
        Object[] arrobject = new Object[n];
        int n2 = 0;
        while (n2 < n) {
            Object object = ScriptableObject.getProperty(scriptable, n2);
            if (object == Scriptable.NOT_FOUND) {
                object = Undefined.instance;
            }
            arrobject[n2] = object;
            ++n2;
        }
        return arrobject;
    }

    static Callable getCallable(Scriptable scriptable) {
        if (scriptable instanceof Callable) {
            return (Callable)((Object)scriptable);
        }
        Object object = scriptable.getDefaultValue(FunctionClass);
        if (!(object instanceof Callable)) {
            throw ScriptRuntime.notFunctionError(object, scriptable);
        }
        return (Callable)object;
    }

    @Deprecated
    public static Callable getElemFunctionAndThis(Object object, Object object2, Context context) {
        return ScriptRuntime.getElemFunctionAndThis(object, object2, context, ScriptRuntime.getTopCallScope(context));
    }

    public static Callable getElemFunctionAndThis(Object object, Object object2, Context context, Scriptable scriptable) {
        String string2 = ScriptRuntime.toStringIdOrIndex(context, object2);
        if (string2 != null) {
            return ScriptRuntime.getPropFunctionAndThis(object, string2, context, scriptable);
        }
        int n = ScriptRuntime.lastIndexResult(context);
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 == null) {
            throw ScriptRuntime.undefCallError(object, String.valueOf((int)n));
        }
        Object object3 = ScriptableObject.getProperty(scriptable2, n);
        if (!(object3 instanceof Callable)) {
            throw ScriptRuntime.notFunctionError(object3, object2);
        }
        ScriptRuntime.storeScriptable(context, scriptable2);
        return (Callable)object3;
    }

    static Function getExistingCtor(Context context, Scriptable scriptable, String string2) {
        Object object = ScriptableObject.getProperty(scriptable, string2);
        if (object instanceof Function) {
            return (Function)object;
        }
        if (object == Scriptable.NOT_FOUND) {
            throw Context.reportRuntimeError1("msg.ctor.not.found", string2);
        }
        throw Context.reportRuntimeError1("msg.not.ctor", string2);
    }

    public static ScriptableObject getGlobal(Context context) {
        Class<?> class_ = Kit.classOrNull("org.mozilla.javascript.tools.shell.Global");
        if (class_ != null) {
            try {
                Class[] arrclass = new Class[]{ContextClass};
                ScriptableObject scriptableObject = (ScriptableObject)class_.getConstructor(arrclass).newInstance(new Object[]{context});
                return scriptableObject;
            }
            catch (RuntimeException runtimeException) {
                throw runtimeException;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return new ImporterTopLevel(context);
    }

    static Object getIndexObject(double d) {
        int n = (int)d;
        if ((double)n == d) {
            return n;
        }
        return ScriptRuntime.toString(d);
    }

    static Object getIndexObject(String string2) {
        long l = ScriptRuntime.indexFromString(string2);
        if (l >= 0L) {
            string2 = Integer.valueOf((int)((int)l));
        }
        return string2;
    }

    public static ScriptableObject getLibraryScopeOrNull(Scriptable scriptable) {
        return (ScriptableObject)ScriptableObject.getTopScopeValue(scriptable, LIBRARY_SCOPE_KEY);
    }

    public static String getMessage(String string2, Object[] arrobject) {
        return messageProvider.getMessage(string2, arrobject);
    }

    public static String getMessage0(String string2) {
        return ScriptRuntime.getMessage(string2, null);
    }

    public static String getMessage1(String string2, Object object) {
        return ScriptRuntime.getMessage(string2, new Object[]{object});
    }

    public static String getMessage2(String string2, Object object, Object object2) {
        return ScriptRuntime.getMessage(string2, new Object[]{object, object2});
    }

    public static String getMessage3(String string2, Object object, Object object2, Object object3) {
        return ScriptRuntime.getMessage(string2, new Object[]{object, object2, object3});
    }

    public static String getMessage4(String string2, Object object, Object object2, Object object3, Object object4) {
        return ScriptRuntime.getMessage(string2, new Object[]{object, object2, object3, object4});
    }

    public static Callable getNameFunctionAndThis(String string2, Context context, Scriptable scriptable) {
        Scriptable scriptable2 = scriptable.getParentScope();
        if (scriptable2 == null) {
            Object object = ScriptRuntime.topScopeName(context, scriptable, string2);
            if (!(object instanceof Callable)) {
                if (object == Scriptable.NOT_FOUND) {
                    throw ScriptRuntime.notFoundError(scriptable, string2);
                }
                throw ScriptRuntime.notFunctionError(object, string2);
            }
            ScriptRuntime.storeScriptable(context, scriptable);
            return (Callable)object;
        }
        return (Callable)ScriptRuntime.nameOrFunction(context, scriptable, scriptable2, string2, true);
    }

    @Deprecated
    public static Object getObjectElem(Object object, Object object2, Context context) {
        return ScriptRuntime.getObjectElem(object, object2, context, ScriptRuntime.getTopCallScope(context));
    }

    public static Object getObjectElem(Object object, Object object2, Context context, Scriptable scriptable) {
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 == null) {
            throw ScriptRuntime.undefReadError(object, object2);
        }
        return ScriptRuntime.getObjectElem(scriptable2, object2, context);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Object getObjectElem(Scriptable scriptable, Object object, Context context) {
        String string2;
        Object object2 = scriptable instanceof XMLObject ? ((XMLObject)scriptable).get(context, object) : ((string2 = ScriptRuntime.toStringIdOrIndex(context, object)) == null ? ScriptableObject.getProperty(scriptable, ScriptRuntime.lastIndexResult(context)) : ScriptableObject.getProperty(scriptable, string2));
        if (object2 != Scriptable.NOT_FOUND) return object2;
        return Undefined.instance;
    }

    @Deprecated
    public static Object getObjectIndex(Object object, double d, Context context) {
        return ScriptRuntime.getObjectIndex(object, d, context, ScriptRuntime.getTopCallScope(context));
    }

    public static Object getObjectIndex(Object object, double d, Context context, Scriptable scriptable) {
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 == null) {
            throw ScriptRuntime.undefReadError(object, ScriptRuntime.toString(d));
        }
        int n = (int)d;
        if ((double)n == d) {
            return ScriptRuntime.getObjectIndex(scriptable2, n, context);
        }
        return ScriptRuntime.getObjectProp(scriptable2, ScriptRuntime.toString(d), context);
    }

    public static Object getObjectIndex(Scriptable scriptable, int n, Context context) {
        Object object = ScriptableObject.getProperty(scriptable, n);
        if (object == Scriptable.NOT_FOUND) {
            object = Undefined.instance;
        }
        return object;
    }

    @Deprecated
    public static Object getObjectProp(Object object, String string2, Context context) {
        return ScriptRuntime.getObjectProp(object, string2, context, ScriptRuntime.getTopCallScope(context));
    }

    public static Object getObjectProp(Object object, String string2, Context context, Scriptable scriptable) {
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 == null) {
            throw ScriptRuntime.undefReadError(object, string2);
        }
        return ScriptRuntime.getObjectProp(scriptable2, string2, context);
    }

    public static Object getObjectProp(Scriptable scriptable, String string2, Context context) {
        Object object = ScriptableObject.getProperty(scriptable, string2);
        if (object == Scriptable.NOT_FOUND) {
            if (context.hasFeature(11)) {
                Context.reportWarning(ScriptRuntime.getMessage1("msg.ref.undefined.prop", string2));
            }
            object = Undefined.instance;
        }
        return object;
    }

    @Deprecated
    public static Object getObjectPropNoWarn(Object object, String string2, Context context) {
        return ScriptRuntime.getObjectPropNoWarn(object, string2, context, ScriptRuntime.getTopCallScope(context));
    }

    public static Object getObjectPropNoWarn(Object object, String string2, Context context, Scriptable scriptable) {
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 == null) {
            throw ScriptRuntime.undefReadError(object, string2);
        }
        Object object2 = ScriptableObject.getProperty(scriptable2, string2);
        if (object2 == Scriptable.NOT_FOUND) {
            object2 = Undefined.instance;
        }
        return object2;
    }

    @Deprecated
    public static Callable getPropFunctionAndThis(Object object, String string2, Context context) {
        return ScriptRuntime.getPropFunctionAndThis(object, string2, context, ScriptRuntime.getTopCallScope(context));
    }

    public static Callable getPropFunctionAndThis(Object object, String string2, Context context, Scriptable scriptable) {
        return ScriptRuntime.getPropFunctionAndThisHelper(object, string2, context, ScriptRuntime.toObjectOrNull(context, object, scriptable));
    }

    private static Callable getPropFunctionAndThisHelper(Object object, String string2, Context context, Scriptable scriptable) {
        Object object2;
        if (scriptable == null) {
            throw ScriptRuntime.undefCallError(object, string2);
        }
        Object object3 = ScriptableObject.getProperty(scriptable, string2);
        if (!(object3 instanceof Callable) && (object2 = ScriptableObject.getProperty(scriptable, "__noSuchMethod__")) instanceof Callable) {
            object3 = new NoSuchMethodShim((Callable)object2, string2);
        }
        if (!(object3 instanceof Callable)) {
            throw ScriptRuntime.notFunctionError(scriptable, object3, string2);
        }
        ScriptRuntime.storeScriptable(context, scriptable);
        return (Callable)object3;
    }

    public static RegExpProxy getRegExpProxy(Context context) {
        return context.getRegExpProxy();
    }

    public static Scriptable getTopCallScope(Context context) {
        Scriptable scriptable = context.topCallScope;
        if (scriptable == null) {
            throw new IllegalStateException();
        }
        return scriptable;
    }

    public static Object getTopLevelProp(Scriptable scriptable, String string2) {
        return ScriptableObject.getProperty(ScriptableObject.getTopLevelScope(scriptable), string2);
    }

    static String[] getTopPackageNames() {
        if ("Dalvik".equals((Object)System.getProperty((String)"java.vm.name"))) {
            return new String[]{"java", "javax", "org", "com", "edu", "net", "android"};
        }
        return new String[]{"java", "javax", "org", "com", "edu", "net"};
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Callable getValueFunctionAndThis(Object object, Context context) {
        if (!(object instanceof Callable)) {
            throw ScriptRuntime.notFunctionError(object);
        }
        Callable callable = (Callable)object;
        boolean bl = callable instanceof Scriptable;
        Scriptable scriptable = null;
        if (bl) {
            scriptable = ((Scriptable)((Object)callable)).getParentScope();
        }
        if (scriptable == null) {
            if (context.topCallScope == null) {
                throw new IllegalStateException();
            }
            scriptable = context.topCallScope;
        }
        if (scriptable.getParentScope() != null && !(scriptable instanceof NativeWith) && scriptable instanceof NativeCall) {
            scriptable = ScriptableObject.getTopLevelScope(scriptable);
        }
        ScriptRuntime.storeScriptable(context, scriptable);
        return callable;
    }

    public static boolean hasObjectElem(Scriptable scriptable, Object object, Context context) {
        String string2 = ScriptRuntime.toStringIdOrIndex(context, object);
        if (string2 == null) {
            return ScriptableObject.hasProperty(scriptable, ScriptRuntime.lastIndexResult(context));
        }
        return ScriptableObject.hasProperty(scriptable, string2);
    }

    public static boolean hasTopCall(Context context) {
        return context.topCallScope != null;
    }

    public static boolean in(Object object, Object object2, Context context) {
        if (!(object2 instanceof Scriptable)) {
            throw ScriptRuntime.typeError0("msg.in.not.object");
        }
        return ScriptRuntime.hasObjectElem((Scriptable)object2, object, context);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static long indexFromString(String string2) {
        int n;
        int n2;
        int n3 = string2.length();
        if (n3 <= 0) return -1L;
        char c = string2.charAt(0);
        int n4 = 0;
        boolean bl = false;
        if (c == '-') {
            n4 = 0;
            bl = false;
            if (n3 > 1) {
                c = string2.charAt(1);
                if (c == '0') {
                    return -1L;
                }
                n4 = 1;
                bl = true;
            }
        }
        if ((n = c - 48) < 0) return -1L;
        if (n > 9) return -1L;
        int n5 = bl ? 11 : 10;
        if (n3 > n5) return -1L;
        int n6 = -n;
        int n7 = 0;
        if (n6 != 0) {
            for (n2 = n4 + 1; n2 != n3 && (n = -48 + string2.charAt(n2)) >= 0 && n <= 9; ++n2) {
                n7 = n6;
                n6 = n6 * 10 - n;
            }
        }
        if (n2 != n3) return -1L;
        if (n7 <= -214748364) {
            if (n7 != -214748364) return -1L;
            int n8 = bl ? 8 : 7;
            if (n > n8) return -1L;
        }
        if (bl) {
            return 0xFFFFFFFFL & (long)n6;
        }
        n6 = -n6;
        return 0xFFFFFFFFL & (long)n6;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void initFunction(Context context, Scriptable scriptable, NativeFunction nativeFunction, int n, boolean bl) {
        if (n == 1) {
            String string2 = nativeFunction.getFunctionName();
            if (string2 == null || string2.length() == 0) return;
            {
                if (bl) {
                    scriptable.put(string2, scriptable, (Object)nativeFunction);
                    return;
                }
                ScriptableObject.defineProperty(scriptable, string2, nativeFunction, 4);
                return;
            }
        } else {
            if (n != 3) {
                throw Kit.codeBug();
            }
            String string3 = nativeFunction.getFunctionName();
            if (string3 == null || string3.length() == 0) return;
            {
                do {
                    if (!(scriptable instanceof NativeWith)) {
                        scriptable.put(string3, scriptable, (Object)nativeFunction);
                        return;
                    }
                    scriptable = scriptable.getParentScope();
                } while (true);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static ScriptableObject initSafeStandardObjects(Context context, ScriptableObject scriptableObject, boolean bl) {
        if (scriptableObject == null) {
            scriptableObject = new NativeObject();
        }
        scriptableObject.associateValue(LIBRARY_SCOPE_KEY, scriptableObject);
        new ClassCache().associate(scriptableObject);
        BaseFunction.init(scriptableObject, bl);
        NativeObject.init(scriptableObject, bl);
        Scriptable scriptable = ScriptableObject.getObjectPrototype(scriptableObject);
        ScriptableObject.getClassPrototype(scriptableObject, "Function").setPrototype(scriptable);
        if (scriptableObject.getPrototype() == null) {
            scriptableObject.setPrototype(scriptable);
        }
        NativeError.init(scriptableObject, bl);
        NativeGlobal.init(context, scriptableObject, bl);
        NativeArray.init(scriptableObject, bl);
        if (context.getOptimizationLevel() > 0) {
            NativeArray.setMaximumInitialCapacity(200000);
        }
        NativeString.init(scriptableObject, bl);
        NativeBoolean.init(scriptableObject, bl);
        NativeNumber.init(scriptableObject, bl);
        NativeDate.init(scriptableObject, bl);
        NativeMath.init(scriptableObject, bl);
        NativeJSON.init(scriptableObject, bl);
        NativeWith.init(scriptableObject, bl);
        NativeCall.init(scriptableObject, bl);
        NativeScript.init(scriptableObject, bl);
        NativeIterator.init(scriptableObject, bl);
        boolean bl2 = context.hasFeature(6) && context.getE4xImplementationFactory() != null;
        new LazilyLoadedCtor(scriptableObject, "RegExp", "org.mozilla.javascript.regexp.NativeRegExp", bl, true);
        new LazilyLoadedCtor(scriptableObject, "Continuation", "org.mozilla.javascript.NativeContinuation", bl, true);
        if (bl2) {
            String string2 = context.getE4xImplementationFactory().getImplementationClassName();
            new LazilyLoadedCtor(scriptableObject, "XML", string2, bl, true);
            new LazilyLoadedCtor(scriptableObject, "XMLList", string2, bl, true);
            new LazilyLoadedCtor(scriptableObject, "Namespace", string2, bl, true);
            new LazilyLoadedCtor(scriptableObject, "QName", string2, bl, true);
        }
        if (context.getLanguageVersion() >= 180 && context.hasFeature(14) || context.getLanguageVersion() >= 200) {
            new LazilyLoadedCtor(scriptableObject, "ArrayBuffer", "org.mozilla.javascript.typedarrays.NativeArrayBuffer", bl, true);
            new LazilyLoadedCtor(scriptableObject, "Int8Array", "org.mozilla.javascript.typedarrays.NativeInt8Array", bl, true);
            new LazilyLoadedCtor(scriptableObject, "Uint8Array", "org.mozilla.javascript.typedarrays.NativeUint8Array", bl, true);
            new LazilyLoadedCtor(scriptableObject, "Uint8ClampedArray", "org.mozilla.javascript.typedarrays.NativeUint8ClampedArray", bl, true);
            new LazilyLoadedCtor(scriptableObject, "Int16Array", "org.mozilla.javascript.typedarrays.NativeInt16Array", bl, true);
            new LazilyLoadedCtor(scriptableObject, "Uint16Array", "org.mozilla.javascript.typedarrays.NativeUint16Array", bl, true);
            new LazilyLoadedCtor(scriptableObject, "Int32Array", "org.mozilla.javascript.typedarrays.NativeInt32Array", bl, true);
            new LazilyLoadedCtor(scriptableObject, "Uint32Array", "org.mozilla.javascript.typedarrays.NativeUint32Array", bl, true);
            new LazilyLoadedCtor(scriptableObject, "Float32Array", "org.mozilla.javascript.typedarrays.NativeFloat32Array", bl, true);
            new LazilyLoadedCtor(scriptableObject, "Float64Array", "org.mozilla.javascript.typedarrays.NativeFloat64Array", bl, true);
            new LazilyLoadedCtor(scriptableObject, "DataView", "org.mozilla.javascript.typedarrays.NativeDataView", bl, true);
        }
        if (scriptableObject instanceof TopLevel) {
            ((TopLevel)scriptableObject).cacheBuiltins();
        }
        return scriptableObject;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void initScript(NativeFunction nativeFunction, Scriptable scriptable, Context context, Scriptable scriptable2, boolean bl) {
        if (context.topCallScope == null) {
            throw new IllegalStateException();
        }
        int n = nativeFunction.getParamAndVarCount();
        if (n != 0) {
            Scriptable scriptable3 = scriptable2;
            while (scriptable3 instanceof NativeWith) {
                scriptable3 = scriptable3.getParentScope();
            }
            int n2 = n;
            do {
                int n3 = n2 - 1;
                if (n2 == 0) break;
                String string2 = nativeFunction.getParamOrVarName(n3);
                boolean bl2 = nativeFunction.getParamOrVarConst(n3);
                if (!ScriptableObject.hasProperty(scriptable2, string2)) {
                    if (bl2) {
                        ScriptableObject.defineConstProperty(scriptable3, string2);
                    } else if (!bl) {
                        ScriptableObject.defineProperty(scriptable3, string2, Undefined.instance, 4);
                    } else {
                        scriptable3.put(string2, scriptable3, Undefined.instance);
                    }
                } else {
                    ScriptableObject.redefineProperty(scriptable2, string2, bl2);
                }
                n2 = n3;
            } while (true);
        }
    }

    public static ScriptableObject initStandardObjects(Context context, ScriptableObject scriptableObject, boolean bl) {
        ScriptableObject scriptableObject2 = ScriptRuntime.initSafeStandardObjects(context, scriptableObject, bl);
        new LazilyLoadedCtor(scriptableObject2, "Packages", "org.mozilla.javascript.NativeJavaTopPackage", bl, true);
        new LazilyLoadedCtor(scriptableObject2, "getClass", "org.mozilla.javascript.NativeJavaTopPackage", bl, true);
        new LazilyLoadedCtor(scriptableObject2, "JavaAdapter", "org.mozilla.javascript.JavaAdapter", bl, true);
        new LazilyLoadedCtor(scriptableObject2, "JavaImporter", "org.mozilla.javascript.ImporterTopLevel", bl, true);
        String[] arrstring = ScriptRuntime.getTopPackageNames();
        int n = arrstring.length;
        for (int i = 0; i < n; ++i) {
            new LazilyLoadedCtor(scriptableObject2, arrstring[i], "org.mozilla.javascript.NativeJavaTopPackage", bl, true);
        }
        return scriptableObject2;
    }

    public static boolean instanceOf(Object object, Object object2, Context context) {
        if (!(object2 instanceof Scriptable)) {
            throw ScriptRuntime.typeError0("msg.instanceof.not.object");
        }
        if (!(object instanceof Scriptable)) {
            return false;
        }
        return ((Scriptable)object2).hasInstance((Scriptable)object);
    }

    public static boolean isArrayObject(Object object) {
        return object instanceof NativeArray || object instanceof Arguments;
    }

    static boolean isGeneratedScript(String string2) {
        return string2.indexOf("(eval)") >= 0 || string2.indexOf("(Function)") >= 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean isJSLineTerminator(int n) {
        return (57296 & n) == 0 && (n == 10 || n == 13 || n == 8232 || n == 8233);
    }

    public static boolean isJSWhitespaceOrLineTerminator(int n) {
        return ScriptRuntime.isStrWhiteSpaceChar(n) || ScriptRuntime.isJSLineTerminator(n);
    }

    public static boolean isPrimitive(Object object) {
        return object == null || object == Undefined.instance || object instanceof Number || object instanceof String || object instanceof Boolean;
    }

    public static boolean isRhinoRuntimeType(Class<?> class_) {
        boolean bl;
        block5 : {
            block4 : {
                if (class_.isPrimitive()) {
                    return class_ != Character.TYPE;
                }
                if (class_ == StringClass || class_ == BooleanClass || NumberClass.isAssignableFrom(class_)) break block4;
                boolean bl2 = ScriptableClass.isAssignableFrom(class_);
                bl = false;
                if (!bl2) break block5;
            }
            bl = true;
        }
        return bl;
    }

    static boolean isSpecialProperty(String string2) {
        return string2.equals((Object)"__proto__") || string2.equals((Object)"__parent__");
    }

    static boolean isStrWhiteSpaceChar(int n) {
        switch (n) {
            default: {
                if (Character.getType((int)n) != 12) break;
            }
            case 9: 
            case 10: 
            case 11: 
            case 12: 
            case 13: 
            case 32: 
            case 160: 
            case 8232: 
            case 8233: 
            case 65279: {
                return true;
            }
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    static boolean isValidIdentifierName(String string2) {
        int n = string2.length();
        if (n == 0 || !Character.isJavaIdentifierStart((char)string2.charAt(0))) return false;
        for (int i = 1; i != n; ++i) {
            if (!Character.isJavaIdentifierPart((char)string2.charAt(i))) return false;
            {
                continue;
            }
        }
        if (!TokenStream.isKeyword(string2)) return true;
        return false;
    }

    private static boolean isVisible(Context context, Object object) {
        ClassShutter classShutter = context.getClassShutter();
        return classShutter == null || classShutter.visibleToScripts(object.getClass().getName());
    }

    public static boolean jsDelegatesTo(Scriptable scriptable, Scriptable scriptable2) {
        for (Scriptable scriptable3 = scriptable.getPrototype(); scriptable3 != null; scriptable3 = scriptable3.getPrototype()) {
            if (!scriptable3.equals((Object)scriptable2)) continue;
            return true;
        }
        return false;
    }

    static int lastIndexResult(Context context) {
        return context.scratchIndex;
    }

    public static Scriptable lastStoredScriptable(Context context) {
        Scriptable scriptable = context.scratchScriptable;
        context.scratchScriptable = null;
        return scriptable;
    }

    public static long lastUint32Result(Context context) {
        long l = context.scratchUint32;
        if (l >>> 32 != 0L) {
            throw new IllegalStateException();
        }
        return l;
    }

    public static Scriptable leaveDotQuery(Scriptable scriptable) {
        return ((NativeWith)scriptable).getParentScope();
    }

    public static Scriptable leaveWith(Scriptable scriptable) {
        return ((NativeWith)scriptable).getParentScope();
    }

    static String makeUrlForGeneratedScript(boolean bl, String string2, int n) {
        if (bl) {
            return string2 + '#' + n + "(eval)";
        }
        return string2 + '#' + n + "(Function)";
    }

    public static Ref memberRef(Object object, Object object2, Object object3, Context context, int n) {
        if (!(object instanceof XMLObject)) {
            throw ScriptRuntime.notXmlError(object);
        }
        return ((XMLObject)object).memberRef(context, object2, object3, n);
    }

    public static Ref memberRef(Object object, Object object2, Context context, int n) {
        if (!(object instanceof XMLObject)) {
            throw ScriptRuntime.notXmlError(object);
        }
        return ((XMLObject)object).memberRef(context, object2, n);
    }

    public static Object name(Context context, Scriptable scriptable, String string2) {
        Object object;
        Scriptable scriptable2 = scriptable.getParentScope();
        if (scriptable2 == null) {
            object = ScriptRuntime.topScopeName(context, scriptable, string2);
            if (object == Scriptable.NOT_FOUND) {
                throw ScriptRuntime.notFoundError(scriptable, string2);
            }
        } else {
            object = ScriptRuntime.nameOrFunction(context, scriptable, scriptable2, string2, false);
        }
        return object;
    }

    @Deprecated
    public static Object nameIncrDecr(Scriptable scriptable, String string2, int n) {
        return ScriptRuntime.nameIncrDecr(scriptable, string2, Context.getContext(), n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Object nameIncrDecr(Scriptable scriptable, String string2, Context context, int n) {
        do {
            if (context.useDynamicScope && scriptable.getParentScope() == null) {
                scriptable = ScriptRuntime.checkDynamicScope(context.topCallScope, scriptable);
            }
            Scriptable scriptable2 = scriptable;
            while (!(scriptable2 instanceof NativeWith) || !(scriptable2.getPrototype() instanceof XMLObject)) {
                Object object = scriptable2.get(string2, scriptable);
                if (object != Scriptable.NOT_FOUND) {
                    return ScriptRuntime.doScriptableIncrDecr(scriptable2, string2, scriptable, object, n);
                }
                if ((scriptable2 = scriptable2.getPrototype()) != null) continue;
            }
        } while ((scriptable = scriptable.getParentScope()) != null);
        throw ScriptRuntime.notFoundError(scriptable, string2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object nameOrFunction(Context context, Scriptable scriptable, Scriptable scriptable2, String string2, boolean bl) {
        Object object;
        Scriptable scriptable3;
        block17 : {
            scriptable3 = scriptable;
            XMLObject xMLObject = null;
            do {
                if (scriptable instanceof NativeWith) {
                    Scriptable scriptable4 = scriptable.getPrototype();
                    if (scriptable4 instanceof XMLObject) {
                        XMLObject xMLObject2 = (XMLObject)scriptable4;
                        if (xMLObject2.has(string2, xMLObject2)) {
                            scriptable3 = xMLObject2;
                            object = xMLObject2.get(string2, xMLObject2);
                            break block17;
                        }
                        if (xMLObject == null) {
                            xMLObject = xMLObject2;
                        }
                    } else {
                        object = ScriptableObject.getProperty(scriptable4, string2);
                        if (object != Scriptable.NOT_FOUND) {
                            scriptable3 = scriptable4;
                            break block17;
                        }
                    }
                } else if (scriptable instanceof NativeCall) {
                    object = scriptable.get(string2, scriptable);
                    if (object != Scriptable.NOT_FOUND) {
                        if (bl) {
                            scriptable3 = ScriptableObject.getTopLevelScope(scriptable2);
                        }
                        break block17;
                    }
                } else {
                    object = ScriptableObject.getProperty(scriptable, string2);
                    if (object != Scriptable.NOT_FOUND) {
                        scriptable3 = scriptable;
                        break block17;
                    }
                }
                scriptable = scriptable2;
            } while ((scriptable2 = scriptable2.getParentScope()) != null);
            object = ScriptRuntime.topScopeName(context, scriptable, string2);
            if (object == Scriptable.NOT_FOUND) {
                if (xMLObject == null || bl) {
                    throw ScriptRuntime.notFoundError(scriptable, string2);
                }
                object = xMLObject.get(string2, xMLObject);
            }
            scriptable3 = scriptable;
        }
        if (bl) {
            if (!(object instanceof Callable)) {
                throw ScriptRuntime.notFunctionError(object, string2);
            }
            ScriptRuntime.storeScriptable(context, scriptable3);
        }
        return object;
    }

    public static Ref nameRef(Object object, Object object2, Context context, Scriptable scriptable, int n) {
        return ScriptRuntime.currentXMLLib(context).nameRef(context, object, object2, scriptable, n);
    }

    public static Ref nameRef(Object object, Context context, Scriptable scriptable, int n) {
        return ScriptRuntime.currentXMLLib(context).nameRef(context, object, scriptable, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Scriptable newArrayLiteral(Object[] arrobject, int[] arrn, Context context, Scriptable scriptable) {
        int n;
        int n2 = arrobject.length;
        int n3 = 0;
        if (arrn != null) {
            n3 = arrn.length;
        }
        if ((n = n2 + n3) > 1 && n3 * 2 < n) {
            Object[] arrobject2;
            if (n3 != 0) {
            } else {
                arrobject2 = arrobject;
                return context.newArray(scriptable, arrobject2);
            }
            arrobject2 = new Object[n];
            int n4 = 0;
            int n5 = 0;
            int n6 = 0;
            while (n5 != n) {
                if (n4 != n3 && arrn[n4] == n5) {
                    arrobject2[n5] = Scriptable.NOT_FOUND;
                    ++n4;
                } else {
                    arrobject2[n5] = arrobject[n6];
                    ++n6;
                }
                ++n5;
            }
            return context.newArray(scriptable, arrobject2);
        }
        Scriptable scriptable2 = context.newArray(scriptable, n);
        int n7 = 0;
        int n8 = 0;
        int n9 = 0;
        while (n8 != n) {
            if (n7 != n3 && arrn[n7] == n8) {
                ++n7;
            } else {
                ScriptableObject.putProperty(scriptable2, n8, arrobject[n9]);
                ++n9;
            }
            ++n8;
        }
        return scriptable2;
    }

    public static Scriptable newBuiltinObject(Context context, Scriptable scriptable, TopLevel.Builtins builtins, Object[] arrobject) {
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        Function function = TopLevel.getBuiltinCtor(context, scriptable2, builtins);
        if (arrobject == null) {
            arrobject = emptyArgs;
        }
        return function.construct(context, scriptable2, arrobject);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Scriptable newCatchScope(Throwable throwable, Scriptable scriptable, String string2, Context context, Scriptable scriptable2) {
        Object object;
        boolean bl;
        if (throwable instanceof JavaScriptException) {
            bl = false;
            object = ((JavaScriptException)((Object)throwable)).getValue();
        } else {
            bl = true;
            if (scriptable != null) {
                object = ((NativeObject)scriptable).getAssociatedValue((Object)throwable);
                if (object == null) {
                    Kit.codeBug();
                }
            } else {
                String string3;
                String string4;
                int n;
                TopLevel.NativeErrors nativeErrors;
                RhinoException rhinoException;
                Throwable throwable2 = null;
                if (throwable instanceof EcmaError) {
                    EcmaError ecmaError = (EcmaError)((Object)throwable);
                    rhinoException = ecmaError;
                    nativeErrors = TopLevel.NativeErrors.valueOf(ecmaError.getName());
                    string4 = ecmaError.getErrorMessage();
                } else if (throwable instanceof WrappedException) {
                    WrappedException wrappedException = (WrappedException)((Object)throwable);
                    rhinoException = wrappedException;
                    throwable2 = wrappedException.getWrappedException();
                    nativeErrors = TopLevel.NativeErrors.JavaException;
                    string4 = throwable2.getClass().getName() + ": " + throwable2.getMessage();
                } else if (throwable instanceof EvaluatorException) {
                    EvaluatorException evaluatorException = (EvaluatorException)((Object)throwable);
                    rhinoException = evaluatorException;
                    nativeErrors = TopLevel.NativeErrors.InternalError;
                    string4 = evaluatorException.getMessage();
                    throwable2 = null;
                } else {
                    if (!context.hasFeature(13)) {
                        throw Kit.codeBug();
                    }
                    rhinoException = new WrappedException(throwable);
                    nativeErrors = TopLevel.NativeErrors.JavaException;
                    string4 = throwable.toString();
                    throwable2 = null;
                }
                if ((string3 = rhinoException.sourceName()) == null) {
                    string3 = "";
                }
                Object[] arrobject = (n = rhinoException.lineNumber()) > 0 ? new Object[]{string4, string3, n} : new Object[]{string4, string3};
                Scriptable scriptable3 = ScriptRuntime.newNativeError(context, scriptable2, nativeErrors, arrobject);
                if (scriptable3 instanceof NativeError) {
                    ((NativeError)scriptable3).setStackProvider(rhinoException);
                }
                if (throwable2 != null && ScriptRuntime.isVisible(context, (Object)throwable2)) {
                    ScriptableObject.defineProperty(scriptable3, "javaException", context.getWrapFactory().wrap(context, scriptable2, (Object)throwable2, null), 7);
                }
                if (ScriptRuntime.isVisible(context, (Object)rhinoException)) {
                    ScriptableObject.defineProperty(scriptable3, "rhinoException", context.getWrapFactory().wrap(context, scriptable2, (Object)rhinoException, null), 7);
                }
                object = scriptable3;
            }
        }
        NativeObject nativeObject = new NativeObject();
        nativeObject.defineProperty(string2, object, 4);
        if (ScriptRuntime.isVisible(context, (Object)throwable)) {
            nativeObject.defineProperty("__exception__", Context.javaToJS((Object)throwable, scriptable2), 6);
        }
        if (bl) {
            nativeObject.associateValue((Object)throwable, object);
        }
        return nativeObject;
    }

    static Scriptable newNativeError(Context context, Scriptable scriptable, TopLevel.NativeErrors nativeErrors, Object[] arrobject) {
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        Function function = TopLevel.getNativeErrorCtor(context, scriptable2, nativeErrors);
        if (arrobject == null) {
            arrobject = emptyArgs;
        }
        return function.construct(context, scriptable2, arrobject);
    }

    public static Scriptable newObject(Object object, Context context, Scriptable scriptable, Object[] arrobject) {
        if (!(object instanceof Function)) {
            throw ScriptRuntime.notFunctionError(object);
        }
        return ((Function)object).construct(context, scriptable, arrobject);
    }

    public static Scriptable newObject(Context context, Scriptable scriptable, String string2, Object[] arrobject) {
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        Function function = ScriptRuntime.getExistingCtor(context, scriptable2, string2);
        if (arrobject == null) {
            arrobject = emptyArgs;
        }
        return function.construct(context, scriptable2, arrobject);
    }

    @Deprecated
    public static Scriptable newObjectLiteral(Object[] arrobject, Object[] arrobject2, Context context, Scriptable scriptable) {
        return ScriptRuntime.newObjectLiteral(arrobject, arrobject2, null, context, scriptable);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Scriptable newObjectLiteral(Object[] arrobject, Object[] arrobject2, int[] arrn, Context context, Scriptable scriptable) {
        Scriptable scriptable2 = context.newObject(scriptable);
        int n = 0;
        int n2 = arrobject.length;
        while (n != n2) {
            Object object = arrobject[n];
            int n3 = arrn == null ? 0 : arrn[n];
            Object object2 = arrobject2[n];
            if (object instanceof String) {
                if (n3 == 0) {
                    if (ScriptRuntime.isSpecialProperty((String)object)) {
                        ScriptRuntime.specialRef(scriptable2, (String)object, context, scriptable).set(context, scriptable, object2);
                    } else {
                        scriptable2.put((String)object, scriptable2, object2);
                    }
                } else {
                    ScriptableObject scriptableObject = (ScriptableObject)scriptable2;
                    Callable callable = (Callable)object2;
                    boolean bl = n3 == 1;
                    scriptableObject.setGetterOrSetter((String)object, 0, callable, bl);
                }
            } else {
                scriptable2.put((Integer)object, scriptable2, object2);
            }
            ++n;
        }
        return scriptable2;
    }

    public static Object newSpecial(Context context, Object object, Object[] arrobject, Scriptable scriptable, int n) {
        if (n == 1) {
            if (NativeGlobal.isEvalFunction(object)) {
                throw ScriptRuntime.typeError1("msg.not.ctor", "eval");
            }
        } else if (n == 2) {
            if (NativeWith.isWithFunction(object)) {
                return NativeWith.newWithSpecial(context, scriptable, arrobject);
            }
        } else {
            throw Kit.codeBug();
        }
        return ScriptRuntime.newObject(object, context, scriptable, arrobject);
    }

    public static RuntimeException notFoundError(Scriptable scriptable, String string2) {
        throw ScriptRuntime.constructError("ReferenceError", ScriptRuntime.getMessage1("msg.is.not.defined", string2));
    }

    public static RuntimeException notFunctionError(Object object) {
        return ScriptRuntime.notFunctionError(object, object);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static RuntimeException notFunctionError(Object object, Object object2) {
        String string2 = object2 == null ? "null" : object2.toString();
        if (object == Scriptable.NOT_FOUND) {
            return ScriptRuntime.typeError1("msg.function.not.found", string2);
        }
        return ScriptRuntime.typeError2("msg.isnt.function", string2, ScriptRuntime.typeof(object));
    }

    public static RuntimeException notFunctionError(Object object, Object object2, String string2) {
        int n;
        String string3 = ScriptRuntime.toString(object);
        if (object instanceof NativeFunction && (n = string3.indexOf(123, string3.indexOf(41))) > -1) {
            string3 = string3.substring(0, n + 1) + "...}";
        }
        if (object2 == Scriptable.NOT_FOUND) {
            return ScriptRuntime.typeError2("msg.function.not.found.in", string2, string3);
        }
        return ScriptRuntime.typeError3("msg.isnt.function.in", string2, string3, ScriptRuntime.typeof(object2));
    }

    private static RuntimeException notXmlError(Object object) {
        throw ScriptRuntime.typeError1("msg.isnt.xml.object", ScriptRuntime.toString(object));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String numberToString(double d, int n) {
        if (n < 2) throw Context.reportRuntimeError1("msg.bad.radix", Integer.toString((int)n));
        if (n > 36) {
            throw Context.reportRuntimeError1("msg.bad.radix", Integer.toString((int)n));
        }
        if (d != d) {
            return "NaN";
        }
        if (d == Double.POSITIVE_INFINITY) {
            return "Infinity";
        }
        if (d == Double.NEGATIVE_INFINITY) {
            return "-Infinity";
        }
        if (d == 0.0) {
            return "0";
        }
        if (n != 10) {
            return DToA.JS_dtobasestr(n, d);
        }
        String string2 = FastDtoa.numberToString(d);
        if (string2 != null) return string2;
        StringBuilder stringBuilder = new StringBuilder();
        DToA.JS_dtostr(stringBuilder, 0, 0, d);
        return stringBuilder.toString();
    }

    public static Object[] padArguments(Object[] arrobject, int n) {
        int n2;
        if (n < arrobject.length) {
            return arrobject;
        }
        Object[] arrobject2 = new Object[n];
        for (n2 = 0; n2 < arrobject.length; ++n2) {
            arrobject2[n2] = arrobject[n2];
        }
        while (n2 < n) {
            arrobject2[n2] = Undefined.instance;
            ++n2;
        }
        return arrobject2;
    }

    @Deprecated
    public static Object propIncrDecr(Object object, String string2, Context context, int n) {
        return ScriptRuntime.propIncrDecr(object, string2, context, ScriptRuntime.getTopCallScope(context), n);
    }

    public static Object propIncrDecr(Object object, String string2, Context context, Scriptable scriptable, int n) {
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 == null) {
            throw ScriptRuntime.undefReadError(object, string2);
        }
        Scriptable scriptable3 = scriptable2;
        do {
            Object object2;
            if ((object2 = scriptable3.get(string2, scriptable2)) == Scriptable.NOT_FOUND) continue;
            return ScriptRuntime.doScriptableIncrDecr(scriptable3, string2, scriptable2, object2, n);
        } while ((scriptable3 = scriptable3.getPrototype()) != null);
        scriptable2.put(string2, scriptable2, (Object)NaNobj);
        return NaNobj;
    }

    public static EcmaError rangeError(String string2) {
        return ScriptRuntime.constructError("RangeError", string2);
    }

    public static Object refDel(Ref ref, Context context) {
        return ScriptRuntime.wrapBoolean(ref.delete(context));
    }

    public static Object refGet(Ref ref, Context context) {
        return ref.get(context);
    }

    @Deprecated
    public static Object refIncrDecr(Ref ref, Context context, int n) {
        return ScriptRuntime.refIncrDecr(ref, context, ScriptRuntime.getTopCallScope(context), n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Object refIncrDecr(Ref ref, Context context, Scriptable scriptable, int n) {
        double d;
        Object object = ref.get(context);
        boolean bl = (n & 2) != 0;
        if (object instanceof Number) {
            d = ((Number)object).doubleValue();
        } else {
            d = ScriptRuntime.toNumber(object);
            if (bl) {
                object = ScriptRuntime.wrapNumber(d);
            }
        }
        double d2 = (n & 1) == 0 ? d + 1.0 : d - 1.0;
        Number number = ScriptRuntime.wrapNumber(d2);
        ref.set(context, scriptable, (Object)number);
        if (bl) {
            return object;
        }
        return number;
    }

    @Deprecated
    public static Object refSet(Ref ref, Object object, Context context) {
        return ScriptRuntime.refSet(ref, object, context, ScriptRuntime.getTopCallScope(context));
    }

    public static Object refSet(Ref ref, Object object, Context context, Scriptable scriptable) {
        return ref.set(context, scriptable, object);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Scriptable requireObjectCoercible(Scriptable scriptable, IdFunctionObject idFunctionObject) {
        Scriptable scriptable2 = scriptable.getParentScope() != null ? scriptable : null;
        if (scriptable2 != null && scriptable2 != Undefined.instance) {
            return scriptable2;
        }
        throw ScriptRuntime.typeError2("msg.called.null.or.undefined", idFunctionObject.getTag(), idFunctionObject.getFunctionName());
    }

    public static Object searchDefaultNamespace(Context context) {
        Scriptable scriptable = context.currentActivationCall;
        if (scriptable == null) {
            scriptable = ScriptRuntime.getTopCallScope(context);
        }
        do {
            Scriptable scriptable2;
            block9 : {
                Object object;
                block8 : {
                    block7 : {
                        if ((scriptable2 = scriptable.getParentScope()) != null) break block7;
                        object = ScriptableObject.getProperty(scriptable, DEFAULT_NS_TAG);
                        if (object == Scriptable.NOT_FOUND) {
                            return null;
                        }
                        break block8;
                    }
                    object = scriptable.get(DEFAULT_NS_TAG, scriptable);
                    if (object == Scriptable.NOT_FOUND) break block9;
                }
                return object;
            }
            scriptable = scriptable2;
        } while (true);
    }

    public static void setBuiltinProtoAndParent(ScriptableObject scriptableObject, Scriptable scriptable, TopLevel.Builtins builtins) {
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        scriptableObject.setParentScope(scriptable2);
        scriptableObject.setPrototype(TopLevel.getBuiltinPrototype(scriptable2, builtins));
    }

    public static Object setConst(Scriptable scriptable, Object object, Context context, String string2) {
        if (scriptable instanceof XMLObject) {
            scriptable.put(string2, scriptable, object);
            return object;
        }
        ScriptableObject.putConstProperty(scriptable, string2, object);
        return object;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Object setDefaultNamespace(Object object, Context context) {
        Scriptable scriptable = context.currentActivationCall;
        if (scriptable == null) {
            scriptable = ScriptRuntime.getTopCallScope(context);
        }
        Object object2 = ScriptRuntime.currentXMLLib(context).toDefaultXmlNamespace(context, object);
        if (!scriptable.has(DEFAULT_NS_TAG, scriptable)) {
            ScriptableObject.defineProperty(scriptable, DEFAULT_NS_TAG, object2, 6);
            do {
                return Undefined.instance;
                break;
            } while (true);
        }
        scriptable.put(DEFAULT_NS_TAG, scriptable, object2);
        return Undefined.instance;
    }

    public static void setEnumNumbers(Object object, boolean bl) {
        ((IdEnumeration)object).enumNumbers = bl;
    }

    public static void setFunctionProtoAndParent(BaseFunction baseFunction, Scriptable scriptable) {
        baseFunction.setParentScope(scriptable);
        baseFunction.setPrototype(ScriptableObject.getFunctionPrototype(scriptable));
    }

    public static Object setName(Scriptable scriptable, Object object, Context context, Scriptable scriptable2, String string2) {
        if (scriptable != null) {
            ScriptableObject.putProperty(scriptable, string2, object);
            return object;
        }
        if (context.hasFeature(11) || context.hasFeature(8)) {
            Context.reportWarning(ScriptRuntime.getMessage1("msg.assn.create.strict", string2));
        }
        Scriptable scriptable3 = ScriptableObject.getTopLevelScope(scriptable2);
        if (context.useDynamicScope) {
            scriptable3 = ScriptRuntime.checkDynamicScope(context.topCallScope, scriptable3);
        }
        scriptable3.put(string2, scriptable3, object);
        return object;
    }

    @Deprecated
    public static Object setObjectElem(Object object, Object object2, Object object3, Context context) {
        return ScriptRuntime.setObjectElem(object, object2, object3, context, ScriptRuntime.getTopCallScope(context));
    }

    public static Object setObjectElem(Object object, Object object2, Object object3, Context context, Scriptable scriptable) {
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 == null) {
            throw ScriptRuntime.undefWriteError(object, object2, object3);
        }
        return ScriptRuntime.setObjectElem(scriptable2, object2, object3, context);
    }

    public static Object setObjectElem(Scriptable scriptable, Object object, Object object2, Context context) {
        if (scriptable instanceof XMLObject) {
            ((XMLObject)scriptable).put(context, object, object2);
            return object2;
        }
        String string2 = ScriptRuntime.toStringIdOrIndex(context, object);
        if (string2 == null) {
            ScriptableObject.putProperty(scriptable, ScriptRuntime.lastIndexResult(context), object2);
            return object2;
        }
        ScriptableObject.putProperty(scriptable, string2, object2);
        return object2;
    }

    @Deprecated
    public static Object setObjectIndex(Object object, double d, Object object2, Context context) {
        return ScriptRuntime.setObjectIndex(object, d, object2, context, ScriptRuntime.getTopCallScope(context));
    }

    public static Object setObjectIndex(Object object, double d, Object object2, Context context, Scriptable scriptable) {
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 == null) {
            throw ScriptRuntime.undefWriteError(object, String.valueOf((double)d), object2);
        }
        int n = (int)d;
        if ((double)n == d) {
            return ScriptRuntime.setObjectIndex(scriptable2, n, object2, context);
        }
        return ScriptRuntime.setObjectProp(scriptable2, ScriptRuntime.toString(d), object2, context);
    }

    public static Object setObjectIndex(Scriptable scriptable, int n, Object object, Context context) {
        ScriptableObject.putProperty(scriptable, n, object);
        return object;
    }

    @Deprecated
    public static Object setObjectProp(Object object, String string2, Object object2, Context context) {
        return ScriptRuntime.setObjectProp(object, string2, object2, context, ScriptRuntime.getTopCallScope(context));
    }

    public static Object setObjectProp(Object object, String string2, Object object2, Context context, Scriptable scriptable) {
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 == null) {
            throw ScriptRuntime.undefWriteError(object, string2, object2);
        }
        return ScriptRuntime.setObjectProp(scriptable2, string2, object2, context);
    }

    public static Object setObjectProp(Scriptable scriptable, String string2, Object object, Context context) {
        ScriptableObject.putProperty(scriptable, string2, object);
        return object;
    }

    public static void setObjectProtoAndParent(ScriptableObject scriptableObject, Scriptable scriptable) {
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        scriptableObject.setParentScope(scriptable2);
        scriptableObject.setPrototype(ScriptableObject.getClassPrototype(scriptable2, scriptableObject.getClassName()));
    }

    public static void setRegExpProxy(Context context, RegExpProxy regExpProxy) {
        if (regExpProxy == null) {
            throw new IllegalArgumentException();
        }
        context.regExpProxy = regExpProxy;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean shallowEq(Object object, Object object2) {
        if (object == object2) {
            double d;
            if (!(object instanceof Number) || (d = ((Number)object).doubleValue()) == d) return true;
            return false;
        }
        if (object == null || object == Undefined.instance) {
            return false;
        }
        if (object instanceof Number) {
            if (!(object2 instanceof Number)) return false;
            if (((Number)object).doubleValue() == ((Number)object2).doubleValue()) return true;
            return false;
        }
        if (object instanceof CharSequence) {
            if (!(object2 instanceof CharSequence)) return false;
            return object.toString().equals((Object)object2.toString());
        }
        if (object instanceof Boolean) {
            if (!(object2 instanceof Boolean)) return false;
            return object.equals(object2);
        }
        if (object instanceof Scriptable) {
            if (!(object instanceof Wrapper) || !(object2 instanceof Wrapper)) return false;
            if (((Wrapper)object).unwrap() == ((Wrapper)object2).unwrap()) return true;
            return false;
        }
        ScriptRuntime.warnAboutNonJSObject(object);
        if (object != object2) return false;
        return true;
    }

    @Deprecated
    public static Ref specialRef(Object object, String string2, Context context) {
        return ScriptRuntime.specialRef(object, string2, context, ScriptRuntime.getTopCallScope(context));
    }

    public static Ref specialRef(Object object, String string2, Context context, Scriptable scriptable) {
        return SpecialRef.createSpecial(context, scriptable, object, string2);
    }

    private static void storeIndexResult(Context context, int n) {
        context.scratchIndex = n;
    }

    private static void storeScriptable(Context context, Scriptable scriptable) {
        if (context.scratchScriptable != null) {
            throw new IllegalStateException();
        }
        context.scratchScriptable = scriptable;
    }

    public static void storeUint32Result(Context context, long l) {
        if (l >>> 32 != 0L) {
            throw new IllegalArgumentException();
        }
        context.scratchUint32 = l;
    }

    public static Object strictSetName(Scriptable scriptable, Object object, Context context, Scriptable scriptable2, String string2) {
        if (scriptable != null) {
            ScriptableObject.putProperty(scriptable, string2, object);
            return object;
        }
        throw ScriptRuntime.constructError("ReferenceError", "Assignment to undefined \"" + string2 + "\" in strict mode");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static double stringToNumber(String var0, int var1_1, int var2_2) {
        var3_3 = '9';
        var4_4 = 'a';
        var5_5 = 'A';
        var6_6 = var0.length();
        if (var2_2 < 10) {
            var3_3 = (char)(-1 + (var2_2 + 48));
        }
        if (var2_2 > 10) {
            var4_4 = (char)(-10 + (var2_2 + 97));
            var5_5 = (char)(-10 + (var2_2 + 65));
        }
        var7_7 = 0.0;
        for (var9_8 = var1_1; var9_8 < var6_6; ++var9_8) {
            var30_9 = var0.charAt(var9_8);
            if ('0' <= var30_9 && var30_9 <= var3_3) {
                var31_10 = var30_9 - 48;
            } else if ('a' <= var30_9 && var30_9 < var4_4) {
                var31_10 = 10 + (var30_9 - 97);
            } else {
                if ('A' > var30_9 || var30_9 >= var5_5) break;
                var31_10 = 10 + (var30_9 - 65);
            }
            var7_7 = var7_7 * (double)var2_2 + (double)var31_10;
        }
        if (var1_1 == var9_8) {
            return ScriptRuntime.NaN;
        }
        if (!(var7_7 >= 9.007199254740992E15)) return var7_7;
        if (var2_2 == 10) {
            try {
                return Double.parseDouble((String)var0.substring(var1_1, var9_8));
            }
            catch (NumberFormatException var27_12) {
                return ScriptRuntime.NaN;
            }
        }
        if (var2_2 != 2 && var2_2 != 4 && var2_2 != 8 && var2_2 != 16) {
            if (var2_2 != 32) return var7_7;
        }
        var10_13 = 1;
        var11_14 = 0;
        var12_15 = 0;
        var13_16 = 53;
        var14_17 = 0.0;
        var16_18 = false;
        var17_19 = false;
        var18_20 = var1_1;
        do {
            block31 : {
                block30 : {
                    block29 : {
                        if (var10_13 != true) break block29;
                        if (var18_20 != var9_8) ** GOTO lbl47
                        switch (var12_15) {
                            default: {
                                return var7_7;
                            }
lbl47: // 1 sources:
                            var19_21 = var18_20 + 1;
                            var21_23 = var0.charAt(var18_20);
                            var11_14 = '0' <= var21_23 && var21_23 <= '9' ? var21_23 - 48 : ('a' <= var21_23 && var21_23 <= 'z' ? var21_23 - 87 : var21_23 - 55);
                            var10_13 = var2_2;
                            break block30;
                            case 0: {
                                return 0.0;
                            }
                            case 1: 
                            case 2: {
                                return var7_7;
                            }
                            case 3: {
                                if (!(var17_19 & var16_18)) return var7_7 *= var14_17;
                                var7_7 += 1.0;
                                return var7_7 *= var14_17;
                            }
                            case 4: 
                        }
                        if (!var17_19) return var7_7 *= var14_17;
                        var7_7 += 1.0;
                        return var7_7 *= var14_17;
                    }
                    var19_21 = var18_20;
                }
                var20_22 = (var11_14 & (var10_13 >>= 1)) != 0;
                switch (var12_15) {
                    case 0: {
                        if (var20_22) {
                            --var13_16;
                            var7_7 = 1.0;
                            var12_15 = 1;
                            ** break;
                        }
                        ** GOTO lbl89
                    }
                    case 1: {
                        var7_7 *= 2.0;
                        if (var20_22) {
                            var7_7 += 1.0;
                        }
                        if (--var13_16 == 0) {
                            var16_18 = var20_22;
                            var12_15 = 2;
                            ** break;
                        }
                        ** GOTO lbl89
                    }
                    case 2: {
                        var17_19 = var20_22;
                        var14_17 = 2.0;
                        var12_15 = 3;
                    }
lbl89: // 6 sources:
                    default: {
                        break block31;
                    }
                    case 3: {
                        if (!var20_22) break;
                        var12_15 = 4;
                    }
                    case 4: 
                }
                var14_17 *= 2.0;
            }
            var18_20 = var19_21;
        } while (true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static long testUint32String(String string2) {
        long l = 0L;
        long l2 = -1L;
        int n = string2.length();
        if (1 > n) return l2;
        if (n > 10) return l2;
        int n2 = -48 + string2.charAt(0);
        if (n2 == 0) {
            if (n != 1) return l2;
            return l;
        }
        if (1 > n2) return l2;
        if (n2 > 9) return l2;
        long l3 = n2;
        for (int i = 1; i != n; ++i) {
            int n3 = -48 + string2.charAt(i);
            if (n3 < 0) return l2;
            if (n3 > 9) return l2;
            l3 = 10L * l3 + (long)n3;
        }
        if (l3 >>> 32 != l) return l2;
        return l3;
    }

    public static JavaScriptException throwCustomError(Context context, Scriptable scriptable, String string2, String string3) {
        int[] arrn = new int[]{0};
        String string4 = Context.getSourcePositionFromStack(arrn);
        Object[] arrobject = new Object[]{string3, string4, arrn[0]};
        return new JavaScriptException(context.newObject(scriptable, string2, arrobject), string4, arrn[0]);
    }

    public static JavaScriptException throwError(Context context, Scriptable scriptable, String string2) {
        int[] arrn = new int[]{0};
        String string3 = Context.getSourcePositionFromStack(arrn);
        TopLevel.Builtins builtins = TopLevel.Builtins.Error;
        Object[] arrobject = new Object[]{string2, string3, arrn[0]};
        return new JavaScriptException(ScriptRuntime.newBuiltinObject(context, scriptable, builtins, arrobject), string3, arrn[0]);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean toBoolean(Object object) {
        boolean bl;
        block6 : {
            bl = true;
            do {
                if (object instanceof Boolean) {
                    return (Boolean)object;
                }
                if (object == null) return false;
                if (object == Undefined.instance) {
                    return false;
                }
                if (object instanceof CharSequence) {
                    if (((CharSequence)object).length() == 0) return false;
                    return bl;
                }
                if (object instanceof Number) {
                    double d = ((Number)object).doubleValue();
                    if (d != d) return false;
                    if (d != 0.0) return bl;
                    return false;
                }
                if (!(object instanceof Scriptable)) break block6;
                if (object instanceof ScriptableObject && ((ScriptableObject)object).avoidObjectDetection()) {
                    return false;
                }
                if (Context.getContext().isVersionECMA1()) return bl;
            } while (!((object = ((Scriptable)object).getDefaultValue(BooleanClass)) instanceof Scriptable));
            throw ScriptRuntime.errorWithClassName("msg.primitive.expected", object);
        }
        ScriptRuntime.warnAboutNonJSObject(object);
        return bl;
    }

    public static CharSequence toCharSequence(Object object) {
        if (object instanceof NativeString) {
            return ((NativeString)object).toCharSequence();
        }
        if (object instanceof CharSequence) {
            return (CharSequence)object;
        }
        return ScriptRuntime.toString(object);
    }

    public static int toInt32(double d) {
        return DoubleConversion.doubleToInt32(d);
    }

    public static int toInt32(Object object) {
        if (object instanceof Integer) {
            return (Integer)object;
        }
        return ScriptRuntime.toInt32(ScriptRuntime.toNumber(object));
    }

    public static int toInt32(Object[] arrobject, int n) {
        if (n < arrobject.length) {
            return ScriptRuntime.toInt32(arrobject[n]);
        }
        return 0;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static double toInteger(double d) {
        if (d != d) {
            return 0.0;
        }
        if (d == 0.0) return d;
        if (d == Double.POSITIVE_INFINITY) return d;
        if (d == Double.NEGATIVE_INFINITY) return d;
        if (!(d > 0.0)) return Math.ceil((double)d);
        return Math.floor((double)d);
    }

    public static double toInteger(Object object) {
        return ScriptRuntime.toInteger(ScriptRuntime.toNumber(object));
    }

    public static double toInteger(Object[] arrobject, int n) {
        if (n < arrobject.length) {
            return ScriptRuntime.toInteger(arrobject[n]);
        }
        return 0.0;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Scriptable toIterator(Context context, Scriptable scriptable, Scriptable scriptable2, boolean bl) {
        if (!ScriptableObject.hasProperty(scriptable2, "__iterator__")) {
            return null;
        }
        Object object = ScriptableObject.getProperty(scriptable2, "__iterator__");
        if (!(object instanceof Callable)) {
            throw ScriptRuntime.typeError0("msg.invalid.iterator");
        }
        Callable callable = (Callable)object;
        Object[] arrobject = new Object[1];
        Boolean bl2 = bl ? Boolean.TRUE : Boolean.FALSE;
        arrobject[0] = bl2;
        Object object2 = callable.call(context, scriptable, scriptable2, arrobject);
        if (!(object2 instanceof Scriptable)) {
            throw ScriptRuntime.typeError0("msg.iterator.primitive");
        }
        return (Scriptable)object2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static double toNumber(Object object) {
        block6 : {
            double d = 0.0;
            do {
                if (object instanceof Number) {
                    return ((Number)object).doubleValue();
                }
                if (object == null) return d;
                if (object == Undefined.instance) {
                    return NaN;
                }
                if (object instanceof String) {
                    return ScriptRuntime.toNumber((String)object);
                }
                if (object instanceof CharSequence) {
                    return ScriptRuntime.toNumber(object.toString());
                }
                if (object instanceof Boolean) {
                    if ((Boolean)object == false) return d;
                    return 1.0;
                }
                if (!(object instanceof Scriptable)) break block6;
            } while (!((object = ((Scriptable)object).getDefaultValue(NumberClass)) instanceof Scriptable));
            throw ScriptRuntime.errorWithClassName("msg.primitive.expected", object);
        }
        ScriptRuntime.warnAboutNonJSObject(object);
        return NaN;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static double toNumber(String string2) {
        int n;
        char c;
        int n2;
        char c2;
        block12 : {
            char c3;
            n2 = string2.length();
            n = 0;
            do {
                if (n == n2) {
                    return 0.0;
                }
                c2 = string2.charAt(n);
                if (!ScriptRuntime.isStrWhiteSpaceChar(c2)) {
                    if (c2 != '0') break;
                    if (n + 2 < n2) {
                        char c4 = string2.charAt(n + 1);
                        if (c4 == 'x') return ScriptRuntime.stringToNumber(string2, n + 2, 16);
                        if (c4 == 'X') {
                            return ScriptRuntime.stringToNumber(string2, n + 2, 16);
                        }
                    }
                    break block12;
                }
                ++n;
            } while (true);
            if (!(c2 != '+' && c2 != '-' || n + 3 >= n2 || string2.charAt(n + 1) != '0' || (c3 = string2.charAt(n + 2)) != 'x' && c3 != 'X')) {
                double d = ScriptRuntime.stringToNumber(string2, n + 3, 16);
                if (c2 != '-') return d;
                return -d;
            }
        }
        int n3 = n2 - 1;
        while (ScriptRuntime.isStrWhiteSpaceChar(c = string2.charAt(n3))) {
            --n3;
        }
        if (c == 'y') {
            if (c2 == '+' || c2 == '-') {
                ++n;
            }
            if (n + 7 != n3) return NaN;
            if (!string2.regionMatches(n, "Infinity", 0, 8)) return NaN;
            if (c2 != '-') return Double.POSITIVE_INFINITY;
            return Double.NEGATIVE_INFINITY;
        }
        String string3 = string2.substring(n, n3 + 1);
        for (int i = -1 + string3.length(); i >= 0; --i) {
            char c5 = string3.charAt(i);
            if ('0' <= c5 && c5 <= '9' || c5 == '.' || c5 == 'e' || c5 == 'E' || c5 == '+') continue;
            if (c5 != '-') return NaN;
        }
        try {
            return Double.parseDouble((String)string3);
        }
        catch (NumberFormatException numberFormatException) {
            return NaN;
        }
    }

    public static double toNumber(Object[] arrobject, int n) {
        if (n < arrobject.length) {
            return ScriptRuntime.toNumber(arrobject[n]);
        }
        return NaN;
    }

    public static Scriptable toObject(Context context, Scriptable scriptable, Object object) {
        if (object instanceof Scriptable) {
            return (Scriptable)object;
        }
        if (object instanceof CharSequence) {
            NativeString nativeString = new NativeString((CharSequence)object);
            ScriptRuntime.setBuiltinProtoAndParent(nativeString, scriptable, TopLevel.Builtins.String);
            return nativeString;
        }
        if (object instanceof Number) {
            NativeNumber nativeNumber = new NativeNumber(((Number)object).doubleValue());
            ScriptRuntime.setBuiltinProtoAndParent(nativeNumber, scriptable, TopLevel.Builtins.Number);
            return nativeNumber;
        }
        if (object instanceof Boolean) {
            NativeBoolean nativeBoolean = new NativeBoolean((Boolean)object);
            ScriptRuntime.setBuiltinProtoAndParent(nativeBoolean, scriptable, TopLevel.Builtins.Boolean);
            return nativeBoolean;
        }
        if (object == null) {
            throw ScriptRuntime.typeError0("msg.null.to.object");
        }
        if (object == Undefined.instance) {
            throw ScriptRuntime.typeError0("msg.undef.to.object");
        }
        Object object2 = context.getWrapFactory().wrap(context, scriptable, object, null);
        if (object2 instanceof Scriptable) {
            return (Scriptable)object2;
        }
        throw ScriptRuntime.errorWithClassName("msg.invalid.type", object);
    }

    @Deprecated
    public static Scriptable toObject(Context context, Scriptable scriptable, Object object, Class<?> class_) {
        return ScriptRuntime.toObject(context, scriptable, object);
    }

    public static Scriptable toObject(Scriptable scriptable, Object object) {
        if (object instanceof Scriptable) {
            return (Scriptable)object;
        }
        return ScriptRuntime.toObject(Context.getContext(), scriptable, object);
    }

    @Deprecated
    public static Scriptable toObject(Scriptable scriptable, Object object, Class<?> class_) {
        if (object instanceof Scriptable) {
            return (Scriptable)object;
        }
        return ScriptRuntime.toObject(Context.getContext(), scriptable, object);
    }

    @Deprecated
    public static Scriptable toObjectOrNull(Context context, Object object) {
        if (object instanceof Scriptable) {
            return (Scriptable)object;
        }
        if (object != null && object != Undefined.instance) {
            return ScriptRuntime.toObject(context, ScriptRuntime.getTopCallScope(context), object);
        }
        return null;
    }

    public static Scriptable toObjectOrNull(Context context, Object object, Scriptable scriptable) {
        if (object instanceof Scriptable) {
            return (Scriptable)object;
        }
        if (object != null && object != Undefined.instance) {
            return ScriptRuntime.toObject(context, scriptable, object);
        }
        return null;
    }

    public static Object toPrimitive(Object object) {
        return ScriptRuntime.toPrimitive(object, null);
    }

    public static Object toPrimitive(Object object, Class<?> class_) {
        if (!(object instanceof Scriptable)) {
            return object;
        }
        Object object2 = ((Scriptable)object).getDefaultValue(class_);
        if (object2 instanceof Scriptable) {
            throw ScriptRuntime.typeError0("msg.bad.default.value");
        }
        return object2;
    }

    public static String toString(double d) {
        return ScriptRuntime.numberToString(d, 10);
    }

    public static String toString(Object object) {
        block6 : {
            do {
                if (object == null) {
                    return "null";
                }
                if (object == Undefined.instance) {
                    return "undefined";
                }
                if (object instanceof String) {
                    return (String)object;
                }
                if (object instanceof CharSequence) {
                    return object.toString();
                }
                if (object instanceof Number) {
                    return ScriptRuntime.numberToString(((Number)object).doubleValue(), 10);
                }
                if (!(object instanceof Scriptable)) break block6;
            } while (!((object = ((Scriptable)object).getDefaultValue(StringClass)) instanceof Scriptable));
            throw ScriptRuntime.errorWithClassName("msg.primitive.expected", object);
        }
        return object.toString();
    }

    public static String toString(Object[] arrobject, int n) {
        if (n < arrobject.length) {
            return ScriptRuntime.toString(arrobject[n]);
        }
        return "undefined";
    }

    /*
     * Enabled aggressive block sorting
     */
    static String toStringIdOrIndex(Context context, Object object) {
        if (object instanceof Number) {
            double d = ((Number)object).doubleValue();
            int n = (int)d;
            if ((double)n != d) {
                return ScriptRuntime.toString(object);
            }
            ScriptRuntime.storeIndexResult(context, n);
            return null;
        }
        String string2 = object instanceof String ? (String)object : ScriptRuntime.toString(object);
        long l = ScriptRuntime.indexFromString(string2);
        if (l < 0L) return string2;
        ScriptRuntime.storeIndexResult(context, (int)l);
        return null;
    }

    public static char toUint16(Object object) {
        return (char)DoubleConversion.doubleToInt32(ScriptRuntime.toNumber(object));
    }

    public static long toUint32(double d) {
        return 0xFFFFFFFFL & (long)DoubleConversion.doubleToInt32(d);
    }

    public static long toUint32(Object object) {
        return ScriptRuntime.toUint32(ScriptRuntime.toNumber(object));
    }

    private static Object topScopeName(Context context, Scriptable scriptable, String string2) {
        if (context.useDynamicScope) {
            scriptable = ScriptRuntime.checkDynamicScope(context.topCallScope, scriptable);
        }
        return ScriptableObject.getProperty(scriptable, string2);
    }

    public static EcmaError typeError(String string2) {
        return ScriptRuntime.constructError("TypeError", string2);
    }

    public static EcmaError typeError0(String string2) {
        return ScriptRuntime.typeError(ScriptRuntime.getMessage0(string2));
    }

    public static EcmaError typeError1(String string2, Object object) {
        return ScriptRuntime.typeError(ScriptRuntime.getMessage1(string2, object));
    }

    public static EcmaError typeError2(String string2, Object object, Object object2) {
        return ScriptRuntime.typeError(ScriptRuntime.getMessage2(string2, object, object2));
    }

    public static EcmaError typeError3(String string2, String string3, String string4, String string5) {
        return ScriptRuntime.typeError(ScriptRuntime.getMessage3(string2, string3, string4, string5));
    }

    @Deprecated
    public static BaseFunction typeErrorThrower() {
        return ScriptRuntime.typeErrorThrower(Context.getCurrentContext());
    }

    public static BaseFunction typeErrorThrower(Context context) {
        if (context.typeErrorThrower == null) {
            BaseFunction baseFunction = new BaseFunction(){
                static final long serialVersionUID = -5891740962154902286L;

                @Override
                public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
                    throw ScriptRuntime.typeError0("msg.op.not.allowed");
                }

                @Override
                public int getLength() {
                    return 0;
                }
            };
            ScriptRuntime.setFunctionProtoAndParent(baseFunction, context.topCallScope);
            baseFunction.preventExtensions();
            context.typeErrorThrower = baseFunction;
        }
        return context.typeErrorThrower;
    }

    public static String typeof(Object object) {
        if (object == null) {
            return "object";
        }
        if (object == Undefined.instance) {
            return "undefined";
        }
        if (object instanceof ScriptableObject) {
            return ((ScriptableObject)object).getTypeOf();
        }
        if (object instanceof Scriptable) {
            if (object instanceof Callable) {
                return "function";
            }
            return "object";
        }
        if (object instanceof CharSequence) {
            return "string";
        }
        if (object instanceof Number) {
            return "number";
        }
        if (object instanceof Boolean) {
            return "boolean";
        }
        throw ScriptRuntime.errorWithClassName("msg.invalid.type", object);
    }

    public static String typeofName(Scriptable scriptable, String string2) {
        Context context = Context.getContext();
        Scriptable scriptable2 = ScriptRuntime.bind(context, scriptable, string2);
        if (scriptable2 == null) {
            return "undefined";
        }
        return ScriptRuntime.typeof(ScriptRuntime.getObjectProp(scriptable2, string2, context));
    }

    public static RuntimeException undefCallError(Object object, Object object2) {
        return ScriptRuntime.typeError2("msg.undef.method.call", ScriptRuntime.toString(object), ScriptRuntime.toString(object2));
    }

    private static RuntimeException undefDeleteError(Object object, Object object2) {
        throw ScriptRuntime.typeError2("msg.undef.prop.delete", ScriptRuntime.toString(object), ScriptRuntime.toString(object2));
    }

    public static RuntimeException undefReadError(Object object, Object object2) {
        return ScriptRuntime.typeError2("msg.undef.prop.read", ScriptRuntime.toString(object), ScriptRuntime.toString(object2));
    }

    public static RuntimeException undefWriteError(Object object, Object object2, Object object3) {
        return ScriptRuntime.typeError3("msg.undef.prop.write", ScriptRuntime.toString(object), ScriptRuntime.toString(object2), ScriptRuntime.toString(object3));
    }

    static String uneval(Context context, Scriptable scriptable, Object object) {
        if (object == null) {
            return "null";
        }
        if (object == Undefined.instance) {
            return "undefined";
        }
        if (object instanceof CharSequence) {
            String string2 = ScriptRuntime.escapeString(object.toString());
            StringBuilder stringBuilder = new StringBuilder(2 + string2.length());
            stringBuilder.append('\"');
            stringBuilder.append(string2);
            stringBuilder.append('\"');
            return stringBuilder.toString();
        }
        if (object instanceof Number) {
            double d = ((Number)object).doubleValue();
            if (d == 0.0 && 1.0 / d < 0.0) {
                return "-0";
            }
            return ScriptRuntime.toString(d);
        }
        if (object instanceof Boolean) {
            return ScriptRuntime.toString(object);
        }
        if (object instanceof Scriptable) {
            Object object2;
            Scriptable scriptable2 = (Scriptable)object;
            if (ScriptableObject.hasProperty(scriptable2, "toSource") && (object2 = ScriptableObject.getProperty(scriptable2, "toSource")) instanceof Function) {
                return ScriptRuntime.toString(((Function)object2).call(context, scriptable, scriptable2, emptyArgs));
            }
            return ScriptRuntime.toString(object);
        }
        ScriptRuntime.warnAboutNonJSObject(object);
        return object.toString();
    }

    public static Object updateDotQuery(boolean bl, Scriptable scriptable) {
        return ((NativeWith)scriptable).updateDotQuery(bl);
    }

    private static void warnAboutNonJSObject(Object object) {
        String string2 = "RHINO USAGE WARNING: Missed Context.javaToJS() conversion:\nRhino runtime detected object " + object + " of class " + object.getClass().getName() + " where it expected String, Number, Boolean or Scriptable instance. Please check your code for missing Context.javaToJS() call.";
        Context.reportWarning(string2);
        System.err.println(string2);
    }

    public static Boolean wrapBoolean(boolean bl) {
        if (bl) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Scriptable wrapException(Throwable throwable, Scriptable scriptable, Context context) {
        String string2;
        String string3;
        int n;
        RhinoException rhinoException;
        String string4;
        Throwable throwable2 = null;
        if (throwable instanceof EcmaError) {
            EcmaError ecmaError = (EcmaError)((Object)throwable);
            rhinoException = ecmaError;
            string3 = ecmaError.getName();
            string2 = ecmaError.getErrorMessage();
        } else if (throwable instanceof WrappedException) {
            WrappedException wrappedException = (WrappedException)((Object)throwable);
            rhinoException = wrappedException;
            throwable2 = wrappedException.getWrappedException();
            string3 = "JavaException";
            string2 = throwable2.getClass().getName() + ": " + throwable2.getMessage();
        } else if (throwable instanceof EvaluatorException) {
            EvaluatorException evaluatorException = (EvaluatorException)((Object)throwable);
            rhinoException = evaluatorException;
            string3 = "InternalError";
            string2 = evaluatorException.getMessage();
            throwable2 = null;
        } else {
            if (!context.hasFeature(13)) {
                throw Kit.codeBug();
            }
            rhinoException = new WrappedException(throwable);
            string3 = "JavaException";
            string2 = throwable.toString();
            throwable2 = null;
        }
        if ((string4 = rhinoException.sourceName()) == null) {
            string4 = "";
        }
        Object[] arrobject = (n = rhinoException.lineNumber()) > 0 ? new Object[]{string2, string4, n} : new Object[]{string2, string4};
        Scriptable scriptable2 = context.newObject(scriptable, string3, arrobject);
        ScriptableObject.putProperty(scriptable2, "name", (Object)string3);
        if (scriptable2 instanceof NativeError) {
            ((NativeError)scriptable2).setStackProvider(rhinoException);
        }
        if (throwable2 != null && ScriptRuntime.isVisible(context, (Object)throwable2)) {
            ScriptableObject.defineProperty(scriptable2, "javaException", context.getWrapFactory().wrap(context, scriptable, (Object)throwable2, null), 7);
        }
        if (ScriptRuntime.isVisible(context, (Object)rhinoException)) {
            ScriptableObject.defineProperty(scriptable2, "rhinoException", context.getWrapFactory().wrap(context, scriptable, (Object)rhinoException, null), 7);
        }
        return scriptable2;
    }

    public static Integer wrapInt(int n) {
        return n;
    }

    public static Number wrapNumber(double d) {
        if (d != d) {
            return NaNobj;
        }
        return new Double(d);
    }

    public static Scriptable wrapRegExp(Context context, Scriptable scriptable, Object object) {
        return context.getRegExpProxy().wrapRegExp(context, scriptable, object);
    }

    private static class DefaultMessageProvider
    implements MessageProvider {
        private DefaultMessageProvider() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public String getMessage(String string2, Object[] arrobject) {
            String string3;
            Context context = Context.getCurrentContext();
            Locale locale = context != null ? context.getLocale() : Locale.getDefault();
            ResourceBundle resourceBundle = ResourceBundle.getBundle((String)"org.mozilla.javascript.resources.Messages", (Locale)locale);
            try {
                string3 = resourceBundle.getString(string2);
            }
            catch (MissingResourceException missingResourceException) {
                throw new RuntimeException("no message resource found for message property " + string2);
            }
            return new MessageFormat(string3).format((Object)arrobject);
        }
    }

    private static class IdEnumeration
    implements Serializable {
        private static final long serialVersionUID = 1L;
        Object currentId;
        boolean enumNumbers;
        int enumType;
        Object[] ids;
        int index;
        Scriptable iterator;
        Scriptable obj;
        ObjToIntMap used;

        private IdEnumeration() {
        }
    }

    public static interface MessageProvider {
        public String getMessage(String var1, Object[] var2);
    }

    static class NoSuchMethodShim
    implements Callable {
        String methodName;
        Callable noSuchMethodMethod;

        NoSuchMethodShim(Callable callable, String string2) {
            this.noSuchMethodMethod = callable;
            this.methodName = string2;
        }

        @Override
        public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
            Object[] arrobject2 = new Object[]{this.methodName, ScriptRuntime.newArrayLiteral(arrobject, null, context, scriptable)};
            return this.noSuchMethodMethod.call(context, scriptable, scriptable2, arrobject2);
        }
    }

}

