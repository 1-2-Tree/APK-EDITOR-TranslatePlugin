/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.ScriptStackElement;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;

public class NativeCallSite
extends IdScriptableObject {
    private static final String CALLSITE_TAG = "CallSite";
    private static final int Id_constructor = 1;
    private static final int Id_getColumnNumber = 9;
    private static final int Id_getEvalOrigin = 10;
    private static final int Id_getFileName = 7;
    private static final int Id_getFunction = 4;
    private static final int Id_getFunctionName = 5;
    private static final int Id_getLineNumber = 8;
    private static final int Id_getMethodName = 6;
    private static final int Id_getThis = 2;
    private static final int Id_getTypeName = 3;
    private static final int Id_isConstructor = 14;
    private static final int Id_isEval = 12;
    private static final int Id_isNative = 13;
    private static final int Id_isToplevel = 11;
    private static final int Id_toString = 15;
    private static final int MAX_PROTOTYPE_ID = 15;
    private ScriptStackElement element;

    private NativeCallSite() {
    }

    private Object getFalse() {
        return Boolean.FALSE;
    }

    private Object getFileName(Scriptable scriptable) {
        while (scriptable != null && !(scriptable instanceof NativeCallSite)) {
            scriptable = scriptable.getPrototype();
        }
        if (scriptable == null) {
            return NOT_FOUND;
        }
        NativeCallSite nativeCallSite = (NativeCallSite)scriptable;
        if (nativeCallSite.element == null) {
            return null;
        }
        return nativeCallSite.element.fileName;
    }

    private Object getFunctionName(Scriptable scriptable) {
        while (scriptable != null && !(scriptable instanceof NativeCallSite)) {
            scriptable = scriptable.getPrototype();
        }
        if (scriptable == null) {
            return NOT_FOUND;
        }
        NativeCallSite nativeCallSite = (NativeCallSite)scriptable;
        if (nativeCallSite.element == null) {
            return null;
        }
        return nativeCallSite.element.functionName;
    }

    private Object getLineNumber(Scriptable scriptable) {
        while (scriptable != null && !(scriptable instanceof NativeCallSite)) {
            scriptable = scriptable.getPrototype();
        }
        if (scriptable == null) {
            return NOT_FOUND;
        }
        NativeCallSite nativeCallSite = (NativeCallSite)scriptable;
        if (nativeCallSite.element == null || nativeCallSite.element.lineNumber < 0) {
            return Undefined.instance;
        }
        return nativeCallSite.element.lineNumber;
    }

    private Object getNull() {
        return null;
    }

    private Object getUndefined() {
        return Undefined.instance;
    }

    static void init(Scriptable scriptable, boolean bl) {
        new NativeCallSite().exportAsJSClass(15, scriptable, bl);
    }

    private Object js_toString(Scriptable scriptable) {
        while (scriptable != null && !(scriptable instanceof NativeCallSite)) {
            scriptable = scriptable.getPrototype();
        }
        if (scriptable == null) {
            return NOT_FOUND;
        }
        NativeCallSite nativeCallSite = (NativeCallSite)scriptable;
        StringBuilder stringBuilder = new StringBuilder();
        nativeCallSite.element.renderJavaStyle(stringBuilder);
        return stringBuilder.toString();
    }

    static NativeCallSite make(Scriptable scriptable, Scriptable scriptable2) {
        NativeCallSite nativeCallSite = new NativeCallSite();
        Scriptable scriptable3 = (Scriptable)scriptable2.get("prototype", scriptable2);
        nativeCallSite.setParentScope(scriptable);
        nativeCallSite.setPrototype(scriptable3);
        return nativeCallSite;
    }

    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(CALLSITE_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                return NativeCallSite.make(scriptable, idFunctionObject);
            }
            case 5: {
                return this.getFunctionName(scriptable2);
            }
            case 7: {
                return this.getFileName(scriptable2);
            }
            case 8: {
                return this.getLineNumber(scriptable2);
            }
            case 2: 
            case 3: 
            case 4: 
            case 9: {
                return this.getUndefined();
            }
            case 6: {
                return this.getNull();
            }
            case 10: 
            case 12: 
            case 14: {
                return this.getFalse();
            }
            case 15: 
        }
        return this.js_toString(scriptable2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        block0 : switch (n) {
            case 6: {
                string3 = "isEval";
                n2 = 12;
                break;
            }
            case 7: {
                string3 = "getThis";
                n2 = 2;
                break;
            }
            case 8: {
                char c = string2.charAt(0);
                if (c == 'i') {
                    string3 = "isNative";
                    n2 = 13;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "toString";
                n2 = 15;
                break;
            }
            case 10: {
                string3 = "isToplevel";
                n2 = 11;
                break;
            }
            case 11: {
                switch (string2.charAt(4)) {
                    default: {
                        return 0;
                    }
                    case 'i': {
                        string3 = "getFileName";
                        n2 = 7;
                        break block0;
                    }
                    case 't': {
                        string3 = "constructor";
                        n2 = 1;
                        break block0;
                    }
                    case 'u': {
                        string3 = "getFunction";
                        n2 = 4;
                        break block0;
                    }
                    case 'y': 
                }
                string3 = "getTypeName";
                n2 = 3;
                break;
            }
            case 13: {
                switch (string2.charAt(3)) {
                    default: {
                        return 0;
                    }
                    case 'E': {
                        string3 = "getEvalOrigin";
                        n2 = 10;
                        break block0;
                    }
                    case 'L': {
                        string3 = "getLineNumber";
                        n2 = 8;
                        break block0;
                    }
                    case 'M': {
                        string3 = "getMethodName";
                        n2 = 6;
                        break block0;
                    }
                    case 'o': 
                }
                string3 = "isConstructor";
                n2 = 14;
                break;
            }
            case 15: {
                char c = string2.charAt(3);
                if (c == 'C') {
                    string3 = "getColumnNumber";
                    n2 = 9;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'F') break;
                string3 = "getFunctionName";
                n2 = 5;
                break;
            }
        }
        if (string3 == null) return n2;
        if (string3 == string2) return n2;
        if (string3.equals((Object)string2)) return n2;
        return 0;
    }

    @Override
    public String getClassName() {
        return CALLSITE_TAG;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                string2 = "constructor";
                break;
            }
            case 2: {
                string2 = "getThis";
                break;
            }
            case 3: {
                string2 = "getTypeName";
                break;
            }
            case 4: {
                string2 = "getFunction";
                break;
            }
            case 5: {
                string2 = "getFunctionName";
                break;
            }
            case 6: {
                string2 = "getMethodName";
                break;
            }
            case 7: {
                string2 = "getFileName";
                break;
            }
            case 8: {
                string2 = "getLineNumber";
                break;
            }
            case 9: {
                string2 = "getColumnNumber";
                break;
            }
            case 10: {
                string2 = "getEvalOrigin";
                break;
            }
            case 11: {
                string2 = "isToplevel";
                break;
            }
            case 12: {
                string2 = "isEval";
                break;
            }
            case 13: {
                string2 = "isNative";
                break;
            }
            case 14: {
                string2 = "isConstructor";
                break;
            }
            case 15: {
                string2 = "toString";
            }
        }
        this.initPrototypeMethod(CALLSITE_TAG, n, string2, 0);
    }

    void setElement(ScriptStackElement scriptStackElement) {
        this.element = scriptStackElement;
    }

    public String toString() {
        if (this.element == null) {
            return "";
        }
        return this.element.toString();
    }
}

