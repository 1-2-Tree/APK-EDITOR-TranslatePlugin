/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.ArrayIndexOutOfBoundsException
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.UnsupportedOperationException
 *  java.util.AbstractCollection
 *  java.util.AbstractSet
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.NoSuchElementException
 *  java.util.Set
 */
package org.mozilla.javascript;

import java.util.AbstractCollection;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;

public class NativeObject
extends IdScriptableObject
implements Map {
    private static final int ConstructorId_create = -9;
    private static final int ConstructorId_defineProperties = -8;
    private static final int ConstructorId_defineProperty = -5;
    private static final int ConstructorId_freeze = -13;
    private static final int ConstructorId_getOwnPropertyDescriptor = -4;
    private static final int ConstructorId_getOwnPropertyNames = -3;
    private static final int ConstructorId_getPrototypeOf = -1;
    private static final int ConstructorId_isExtensible = -6;
    private static final int ConstructorId_isFrozen = -11;
    private static final int ConstructorId_isSealed = -10;
    private static final int ConstructorId_keys = -2;
    private static final int ConstructorId_preventExtensions = -7;
    private static final int ConstructorId_seal = -12;
    private static final int Id___defineGetter__ = 9;
    private static final int Id___defineSetter__ = 10;
    private static final int Id___lookupGetter__ = 11;
    private static final int Id___lookupSetter__ = 12;
    private static final int Id_constructor = 1;
    private static final int Id_hasOwnProperty = 5;
    private static final int Id_isPrototypeOf = 7;
    private static final int Id_propertyIsEnumerable = 6;
    private static final int Id_toLocaleString = 3;
    private static final int Id_toSource = 8;
    private static final int Id_toString = 2;
    private static final int Id_valueOf = 4;
    private static final int MAX_PROTOTYPE_ID = 12;
    private static final Object OBJECT_TAG = "Object";
    static final long serialVersionUID = -6345305608474346996L;

    static void init(Scriptable scriptable, boolean bl) {
        new NativeObject().exportAsJSClass(12, scriptable, bl);
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public boolean containsKey(Object object) {
        if (object instanceof String) {
            return this.has((String)object, this);
        }
        if (object instanceof Number) {
            return this.has(((Number)object).intValue(), (Scriptable)this);
        }
        return false;
    }

    public boolean containsValue(Object object) {
        for (Object object2 : this.values()) {
            if (object != object2 && (object == null || !object.equals(object2))) continue;
            return true;
        }
        return false;
    }

    public Set<Map.Entry<Object, Object>> entrySet() {
        return new EntrySet();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(OBJECT_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                if (scriptable2 != null) {
                    return idFunctionObject.construct(context, scriptable, arrobject);
                }
                if (arrobject.length == 0) return new NativeObject();
                if (arrobject[0] == null) return new NativeObject();
                if (arrobject[0] != Undefined.instance) return ScriptRuntime.toObject(context, scriptable, arrobject[0]);
                return new NativeObject();
            }
            case 3: {
                Object object = ScriptableObject.getProperty(scriptable2, "toString");
                if (object instanceof Callable) return ((Callable)object).call(context, scriptable, scriptable2, ScriptRuntime.emptyArgs);
                throw ScriptRuntime.notFunctionError(object);
            }
            case 2: {
                if (!context.hasFeature(4)) return ScriptRuntime.defaultObjectToString(scriptable2);
                String string2 = ScriptRuntime.defaultObjectToSource(context, scriptable, scriptable2, arrobject);
                int n2 = string2.length();
                if (n2 == 0) return string2;
                if (string2.charAt(0) != '(') return string2;
                int n3 = n2 - 1;
                if (string2.charAt(n3) != ')') return string2;
                int n4 = n2 - 1;
                return string2.substring(1, n4);
            }
            case 4: {
                return scriptable2;
            }
            case 5: {
                boolean bl;
                Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
                String string3 = ScriptRuntime.toStringIdOrIndex(context, object);
                if (string3 == null) {
                    bl = scriptable2.has(ScriptRuntime.lastIndexResult(context), scriptable2);
                    return ScriptRuntime.wrapBoolean(bl);
                }
                bl = scriptable2.has(string3, scriptable2);
                return ScriptRuntime.wrapBoolean(bl);
            }
            case 6: {
                boolean bl;
                Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
                String string4 = ScriptRuntime.toStringIdOrIndex(context, object);
                if (string4 == null) {
                    int n5 = ScriptRuntime.lastIndexResult(context);
                    bl = scriptable2.has(n5, scriptable2);
                    if (!bl) return ScriptRuntime.wrapBoolean(bl);
                    if (!(scriptable2 instanceof ScriptableObject)) return ScriptRuntime.wrapBoolean(bl);
                    if ((2 & ((ScriptableObject)scriptable2).getAttributes(n5)) == 0) {
                        bl = true;
                        return ScriptRuntime.wrapBoolean(bl);
                    }
                    bl = false;
                    return ScriptRuntime.wrapBoolean(bl);
                }
                bl = scriptable2.has(string4, scriptable2);
                if (!bl) return ScriptRuntime.wrapBoolean(bl);
                if (!(scriptable2 instanceof ScriptableObject)) return ScriptRuntime.wrapBoolean(bl);
                if ((2 & ((ScriptableObject)scriptable2).getAttributes(string4)) == 0) {
                    bl = true;
                    return ScriptRuntime.wrapBoolean(bl);
                }
                bl = false;
                return ScriptRuntime.wrapBoolean(bl);
            }
            case 7: {
                int n6 = arrobject.length;
                boolean bl = false;
                if (n6 == 0) return ScriptRuntime.wrapBoolean(bl);
                boolean bl2 = arrobject[0] instanceof Scriptable;
                bl = false;
                if (!bl2) return ScriptRuntime.wrapBoolean(bl);
                Scriptable scriptable3 = (Scriptable)arrobject[0];
                do {
                    if ((scriptable3 = scriptable3.getPrototype()) != scriptable2) continue;
                    bl = true;
                    return ScriptRuntime.wrapBoolean(bl);
                } while (scriptable3 != null);
                bl = false;
                return ScriptRuntime.wrapBoolean(bl);
            }
            case 8: {
                return ScriptRuntime.defaultObjectToSource(context, scriptable, scriptable2, arrobject);
            }
            case 9: 
            case 10: {
                if (arrobject.length < 2 || !(arrobject[1] instanceof Callable)) {
                    Object object;
                    if (arrobject.length >= 2) {
                        object = arrobject[1];
                        throw ScriptRuntime.notFunctionError(object);
                    }
                    object = Undefined.instance;
                    throw ScriptRuntime.notFunctionError(object);
                }
                if (!(scriptable2 instanceof ScriptableObject)) {
                    throw Context.reportRuntimeError2("msg.extend.scriptable", scriptable2.getClass().getName(), String.valueOf((Object)arrobject[0]));
                }
                ScriptableObject scriptableObject = (ScriptableObject)scriptable2;
                String string5 = ScriptRuntime.toStringIdOrIndex(context, arrobject[0]);
                int n7 = string5 != null ? 0 : ScriptRuntime.lastIndexResult(context);
                Callable callable = (Callable)arrobject[1];
                boolean bl = n == 10;
                scriptableObject.setGetterOrSetter(string5, n7, callable, bl);
                if (!(scriptableObject instanceof NativeArray)) return Undefined.instance;
                ((NativeArray)scriptableObject).setDenseOnly(false);
                return Undefined.instance;
            }
            case 11: 
            case 12: {
                if (arrobject.length < 1) return Undefined.instance;
                if (!(scriptable2 instanceof ScriptableObject)) {
                    return Undefined.instance;
                }
                ScriptableObject scriptableObject = (ScriptableObject)scriptable2;
                String string6 = ScriptRuntime.toStringIdOrIndex(context, arrobject[0]);
                int n8 = string6 != null ? 0 : ScriptRuntime.lastIndexResult(context);
                boolean bl = n == 12;
                do {
                    Object object;
                    Scriptable scriptable4;
                    if ((object = scriptableObject.getGetterOrSetter(string6, n8, bl)) != null || (scriptable4 = scriptableObject.getPrototype()) == null || !(scriptable4 instanceof ScriptableObject)) {
                        if (object == null) return Undefined.instance;
                        return object;
                    }
                    scriptableObject = (ScriptableObject)scriptable4;
                } while (true);
            }
            case -1: {
                Object object;
                if (arrobject.length < 1) {
                    object = Undefined.instance;
                    return NativeObject.ensureScriptable(object).getPrototype();
                }
                object = arrobject[0];
                return NativeObject.ensureScriptable(object).getPrototype();
            }
            case -2: {
                Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
                Object[] arrobject2 = NativeObject.ensureScriptable(object).getIds();
                int n9 = 0;
                while (n9 < arrobject2.length) {
                    arrobject2[n9] = ScriptRuntime.toString(arrobject2[n9]);
                    ++n9;
                }
                return context.newArray(scriptable, arrobject2);
            }
            case -3: {
                Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
                Object[] arrobject3 = NativeObject.ensureScriptableObject(object).getAllIds();
                int n10 = 0;
                while (n10 < arrobject3.length) {
                    arrobject3[n10] = ScriptRuntime.toString(arrobject3[n10]);
                    ++n10;
                }
                return context.newArray(scriptable, arrobject3);
            }
            case -4: {
                Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
                ScriptableObject scriptableObject = NativeObject.ensureScriptableObject(object);
                Object object2 = arrobject.length < 2 ? Undefined.instance : arrobject[1];
                ScriptableObject scriptableObject2 = scriptableObject.getOwnPropertyDescriptor(context, ScriptRuntime.toString(object2));
                if (scriptableObject2 != null) return scriptableObject2;
                return Undefined.instance;
            }
            case -5: {
                Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
                ScriptableObject scriptableObject = NativeObject.ensureScriptableObject(object);
                Object object3 = arrobject.length < 2 ? Undefined.instance : arrobject[1];
                Object object4 = arrobject.length < 3 ? Undefined.instance : arrobject[2];
                ScriptableObject scriptableObject3 = NativeObject.ensureScriptableObject(object4);
                scriptableObject.defineOwnProperty(context, object3, scriptableObject3);
                return scriptableObject;
            }
            case -6: {
                Object object;
                if (arrobject.length < 1) {
                    object = Undefined.instance;
                    return NativeObject.ensureScriptableObject(object).isExtensible();
                }
                object = arrobject[0];
                return NativeObject.ensureScriptableObject(object).isExtensible();
            }
            case -7: {
                Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
                ScriptableObject scriptableObject = NativeObject.ensureScriptableObject(object);
                scriptableObject.preventExtensions();
                return scriptableObject;
            }
            case -8: {
                Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
                ScriptableObject scriptableObject = NativeObject.ensureScriptableObject(object);
                Object object5 = arrobject.length < 2 ? Undefined.instance : arrobject[1];
                Scriptable scriptable5 = this.getParentScope();
                scriptableObject.defineOwnProperties(context, NativeObject.ensureScriptableObject(Context.toObject(object5, scriptable5)));
                return scriptableObject;
            }
            case -9: {
                Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
                Scriptable scriptable6 = object == null ? null : NativeObject.ensureScriptable(object);
                NativeObject nativeObject = new NativeObject();
                nativeObject.setParentScope(this.getParentScope());
                nativeObject.setPrototype(scriptable6);
                if (arrobject.length <= 1) return nativeObject;
                if (arrobject[1] == Undefined.instance) return nativeObject;
                nativeObject.defineOwnProperties(context, NativeObject.ensureScriptableObject(Context.toObject(arrobject[1], this.getParentScope())));
                return nativeObject;
            }
            case -10: {
                Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
                ScriptableObject scriptableObject = NativeObject.ensureScriptableObject(object);
                if (scriptableObject.isExtensible()) {
                    return Boolean.FALSE;
                }
                Object[] arrobject4 = scriptableObject.getAllIds();
                int n11 = arrobject4.length;
                int n12 = 0;
                while (n12 < n11) {
                    Object object6 = scriptableObject.getOwnPropertyDescriptor(context, arrobject4[n12]).get("configurable");
                    if (Boolean.TRUE.equals(object6)) {
                        return Boolean.FALSE;
                    }
                    ++n12;
                }
                return Boolean.TRUE;
            }
            case -11: {
                Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
                ScriptableObject scriptableObject = NativeObject.ensureScriptableObject(object);
                if (scriptableObject.isExtensible()) {
                    return Boolean.FALSE;
                }
                Object[] arrobject5 = scriptableObject.getAllIds();
                int n13 = arrobject5.length;
                int n14 = 0;
                while (n14 < n13) {
                    ScriptableObject scriptableObject4 = scriptableObject.getOwnPropertyDescriptor(context, arrobject5[n14]);
                    if (Boolean.TRUE.equals(scriptableObject4.get("configurable"))) {
                        return Boolean.FALSE;
                    }
                    if (this.isDataDescriptor(scriptableObject4) && Boolean.TRUE.equals(scriptableObject4.get("writable"))) {
                        return Boolean.FALSE;
                    }
                    ++n14;
                }
                return Boolean.TRUE;
            }
            case -12: {
                Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
                ScriptableObject scriptableObject = NativeObject.ensureScriptableObject(object);
                Object[] arrobject6 = scriptableObject.getAllIds();
                int n15 = arrobject6.length;
                int n16 = 0;
                do {
                    if (n16 >= n15) {
                        scriptableObject.preventExtensions();
                        return scriptableObject;
                    }
                    Object object7 = arrobject6[n16];
                    ScriptableObject scriptableObject5 = scriptableObject.getOwnPropertyDescriptor(context, object7);
                    if (Boolean.TRUE.equals(scriptableObject5.get("configurable"))) {
                        scriptableObject5.put("configurable", (Scriptable)scriptableObject5, (Object)Boolean.FALSE);
                        scriptableObject.defineOwnProperty(context, object7, scriptableObject5, false);
                    }
                    ++n16;
                } while (true);
            }
            case -13: 
        }
        Object object = arrobject.length < 1 ? Undefined.instance : arrobject[0];
        ScriptableObject scriptableObject = NativeObject.ensureScriptableObject(object);
        Object[] arrobject7 = scriptableObject.getAllIds();
        int n17 = arrobject7.length;
        int n18 = 0;
        do {
            if (n18 >= n17) {
                scriptableObject.preventExtensions();
                return scriptableObject;
            }
            Object object8 = arrobject7[n18];
            ScriptableObject scriptableObject6 = scriptableObject.getOwnPropertyDescriptor(context, object8);
            if (this.isDataDescriptor(scriptableObject6) && Boolean.TRUE.equals(scriptableObject6.get("writable"))) {
                scriptableObject6.put("writable", (Scriptable)scriptableObject6, (Object)Boolean.FALSE);
            }
            if (Boolean.TRUE.equals(scriptableObject6.get("configurable"))) {
                scriptableObject6.put("configurable", (Scriptable)scriptableObject6, (Object)Boolean.FALSE);
            }
            scriptableObject.defineOwnProperty(context, object8, scriptableObject6, false);
            ++n18;
        } while (true);
    }

    @Override
    protected void fillConstructorProperties(IdFunctionObject idFunctionObject) {
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -1, "getPrototypeOf", 1);
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -2, "keys", 1);
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -3, "getOwnPropertyNames", 1);
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -4, "getOwnPropertyDescriptor", 2);
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -5, "defineProperty", 3);
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -6, "isExtensible", 1);
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -7, "preventExtensions", 1);
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -8, "defineProperties", 2);
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -9, "create", 2);
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -10, "isSealed", 1);
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -11, "isFrozen", 1);
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -12, "seal", 1);
        this.addIdFunctionProperty(idFunctionObject, OBJECT_TAG, -13, "freeze", 1);
        super.fillConstructorProperties(idFunctionObject);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        switch (n) {
            case 7: {
                string3 = "valueOf";
                n2 = 4;
                break;
            }
            case 8: {
                char c = string2.charAt(3);
                if (c == 'o') {
                    string3 = "toSource";
                    n2 = 8;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "toString";
                n2 = 2;
                break;
            }
            case 11: {
                string3 = "constructor";
                n2 = 1;
                break;
            }
            case 13: {
                string3 = "isPrototypeOf";
                n2 = 7;
                break;
            }
            case 14: {
                char c = string2.charAt(0);
                if (c == 'h') {
                    string3 = "hasOwnProperty";
                    n2 = 5;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "toLocaleString";
                n2 = 3;
                break;
            }
            case 16: {
                char c = string2.charAt(2);
                if (c == 'd') {
                    char c2 = string2.charAt(8);
                    if (c2 == 'G') {
                        string3 = "__defineGetter__";
                        n2 = 9;
                        break;
                    }
                    string3 = null;
                    n2 = 0;
                    if (c2 != 'S') break;
                    string3 = "__defineSetter__";
                    n2 = 10;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'l') break;
                char c3 = string2.charAt(8);
                if (c3 == 'G') {
                    string3 = "__lookupGetter__";
                    n2 = 11;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c3 != 'S') break;
                string3 = "__lookupSetter__";
                n2 = 12;
                break;
            }
            case 20: {
                string3 = "propertyIsEnumerable";
                n2 = 6;
                break;
            }
        }
        if (string3 == null) return n2;
        if (string3 == string2) return n2;
        if (string3.equals((Object)string2)) return n2;
        return 0;
    }

    @Override
    public String getClassName() {
        return "Object";
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 1;
                string2 = "constructor";
                break;
            }
            case 2: {
                string2 = "toString";
                n2 = 0;
                break;
            }
            case 3: {
                string2 = "toLocaleString";
                n2 = 0;
                break;
            }
            case 4: {
                string2 = "valueOf";
                n2 = 0;
                break;
            }
            case 5: {
                n2 = 1;
                string2 = "hasOwnProperty";
                break;
            }
            case 6: {
                n2 = 1;
                string2 = "propertyIsEnumerable";
                break;
            }
            case 7: {
                n2 = 1;
                string2 = "isPrototypeOf";
                break;
            }
            case 8: {
                string2 = "toSource";
                n2 = 0;
                break;
            }
            case 9: {
                n2 = 2;
                string2 = "__defineGetter__";
                break;
            }
            case 10: {
                n2 = 2;
                string2 = "__defineSetter__";
                break;
            }
            case 11: {
                n2 = 1;
                string2 = "__lookupGetter__";
                break;
            }
            case 12: {
                n2 = 1;
                string2 = "__lookupSetter__";
            }
        }
        this.initPrototypeMethod(OBJECT_TAG, n, string2, n2);
    }

    public Set<Object> keySet() {
        return new KeySet();
    }

    public Object put(Object object, Object object2) {
        throw new UnsupportedOperationException();
    }

    public void putAll(Map map) {
        throw new UnsupportedOperationException();
    }

    /*
     * Enabled aggressive block sorting
     */
    public Object remove(Object object) {
        Object object2 = this.get(object);
        if (object instanceof String) {
            this.delete((String)object);
            return object2;
        } else {
            if (!(object instanceof Number)) return object2;
            {
                this.delete(((Number)object).intValue());
                return object2;
            }
        }
    }

    public String toString() {
        return ScriptRuntime.defaultObjectToString(this);
    }

    public Collection<Object> values() {
        return new ValueCollection();
    }

    class EntrySet
    extends AbstractSet<Map.Entry<Object, Object>> {
        EntrySet() {
        }

        public Iterator<Map.Entry<Object, Object>> iterator() {
            return new Iterator<Map.Entry<Object, Object>>(){
                Object[] ids;
                int index;
                Object key;
                {
                    this.ids = NativeObject.this.getIds();
                    this.key = null;
                    this.index = 0;
                }

                public boolean hasNext() {
                    return this.index < this.ids.length;
                }

                public Map.Entry<Object, Object> next() {
                    Object object;
                    Object[] arrobject = this.ids;
                    int n = this.index;
                    this.index = n + 1;
                    this.key = object = arrobject[n];
                    return new Map.Entry<Object, Object>(NativeObject.this.get(this.key)){
                        final /* synthetic */ Object val$value;
                        {
                            this.val$value = object2;
                        }

                        /*
                         * Enabled aggressive block sorting
                         */
                        public boolean equals(Object object2) {
                            if (!(object2 instanceof Map.Entry)) {
                                return false;
                            }
                            Map.Entry entry = (Map.Entry)object2;
                            if (object == null) {
                                if (entry.getKey() != null) return false;
                            } else if (!object.equals(entry.getKey())) return false;
                            if (this.val$value == null) {
                                if (entry.getValue() != null) return false;
                                return true;
                            }
                            if (!this.val$value.equals(entry.getValue())) return false;
                            return true;
                        }

                        public Object getKey() {
                            return object;
                        }

                        public Object getValue() {
                            return this.val$value;
                        }

                        /*
                         * Enabled aggressive block sorting
                         */
                        public int hashCode() {
                            int n = object == null ? 0 : object.hashCode();
                            Object object2 = this.val$value;
                            int n2 = 0;
                            if (object2 == null) {
                                return n ^ n2;
                            }
                            n2 = this.val$value.hashCode();
                            return n ^ n2;
                        }

                        public Object setValue(Object object2) {
                            throw new UnsupportedOperationException();
                        }

                        public String toString() {
                            return object + "=" + this.val$value;
                        }
                    };
                }

                public void remove() {
                    if (this.key == null) {
                        throw new IllegalStateException();
                    }
                    NativeObject.this.remove(this.key);
                    this.key = null;
                }

            };
        }

        public int size() {
            return NativeObject.this.size();
        }

    }

    class KeySet
    extends AbstractSet<Object> {
        KeySet() {
        }

        public boolean contains(Object object) {
            return NativeObject.this.containsKey(object);
        }

        public Iterator<Object> iterator() {
            return new Iterator<Object>(){
                Object[] ids;
                int index;
                Object key;
                {
                    this.ids = NativeObject.this.getIds();
                    this.index = 0;
                }

                public boolean hasNext() {
                    return this.index < this.ids.length;
                }

                public Object next() {
                    try {
                        Object object;
                        Object[] arrobject = this.ids;
                        int n = this.index;
                        this.index = n + 1;
                        this.key = object = arrobject[n];
                        return object;
                    }
                    catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
                        this.key = null;
                        throw new NoSuchElementException();
                    }
                }

                public void remove() {
                    if (this.key == null) {
                        throw new IllegalStateException();
                    }
                    NativeObject.this.remove(this.key);
                    this.key = null;
                }
            };
        }

        public int size() {
            return NativeObject.this.size();
        }

    }

    class ValueCollection
    extends AbstractCollection<Object> {
        ValueCollection() {
        }

        public Iterator<Object> iterator() {
            return new Iterator<Object>(){
                Object[] ids;
                int index;
                Object key;
                {
                    this.ids = NativeObject.this.getIds();
                    this.index = 0;
                }

                public boolean hasNext() {
                    return this.index < this.ids.length;
                }

                public Object next() {
                    Object object;
                    NativeObject nativeObject = NativeObject.this;
                    Object[] arrobject = this.ids;
                    int n = this.index;
                    this.index = n + 1;
                    this.key = object = arrobject[n];
                    return nativeObject.get(object);
                }

                public void remove() {
                    if (this.key == null) {
                        throw new IllegalStateException();
                    }
                    NativeObject.this.remove(this.key);
                    this.key = null;
                }
            };
        }

        public int size() {
            return NativeObject.this.size();
        }

    }

}

