/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.text.DateFormat
 *  java.text.SimpleDateFormat
 *  java.util.Date
 *  java.util.TimeZone
 */
package org.mozilla.javascript;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

final class NativeDate
extends IdScriptableObject {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    private static final int ConstructorId_UTC = -1;
    private static final int ConstructorId_now = -3;
    private static final int ConstructorId_parse = -2;
    private static final Object DATE_TAG;
    private static final double HalfTimeDomain = 8.64E15;
    private static final double HoursPerDay = 24.0;
    private static final int Id_constructor = 1;
    private static final int Id_getDate = 17;
    private static final int Id_getDay = 19;
    private static final int Id_getFullYear = 13;
    private static final int Id_getHours = 21;
    private static final int Id_getMilliseconds = 27;
    private static final int Id_getMinutes = 23;
    private static final int Id_getMonth = 15;
    private static final int Id_getSeconds = 25;
    private static final int Id_getTime = 11;
    private static final int Id_getTimezoneOffset = 29;
    private static final int Id_getUTCDate = 18;
    private static final int Id_getUTCDay = 20;
    private static final int Id_getUTCFullYear = 14;
    private static final int Id_getUTCHours = 22;
    private static final int Id_getUTCMilliseconds = 28;
    private static final int Id_getUTCMinutes = 24;
    private static final int Id_getUTCMonth = 16;
    private static final int Id_getUTCSeconds = 26;
    private static final int Id_getYear = 12;
    private static final int Id_setDate = 39;
    private static final int Id_setFullYear = 43;
    private static final int Id_setHours = 37;
    private static final int Id_setMilliseconds = 31;
    private static final int Id_setMinutes = 35;
    private static final int Id_setMonth = 41;
    private static final int Id_setSeconds = 33;
    private static final int Id_setTime = 30;
    private static final int Id_setUTCDate = 40;
    private static final int Id_setUTCFullYear = 44;
    private static final int Id_setUTCHours = 38;
    private static final int Id_setUTCMilliseconds = 32;
    private static final int Id_setUTCMinutes = 36;
    private static final int Id_setUTCMonth = 42;
    private static final int Id_setUTCSeconds = 34;
    private static final int Id_setYear = 45;
    private static final int Id_toDateString = 4;
    private static final int Id_toGMTString = 8;
    private static final int Id_toISOString = 46;
    private static final int Id_toJSON = 47;
    private static final int Id_toLocaleDateString = 7;
    private static final int Id_toLocaleString = 5;
    private static final int Id_toLocaleTimeString = 6;
    private static final int Id_toSource = 9;
    private static final int Id_toString = 2;
    private static final int Id_toTimeString = 3;
    private static final int Id_toUTCString = 8;
    private static final int Id_valueOf = 10;
    private static double LocalTZA = 0.0;
    private static final int MAXARGS = 7;
    private static final int MAX_PROTOTYPE_ID = 47;
    private static final double MinutesPerDay = 1440.0;
    private static final double MinutesPerHour = 60.0;
    private static final double SecondsPerDay = 86400.0;
    private static final double SecondsPerHour = 3600.0;
    private static final double SecondsPerMinute = 60.0;
    private static final String js_NaN_date_str = "Invalid Date";
    private static DateFormat localeDateFormatter;
    private static DateFormat localeDateTimeFormatter;
    private static DateFormat localeTimeFormatter;
    private static final double msPerDay = 8.64E7;
    private static final double msPerHour = 3600000.0;
    private static final double msPerMinute = 60000.0;
    private static final double msPerSecond = 1000.0;
    static final long serialVersionUID = -8307438915861678966L;
    private static TimeZone thisTimeZone;
    private static DateFormat timeZoneFormatter;
    private double date;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !NativeDate.class.desiredAssertionStatus();
        $assertionsDisabled = bl;
        DATE_TAG = "Date";
    }

    private NativeDate() {
        if (thisTimeZone == null) {
            thisTimeZone = TimeZone.getDefault();
            LocalTZA = thisTimeZone.getRawOffset();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int DateFromTime(double var0) {
        var2_1 = NativeDate.YearFromTime(var0);
        var3_2 = -59 + (int)(NativeDate.Day(var0) - NativeDate.DayFromYear(var2_1));
        if (var3_2 < 0) {
            if (var3_2 >= -28) return 1 + (var3_2 + 28);
            return 1 + (28 + (var3_2 + 31));
        }
        if (NativeDate.IsLeapYear(var2_1)) {
            if (var3_2 == 0) {
                return 29;
            }
            --var3_2;
        }
        switch (var3_2 / 30) {
            default: {
                throw Kit.codeBug();
            }
            case 0: {
                return var3_2 + 1;
            }
            case 1: {
                var4_3 = 31;
                var5_4 = 31;
                ** GOTO lbl50
            }
            case 2: {
                var4_3 = 30;
                var5_4 = 61;
                ** GOTO lbl50
            }
            case 3: {
                var4_3 = 31;
                var5_4 = 92;
                ** GOTO lbl50
            }
            case 4: {
                var4_3 = 30;
                var5_4 = 122;
                ** GOTO lbl50
            }
            case 5: {
                var4_3 = 31;
                var5_4 = 153;
                ** GOTO lbl50
            }
            case 6: {
                var4_3 = 31;
                var5_4 = 184;
                ** GOTO lbl50
            }
            case 7: {
                var4_3 = 30;
                var5_4 = 214;
                ** GOTO lbl50
            }
            case 8: {
                var4_3 = 31;
                var5_4 = 245;
                ** GOTO lbl50
            }
            case 9: {
                var4_3 = 30;
                var5_4 = 275;
lbl50: // 9 sources:
                if ((var6_5 = var3_2 - var5_4) >= 0) return var6_5 + 1;
                var6_5 += var4_3;
                return var6_5 + 1;
            }
            case 10: 
        }
        return 1 + (var3_2 - 275);
    }

    private static double Day(double d) {
        return Math.floor((double)(d / 8.64E7));
    }

    /*
     * Enabled aggressive block sorting
     */
    private static double DayFromMonth(int n, int n2) {
        int n3 = n * 30;
        int n4 = n >= 7 ? n3 + (-1 + n / 2) : (n >= 2 ? n3 + (-1 + (n - 1) / 2) : n3 + n);
        if (n >= 2 && NativeDate.IsLeapYear(n2)) {
            ++n4;
        }
        return n4;
    }

    private static double DayFromYear(double d) {
        return 365.0 * (d - 1970.0) + Math.floor((double)((d - 1969.0) / 4.0)) - Math.floor((double)((d - 1901.0) / 100.0)) + Math.floor((double)((d - 1601.0) / 400.0));
    }

    private static double DaylightSavingTA(double d) {
        Date date;
        if (d < 0.0) {
            d = NativeDate.MakeDate(NativeDate.MakeDay(NativeDate.EquivalentYear(NativeDate.YearFromTime(d)), NativeDate.MonthFromTime(d), NativeDate.DateFromTime(d)), NativeDate.TimeWithinDay(d));
        }
        if (thisTimeZone.inDaylightTime(date = new Date((long)d))) {
            return 3600000.0;
        }
        return 0.0;
    }

    private static int DaysInMonth(int n, int n2) {
        if (n2 == 2) {
            if (NativeDate.IsLeapYear(n)) {
                return 29;
            }
            return 28;
        }
        if (n2 >= 8) {
            return 31 - (n2 & 1);
        }
        return 30 + (n2 & 1);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static int EquivalentYear(int n) {
        int n2 = (4 + (int)NativeDate.DayFromYear(n)) % 7;
        if (n2 < 0) {
            n2 += 7;
        }
        if (NativeDate.IsLeapYear(n)) {
            switch (n2) {
                default: {
                    do {
                        throw Kit.codeBug();
                        break;
                    } while (true);
                }
                case 0: {
                    return 1984;
                }
                case 1: {
                    return 1996;
                }
                case 2: {
                    return 1980;
                }
                case 3: {
                    return 1992;
                }
                case 4: {
                    return 1976;
                }
                case 5: {
                    return 1988;
                }
                case 6: 
            }
            return 1972;
        }
        switch (n2) {
            default: {
                throw Kit.codeBug();
            }
            case 0: {
                return 1978;
            }
            case 1: {
                return 1973;
            }
            case 2: {
                return 1985;
            }
            case 3: {
                return 1986;
            }
            case 4: {
                return 1981;
            }
            case 5: {
                return 1971;
            }
            case 6: 
        }
        return 1977;
    }

    private static int HourFromTime(double d) {
        double d2 = Math.floor((double)(d / 3600000.0)) % 24.0;
        if (d2 < 0.0) {
            d2 += 24.0;
        }
        return (int)d2;
    }

    private static boolean IsLeapYear(int n) {
        return n % 4 == 0 && (n % 100 != 0 || n % 400 == 0);
    }

    private static double LocalTime(double d) {
        return d + LocalTZA + NativeDate.DaylightSavingTA(d);
    }

    private static double MakeDate(double d, double d2) {
        return d2 + 8.64E7 * d;
    }

    private static double MakeDay(double d, double d2, double d3) {
        double d4 = d + Math.floor((double)(d2 / 12.0));
        double d5 = d2 % 12.0;
        if (d5 < 0.0) {
            d5 += 12.0;
        }
        return d3 + (Math.floor((double)(NativeDate.TimeFromYear(d4) / 8.64E7)) + NativeDate.DayFromMonth((int)d5, (int)d4)) - 1.0;
    }

    private static double MakeTime(double d, double d2, double d3, double d4) {
        return d4 + 1000.0 * (d3 + 60.0 * (d2 + d * 60.0));
    }

    private static int MinFromTime(double d) {
        double d2 = Math.floor((double)(d / 60000.0)) % 60.0;
        if (d2 < 0.0) {
            d2 += 60.0;
        }
        return (int)d2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static int MonthFromTime(double var0) {
        var2_1 = 1;
        var3_2 = NativeDate.YearFromTime(var0);
        var4_3 = -59 + (int)(NativeDate.Day(var0) - NativeDate.DayFromYear(var3_2));
        if (var4_3 < 0) {
            if (var4_3 >= -28) return var2_1;
            return 0;
        }
        if (NativeDate.IsLeapYear(var3_2)) {
            if (var4_3 == 0) return var2_1;
            --var4_3;
        }
        var5_4 = var4_3 / 30;
        switch (var5_4) {
            default: {
                throw Kit.codeBug();
            }
            case 0: {
                return 2;
            }
            case 1: {
                var6_5 = 31;
                ** GOTO lbl42
            }
            case 2: {
                var6_5 = 61;
                ** GOTO lbl42
            }
            case 3: {
                var6_5 = 92;
                ** GOTO lbl42
            }
            case 4: {
                var6_5 = 122;
                ** GOTO lbl42
            }
            case 5: {
                var6_5 = 153;
                ** GOTO lbl42
            }
            case 6: {
                var6_5 = 184;
                ** GOTO lbl42
            }
            case 7: {
                var6_5 = 214;
                ** GOTO lbl42
            }
            case 8: {
                var6_5 = 245;
                ** GOTO lbl42
            }
            case 9: {
                var6_5 = 275;
lbl42: // 9 sources:
                if (var4_3 < var6_5) return var5_4 + 1;
                return var5_4 + 2;
            }
            case 10: 
        }
        return 11;
    }

    private static int SecFromTime(double d) {
        double d2 = Math.floor((double)(d / 1000.0)) % 60.0;
        if (d2 < 0.0) {
            d2 += 60.0;
        }
        return (int)d2;
    }

    private static double TimeClip(double d) {
        if (d != d || d == Double.POSITIVE_INFINITY || d == Double.NEGATIVE_INFINITY || Math.abs((double)d) > 8.64E15) {
            return ScriptRuntime.NaN;
        }
        if (d > 0.0) {
            return Math.floor((double)(d + 0.0));
        }
        return Math.ceil((double)(d + 0.0));
    }

    private static double TimeFromYear(double d) {
        return 8.64E7 * NativeDate.DayFromYear(d);
    }

    private static double TimeWithinDay(double d) {
        double d2 = d % 8.64E7;
        if (d2 < 0.0) {
            d2 += 8.64E7;
        }
        return d2;
    }

    private static int WeekDay(double d) {
        double d2 = (4.0 + NativeDate.Day(d)) % 7.0;
        if (d2 < 0.0) {
            d2 += 7.0;
        }
        return (int)d2;
    }

    private static int YearFromTime(double d) {
        int n = 1970 + (int)Math.floor((double)(d / 8.64E7 / 366.0));
        int n2 = 1970 + (int)Math.floor((double)(d / 8.64E7 / 365.0));
        if (n2 < n) {
            int n3 = n;
            n = n2;
            n2 = n3;
        }
        while (n2 > n) {
            int n4 = (n2 + n) / 2;
            if (NativeDate.TimeFromYear(n4) > d) {
                n2 = n4 - 1;
                continue;
            }
            n = n4 + 1;
            if (!(NativeDate.TimeFromYear(n) > d)) continue;
            return n4;
        }
        return n;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void append0PaddedUint(StringBuilder var0, int var1_1, int var2_2) {
        block6 : {
            if (var1_1 < 0) {
                Kit.codeBug();
            }
            var3_3 = 1;
            var4_4 = var2_2 - 1;
            if (var1_1 < 10) ** GOTO lbl13
            if (var1_1 < 1000000000) break block6;
            var4_4 -= 9;
            var3_3 = 1000000000;
            ** GOTO lbl13
        }
        do {
            block7 : {
                if (var1_1 >= (var8_5 = var3_3 * 10)) break block7;
lbl13: // 4 sources:
                while (var4_4 > 0) {
                    var0.append('0');
                    --var4_4;
                }
                break;
            }
            --var4_4;
            var3_3 = var8_5;
        } while (true);
        do {
            if (var3_3 == 1) {
                var0.append((char)(var1_1 + 48));
                return;
            }
            var0.append((char)(48 + var1_1 / var3_3));
            var1_1 %= var3_3;
            var3_3 /= 10;
        } while (true);
    }

    private static void appendMonthName(StringBuilder stringBuilder, int n) {
        int n2 = n * 3;
        for (int i = 0; i != 3; ++i) {
            stringBuilder.append("JanFebMarAprMayJunJulAugSepOctNovDec".charAt(n2 + i));
        }
    }

    private static void appendWeekDayName(StringBuilder stringBuilder, int n) {
        int n2 = n * 3;
        for (int i = 0; i != 3; ++i) {
            stringBuilder.append("SunMonTueWedThuFriSat".charAt(n2 + i));
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static String date_format(double d, int n) {
        StringBuilder stringBuilder = new StringBuilder(60);
        double d2 = NativeDate.LocalTime(d);
        if (n != 3) {
            NativeDate.appendWeekDayName(stringBuilder, NativeDate.WeekDay(d2));
            stringBuilder.append(' ');
            NativeDate.appendMonthName(stringBuilder, NativeDate.MonthFromTime(d2));
            stringBuilder.append(' ');
            NativeDate.append0PaddedUint(stringBuilder, NativeDate.DateFromTime(d2), 2);
            stringBuilder.append(' ');
            int n2 = NativeDate.YearFromTime(d2);
            if (n2 < 0) {
                stringBuilder.append('-');
                n2 = -n2;
            }
            NativeDate.append0PaddedUint(stringBuilder, n2, 4);
            if (n != 4) {
                stringBuilder.append(' ');
            }
        }
        if (n != 4) {
            DateFormat dateFormat;
            NativeDate.append0PaddedUint(stringBuilder, NativeDate.HourFromTime(d2), 2);
            stringBuilder.append(':');
            NativeDate.append0PaddedUint(stringBuilder, NativeDate.MinFromTime(d2), 2);
            stringBuilder.append(':');
            NativeDate.append0PaddedUint(stringBuilder, NativeDate.SecFromTime(d2), 2);
            int n3 = (int)Math.floor((double)((LocalTZA + NativeDate.DaylightSavingTA(d)) / 60000.0));
            int n4 = 100 * (n3 / 60) + n3 % 60;
            if (n4 > 0) {
                stringBuilder.append(" GMT+");
            } else {
                stringBuilder.append(" GMT-");
                n4 = -n4;
            }
            NativeDate.append0PaddedUint(stringBuilder, n4, 4);
            if (timeZoneFormatter == null) {
                timeZoneFormatter = new SimpleDateFormat("zzz");
            }
            if (d < 0.0) {
                d = NativeDate.MakeDate(NativeDate.MakeDay(NativeDate.EquivalentYear(NativeDate.YearFromTime(d2)), NativeDate.MonthFromTime(d), NativeDate.DateFromTime(d)), NativeDate.TimeWithinDay(d));
            }
            stringBuilder.append(" (");
            Date date = new Date((long)d);
            DateFormat dateFormat2 = dateFormat = timeZoneFormatter;
            synchronized (dateFormat2) {
                stringBuilder.append(timeZoneFormatter.format(date));
            }
            stringBuilder.append(')');
        }
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    private static double date_msecFromArgs(Object[] arrobject) {
        double[] arrd = new double[7];
        for (int i = 0; i < 7; ++i) {
            int n = arrobject.length;
            if (i < n) {
                double d = ScriptRuntime.toNumber(arrobject[i]);
                if (d != d || Double.isInfinite((double)d)) {
                    return ScriptRuntime.NaN;
                }
                arrd[i] = ScriptRuntime.toInteger(arrobject[i]);
                continue;
            }
            arrd[i] = i == 2 ? 1.0 : 0.0;
        }
        if (arrd[0] >= 0.0 && arrd[0] <= 99.0) {
            arrd[0] = 1900.0 + arrd[0];
        }
        return NativeDate.date_msecFromDate(arrd[0], arrd[1], arrd[2], arrd[3], arrd[4], arrd[5], arrd[6]);
    }

    private static double date_msecFromDate(double d, double d2, double d3, double d4, double d5, double d6, double d7) {
        return NativeDate.MakeDate(NativeDate.MakeDay(d, d2, d3), NativeDate.MakeTime(d4, d5, d6, d7));
    }

    /*
     * Enabled aggressive block sorting
     */
    private static double date_parseString(String string2) {
        double d = NativeDate.parseISOString(string2);
        if (d == d) {
            return d;
        }
        int n = -1;
        int n2 = -1;
        int n3 = -1;
        int n4 = -1;
        int n5 = -1;
        int n6 = -1;
        int n7 = 0;
        double d2 = -1.0;
        char c = '\u0000';
        boolean bl = false;
        int n8 = string2.length();
        block13 : do {
            int n9;
            block61 : {
                int n10;
                block64 : {
                    block63 : {
                        block62 : {
                            if (n7 >= n8) break block62;
                            char c2 = string2.charAt(n7);
                            ++n7;
                            if (c2 <= ' ' || c2 == ',' || c2 == '-') {
                                if (n7 >= n8) continue;
                                char c3 = string2.charAt(n7);
                                if (c2 != '-' || '0' > c3 || c3 > '9') continue;
                                c = c2;
                                continue;
                            }
                            if (c2 == '(') break block63;
                            if ('0' <= c2 && c2 <= '9') {
                                int n11 = c2 - 48;
                                while (n7 < n8 && '0' <= (c2 = string2.charAt(n7)) && c2 <= '9') {
                                    n11 = -48 + (c2 + n11 * 10);
                                    ++n7;
                                }
                                if (c == '+' || c == '-') {
                                    bl = true;
                                    int n12 = n11 < 24 ? n11 * 60 : n11 % 100 + 60 * (n11 / 100);
                                    if (c == '+') {
                                        n12 = -n12;
                                    }
                                    if (d2 != 0.0 && d2 != -1.0) {
                                        return ScriptRuntime.NaN;
                                    }
                                    d2 = n12;
                                } else if (n11 >= 70 || c == '/' && n2 >= 0 && n3 >= 0 && n < 0) {
                                    if (n >= 0) {
                                        return ScriptRuntime.NaN;
                                    }
                                    if (c2 > ' ' && c2 != ',' && c2 != '/' && n7 < n8) {
                                        return ScriptRuntime.NaN;
                                    }
                                    n = n11 < 100 ? 1900 + n11 : n11;
                                } else if (c2 == ':') {
                                    if (n4 < 0) {
                                        n4 = n11;
                                    } else {
                                        if (n5 >= 0) {
                                            return ScriptRuntime.NaN;
                                        }
                                        n5 = n11;
                                    }
                                } else if (c2 == '/') {
                                    if (n2 < 0) {
                                        n2 = n11 - 1;
                                    } else {
                                        if (n3 >= 0) {
                                            return ScriptRuntime.NaN;
                                        }
                                        n3 = n11;
                                    }
                                } else {
                                    if (n7 < n8 && c2 != ',' && c2 > ' ' && c2 != '-') {
                                        return ScriptRuntime.NaN;
                                    }
                                    if (bl && n11 < 60) {
                                        d2 = d2 < 0.0 ? (d2 -= (double)n11) : (d2 += (double)n11);
                                    } else if (n4 >= 0 && n5 < 0) {
                                        n5 = n11;
                                    } else if (n5 >= 0 && n6 < 0) {
                                        n6 = n11;
                                    } else {
                                        if (n3 >= 0) {
                                            return ScriptRuntime.NaN;
                                        }
                                        n3 = n11;
                                    }
                                }
                                c = '\u0000';
                                continue;
                            }
                            if (c2 == '/' || c2 == ':' || c2 == '+' || c2 == '-') {
                                c = c2;
                                continue;
                            }
                            break block64;
                        }
                        if (n < 0 || n2 < 0 || n3 < 0) {
                            return ScriptRuntime.NaN;
                        }
                        if (n6 < 0) {
                            n6 = 0;
                        }
                        if (n5 < 0) {
                            n5 = 0;
                        }
                        if (n4 < 0) {
                            n4 = 0;
                        }
                        double d3 = NativeDate.date_msecFromDate(n, n2, n3, n4, n5, n6, 0.0);
                        if (d2 == -1.0) {
                            return NativeDate.internalUTC(d3);
                        }
                        return d3 + 60000.0 * d2;
                    }
                    int n13 = 1;
                    do {
                        if (n7 >= n8) continue block13;
                        char c4 = string2.charAt(n7);
                        ++n7;
                        if (c4 == '(') {
                            ++n13;
                            continue;
                        }
                        if (c4 == ')' && --n13 <= 0) break;
                    } while (true);
                    continue;
                }
                int n14 = n7 - 1;
                do {
                    char c5;
                    if (n7 >= n8 || ('A' > (c5 = string2.charAt(n7)) || c5 > 'Z') && ('a' > c5 || c5 > 'z')) {
                        n10 = n7 - n14;
                        if (n10 >= 2) break;
                        return ScriptRuntime.NaN;
                    }
                    ++n7;
                } while (true);
                n9 = 0;
                int n15 = 0;
                do {
                    int n16;
                    if ((n16 = "am;pm;monday;tuesday;wednesday;thursday;friday;saturday;sunday;january;february;march;april;may;june;july;august;september;october;november;december;gmt;ut;utc;est;edt;cst;cdt;mst;mdt;pst;pdt;".indexOf(59, n15)) < 0) {
                        return ScriptRuntime.NaN;
                    }
                    if ("am;pm;monday;tuesday;wednesday;thursday;friday;saturday;sunday;january;february;march;april;may;june;july;august;september;october;november;december;gmt;ut;utc;est;edt;cst;cdt;mst;mdt;pst;pdt;".regionMatches(true, n15, string2, n14, n10)) {
                        if (n9 < 2) {
                            if (n4 <= 12 && n4 >= 0) break;
                            return ScriptRuntime.NaN;
                        }
                        break block61;
                    }
                    n15 = n16 + 1;
                    ++n9;
                } while (true);
                if (n9 == 0) {
                    if (n4 != 12) continue;
                    n4 = 0;
                    continue;
                }
                if (n4 == 12) continue;
                n4 += 12;
                continue;
            }
            int n17 = n9 - 2;
            if (n17 < 7) continue;
            int n18 = n17 - 7;
            if (n18 < 12) {
                if (n2 >= 0) {
                    return ScriptRuntime.NaN;
                }
                n2 = n18;
                continue;
            }
            switch (n18 - 12) {
                default: {
                    Kit.codeBug();
                    continue block13;
                }
                case 0: {
                    d2 = 0.0;
                    continue block13;
                }
                case 1: {
                    d2 = 0.0;
                    continue block13;
                }
                case 2: {
                    d2 = 0.0;
                    continue block13;
                }
                case 3: {
                    d2 = 300.0;
                    continue block13;
                }
                case 4: {
                    d2 = 240.0;
                    continue block13;
                }
                case 5: {
                    d2 = 360.0;
                    continue block13;
                }
                case 6: {
                    d2 = 300.0;
                    continue block13;
                }
                case 7: {
                    d2 = 420.0;
                    continue block13;
                }
                case 8: {
                    d2 = 360.0;
                    continue block13;
                }
                case 9: {
                    d2 = 480.0;
                    continue block13;
                }
                case 10: 
            }
            d2 = 420.0;
        } while (true);
    }

    static void init(Scriptable scriptable, boolean bl) {
        NativeDate nativeDate = new NativeDate();
        nativeDate.date = ScriptRuntime.NaN;
        nativeDate.exportAsJSClass(47, scriptable, bl);
    }

    private static double internalUTC(double d) {
        return d - LocalTZA - NativeDate.DaylightSavingTA(d - LocalTZA);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object jsConstructor(Object[] arrobject) {
        NativeDate nativeDate = new NativeDate();
        if (arrobject.length == 0) {
            nativeDate.date = NativeDate.now();
            return nativeDate;
        }
        if (arrobject.length == 1) {
            Object object = arrobject[0];
            if (object instanceof Scriptable) {
                object = ((Scriptable)object).getDefaultValue(null);
            }
            double d = object instanceof CharSequence ? NativeDate.date_parseString(object.toString()) : ScriptRuntime.toNumber(object);
            nativeDate.date = NativeDate.TimeClip(d);
            return nativeDate;
        }
        double d = NativeDate.date_msecFromArgs(arrobject);
        if (!Double.isNaN((double)d) && !Double.isInfinite((double)d)) {
            d = NativeDate.TimeClip(NativeDate.internalUTC(d));
        }
        nativeDate.date = d;
        return nativeDate;
    }

    private static double jsStaticFunction_UTC(Object[] arrobject) {
        return NativeDate.TimeClip(NativeDate.date_msecFromArgs(arrobject));
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String js_toISOString(double d) {
        StringBuilder stringBuilder = new StringBuilder(27);
        int n = NativeDate.YearFromTime(d);
        if (n < 0) {
            stringBuilder.append('-');
            NativeDate.append0PaddedUint(stringBuilder, -n, 6);
        } else if (n > 9999) {
            NativeDate.append0PaddedUint(stringBuilder, n, 6);
        } else {
            NativeDate.append0PaddedUint(stringBuilder, n, 4);
        }
        stringBuilder.append('-');
        NativeDate.append0PaddedUint(stringBuilder, 1 + NativeDate.MonthFromTime(d), 2);
        stringBuilder.append('-');
        NativeDate.append0PaddedUint(stringBuilder, NativeDate.DateFromTime(d), 2);
        stringBuilder.append('T');
        NativeDate.append0PaddedUint(stringBuilder, NativeDate.HourFromTime(d), 2);
        stringBuilder.append(':');
        NativeDate.append0PaddedUint(stringBuilder, NativeDate.MinFromTime(d), 2);
        stringBuilder.append(':');
        NativeDate.append0PaddedUint(stringBuilder, NativeDate.SecFromTime(d), 2);
        stringBuilder.append('.');
        NativeDate.append0PaddedUint(stringBuilder, NativeDate.msFromTime(d), 3);
        stringBuilder.append('Z');
        return stringBuilder.toString();
    }

    private static String js_toUTCString(double d) {
        StringBuilder stringBuilder = new StringBuilder(60);
        NativeDate.appendWeekDayName(stringBuilder, NativeDate.WeekDay(d));
        stringBuilder.append(", ");
        NativeDate.append0PaddedUint(stringBuilder, NativeDate.DateFromTime(d), 2);
        stringBuilder.append(' ');
        NativeDate.appendMonthName(stringBuilder, NativeDate.MonthFromTime(d));
        stringBuilder.append(' ');
        int n = NativeDate.YearFromTime(d);
        if (n < 0) {
            stringBuilder.append('-');
            n = -n;
        }
        NativeDate.append0PaddedUint(stringBuilder, n, 4);
        stringBuilder.append(' ');
        NativeDate.append0PaddedUint(stringBuilder, NativeDate.HourFromTime(d), 2);
        stringBuilder.append(':');
        NativeDate.append0PaddedUint(stringBuilder, NativeDate.MinFromTime(d), 2);
        stringBuilder.append(':');
        NativeDate.append0PaddedUint(stringBuilder, NativeDate.SecFromTime(d), 2);
        stringBuilder.append(" GMT");
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    private static double makeDate(double d, Object[] arrobject, int n) {
        double d2;
        int n2;
        double d3;
        int n3;
        double d4;
        double d5;
        if (arrobject.length == 0) {
            return ScriptRuntime.NaN;
        }
        boolean bl = true;
        switch (n) {
            default: {
                throw Kit.codeBug();
            }
            case 40: {
                bl = false;
            }
            case 39: {
                n2 = 1;
                break;
            }
            case 42: {
                bl = false;
            }
            case 41: {
                n2 = 2;
                break;
            }
            case 44: {
                bl = false;
            }
            case 43: {
                n2 = 3;
            }
        }
        boolean bl2 = false;
        int n4 = arrobject.length < n2 ? arrobject.length : n2;
        if (!($assertionsDisabled || 1 <= n4 && n4 <= 3)) {
            throw new AssertionError();
        }
        double[] arrd = new double[3];
        for (int i = 0; i < n4; ++i) {
            double d6 = ScriptRuntime.toNumber(arrobject[i]);
            if (d6 != d6 || Double.isInfinite((double)d6)) {
                bl2 = true;
                continue;
            }
            arrd[i] = ScriptRuntime.toInteger(d6);
        }
        if (bl2) {
            return ScriptRuntime.NaN;
        }
        int n5 = n4;
        if (d != d) {
            if (n2 < 3) {
                return ScriptRuntime.NaN;
            }
            d4 = 0.0;
        } else {
            d4 = bl ? NativeDate.LocalTime(d) : d;
        }
        if (n2 >= 3 && n5 < 0) {
            n3 = 0 + 1;
            d3 = arrd[0];
        } else {
            d3 = NativeDate.YearFromTime(d4);
            n3 = 0;
        }
        if (n2 >= 2 && n3 < n5) {
            int n6 = n3 + 1;
            d5 = arrd[n3];
            n3 = n6;
        } else {
            d5 = NativeDate.MonthFromTime(d4);
        }
        if (n2 >= 1 && n3 < n5) {
            n3 + 1;
            d2 = arrd[n3];
        } else {
            d2 = NativeDate.DateFromTime(d4);
        }
        double d7 = NativeDate.MakeDate(NativeDate.MakeDay(d3, d5, d2), NativeDate.TimeWithinDay(d4));
        if (bl) {
            d7 = NativeDate.internalUTC(d7);
        }
        return NativeDate.TimeClip(d7);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static double makeTime(double d, Object[] arrobject, int n) {
        double d2;
        int n2;
        double d3;
        int n3;
        double d4;
        double d5;
        if (arrobject.length == 0) {
            return ScriptRuntime.NaN;
        }
        boolean bl = true;
        switch (n) {
            default: {
                throw Kit.codeBug();
            }
            case 32: {
                bl = false;
            }
            case 31: {
                n2 = 1;
                break;
            }
            case 34: {
                bl = false;
            }
            case 33: {
                n2 = 2;
                break;
            }
            case 36: {
                bl = false;
            }
            case 35: {
                n2 = 3;
                break;
            }
            case 38: {
                bl = false;
            }
            case 37: {
                n2 = 4;
            }
        }
        boolean bl2 = false;
        int n4 = arrobject.length < n2 ? arrobject.length : n2;
        if (!$assertionsDisabled && n4 > 4) {
            throw new AssertionError();
        }
        double[] arrd = new double[4];
        for (int i = 0; i < n4; ++i) {
            double d6 = ScriptRuntime.toNumber(arrobject[i]);
            if (d6 != d6 || Double.isInfinite((double)d6)) {
                bl2 = true;
                continue;
            }
            arrd[i] = ScriptRuntime.toInteger(d6);
        }
        if (bl2 || d != d) {
            return ScriptRuntime.NaN;
        }
        int n5 = n4;
        double d7 = bl ? NativeDate.LocalTime(d) : d;
        if (n2 >= 4 && n5 < 0) {
            n3 = 0 + 1;
            d3 = arrd[0];
        } else {
            d3 = NativeDate.HourFromTime(d7);
            n3 = 0;
        }
        if (n2 >= 3 && n3 < n5) {
            int n6 = n3 + 1;
            d4 = arrd[n3];
            n3 = n6;
        } else {
            d4 = NativeDate.MinFromTime(d7);
        }
        if (n2 >= 2 && n3 < n5) {
            int n7 = n3 + 1;
            d2 = arrd[n3];
            n3 = n7;
        } else {
            d2 = NativeDate.SecFromTime(d7);
        }
        if (n2 >= 1 && n3 < n5) {
            n3 + 1;
            d5 = arrd[n3];
        } else {
            d5 = NativeDate.msFromTime(d7);
        }
        double d8 = NativeDate.MakeTime(d3, d4, d2, d5);
        double d9 = NativeDate.MakeDate(NativeDate.Day(d7), d8);
        if (bl) {
            d9 = NativeDate.internalUTC(d9);
        }
        return NativeDate.TimeClip(d9);
    }

    private static int msFromTime(double d) {
        double d2 = d % 1000.0;
        if (d2 < 0.0) {
            d2 += 1000.0;
        }
        return (int)d2;
    }

    private static double now() {
        return System.currentTimeMillis();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static double parseISOString(String var0) {
        var1_1 = new int[]{1970, 1, 1, 0, 0, 0, 0, -1, -1};
        var2_2 = 4;
        var3_3 = 1;
        var4_4 = 1;
        var5_5 = var0.length();
        var6_6 = 0;
        var7_7 = 0;
        if (var5_5 != 0) {
            var25_8 = var0.charAt(0);
            if (var25_8 == '+' || var25_8 == '-') {
                var6_6 = 0 + 1;
                var2_2 = 6;
                if (var25_8 == '-') {
                    var3_3 = -1;
                } else {
                    var3_3 = 1;
                    var7_7 = 0;
                }
            } else {
                var6_6 = 0;
                var7_7 = 0;
                if (var25_8 == 'T') {
                    var6_6 = 0 + 1;
                    var7_7 = 3;
                }
            }
        }
        block16 : do {
            block42 : {
                block41 : {
                    if (var7_7 == -1) ** GOTO lbl32
                    var19_9 = var7_7 == 0 ? var2_2 : (var7_7 == 6 ? 3 : 2);
                    var20_10 = var6_6 + var19_9;
                    if (var20_10 <= var5_5) {
                        var21_11 = 0;
                    } else {
                        var7_7 = -1;
lbl32: // 6 sources:
                        do {
                            if (var7_7 == -1) return ScriptRuntime.NaN;
                            if (var6_6 != var5_5) return ScriptRuntime.NaN;
                            var10_16 = var1_1[0];
                            var11_17 = var1_1[1];
                            var12_18 = var1_1[2];
                            var13_19 = var1_1[3];
                            var14_20 = var1_1[4];
                            var15_21 = var1_1[5];
                            var16_22 = var1_1[6];
                            var17_23 = var1_1[7];
                            var18_24 = var1_1[8];
                            if (var10_16 > 275943) return ScriptRuntime.NaN;
                            if (var11_17 < 1) return ScriptRuntime.NaN;
                            if (var11_17 > 12) return ScriptRuntime.NaN;
                            if (var12_18 < 1) return ScriptRuntime.NaN;
                            if (var12_18 > NativeDate.DaysInMonth(var10_16, var11_17)) return ScriptRuntime.NaN;
                            if (var13_19 > 24) return ScriptRuntime.NaN;
                            if (var13_19 == 24) {
                                if (var14_20 > 0) return ScriptRuntime.NaN;
                                if (var15_21 > 0) return ScriptRuntime.NaN;
                                if (var16_22 > 0) return ScriptRuntime.NaN;
                            }
                            if (var14_20 > 59) return ScriptRuntime.NaN;
                            if (var15_21 > 59) return ScriptRuntime.NaN;
                            if (var17_23 > 23) return ScriptRuntime.NaN;
                            if (var18_24 > 59) return ScriptRuntime.NaN;
                            var8_15 = NativeDate.date_msecFromDate(var10_16 * var3_3, var11_17 - 1, var12_18, var13_19, var14_20, var15_21, var16_22);
                            if (var17_23 != -1) {
                                var8_15 -= 60000.0 * (double)(var18_24 + var17_23 * 60) * (double)var4_4;
                            }
                            break block16;
                            break;
                        } while (true);
                    }
                    for (var22_12 = var6_6; var22_12 < var20_10; ++var22_12) {
                        block40 : {
                            var24_14 = var0.charAt(var22_12);
                            if (var24_14 >= '0' && var24_14 <= '9') break block40;
                            var7_7 = -1;
                            var6_6 = var22_12;
                            ** GOTO lbl32
                        }
                        var21_11 = var21_11 * 10 + (var24_14 - 48);
                    }
                    var1_1[var7_7] = var21_11;
                    if (var22_12 != var5_5) break block41;
                    switch (var7_7) {
                        default: {
                            break;
                        }
                        case 3: 
                        case 7: {
                            var7_7 = -1;
                        }
                    }
                    var6_6 = var22_12;
                    ** GOTO lbl32
                }
                var6_6 = var22_12 + 1;
                var23_13 = var0.charAt(var22_12);
                if (var23_13 != 'Z') break block42;
                var1_1[7] = 0;
                var1_1[8] = 0;
                switch (var7_7) {
                    case 4: 
                    case 5: 
                    case 6: {
                        ** GOTO lbl32
                    }
                }
                var7_7 = -1;
                ** continue;
            }
            switch (var7_7) {
                case 0: 
                case 1: {
                    if (var23_13 == '-') {
                        ++var7_7;
                        break;
                    }
                    if (var23_13 == 'T') {
                        var7_7 = 3;
                        break;
                    }
                    var7_7 = -1;
                    break;
                }
                case 2: {
                    if (var23_13 == 'T') {
                        var7_7 = 3;
                        break;
                    }
                    var7_7 = -1;
                    break;
                }
                case 3: {
                    if (var23_13 == ':') {
                        var7_7 = 4;
                        break;
                    }
                    var7_7 = -1;
                    break;
                }
                case 7: {
                    if (var23_13 != ':') {
                        --var6_6;
                    }
                    var7_7 = 8;
                    break;
                }
                case 4: {
                    if (var23_13 == ':') {
                        var7_7 = 5;
                        break;
                    }
                    if (var23_13 == '+' || var23_13 == '-') {
                        var7_7 = 7;
                        break;
                    }
                    var7_7 = -1;
                    break;
                }
                case 5: {
                    if (var23_13 == '.') {
                        var7_7 = 6;
                        break;
                    }
                    if (var23_13 == '+' || var23_13 == '-') {
                        var7_7 = 7;
                        break;
                    }
                    var7_7 = -1;
                    break;
                }
                case 6: {
                    if (var23_13 == '+' || var23_13 == '-') {
                        var7_7 = 7;
                        break;
                    }
                    var7_7 = -1;
                    break;
                }
                case 8: {
                    var7_7 = -1;
                }
            }
            if (var7_7 != 7) continue;
            if (var23_13 == '-') {
                var4_4 = -1;
                continue;
            }
            var4_4 = 1;
        } while (true);
        if (var8_15 < -8.64E15) return ScriptRuntime.NaN;
        if (!(var8_15 > 8.64E15)) return var8_15;
        return ScriptRuntime.NaN;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static String toLocale_helper(double d, int n) {
        DateFormat dateFormat;
        switch (n) {
            default: {
                throw new AssertionError();
            }
            case 5: {
                if (localeDateTimeFormatter == null) {
                    localeDateTimeFormatter = DateFormat.getDateTimeInstance((int)1, (int)1);
                }
                dateFormat = localeDateTimeFormatter;
                break;
            }
            case 6: {
                if (localeTimeFormatter == null) {
                    localeTimeFormatter = DateFormat.getTimeInstance((int)1);
                }
                dateFormat = localeTimeFormatter;
                break;
            }
            case 7: {
                if (localeDateFormatter == null) {
                    localeDateFormatter = DateFormat.getDateInstance((int)1);
                }
                dateFormat = localeDateFormatter;
            }
        }
        DateFormat dateFormat2 = dateFormat;
        synchronized (dateFormat2) {
            return dateFormat.format(new Date((long)d));
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(DATE_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                if (scriptable2 instanceof NativeDate) break;
                throw NativeDate.incompatibleCallError(idFunctionObject);
            }
            case -3: {
                return ScriptRuntime.wrapNumber(NativeDate.now());
            }
            case -2: {
                return ScriptRuntime.wrapNumber(NativeDate.date_parseString(ScriptRuntime.toString(arrobject, 0)));
            }
            case -1: {
                return ScriptRuntime.wrapNumber(NativeDate.jsStaticFunction_UTC(arrobject));
            }
            case 1: {
                if (scriptable2 == null) return NativeDate.jsConstructor(arrobject);
                return NativeDate.date_format(NativeDate.now(), 2);
            }
            case 47: {
                Object object;
                Scriptable scriptable3 = ScriptRuntime.toObject(context, scriptable, scriptable2);
                Object object2 = ScriptRuntime.toPrimitive(scriptable3, ScriptRuntime.NumberClass);
                if (object2 instanceof Number) {
                    double d = ((Number)object2).doubleValue();
                    if (d != d) return null;
                    if (Double.isInfinite((double)d)) {
                        return null;
                    }
                }
                if ((object = ScriptableObject.getProperty(scriptable3, "toISOString")) == NOT_FOUND) {
                    throw ScriptRuntime.typeError2("msg.function.not.found.in", "toISOString", ScriptRuntime.toString(scriptable3));
                }
                if (!(object instanceof Callable)) {
                    throw ScriptRuntime.typeError3("msg.isnt.function.in", "toISOString", ScriptRuntime.toString(scriptable3), ScriptRuntime.toString(object));
                }
                Object object3 = ((Callable)object).call(context, scriptable, scriptable3, ScriptRuntime.emptyArgs);
                if (ScriptRuntime.isPrimitive(object3)) return object3;
                throw ScriptRuntime.typeError1("msg.toisostring.must.return.primitive", ScriptRuntime.toString(object3));
            }
        }
        NativeDate nativeDate = (NativeDate)scriptable2;
        double d = nativeDate.date;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 2: 
            case 3: 
            case 4: {
                if (d != d) return js_NaN_date_str;
                return NativeDate.date_format(d, n);
            }
            case 5: 
            case 6: 
            case 7: {
                if (d != d) return js_NaN_date_str;
                return NativeDate.toLocale_helper(d, n);
            }
            case 8: {
                if (d != d) return js_NaN_date_str;
                return NativeDate.js_toUTCString(d);
            }
            case 9: {
                return "(new Date(" + ScriptRuntime.toString(d) + "))";
            }
            case 10: 
            case 11: {
                return ScriptRuntime.wrapNumber(d);
            }
            case 12: 
            case 13: 
            case 14: {
                if (d != d) return ScriptRuntime.wrapNumber(d);
                if (n != 14) {
                    d = NativeDate.LocalTime(d);
                }
                d = NativeDate.YearFromTime(d);
                if (n != 12) return ScriptRuntime.wrapNumber(d);
                if (context.hasFeature(1)) {
                    if (!(1900.0 <= d)) return ScriptRuntime.wrapNumber(d);
                    if (!(d < 2000.0)) return ScriptRuntime.wrapNumber(d);
                    d -= 1900.0;
                    return ScriptRuntime.wrapNumber(d);
                }
                return ScriptRuntime.wrapNumber(d -= 1900.0);
            }
            case 15: 
            case 16: {
                if (d != d) return ScriptRuntime.wrapNumber(d);
                if (n == 15) {
                    d = NativeDate.LocalTime(d);
                }
                d = NativeDate.MonthFromTime(d);
                return ScriptRuntime.wrapNumber(d);
            }
            case 17: 
            case 18: {
                if (d != d) return ScriptRuntime.wrapNumber(d);
                if (n == 17) {
                    d = NativeDate.LocalTime(d);
                }
                d = NativeDate.DateFromTime(d);
                return ScriptRuntime.wrapNumber(d);
            }
            case 19: 
            case 20: {
                if (d != d) return ScriptRuntime.wrapNumber(d);
                if (n == 19) {
                    d = NativeDate.LocalTime(d);
                }
                d = NativeDate.WeekDay(d);
                return ScriptRuntime.wrapNumber(d);
            }
            case 21: 
            case 22: {
                if (d != d) return ScriptRuntime.wrapNumber(d);
                if (n == 21) {
                    d = NativeDate.LocalTime(d);
                }
                d = NativeDate.HourFromTime(d);
                return ScriptRuntime.wrapNumber(d);
            }
            case 23: 
            case 24: {
                if (d != d) return ScriptRuntime.wrapNumber(d);
                if (n == 23) {
                    d = NativeDate.LocalTime(d);
                }
                d = NativeDate.MinFromTime(d);
                return ScriptRuntime.wrapNumber(d);
            }
            case 25: 
            case 26: {
                if (d != d) return ScriptRuntime.wrapNumber(d);
                if (n == 25) {
                    d = NativeDate.LocalTime(d);
                }
                d = NativeDate.SecFromTime(d);
                return ScriptRuntime.wrapNumber(d);
            }
            case 27: 
            case 28: {
                if (d != d) return ScriptRuntime.wrapNumber(d);
                if (n == 27) {
                    d = NativeDate.LocalTime(d);
                }
                d = NativeDate.msFromTime(d);
                return ScriptRuntime.wrapNumber(d);
            }
            case 29: {
                if (d != d) return ScriptRuntime.wrapNumber(d);
                d = (d - NativeDate.LocalTime(d)) / 60000.0;
                return ScriptRuntime.wrapNumber(d);
            }
            case 30: {
                double d2;
                nativeDate.date = d2 = NativeDate.TimeClip(ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d2);
            }
            case 31: 
            case 32: 
            case 33: 
            case 34: 
            case 35: 
            case 36: 
            case 37: 
            case 38: {
                double d3;
                nativeDate.date = d3 = NativeDate.makeTime(d, arrobject, n);
                return ScriptRuntime.wrapNumber(d3);
            }
            case 39: 
            case 40: 
            case 41: 
            case 42: 
            case 43: 
            case 44: {
                double d4;
                nativeDate.date = d4 = NativeDate.makeDate(d, arrobject, n);
                return ScriptRuntime.wrapNumber(d4);
            }
            case 45: {
                double d5;
                double d6 = ScriptRuntime.toNumber(arrobject, 0);
                if (d6 != d6 || Double.isInfinite((double)d6)) {
                    d5 = ScriptRuntime.NaN;
                } else {
                    double d7 = d != d ? 0.0 : NativeDate.LocalTime(d);
                    if (d6 >= 0.0 && d6 <= 99.0) {
                        d6 += 1900.0;
                    }
                    d5 = NativeDate.TimeClip(NativeDate.internalUTC(NativeDate.MakeDate(NativeDate.MakeDay(d6, NativeDate.MonthFromTime(d7), NativeDate.DateFromTime(d7)), NativeDate.TimeWithinDay(d7))));
                }
                nativeDate.date = d5;
                return ScriptRuntime.wrapNumber(d5);
            }
            case 46: 
        }
        if (d != d) throw ScriptRuntime.constructError("RangeError", ScriptRuntime.getMessage0("msg.invalid.date"));
        return NativeDate.js_toISOString(d);
    }

    @Override
    protected void fillConstructorProperties(IdFunctionObject idFunctionObject) {
        this.addIdFunctionProperty(idFunctionObject, DATE_TAG, -3, "now", 0);
        this.addIdFunctionProperty(idFunctionObject, DATE_TAG, -2, "parse", 1);
        this.addIdFunctionProperty(idFunctionObject, DATE_TAG, -1, "UTC", 7);
        super.fillConstructorProperties(idFunctionObject);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        block0 : switch (n) {
            case 6: {
                char c = string2.charAt(0);
                if (c == 'g') {
                    string3 = "getDay";
                    n2 = 19;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "toJSON";
                n2 = 47;
                break;
            }
            case 7: {
                switch (string2.charAt(3)) {
                    default: {
                        return 0;
                    }
                    case 'D': {
                        char c = string2.charAt(0);
                        if (c == 'g') {
                            string3 = "getDate";
                            n2 = 17;
                            break block0;
                        }
                        string3 = null;
                        n2 = 0;
                        if (c != 's') break block0;
                        string3 = "setDate";
                        n2 = 39;
                        break block0;
                    }
                    case 'T': {
                        char c = string2.charAt(0);
                        if (c == 'g') {
                            string3 = "getTime";
                            n2 = 11;
                            break block0;
                        }
                        string3 = null;
                        n2 = 0;
                        if (c != 's') break block0;
                        string3 = "setTime";
                        n2 = 30;
                        break block0;
                    }
                    case 'Y': {
                        char c = string2.charAt(0);
                        if (c == 'g') {
                            string3 = "getYear";
                            n2 = 12;
                            break block0;
                        }
                        string3 = null;
                        n2 = 0;
                        if (c != 's') break block0;
                        string3 = "setYear";
                        n2 = 45;
                        break block0;
                    }
                    case 'u': 
                }
                string3 = "valueOf";
                n2 = 10;
                break;
            }
            case 8: {
                switch (string2.charAt(3)) {
                    default: {
                        return 0;
                    }
                    case 'H': {
                        char c = string2.charAt(0);
                        if (c == 'g') {
                            string3 = "getHours";
                            n2 = 21;
                            break block0;
                        }
                        string3 = null;
                        n2 = 0;
                        if (c != 's') break block0;
                        string3 = "setHours";
                        n2 = 37;
                        break block0;
                    }
                    case 'M': {
                        char c = string2.charAt(0);
                        if (c == 'g') {
                            string3 = "getMonth";
                            n2 = 15;
                            break block0;
                        }
                        string3 = null;
                        n2 = 0;
                        if (c != 's') break block0;
                        string3 = "setMonth";
                        n2 = 41;
                        break block0;
                    }
                    case 'o': {
                        string3 = "toSource";
                        n2 = 9;
                        break block0;
                    }
                    case 't': 
                }
                string3 = "toString";
                n2 = 2;
                break;
            }
            case 9: {
                string3 = "getUTCDay";
                n2 = 20;
                break;
            }
            case 10: {
                char c = string2.charAt(3);
                if (c == 'M') {
                    char c2 = string2.charAt(0);
                    if (c2 == 'g') {
                        string3 = "getMinutes";
                        n2 = 23;
                        break;
                    }
                    string3 = null;
                    n2 = 0;
                    if (c2 != 's') break;
                    string3 = "setMinutes";
                    n2 = 35;
                    break;
                }
                if (c == 'S') {
                    char c3 = string2.charAt(0);
                    if (c3 == 'g') {
                        string3 = "getSeconds";
                        n2 = 25;
                        break;
                    }
                    string3 = null;
                    n2 = 0;
                    if (c3 != 's') break;
                    string3 = "setSeconds";
                    n2 = 33;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'U') break;
                char c4 = string2.charAt(0);
                if (c4 == 'g') {
                    string3 = "getUTCDate";
                    n2 = 18;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c4 != 's') break;
                string3 = "setUTCDate";
                n2 = 40;
                break;
            }
            case 11: {
                switch (string2.charAt(3)) {
                    default: {
                        return 0;
                    }
                    case 'F': {
                        char c = string2.charAt(0);
                        if (c == 'g') {
                            string3 = "getFullYear";
                            n2 = 13;
                            break block0;
                        }
                        string3 = null;
                        n2 = 0;
                        if (c != 's') break block0;
                        string3 = "setFullYear";
                        n2 = 43;
                        break block0;
                    }
                    case 'M': {
                        string3 = "toGMTString";
                        n2 = 8;
                        break block0;
                    }
                    case 'S': {
                        string3 = "toISOString";
                        n2 = 46;
                        break block0;
                    }
                    case 'T': {
                        string3 = "toUTCString";
                        n2 = 8;
                        break block0;
                    }
                    case 'U': {
                        char c = string2.charAt(0);
                        if (c == 'g') {
                            char c5 = string2.charAt(9);
                            if (c5 == 'r') {
                                string3 = "getUTCHours";
                                n2 = 22;
                                break block0;
                            }
                            string3 = null;
                            n2 = 0;
                            if (c5 != 't') break block0;
                            string3 = "getUTCMonth";
                            n2 = 16;
                            break block0;
                        }
                        string3 = null;
                        n2 = 0;
                        if (c != 's') break block0;
                        char c6 = string2.charAt(9);
                        if (c6 == 'r') {
                            string3 = "setUTCHours";
                            n2 = 38;
                            break block0;
                        }
                        string3 = null;
                        n2 = 0;
                        if (c6 != 't') break block0;
                        string3 = "setUTCMonth";
                        n2 = 42;
                        break block0;
                    }
                    case 's': 
                }
                string3 = "constructor";
                n2 = 1;
                break;
            }
            case 12: {
                char c = string2.charAt(2);
                if (c == 'D') {
                    string3 = "toDateString";
                    n2 = 4;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'T') break;
                string3 = "toTimeString";
                n2 = 3;
                break;
            }
            case 13: {
                char c = string2.charAt(0);
                if (c == 'g') {
                    char c7 = string2.charAt(6);
                    if (c7 == 'M') {
                        string3 = "getUTCMinutes";
                        n2 = 24;
                        break;
                    }
                    string3 = null;
                    n2 = 0;
                    if (c7 != 'S') break;
                    string3 = "getUTCSeconds";
                    n2 = 26;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 's') break;
                char c8 = string2.charAt(6);
                if (c8 == 'M') {
                    string3 = "setUTCMinutes";
                    n2 = 36;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c8 != 'S') break;
                string3 = "setUTCSeconds";
                n2 = 34;
                break;
            }
            case 14: {
                char c = string2.charAt(0);
                if (c == 'g') {
                    string3 = "getUTCFullYear";
                    n2 = 14;
                    break;
                }
                if (c == 's') {
                    string3 = "setUTCFullYear";
                    n2 = 44;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "toLocaleString";
                n2 = 5;
                break;
            }
            case 15: {
                char c = string2.charAt(0);
                if (c == 'g') {
                    string3 = "getMilliseconds";
                    n2 = 27;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 's') break;
                string3 = "setMilliseconds";
                n2 = 31;
                break;
            }
            case 17: {
                string3 = "getTimezoneOffset";
                n2 = 29;
                break;
            }
            case 18: {
                char c = string2.charAt(0);
                if (c == 'g') {
                    string3 = "getUTCMilliseconds";
                    n2 = 28;
                    break;
                }
                if (c == 's') {
                    string3 = "setUTCMilliseconds";
                    n2 = 32;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                char c9 = string2.charAt(8);
                if (c9 == 'D') {
                    string3 = "toLocaleDateString";
                    n2 = 7;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c9 != 'T') break;
                string3 = "toLocaleTimeString";
                n2 = 6;
                break;
            }
        }
        if (string3 == null) return n2;
        if (string3 == string2) return n2;
        if (string3.equals((Object)string2)) return n2;
        return 0;
    }

    @Override
    public String getClassName() {
        return "Date";
    }

    @Override
    public Object getDefaultValue(Class<?> class_) {
        if (class_ == null) {
            class_ = ScriptRuntime.StringClass;
        }
        return super.getDefaultValue(class_);
    }

    double getJSTimeValue() {
        return this.date;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 7;
                string2 = "constructor";
                break;
            }
            case 2: {
                string2 = "toString";
                n2 = 0;
                break;
            }
            case 3: {
                string2 = "toTimeString";
                n2 = 0;
                break;
            }
            case 4: {
                string2 = "toDateString";
                n2 = 0;
                break;
            }
            case 5: {
                string2 = "toLocaleString";
                n2 = 0;
                break;
            }
            case 6: {
                string2 = "toLocaleTimeString";
                n2 = 0;
                break;
            }
            case 7: {
                string2 = "toLocaleDateString";
                n2 = 0;
                break;
            }
            case 8: {
                string2 = "toUTCString";
                n2 = 0;
                break;
            }
            case 9: {
                string2 = "toSource";
                n2 = 0;
                break;
            }
            case 10: {
                string2 = "valueOf";
                n2 = 0;
                break;
            }
            case 11: {
                string2 = "getTime";
                n2 = 0;
                break;
            }
            case 12: {
                string2 = "getYear";
                n2 = 0;
                break;
            }
            case 13: {
                string2 = "getFullYear";
                n2 = 0;
                break;
            }
            case 14: {
                string2 = "getUTCFullYear";
                n2 = 0;
                break;
            }
            case 15: {
                string2 = "getMonth";
                n2 = 0;
                break;
            }
            case 16: {
                string2 = "getUTCMonth";
                n2 = 0;
                break;
            }
            case 17: {
                string2 = "getDate";
                n2 = 0;
                break;
            }
            case 18: {
                string2 = "getUTCDate";
                n2 = 0;
                break;
            }
            case 19: {
                string2 = "getDay";
                n2 = 0;
                break;
            }
            case 20: {
                string2 = "getUTCDay";
                n2 = 0;
                break;
            }
            case 21: {
                string2 = "getHours";
                n2 = 0;
                break;
            }
            case 22: {
                string2 = "getUTCHours";
                n2 = 0;
                break;
            }
            case 23: {
                string2 = "getMinutes";
                n2 = 0;
                break;
            }
            case 24: {
                string2 = "getUTCMinutes";
                n2 = 0;
                break;
            }
            case 25: {
                string2 = "getSeconds";
                n2 = 0;
                break;
            }
            case 26: {
                string2 = "getUTCSeconds";
                n2 = 0;
                break;
            }
            case 27: {
                string2 = "getMilliseconds";
                n2 = 0;
                break;
            }
            case 28: {
                string2 = "getUTCMilliseconds";
                n2 = 0;
                break;
            }
            case 29: {
                string2 = "getTimezoneOffset";
                n2 = 0;
                break;
            }
            case 30: {
                n2 = 1;
                string2 = "setTime";
                break;
            }
            case 31: {
                n2 = 1;
                string2 = "setMilliseconds";
                break;
            }
            case 32: {
                n2 = 1;
                string2 = "setUTCMilliseconds";
                break;
            }
            case 33: {
                n2 = 2;
                string2 = "setSeconds";
                break;
            }
            case 34: {
                n2 = 2;
                string2 = "setUTCSeconds";
                break;
            }
            case 35: {
                n2 = 3;
                string2 = "setMinutes";
                break;
            }
            case 36: {
                n2 = 3;
                string2 = "setUTCMinutes";
                break;
            }
            case 37: {
                n2 = 4;
                string2 = "setHours";
                break;
            }
            case 38: {
                n2 = 4;
                string2 = "setUTCHours";
                break;
            }
            case 39: {
                n2 = 1;
                string2 = "setDate";
                break;
            }
            case 40: {
                n2 = 1;
                string2 = "setUTCDate";
                break;
            }
            case 41: {
                n2 = 2;
                string2 = "setMonth";
                break;
            }
            case 42: {
                n2 = 2;
                string2 = "setUTCMonth";
                break;
            }
            case 43: {
                n2 = 3;
                string2 = "setFullYear";
                break;
            }
            case 44: {
                n2 = 3;
                string2 = "setUTCFullYear";
                break;
            }
            case 45: {
                n2 = 1;
                string2 = "setYear";
                break;
            }
            case 46: {
                string2 = "toISOString";
                n2 = 0;
                break;
            }
            case 47: {
                n2 = 1;
                string2 = "toJSON";
            }
        }
        this.initPrototypeMethod(DATE_TAG, n, string2, n2);
    }
}

