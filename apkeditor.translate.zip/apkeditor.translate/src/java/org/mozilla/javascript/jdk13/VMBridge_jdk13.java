/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalStateException
 *  java.lang.InstantiationException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.ThreadLocal
 *  java.lang.reflect.AccessibleObject
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.InvocationHandler
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Member
 *  java.lang.reflect.Method
 *  java.lang.reflect.Proxy
 */
package org.mozilla.javascript.jdk13;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextFactory;
import org.mozilla.javascript.InterfaceAdapter;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.VMBridge;

public class VMBridge_jdk13
extends VMBridge {
    private ThreadLocal<Object[]> contextLocal = new ThreadLocal();

    @Override
    protected Context getContext(Object object) {
        return (Context)((Object[])object)[0];
    }

    @Override
    protected ClassLoader getCurrentThreadClassLoader() {
        return Thread.currentThread().getContextClassLoader();
    }

    @Override
    protected Object getInterfaceProxyHelper(ContextFactory contextFactory, Class<?>[] arrclass) {
        Class class_ = Proxy.getProxyClass((ClassLoader)arrclass[0].getClassLoader(), arrclass);
        try {
            Constructor constructor = class_.getConstructor(new Class[]{InvocationHandler.class});
            return constructor;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw Kit.initCause((RuntimeException)new IllegalStateException(), noSuchMethodException);
        }
    }

    @Override
    protected Object getThreadContextHelper() {
        Object[] arrobject = (Object[])this.contextLocal.get();
        if (arrobject == null) {
            arrobject = new Object[1];
            this.contextLocal.set((Object)arrobject);
        }
        return arrobject;
    }

    @Override
    protected boolean isVarArgs(Member member) {
        return false;
    }

    @Override
    protected Object newInterfaceProxy(Object object, final ContextFactory contextFactory, final InterfaceAdapter interfaceAdapter, final Object object2, final Scriptable scriptable) {
        Constructor constructor = (Constructor)object;
        InvocationHandler invocationHandler = new InvocationHandler(){

            public Object invoke(Object object, Method method, Object[] arrobject) {
                if (method.getDeclaringClass() == Object.class) {
                    String string2 = method.getName();
                    if (string2.equals((Object)"equals")) {
                        Object object22 = arrobject[0];
                        boolean bl = false;
                        if (object == object22) {
                            bl = true;
                        }
                        return bl;
                    }
                    if (string2.equals((Object)"hashCode")) {
                        return object2.hashCode();
                    }
                    if (string2.equals((Object)"toString")) {
                        return "Proxy[" + object2.toString() + "]";
                    }
                }
                return interfaceAdapter.invoke(contextFactory, object2, scriptable, object, method, arrobject);
            }
        };
        try {
            Object object3 = constructor.newInstance(new Object[]{invocationHandler});
            return object3;
        }
        catch (InvocationTargetException invocationTargetException) {
            throw Context.throwAsScriptRuntimeEx(invocationTargetException);
        }
        catch (IllegalAccessException illegalAccessException) {
            throw Kit.initCause((RuntimeException)new IllegalStateException(), illegalAccessException);
        }
        catch (InstantiationException instantiationException) {
            throw Kit.initCause((RuntimeException)new IllegalStateException(), instantiationException);
        }
    }

    @Override
    protected void setContext(Object object, Context context) {
        ((Object[])object)[0] = context;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean tryToMakeAccessible(Object object) {
        boolean bl = true;
        if (!(object instanceof AccessibleObject)) {
            return false;
        }
        AccessibleObject accessibleObject = (AccessibleObject)object;
        if (accessibleObject.isAccessible()) return bl;
        try {
            accessibleObject.setAccessible(true);
        }
        catch (Exception exception) {
            return accessibleObject.isAccessible();
        }
        do {
            return accessibleObject.isAccessible();
            break;
        } while (true);
    }

}

