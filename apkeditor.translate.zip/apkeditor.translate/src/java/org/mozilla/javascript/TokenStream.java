/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.Reader
 *  java.lang.AssertionError
 *  java.lang.Character
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.StringBuilder
 *  java.lang.System
 */
package org.mozilla.javascript;

import java.io.IOException;
import java.io.Reader;
import org.mozilla.javascript.CompilerEnvirons;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.ObjToIntMap;
import org.mozilla.javascript.Parser;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Token;

class TokenStream {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    private static final char BYTE_ORDER_MARK = '\ufeff';
    private static final int EOF_CHAR = -1;
    private ObjToIntMap allStrings = new ObjToIntMap(50);
    private int commentCursor = -1;
    private String commentPrefix = "";
    Token.CommentType commentType;
    int cursor;
    private boolean dirtyLine;
    private boolean hitEOF = false;
    private boolean isHex;
    private boolean isOctal;
    private int lineEndChar = -1;
    private int lineStart = 0;
    int lineno;
    private double number;
    private Parser parser;
    private int quoteChar;
    String regExpFlags;
    private char[] sourceBuffer;
    int sourceCursor;
    private int sourceEnd;
    private Reader sourceReader;
    private String sourceString;
    private String string = "";
    private char[] stringBuffer = new char[128];
    private int stringBufferTop;
    int tokenBeg;
    int tokenEnd;
    private final int[] ungetBuffer = new int[3];
    private int ungetCursor;
    private boolean xmlIsAttribute;
    private boolean xmlIsTagContent;
    private int xmlOpenTagsCount;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !TokenStream.class.desiredAssertionStatus();
        $assertionsDisabled = bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    TokenStream(Parser parser, Reader reader, String string2, int n) {
        this.parser = parser;
        this.lineno = n;
        if (reader != null) {
            if (string2 != null) {
                Kit.codeBug();
            }
            this.sourceReader = reader;
            this.sourceBuffer = new char[512];
            this.sourceEnd = 0;
        } else {
            if (string2 == null) {
                Kit.codeBug();
            }
            this.sourceString = string2;
            this.sourceEnd = string2.length();
        }
        this.cursor = 0;
        this.sourceCursor = 0;
    }

    private void addToString(int n) {
        int n2 = this.stringBufferTop;
        if (n2 == this.stringBuffer.length) {
            char[] arrc = new char[2 * this.stringBuffer.length];
            System.arraycopy((Object)this.stringBuffer, (int)0, (Object)arrc, (int)0, (int)n2);
            this.stringBuffer = arrc;
        }
        this.stringBuffer[n2] = (char)n;
        this.stringBufferTop = n2 + 1;
    }

    private boolean canUngetChar() {
        return this.ungetCursor == 0 || this.ungetBuffer[-1 + this.ungetCursor] != 10;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private final int charAt(int n) {
        int n2;
        block4 : {
            if (n < 0) return -1;
            if (this.sourceString != null) {
                if (n >= this.sourceEnd) return -1;
                return this.sourceString.charAt(n);
            }
            if (n < this.sourceEnd) return this.sourceBuffer[n];
            n2 = this.sourceCursor;
            try {
                boolean bl = this.fillSourceBuffer();
                if (bl) break block4;
            }
            catch (IOException iOException) {
                return -1;
            }
            return -1;
        }
        n -= n2 - this.sourceCursor;
        return this.sourceBuffer[n];
    }

    private String convertLastCharToHex(String string2) {
        int n = -1 + string2.length();
        StringBuffer stringBuffer = new StringBuffer(string2.substring(0, n));
        stringBuffer.append("\\u");
        String string3 = Integer.toHexString((int)string2.charAt(n));
        for (int i = 0; i < 4 - string3.length(); ++i) {
            stringBuffer.append('0');
        }
        stringBuffer.append(string3);
        return stringBuffer.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean fillSourceBuffer() throws IOException {
        int n;
        if (this.sourceString != null) {
            Kit.codeBug();
        }
        if (this.sourceEnd == this.sourceBuffer.length) {
            if (this.lineStart != 0 && !this.isMarkingComment()) {
                System.arraycopy((Object)this.sourceBuffer, (int)this.lineStart, (Object)this.sourceBuffer, (int)0, (int)(this.sourceEnd - this.lineStart));
                this.sourceEnd -= this.lineStart;
                this.sourceCursor -= this.lineStart;
                this.lineStart = 0;
            } else {
                char[] arrc = new char[2 * this.sourceBuffer.length];
                System.arraycopy((Object)this.sourceBuffer, (int)0, (Object)arrc, (int)0, (int)this.sourceEnd);
                this.sourceBuffer = arrc;
            }
        }
        if ((n = this.sourceReader.read(this.sourceBuffer, this.sourceEnd, this.sourceBuffer.length - this.sourceEnd)) < 0) {
            return false;
        }
        this.sourceEnd = n + this.sourceEnd;
        return true;
    }

    private int getChar() throws IOException {
        return this.getChar(true);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private int getChar(boolean var1_1) throws IOException {
        if (this.ungetCursor == 0) ** GOTO lbl19
        this.cursor = 1 + this.cursor;
        var7_2 = this.ungetBuffer;
        this.ungetCursor = var8_3 = -1 + this.ungetCursor;
        return var7_2[var8_3];
        {
            this.cursor = 1 + this.cursor;
            var5_7 = this.sourceString;
            var6_8 = this.sourceCursor;
            this.sourceCursor = var6_8 + 1;
            var4_4 = var5_7.charAt(var6_8);
            block1 : while (this.lineEndChar >= 0) {
                if (this.lineEndChar == 13 && var4_4 == 10) {
                    this.lineEndChar = 10;
                } else {
                    this.lineEndChar = -1;
                    this.lineStart = -1 + this.sourceCursor;
                    this.lineno = 1 + this.lineno;
                    break block0;
                }
lbl19: // 3 sources:
                do {
                    if (this.sourceString != null) {
                        if (this.sourceCursor != this.sourceEnd) continue block0;
                        this.hitEOF = true;
                        return -1;
                    }
                    if (this.sourceCursor == this.sourceEnd && !this.fillSourceBuffer()) {
                        this.hitEOF = true;
                        return -1;
                    }
                    this.cursor = 1 + this.cursor;
                    var2_5 = this.sourceBuffer;
                    var3_6 = this.sourceCursor;
                    this.sourceCursor = var3_6 + 1;
                    var4_4 = var2_5[var3_6];
                    continue block1;
                    break;
                } while (true);
            }
            break block0;
        }
        if (var4_4 <= 127) {
            if (var4_4 != 10) {
                if (var4_4 != 13) return var4_4;
            }
            this.lineEndChar = var4_4;
            return 10;
        }
        if (var4_4 == 65279) return var4_4;
        ** while (var1_1 && TokenStream.isJSFormatChar((int)var4_4))
lbl40: // 1 sources:
        if (ScriptRuntime.isJSLineTerminator(var4_4) == false) return var4_4;
        this.lineEndChar = var4_4;
        return 10;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private int getCharIgnoreLineEnd() throws IOException {
        if (this.ungetCursor == 0) ** GOTO lbl10
        this.cursor = 1 + this.cursor;
        var6_1 = this.ungetBuffer;
        this.ungetCursor = var7_2 = -1 + this.ungetCursor;
        return var6_1[var7_2];
lbl-1000: // 1 sources:
        {
            if (!TokenStream.isJSFormatChar(var3_3)) {
                if (ScriptRuntime.isJSLineTerminator(var3_3) == false) return var3_3;
                this.lineEndChar = var3_3;
                return 10;
            }
lbl10: // 3 sources:
            if (this.sourceString != null) {
                if (this.sourceCursor == this.sourceEnd) {
                    this.hitEOF = true;
                    return -1;
                }
                this.cursor = 1 + this.cursor;
                var4_6 = this.sourceString;
                var5_7 = this.sourceCursor;
                this.sourceCursor = var5_7 + 1;
                var3_3 = var4_6.charAt(var5_7);
            } else {
                if (this.sourceCursor == this.sourceEnd && !this.fillSourceBuffer()) {
                    this.hitEOF = true;
                    return -1;
                }
                this.cursor = 1 + this.cursor;
                var1_4 = this.sourceBuffer;
                var2_5 = this.sourceCursor;
                this.sourceCursor = var2_5 + 1;
                var3_3 = var1_4[var2_5];
            }
            if (var3_3 > 127) continue;
            if (var3_3 != 10) {
                if (var3_3 != 13) return var3_3;
            }
            this.lineEndChar = var3_3;
            return 10;
            ** while (var3_3 != 65279)
        }
lbl34: // 1 sources:
        return var3_3;
    }

    private String getStringFromBuffer() {
        this.tokenEnd = this.cursor;
        return new String(this.stringBuffer, 0, this.stringBufferTop);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean isAlpha(int n) {
        if (n <= 90) {
            if (65 <= n) return true;
            return false;
        }
        if (97 > n || n > 122) return false;
        return true;
    }

    static boolean isDigit(int n) {
        return 48 <= n && n <= 57;
    }

    private static boolean isJSFormatChar(int n) {
        return n > 127 && Character.getType((char)((char)n)) == 16;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static boolean isJSSpace(int n) {
        boolean bl;
        if (n <= 127) {
            if (n == 32) return true;
            if (n == 9) return true;
            if (n == 12) return true;
            bl = false;
            if (n != 11) return bl;
            return true;
        }
        if (n == 160) return true;
        if (n == 65279) return true;
        int n2 = Character.getType((char)((char)n));
        bl = false;
        if (n2 != 12) return bl;
        return true;
    }

    static boolean isKeyword(String string2) {
        return TokenStream.stringToKeyword(string2) != 0;
    }

    private boolean isMarkingComment() {
        return this.commentCursor != -1;
    }

    private void markCommentStart() {
        this.markCommentStart("");
    }

    private void markCommentStart(String string2) {
        if (this.parser.compilerEnv.isRecordingComments() && this.sourceReader != null) {
            this.commentPrefix = string2;
            this.commentCursor = -1 + this.sourceCursor;
        }
    }

    private boolean matchChar(int n) throws IOException {
        int n2 = this.getCharIgnoreLineEnd();
        if (n2 == n) {
            this.tokenEnd = this.cursor;
            return true;
        }
        this.ungetCharIgnoreLineEnd(n2);
        return false;
    }

    private int peekChar() throws IOException {
        int n = this.getChar();
        this.ungetChar(n);
        return n;
    }

    private boolean readCDATA() throws IOException {
        int n = this.getChar();
        while (n != -1) {
            this.addToString(n);
            if (n == 93 && this.peekChar() == 93) {
                n = this.getChar();
                this.addToString(n);
                if (this.peekChar() != 62) continue;
                this.addToString(this.getChar());
                return true;
            }
            n = this.getChar();
        }
        this.stringBufferTop = 0;
        this.string = null;
        this.parser.addError("msg.XML.bad.form");
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean readEntity() throws IOException {
        int n = 1;
        int n2 = this.getChar();
        do {
            if (n2 == -1) {
                this.stringBufferTop = 0;
                this.string = null;
                this.parser.addError("msg.XML.bad.form");
                return false;
            }
            this.addToString(n2);
            switch (n2) {
                case 60: {
                    ++n;
                }
                default: {
                    break;
                }
                case 62: {
                    if (--n != 0) break;
                    return true;
                }
            }
            n2 = this.getChar();
        } while (true);
    }

    private boolean readPI() throws IOException {
        int n = this.getChar();
        while (n != -1) {
            this.addToString(n);
            if (n == 63 && this.peekChar() == 62) {
                this.addToString(this.getChar());
                return true;
            }
            n = this.getChar();
        }
        this.stringBufferTop = 0;
        this.string = null;
        this.parser.addError("msg.XML.bad.form");
        return false;
    }

    private boolean readQuotedString(int n) throws IOException {
        int n2 = this.getChar();
        while (n2 != -1) {
            this.addToString(n2);
            if (n2 == n) {
                return true;
            }
            n2 = this.getChar();
        }
        this.stringBufferTop = 0;
        this.string = null;
        this.parser.addError("msg.XML.bad.form");
        return false;
    }

    private boolean readXmlComment() throws IOException {
        int n = this.getChar();
        while (n != -1) {
            this.addToString(n);
            if (n == 45 && this.peekChar() == 45) {
                n = this.getChar();
                this.addToString(n);
                if (this.peekChar() != 62) continue;
                this.addToString(this.getChar());
                return true;
            }
            n = this.getChar();
        }
        this.stringBufferTop = 0;
        this.string = null;
        this.parser.addError("msg.XML.bad.form");
        return false;
    }

    private void skipLine() throws IOException {
        int n;
        while ((n = this.getChar()) != -1 && n != 10) {
        }
        this.ungetChar(n);
        this.tokenEnd = this.cursor;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int stringToKeyword(String string2) {
        int n;
        block87 : {
            int n2 = string2.length();
            String string3 = null;
            n = 0;
            block0 : switch (n2) {
                case 2: {
                    char c = string2.charAt(1);
                    if (c == 'f') {
                        char c2 = string2.charAt(0);
                        string3 = null;
                        n = 0;
                        if (c2 != 'i') break;
                        n = 112;
                    } else if (c == 'n') {
                        char c3 = string2.charAt(0);
                        string3 = null;
                        n = 0;
                        if (c3 != 'i') break;
                        n = 52;
                    } else {
                        string3 = null;
                        n = 0;
                        if (c != 'o') break;
                        char c4 = string2.charAt(0);
                        string3 = null;
                        n = 0;
                        if (c4 != 'd') break;
                        n = 118;
                    }
                    break block87;
                }
                case 3: {
                    switch (string2.charAt(0)) {
                        default: {
                            string3 = null;
                            n = 0;
                            break block0;
                        }
                        case 'f': {
                            char c = string2.charAt(2);
                            string3 = null;
                            n = 0;
                            if (c != 'r') break block0;
                            char c5 = string2.charAt(1);
                            string3 = null;
                            n = 0;
                            if (c5 != 'o') break block0;
                            n = 119;
                            break;
                        }
                        case 'i': {
                            char c = string2.charAt(2);
                            string3 = null;
                            n = 0;
                            if (c != 't') break block0;
                            char c6 = string2.charAt(1);
                            string3 = null;
                            n = 0;
                            if (c6 != 'n') break block0;
                            n = 127;
                            break;
                        }
                        case 'l': {
                            char c = string2.charAt(2);
                            string3 = null;
                            n = 0;
                            if (c != 't') break block0;
                            char c7 = string2.charAt(1);
                            string3 = null;
                            n = 0;
                            if (c7 != 'e') break block0;
                            n = 153;
                            break;
                        }
                        case 'n': {
                            char c = string2.charAt(2);
                            string3 = null;
                            n = 0;
                            if (c != 'w') break block0;
                            char c8 = string2.charAt(1);
                            string3 = null;
                            n = 0;
                            if (c8 != 'e') break block0;
                            n = 30;
                            break;
                        }
                        case 't': {
                            char c = string2.charAt(2);
                            string3 = null;
                            n = 0;
                            if (c != 'y') break block0;
                            char c9 = string2.charAt(1);
                            string3 = null;
                            n = 0;
                            if (c9 != 'r') break block0;
                            n = 81;
                            break;
                        }
                        case 'v': {
                            char c = string2.charAt(2);
                            string3 = null;
                            n = 0;
                            if (c != 'r') break block0;
                            char c10 = string2.charAt(1);
                            string3 = null;
                            n = 0;
                            if (c10 != 'a') break block0;
                            n = 122;
                            break;
                        }
                    }
                    break block87;
                }
                case 4: {
                    switch (string2.charAt(0)) {
                        default: {
                            string3 = null;
                            n = 0;
                            break;
                        }
                        case 'b': {
                            string3 = "byte";
                            n = 127;
                            break;
                        }
                        case 'c': {
                            char c = string2.charAt(3);
                            if (c == 'e') {
                                char c11 = string2.charAt(2);
                                string3 = null;
                                n = 0;
                                if (c11 != 's') break;
                                char c12 = string2.charAt(1);
                                string3 = null;
                                n = 0;
                                if (c12 != 'a') break;
                                n = 115;
                            } else {
                                string3 = null;
                                n = 0;
                                if (c != 'r') break;
                                char c13 = string2.charAt(2);
                                string3 = null;
                                n = 0;
                                if (c13 != 'a') break;
                                char c14 = string2.charAt(1);
                                string3 = null;
                                n = 0;
                                if (c14 != 'h') break;
                                n = 127;
                            }
                            break block87;
                        }
                        case 'e': {
                            char c = string2.charAt(3);
                            if (c == 'e') {
                                char c15 = string2.charAt(2);
                                string3 = null;
                                n = 0;
                                if (c15 != 's') break;
                                char c16 = string2.charAt(1);
                                string3 = null;
                                n = 0;
                                if (c16 != 'l') break;
                                n = 113;
                            } else {
                                string3 = null;
                                n = 0;
                                if (c != 'm') break;
                                char c17 = string2.charAt(2);
                                string3 = null;
                                n = 0;
                                if (c17 != 'u') break;
                                char c18 = string2.charAt(1);
                                string3 = null;
                                n = 0;
                                if (c18 != 'n') break;
                                n = 127;
                            }
                            break block87;
                        }
                        case 'g': {
                            string3 = "goto";
                            n = 127;
                            break;
                        }
                        case 'l': {
                            string3 = "long";
                            n = 127;
                            break;
                        }
                        case 'n': {
                            string3 = "null";
                            n = 42;
                            break;
                        }
                        case 't': {
                            char c = string2.charAt(3);
                            if (c == 'e') {
                                char c19 = string2.charAt(2);
                                string3 = null;
                                n = 0;
                                if (c19 != 'u') break;
                                char c20 = string2.charAt(1);
                                string3 = null;
                                n = 0;
                                if (c20 != 'r') break;
                                n = 45;
                            } else {
                                string3 = null;
                                n = 0;
                                if (c != 's') break;
                                char c21 = string2.charAt(2);
                                string3 = null;
                                n = 0;
                                if (c21 != 'i') break;
                                char c22 = string2.charAt(1);
                                string3 = null;
                                n = 0;
                                if (c22 != 'h') break;
                                n = 43;
                            }
                            break block87;
                        }
                        case 'v': {
                            string3 = "void";
                            n = 126;
                            break;
                        }
                        case 'w': {
                            string3 = "with";
                            n = 123;
                            break;
                        }
                    }
                    break;
                }
                case 5: {
                    switch (string2.charAt(2)) {
                        default: {
                            string3 = null;
                            n = 0;
                            break;
                        }
                        case 'a': {
                            string3 = "class";
                            n = 127;
                            break;
                        }
                        case 'e': {
                            char c = string2.charAt(0);
                            if (c == 'b') {
                                string3 = "break";
                                n = 120;
                                break;
                            }
                            string3 = null;
                            n = 0;
                            if (c != 'y') break;
                            string3 = "yield";
                            n = 72;
                            break;
                        }
                        case 'i': {
                            string3 = "while";
                            n = 117;
                            break;
                        }
                        case 'l': {
                            string3 = "false";
                            n = 44;
                            break;
                        }
                        case 'n': {
                            char c = string2.charAt(0);
                            if (c == 'c') {
                                string3 = "const";
                                n = 154;
                                break;
                            }
                            string3 = null;
                            n = 0;
                            if (c != 'f') break;
                            string3 = "final";
                            n = 127;
                            break;
                        }
                        case 'o': {
                            char c = string2.charAt(0);
                            if (c == 'f') {
                                string3 = "float";
                                n = 127;
                                break;
                            }
                            string3 = null;
                            n = 0;
                            if (c != 's') break;
                            string3 = "short";
                            n = 127;
                            break;
                        }
                        case 'p': {
                            string3 = "super";
                            n = 127;
                            break;
                        }
                        case 'r': {
                            string3 = "throw";
                            n = 50;
                            break;
                        }
                        case 't': {
                            string3 = "catch";
                            n = 124;
                            break;
                        }
                    }
                    break;
                }
                case 6: {
                    switch (string2.charAt(1)) {
                        default: {
                            string3 = null;
                            n = 0;
                            break;
                        }
                        case 'a': {
                            string3 = "native";
                            n = 127;
                            break;
                        }
                        case 'e': {
                            char c = string2.charAt(0);
                            if (c == 'd') {
                                string3 = "delete";
                                n = 31;
                                break;
                            }
                            string3 = null;
                            n = 0;
                            if (c != 'r') break;
                            string3 = "return";
                            n = 4;
                            break;
                        }
                        case 'h': {
                            string3 = "throws";
                            n = 127;
                            break;
                        }
                        case 'm': {
                            string3 = "import";
                            n = 127;
                            break;
                        }
                        case 'o': {
                            string3 = "double";
                            n = 127;
                            break;
                        }
                        case 't': {
                            string3 = "static";
                            n = 127;
                            break;
                        }
                        case 'u': {
                            string3 = "public";
                            n = 127;
                            break;
                        }
                        case 'w': {
                            string3 = "switch";
                            n = 114;
                            break;
                        }
                        case 'x': {
                            string3 = "export";
                            n = 127;
                            break;
                        }
                        case 'y': {
                            string3 = "typeof";
                            n = 32;
                            break;
                        }
                    }
                    break;
                }
                case 7: {
                    switch (string2.charAt(1)) {
                        default: {
                            string3 = null;
                            n = 0;
                            break block0;
                        }
                        case 'a': {
                            string3 = "package";
                            n = 127;
                            break block0;
                        }
                        case 'e': {
                            string3 = "default";
                            n = 116;
                            break block0;
                        }
                        case 'i': {
                            string3 = "finally";
                            n = 125;
                            break block0;
                        }
                        case 'o': {
                            string3 = "boolean";
                            n = 127;
                            break block0;
                        }
                        case 'r': {
                            string3 = "private";
                            n = 127;
                            break block0;
                        }
                        case 'x': 
                    }
                    string3 = "extends";
                    n = 127;
                    break;
                }
                case 8: {
                    switch (string2.charAt(0)) {
                        default: {
                            string3 = null;
                            n = 0;
                            break block0;
                        }
                        case 'a': {
                            string3 = "abstract";
                            n = 127;
                            break block0;
                        }
                        case 'c': {
                            string3 = "continue";
                            n = 121;
                            break block0;
                        }
                        case 'd': {
                            string3 = "debugger";
                            n = 160;
                            break block0;
                        }
                        case 'f': {
                            string3 = "function";
                            n = 109;
                            break block0;
                        }
                        case 'v': 
                    }
                    string3 = "volatile";
                    n = 127;
                    break;
                }
                case 9: {
                    char c = string2.charAt(0);
                    if (c == 'i') {
                        string3 = "interface";
                        n = 127;
                        break;
                    }
                    if (c == 'p') {
                        string3 = "protected";
                        n = 127;
                        break;
                    }
                    string3 = null;
                    n = 0;
                    if (c != 't') break;
                    string3 = "transient";
                    n = 127;
                    break;
                }
                case 10: {
                    char c = string2.charAt(1);
                    if (c == 'm') {
                        string3 = "implements";
                        n = 127;
                        break;
                    }
                    string3 = null;
                    n = 0;
                    if (c != 'n') break;
                    string3 = "instanceof";
                    n = 53;
                    break;
                }
                case 12: {
                    string3 = "synchronized";
                    n = 127;
                }
            }
            if (string3 != null && string3 != string2 && !string3.equals((Object)string2)) {
                return 0;
            }
        }
        if (n != 0) return 255 & n;
        return 0;
    }

    private final String substring(int n, int n2) {
        if (this.sourceString != null) {
            return this.sourceString.substring(n, n2);
        }
        int n3 = n2 - n;
        return new String(this.sourceBuffer, n, n3);
    }

    private void ungetChar(int n) {
        if (this.ungetCursor != 0 && this.ungetBuffer[-1 + this.ungetCursor] == 10) {
            Kit.codeBug();
        }
        int[] arrn = this.ungetBuffer;
        int n2 = this.ungetCursor;
        this.ungetCursor = n2 + 1;
        arrn[n2] = n;
        this.cursor = -1 + this.cursor;
    }

    private void ungetCharIgnoreLineEnd(int n) {
        int[] arrn = this.ungetBuffer;
        int n2 = this.ungetCursor;
        this.ungetCursor = n2 + 1;
        arrn[n2] = n;
        this.cursor = -1 + this.cursor;
    }

    final boolean eof() {
        return this.hitEOF;
    }

    final String getAndResetCurrentComment() {
        if (this.sourceString != null) {
            if (this.isMarkingComment()) {
                Kit.codeBug();
            }
            return this.sourceString.substring(this.tokenBeg, this.tokenEnd);
        }
        if (!this.isMarkingComment()) {
            Kit.codeBug();
        }
        StringBuilder stringBuilder = new StringBuilder(this.commentPrefix);
        stringBuilder.append(this.sourceBuffer, this.commentCursor, this.getTokenLength() - this.commentPrefix.length());
        this.commentCursor = -1;
        return stringBuilder.toString();
    }

    public Token.CommentType getCommentType() {
        return this.commentType;
    }

    public int getCursor() {
        return this.cursor;
    }

    int getFirstXMLToken() throws IOException {
        this.xmlOpenTagsCount = 0;
        this.xmlIsAttribute = false;
        this.xmlIsTagContent = false;
        if (!this.canUngetChar()) {
            return -1;
        }
        this.ungetChar(60);
        return this.getNextXMLToken();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    final String getLine() {
        int n;
        int n2 = this.sourceCursor;
        if (this.lineEndChar >= 0) {
            n = n2 - 1;
            if (this.lineEndChar == 10 && this.charAt(n - 1) == 13) {
                --n;
            }
            do {
                return this.substring(this.lineStart, n);
                break;
            } while (true);
        }
        int n3 = n2 - this.lineStart;
        do {
            int n4;
            if ((n4 = this.charAt(n3 + this.lineStart)) == -1 || ScriptRuntime.isJSLineTerminator(n4)) {
                n = n3 + this.lineStart;
                return this.substring(this.lineStart, n);
            }
            ++n3;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    final String getLine(int n, int[] arrn) {
        int n2;
        if (!($assertionsDisabled || n >= 0 && n <= this.cursor)) {
            throw new AssertionError();
        }
        if (!$assertionsDisabled && arrn.length != 2) {
            throw new AssertionError();
        }
        int n3 = this.cursor + this.ungetCursor - n;
        int n4 = this.sourceCursor;
        if (n3 > n4) {
            return null;
        }
        int n5 = 0;
        int n6 = 0;
        while (n3 > 0) {
            if (!$assertionsDisabled && n4 <= 0) {
                throw new AssertionError();
            }
            int n7 = this.charAt(n4 - 1);
            if (ScriptRuntime.isJSLineTerminator(n7)) {
                if (n7 == 10 && this.charAt(n4 - 2) == 13) {
                    --n3;
                    --n4;
                }
                ++n6;
                n5 = n4 - 1;
            }
            --n3;
            --n4;
        }
        int n8 = 0;
        do {
            block12 : {
                block11 : {
                    n2 = 0;
                    if (n4 <= 0) break block11;
                    if (!ScriptRuntime.isJSLineTerminator(this.charAt(n4 - 1))) break block12;
                    n2 = n4;
                }
                int n9 = this.lineno - n6;
                int n10 = this.lineEndChar >= 0 ? 1 : 0;
                arrn[0] = n10 + n9;
                arrn[1] = n8;
                if (n6 != 0) break;
                return this.getLine();
            }
            --n4;
            ++n8;
        } while (true);
        return this.substring(n2, n5);
    }

    final int getLineno() {
        return this.lineno;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    int getNextXMLToken() throws IOException {
        this.tokenBeg = this.cursor;
        this.stringBufferTop = 0;
        var1_1 = this.getChar();
        block21 : do {
            block27 : {
                if (var1_1 == -1) {
                    this.tokenEnd = this.cursor;
                    this.stringBufferTop = 0;
                    this.string = null;
                    this.parser.addError("msg.XML.bad.form");
                    return -1;
                }
                if (!this.xmlIsTagContent) break block27;
                switch (var1_1) {
                    default: {
                        this.addToString(var1_1);
                        this.xmlIsAttribute = false;
                        break;
                    }
                    case 62: {
                        this.addToString(var1_1);
                        this.xmlIsTagContent = false;
                        this.xmlIsAttribute = false;
                        break;
                    }
                    case 47: {
                        this.addToString(var1_1);
                        if (this.peekChar() != 62) break;
                        this.addToString(this.getChar());
                        this.xmlIsTagContent = false;
                        this.xmlOpenTagsCount = -1 + this.xmlOpenTagsCount;
                        break;
                    }
                    case 123: {
                        this.ungetChar(var1_1);
                        this.string = this.getStringFromBuffer();
                        return 145;
                    }
                    case 34: 
                    case 39: {
                        this.addToString(var1_1);
                        if (this.readQuotedString(var1_1)) break;
                        return -1;
                    }
                    case 61: {
                        this.addToString(var1_1);
                        this.xmlIsAttribute = true;
                        break;
                    }
                    case 9: 
                    case 10: 
                    case 13: 
                    case 32: {
                        this.addToString(var1_1);
                        break;
                    }
                }
                if (!this.xmlIsTagContent && this.xmlOpenTagsCount == 0) {
                    this.string = this.getStringFromBuffer();
                    return 148;
                }
                ** GOTO lbl105
            }
            switch (var1_1) {
                default: {
                    this.addToString(var1_1);
                    ** GOTO lbl105
                }
                case 60: {
                    this.addToString(var1_1);
                    block12 : switch (this.peekChar()) {
                        default: {
                            this.xmlIsTagContent = true;
                            this.xmlOpenTagsCount = 1 + this.xmlOpenTagsCount;
                            break;
                        }
                        case 33: {
                            this.addToString(this.getChar());
                            switch (this.peekChar()) {
                                default: {
                                    if (this.readEntity()) break block12;
                                    return -1;
                                }
                                case 45: {
                                    this.addToString(this.getChar());
                                    var2_2 = this.getChar();
                                    if (var2_2 != 45) {
                                        this.stringBufferTop = 0;
                                        this.string = null;
                                        this.parser.addError("msg.XML.bad.form");
                                        return -1;
                                    }
                                    this.addToString(var2_2);
                                    if (this.readXmlComment()) break block12;
                                    return -1;
                                }
                                case 91: {
                                    this.addToString(this.getChar());
                                    if (this.getChar() == 67 && this.getChar() == 68 && this.getChar() == 65 && this.getChar() == 84 && this.getChar() == 65 && this.getChar() == 91) {
                                        this.addToString(67);
                                        this.addToString(68);
                                        this.addToString(65);
                                        this.addToString(84);
                                        this.addToString(65);
                                        this.addToString(91);
                                        if (this.readCDATA()) break block12;
                                        return -1;
                                    }
                                    this.stringBufferTop = 0;
                                    this.string = null;
                                    this.parser.addError("msg.XML.bad.form");
                                    return -1;
                                }
                            }
                        }
                        case 63: {
                            this.addToString(this.getChar());
                            if (this.readPI()) break;
                            return -1;
                        }
                        case 47: {
                            this.addToString(this.getChar());
                            if (this.xmlOpenTagsCount == 0) {
                                this.stringBufferTop = 0;
                                this.string = null;
                                this.parser.addError("msg.XML.bad.form");
                                return -1;
                            }
                            this.xmlIsTagContent = true;
                            this.xmlOpenTagsCount = -1 + this.xmlOpenTagsCount;
                        }
                    }
lbl105: // 8 sources:
                    var1_1 = this.getChar();
                    continue block21;
                }
                case 123: 
            }
            break;
        } while (true);
        this.ungetChar(var1_1);
        this.string = this.getStringFromBuffer();
        return 145;
    }

    final double getNumber() {
        return this.number;
    }

    final int getOffset() {
        int n = this.sourceCursor - this.lineStart;
        if (this.lineEndChar >= 0) {
            --n;
        }
        return n;
    }

    final char getQuoteChar() {
        return (char)this.quoteChar;
    }

    final String getSourceString() {
        return this.sourceString;
    }

    final String getString() {
        return this.string;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    final int getToken() throws IOException {
        block112 : {
            block117 : {
                block118 : {
                    block111 : {
                        block110 : {
                            block108 : {
                                block109 : {
                                    do {
                                        if ((var1_1 = this.getChar()) == -1) {
                                            this.tokenBeg = -1 + this.cursor;
                                            this.tokenEnd = this.cursor;
                                            return 0;
                                        }
                                        if (var1_1 != 10) continue;
                                        this.dirtyLine = false;
                                        this.tokenBeg = -1 + this.cursor;
                                        this.tokenEnd = this.cursor;
                                        return 1;
                                    } while (TokenStream.isJSSpace(var1_1));
                                    if (var1_1 != 45) {
                                        this.dirtyLine = true;
                                    }
                                    this.tokenBeg = -1 + this.cursor;
                                    this.tokenEnd = this.cursor;
                                    if (var1_1 == 64) {
                                        return 147;
                                    }
                                    if (var1_1 == 92) {
                                        var1_1 = this.getChar();
                                        if (var1_1 == 117) {
                                            var2_3 = true;
                                            var3_4 = true;
                                            this.stringBufferTop = 0;
                                        } else {
                                            this.ungetChar(var1_1);
                                            var1_1 = 92;
                                            var2_3 = false;
                                            var3_4 = false;
                                        }
                                    } else {
                                        var2_3 = Character.isJavaIdentifierStart((char)((char)var1_1));
                                        var3_4 = false;
                                        if (var2_3) {
                                            this.stringBufferTop = 0;
                                            this.addToString(var1_1);
                                            var3_4 = false;
                                        }
                                    }
                                    if (var2_3) break block108;
                                    if (!TokenStream.isDigit(var1_1) && (var1_1 != 46 || !TokenStream.isDigit(this.peekChar()))) break block109;
                                    this.isOctal = false;
                                    this.stringBufferTop = 0;
                                    var4_11 = 10;
                                    this.isOctal = false;
                                    this.isHex = false;
                                    if (var1_1 == 48) {
                                        var1_1 = this.getChar();
                                        if (var1_1 == 120 || var1_1 == 88) {
                                            var4_11 = 16;
                                            this.isHex = true;
                                            var1_1 = this.getChar();
                                        } else if (TokenStream.isDigit(var1_1)) {
                                            var4_11 = 8;
                                            this.isOctal = true;
                                        } else {
                                            this.addToString(48);
                                        }
                                    }
                                    if (var4_11 != 16) break block110;
                                    while (Kit.xDigitToInt(var1_1, 0) >= 0) {
                                        this.addToString(var1_1);
                                        var1_1 = this.getChar();
                                    }
                                    break block111;
                                }
                                if (var1_1 != 34 && var1_1 != 39) {
                                    switch (var1_1) {
                                        default: {
                                            this.parser.addError("msg.illegal.character");
                                            return -1;
                                        }
                                        case 59: {
                                            return 82;
                                        }
                                        case 91: {
                                            return 83;
                                        }
                                        case 93: {
                                            return 84;
                                        }
                                        case 123: {
                                            return 85;
                                        }
                                        case 125: {
                                            return 86;
                                        }
                                        case 40: {
                                            return 87;
                                        }
                                        case 41: {
                                            return 88;
                                        }
                                        case 44: {
                                            return 89;
                                        }
                                        case 63: {
                                            return 102;
                                        }
                                        case 58: {
                                            if (this.matchChar(58) == false) return 103;
                                            return 144;
                                        }
                                        case 46: {
                                            if (this.matchChar(46)) {
                                                return 143;
                                            }
                                            if (this.matchChar(40) == false) return 108;
                                            return 146;
                                        }
                                        case 124: {
                                            if (this.matchChar(124)) {
                                                return 104;
                                            }
                                            if (this.matchChar(61) == false) return 9;
                                            return 91;
                                        }
                                        case 94: {
                                            if (this.matchChar(61) == false) return 10;
                                            return 92;
                                        }
                                        case 38: {
                                            if (this.matchChar(38)) {
                                                return 105;
                                            }
                                            if (this.matchChar(61) == false) return 11;
                                            return 93;
                                        }
                                        case 61: {
                                            if (this.matchChar(61) == false) return 90;
                                            if (this.matchChar(61) == false) return 12;
                                            return 46;
                                        }
                                        case 33: {
                                            if (this.matchChar(61) == false) return 26;
                                            if (this.matchChar(61) == false) return 13;
                                            return 47;
                                        }
                                        case 60: {
                                            if (this.matchChar(33)) {
                                                if (this.matchChar(45)) {
                                                    if (this.matchChar(45)) {
                                                        this.tokenBeg = -4 + this.cursor;
                                                        this.skipLine();
                                                        this.commentType = Token.CommentType.HTML;
                                                        return 161;
                                                    }
                                                    this.ungetCharIgnoreLineEnd(45);
                                                }
                                                this.ungetCharIgnoreLineEnd(33);
                                            }
                                            if (this.matchChar(60)) {
                                                if (this.matchChar(61) == false) return 18;
                                                return 94;
                                            }
                                            if (this.matchChar(61) == false) return 14;
                                            return 15;
                                        }
                                        case 62: {
                                            if (!this.matchChar(62)) {
                                                if (this.matchChar(61) == false) return 16;
                                                return 17;
                                            }
                                            if (this.matchChar(62)) {
                                                if (this.matchChar(61) == false) return 20;
                                                return 96;
                                            }
                                            if (this.matchChar(61) == false) return 19;
                                            return 95;
                                        }
                                        case 42: {
                                            if (this.matchChar(61) == false) return 23;
                                            return 99;
                                        }
                                        case 47: {
                                            this.markCommentStart();
                                            if (this.matchChar(47)) {
                                                this.tokenBeg = -2 + this.cursor;
                                                this.skipLine();
                                                this.commentType = Token.CommentType.LINE;
                                                return 161;
                                            }
                                            if (!this.matchChar(42)) {
                                                if (this.matchChar(61) == false) return 24;
                                                return 100;
                                            }
                                            this.tokenBeg = -2 + this.cursor;
                                            if (this.matchChar(42)) {
                                                var26_30 = true;
                                                this.commentType = Token.CommentType.JSDOC;
                                            } else {
                                                this.commentType = Token.CommentType.BLOCK_COMMENT;
                                                var26_30 = false;
                                            }
                                            do {
                                                if ((var27_31 = this.getChar()) == -1) {
                                                    this.tokenEnd = -1 + this.cursor;
                                                    this.parser.addError("msg.unterminated.comment");
                                                    return 161;
                                                }
                                                if (var27_31 == 42) {
                                                    var26_30 = true;
                                                    continue;
                                                }
                                                if (var27_31 == 47) {
                                                    if (!var26_30) continue;
                                                    this.tokenEnd = this.cursor;
                                                    return 161;
                                                }
                                                this.tokenEnd = this.cursor;
                                                var26_30 = false;
                                            } while (true);
                                        }
                                        case 37: {
                                            if (this.matchChar(61) == false) return 25;
                                            return 101;
                                        }
                                        case 126: {
                                            return 27;
                                        }
                                        case 43: {
                                            if (this.matchChar(61)) {
                                                return 97;
                                            }
                                            if (this.matchChar(43) == false) return 21;
                                            return 106;
                                        }
                                        case 45: 
                                    }
                                    if (this.matchChar(61)) {
                                        var25_32 = 98;
                                    } else if (this.matchChar(45)) {
                                        if (!this.dirtyLine && this.matchChar(62)) {
                                            this.markCommentStart("--");
                                            this.skipLine();
                                            this.commentType = Token.CommentType.HTML;
                                            return 161;
                                        }
                                        var25_32 = 107;
                                    } else {
                                        var25_32 = 22;
                                    }
                                    this.dirtyLine = true;
                                    return var25_32;
                                }
                                break block112;
                            }
                            var28_5 = var3_4;
                            do {
                                block113 : {
                                    block116 : {
                                        block115 : {
                                            block114 : {
                                                if (var3_4) break block113;
                                                var29_8 = this.getChar();
                                                if (var29_8 == 92) {
                                                    if (this.getChar() != 117) {
                                                        this.parser.addError("msg.illegal.character");
                                                        return -1;
                                                    }
                                                    var3_4 = true;
                                                    var28_5 = true;
                                                    continue;
                                                }
                                                if (var29_8 != -1 && var29_8 != 65279 && Character.isJavaIdentifierPart((char)((char)var29_8))) break block114;
                                                this.ungetChar(var29_8);
                                                var30_9 = this.getStringFromBuffer();
                                                if (var28_5) break block115;
                                                var31_2 = TokenStream.stringToKeyword(var30_9);
                                                if (var31_2 != 0) {
                                                    if ((var31_2 == 153 || var31_2 == 72) && this.parser.compilerEnv.getLanguageVersion() < 170) {
                                                        var32_10 = var31_2 == 153 ? "let" : "yield";
                                                        this.string = var32_10;
                                                        var31_2 = 39;
                                                    }
                                                    this.string = (String)this.allStrings.intern(var30_9);
                                                    if (var31_2 != 127) return var31_2;
                                                    if (this.parser.compilerEnv.isReservedKeywordAsIdentifier() == false) return var31_2;
                                                }
                                                break block116;
                                            }
                                            this.addToString(var29_8);
                                            continue;
                                        }
                                        if (TokenStream.isKeyword(var30_9)) {
                                            var30_9 = this.convertLastCharToHex(var30_9);
                                        }
                                    }
                                    this.string = (String)this.allStrings.intern(var30_9);
                                    return 39;
                                }
                                var33_6 = 0;
                                var34_7 = 0;
                                do {
                                    if (var34_7 == 4 || (var33_6 = Kit.xDigitToInt(this.getChar(), var33_6)) < 0) {
                                        if (var33_6 >= 0) break;
                                        this.parser.addError("msg.invalid.escape");
                                        return -1;
                                    }
                                    ++var34_7;
                                } while (true);
                                this.addToString(var33_6);
                                var3_4 = false;
                            } while (true);
                        }
                        while (48 <= var1_1 && var1_1 <= 57) {
                            if (var4_11 == 8 && var1_1 >= 56) {
                                var13_12 = this.parser;
                                var14_13 = var1_1 == 56 ? "8" : "9";
                                var13_12.addWarning("msg.bad.octal.literal", var14_13);
                                var4_11 = 10;
                            }
                            this.addToString(var1_1);
                            var1_1 = this.getChar();
                        }
                    }
                    var5_14 = true;
                    if (var4_11 != 10 || var1_1 != 46 && var1_1 != 101 && var1_1 != 69) break block117;
                    if (var1_1 == 46) {
                        do {
                            this.addToString(var1_1);
                        } while (TokenStream.isDigit(var1_1 = this.getChar()));
                    }
                    if (var1_1 == 101) break block118;
                    var5_14 = false;
                    if (var1_1 != 69) break block117;
                }
                this.addToString(var1_1);
                var1_1 = this.getChar();
                if (var1_1 == 43 || var1_1 == 45) {
                    this.addToString(var1_1);
                    var1_1 = this.getChar();
                }
                if (!TokenStream.isDigit(var1_1)) {
                    this.parser.addError("msg.missing.exponent");
                    return -1;
                }
                do {
                    this.addToString(var1_1);
                    var1_1 = this.getChar();
                    var12_15 = TokenStream.isDigit(var1_1);
                    var5_14 = false;
                } while (var12_15);
            }
            this.ungetChar(var1_1);
            this.string = var6_16 = this.getStringFromBuffer();
            if (var4_11 == 10 && !var5_14) {
                try {
                    var7_18 = var10_17 = Double.parseDouble((String)var6_16);
                }
                catch (NumberFormatException var9_19) {
                    this.parser.addError("msg.caught.nfe");
                    return -1;
                }
            } else {
                var7_18 = ScriptRuntime.stringToNumber(var6_16, 0, var4_11);
            }
            this.number = var7_18;
            return 40;
        }
        this.quoteChar = var1_1;
        this.stringBufferTop = 0;
        var15_20 = this.getChar(false);
        block47 : do {
            if (var15_20 == this.quoteChar) {
                var16_29 = this.getStringFromBuffer();
                this.string = (String)this.allStrings.intern(var16_29);
                return 41;
            }
            if (var15_20 == 10 || var15_20 == -1) {
                this.ungetChar(var15_20);
                this.tokenEnd = this.cursor;
                this.parser.addError("msg.unterminated.string.lit");
                return -1;
            }
            if (var15_20 != 92) ** GOTO lbl370
            var15_20 = this.getChar();
            switch (var15_20) {
                default: {
                    if (48 <= var15_20 && var15_20 < 56) {
                        var23_27 = var15_20 - 48;
                        var24_28 = this.getChar();
                        if (48 <= var24_28 && var24_28 < 56) {
                            var23_27 = -48 + (var24_28 + var23_27 * 8);
                            var24_28 = this.getChar();
                            if (48 <= var24_28 && var24_28 < 56 && var23_27 <= 31) {
                                var23_27 = -48 + (var24_28 + var23_27 * 8);
                                var24_28 = this.getChar();
                            }
                        }
                        this.ungetChar(var24_28);
                        var15_20 = var23_27;
                    }
                    ** GOTO lbl370
                }
                case 98: {
                    var15_20 = 8;
                    ** GOTO lbl370
                }
                case 102: {
                    var15_20 = 12;
                    ** GOTO lbl370
                }
                case 110: {
                    var15_20 = 10;
                    ** GOTO lbl370
                }
                case 114: {
                    var15_20 = 13;
                    ** GOTO lbl370
                }
                case 116: {
                    var15_20 = 9;
                    ** GOTO lbl370
                }
                case 118: {
                    var15_20 = 11;
                    ** GOTO lbl370
                }
                case 117: {
                    var20_24 = this.stringBufferTop;
                    this.addToString(117);
                    var21_25 = 0;
                    for (var22_26 = 0; var22_26 != 4; ++var22_26) {
                        var15_20 = this.getChar();
                        var21_25 = Kit.xDigitToInt(var15_20, var21_25);
                        if (var21_25 < 0) continue block47;
                        this.addToString(var15_20);
                    }
                    this.stringBufferTop = var20_24;
                    var15_20 = var21_25;
                    ** GOTO lbl370
                }
                case 120: {
                    var15_20 = this.getChar();
                    var17_21 = Kit.xDigitToInt(var15_20, 0);
                    if (var17_21 < 0) {
                        this.addToString(120);
                        continue block47;
                    }
                    var18_22 = var15_20;
                    var15_20 = this.getChar();
                    var19_23 = Kit.xDigitToInt(var15_20, var17_21);
                    if (var19_23 < 0) {
                        this.addToString(120);
                        this.addToString(var18_22);
                        continue block47;
                    }
                    var15_20 = var19_23;
lbl370: // 10 sources:
                    this.addToString(var15_20);
                    var15_20 = this.getChar(false);
                    continue block47;
                }
                case 10: 
            }
            var15_20 = this.getChar();
        } while (true);
    }

    public int getTokenBeg() {
        return this.tokenBeg;
    }

    public int getTokenEnd() {
        return this.tokenEnd;
    }

    public int getTokenLength() {
        return this.tokenEnd - this.tokenBeg;
    }

    final boolean isNumberHex() {
        return this.isHex;
    }

    final boolean isNumberOctal() {
        return this.isOctal;
    }

    boolean isXMLAttribute() {
        return this.xmlIsAttribute;
    }

    String readAndClearRegExpFlags() {
        String string2 = this.regExpFlags;
        this.regExpFlags = null;
        return string2;
    }

    /*
     * Enabled aggressive block sorting
     */
    void readRegExp(int n) throws IOException {
        int n2;
        int n3 = this.tokenBeg;
        this.stringBufferTop = 0;
        if (n == 100) {
            this.addToString(61);
        } else if (n != 24) {
            Kit.codeBug();
        }
        boolean bl = false;
        while ((n2 = this.getChar()) != 47 || bl) {
            if (n2 == 10 || n2 == -1) {
                this.ungetChar(n2);
                this.tokenEnd = -1 + this.cursor;
                this.string = new String(this.stringBuffer, 0, this.stringBufferTop);
                this.parser.reportError("msg.unterminated.re.lit");
                return;
            }
            if (n2 == 92) {
                this.addToString(n2);
                n2 = this.getChar();
            } else if (n2 == 91) {
                bl = true;
            } else if (n2 == 93) {
                bl = false;
            }
            this.addToString(n2);
        }
        int n4 = this.stringBufferTop;
        do {
            if (this.matchChar(103)) {
                this.addToString(103);
                continue;
            }
            if (this.matchChar(105)) {
                this.addToString(105);
                continue;
            }
            if (this.matchChar(109)) {
                this.addToString(109);
                continue;
            }
            if (!this.matchChar(121)) break;
            this.addToString(121);
        } while (true);
        this.tokenEnd = 2 + (n3 + this.stringBufferTop);
        if (TokenStream.isAlpha(this.peekChar())) {
            this.parser.reportError("msg.invalid.re.flag");
        }
        this.string = new String(this.stringBuffer, 0, n4);
        this.regExpFlags = new String(this.stringBuffer, n4, this.stringBufferTop - n4);
    }

    String tokenToString(int n) {
        return "";
    }
}

