/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.PrintStream
 *  java.io.Reader
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.InstantiationException
 *  java.lang.LinkageError
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  java.util.Map
 */
package org.mozilla.javascript;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.Reader;
import java.lang.reflect.Method;
import java.util.Map;
import org.mozilla.javascript.ScriptRuntime;

public class Kit {
    private static Method Throwable_initCause = null;

    static {
        try {
            Class<?> class_ = Kit.classOrNull("java.lang.Throwable");
            Throwable_initCause = class_.getMethod("initCause", new Class[]{class_});
        }
        catch (Exception exception) {}
    }

    public static Object addListener(Object object, Object object2) {
        if (object2 == null) {
            throw new IllegalArgumentException();
        }
        if (object2 instanceof Object[]) {
            throw new IllegalArgumentException();
        }
        if (object == null) {
            return object2;
        }
        if (!(object instanceof Object[])) {
            return new Object[]{object, object2};
        }
        Object[] arrobject = (Object[])object;
        int n = arrobject.length;
        if (n < 2) {
            throw new IllegalArgumentException();
        }
        Object[] arrobject2 = new Object[n + 1];
        System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)0, (int)n);
        arrobject2[n] = object2;
        return arrobject2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Class<?> classOrNull(ClassLoader classLoader, String string2) {
        try {
            return classLoader.loadClass(string2);
        }
        catch (ClassNotFoundException classNotFoundException) {
            do {
                return null;
                break;
            } while (true);
        }
        catch (SecurityException securityException) {
            return null;
        }
        catch (LinkageError linkageError) {
            return null;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return null;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Class<?> classOrNull(String string2) {
        try {
            return Class.forName((String)string2);
        }
        catch (ClassNotFoundException classNotFoundException) {
            do {
                return null;
                break;
            } while (true);
        }
        catch (SecurityException securityException) {
            return null;
        }
        catch (LinkageError linkageError) {
            return null;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return null;
        }
    }

    public static RuntimeException codeBug() throws RuntimeException {
        IllegalStateException illegalStateException = new IllegalStateException("FAILED ASSERTION");
        illegalStateException.printStackTrace(System.err);
        throw illegalStateException;
    }

    public static RuntimeException codeBug(String string2) throws RuntimeException {
        IllegalStateException illegalStateException = new IllegalStateException("FAILED ASSERTION: " + string2);
        illegalStateException.printStackTrace(System.err);
        throw illegalStateException;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Object getListener(Object object, int n) {
        if (n == 0) {
            if (object == null) {
                return null;
            }
            if (!(object instanceof Object[])) return object;
            Object[] arrobject = (Object[])object;
            if (arrobject.length >= 2) return arrobject[0];
            throw new IllegalArgumentException();
        }
        if (n == 1) {
            if (object instanceof Object[]) return ((Object[])object)[1];
            if (object != null) return null;
            throw new IllegalArgumentException();
        }
        Object[] arrobject = (Object[])object;
        int n2 = arrobject.length;
        if (n2 < 2) {
            throw new IllegalArgumentException();
        }
        if (n != n2) return arrobject[n];
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static RuntimeException initCause(RuntimeException runtimeException, Throwable throwable) {
        if (Throwable_initCause == null) return runtimeException;
        Object[] arrobject = new Object[]{throwable};
        try {
            Throwable_initCause.invoke((Object)runtimeException, arrobject);
        }
        catch (Exception exception) {
            return runtimeException;
        }
        return runtimeException;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static Object initHash(Map<Object, Object> map, Object object, Object object2) {
        Map<Object, Object> map2 = map;
        synchronized (map2) {
            Object object3 = map.get(object);
            if (object3 != null) return object3;
            map.put(object, object2);
            return object2;
        }
    }

    public static Object makeHashKeyFromPair(Object object, Object object2) {
        if (object == null) {
            throw new IllegalArgumentException();
        }
        if (object2 == null) {
            throw new IllegalArgumentException();
        }
        return new ComplexKey(object, object2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static Object newInstanceOrNull(Class<?> class_) {
        try {
            return class_.newInstance();
        }
        catch (SecurityException securityException) {
            do {
                return null;
                break;
            } while (true);
        }
        catch (LinkageError linkageError) {
            return null;
        }
        catch (InstantiationException instantiationException) {
            return null;
        }
        catch (IllegalAccessException illegalAccessException) {
            return null;
        }
    }

    public static String readReader(Reader reader) throws IOException {
        char[] arrc = new char[512];
        int n = 0;
        int n2;
        while ((n2 = reader.read(arrc, n, arrc.length - n)) >= 0) {
            if ((n += n2) != arrc.length) continue;
            char[] arrc2 = new char[2 * arrc.length];
            System.arraycopy((Object)arrc, (int)0, (Object)arrc2, (int)0, (int)n);
            arrc = arrc2;
        }
        return new String(arrc, 0, n);
    }

    public static byte[] readStream(InputStream inputStream, int n) throws IOException {
        if (n <= 0) {
            throw new IllegalArgumentException("Bad initialBufferCapacity: " + n);
        }
        byte[] arrby = new byte[n];
        int n2 = 0;
        do {
            int n3;
            if ((n3 = inputStream.read(arrby, n2, arrby.length - n2)) < 0) {
                if (n2 != arrby.length) {
                    byte[] arrby2 = new byte[n2];
                    System.arraycopy((Object)arrby, (int)0, (Object)arrby2, (int)0, (int)n2);
                    arrby = arrby2;
                }
                return arrby;
            }
            if ((n2 += n3) != arrby.length) continue;
            byte[] arrby3 = new byte[2 * arrby.length];
            System.arraycopy((Object)arrby, (int)0, (Object)arrby3, (int)0, (int)n2);
            arrby = arrby3;
        } while (true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Object removeListener(Object object, Object object2) {
        if (object2 == null) {
            throw new IllegalArgumentException();
        }
        if (object2 instanceof Object[]) {
            throw new IllegalArgumentException();
        }
        if (object == object2) {
            return null;
        }
        if (!(object instanceof Object[])) return object;
        Object[] arrobject = (Object[])object;
        int n = arrobject.length;
        if (n < 2) {
            throw new IllegalArgumentException();
        }
        if (n == 2) {
            if (arrobject[1] == object2) {
                return arrobject[0];
            }
            if (arrobject[0] != object2) return object;
            return arrobject[1];
        }
        int n2 = n;
        do {
            if (arrobject[--n2] != object2) continue;
            Object[] arrobject2 = new Object[n - 1];
            System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)0, (int)n2);
            System.arraycopy((Object)arrobject, (int)(n2 + 1), (Object)arrobject2, (int)n2, (int)(n - (n2 + 1)));
            return arrobject2;
        } while (n2 != 0);
        return object;
    }

    static boolean testIfCanLoadRhinoClasses(ClassLoader classLoader) {
        Class<?> class_ = ScriptRuntime.ContextFactoryClass;
        return Kit.classOrNull(classLoader, class_.getName()) == class_;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int xDigitToInt(int n, int n2) {
        int n3;
        if (n <= 57) {
            n3 = n - 48;
            if (n3 < 0) return -1;
            do {
                return n3 | n2 << 4;
                break;
            } while (true);
        }
        if (n <= 70) {
            if (65 > n) return -1;
            n3 = n - 55;
            return n3 | n2 << 4;
        }
        if (n > 102 || 97 > n) return -1;
        n3 = n - 87;
        return n3 | n2 << 4;
    }

    private static final class ComplexKey {
        private int hash;
        private Object key1;
        private Object key2;

        ComplexKey(Object object, Object object2) {
            this.key1 = object;
            this.key2 = object2;
        }

        /*
         * Enabled aggressive block sorting
         */
        public boolean equals(Object object) {
            block3 : {
                block2 : {
                    if (!(object instanceof ComplexKey)) break block2;
                    ComplexKey complexKey = (ComplexKey)object;
                    if (this.key1.equals(complexKey.key1) && this.key2.equals(complexKey.key2)) break block3;
                }
                return false;
            }
            return true;
        }

        public int hashCode() {
            if (this.hash == 0) {
                this.hash = this.key1.hashCode() ^ this.key2.hashCode();
            }
            return this.hash;
        }
    }

}

