/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.System
 *  java.lang.reflect.Array
 *  java.lang.reflect.Modifier
 *  java.util.Map
 */
package org.mozilla.javascript;

import java.lang.reflect.Array;
import java.lang.reflect.Modifier;
import java.util.Map;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.FieldAndMethods;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.JavaMembers;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.MemberBox;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.NativeJavaArray;
import org.mozilla.javascript.NativeJavaMethod;
import org.mozilla.javascript.NativeJavaObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.WrapFactory;
import org.mozilla.javascript.Wrapper;

public class NativeJavaClass
extends NativeJavaObject
implements Function {
    static final String javaClassPropertyName = "__javaObject__";
    static final long serialVersionUID = -6460763940409461664L;
    private Map<String, FieldAndMethods> staticFieldAndMethods;

    public NativeJavaClass() {
    }

    public NativeJavaClass(Scriptable scriptable, Class<?> class_) {
        this(scriptable, class_, false);
    }

    public NativeJavaClass(Scriptable scriptable, Class<?> class_, boolean bl) {
        super(scriptable, class_, (Class<?>)null, bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    static Object constructInternal(Object[] arrobject, MemberBox memberBox) {
        Class<?>[] arrclass = memberBox.argTypes;
        if (memberBox.vararg) {
            Object object;
            Object[] arrobject2 = new Object[arrclass.length];
            for (int i = 0; i < -1 + arrclass.length; ++i) {
                arrobject2[i] = Context.jsToJava(arrobject[i], arrclass[i]);
            }
            if (arrobject.length == arrclass.length && (arrobject[-1 + arrobject.length] == null || arrobject[-1 + arrobject.length] instanceof NativeArray || arrobject[-1 + arrobject.length] instanceof NativeJavaArray)) {
                object = Context.jsToJava(arrobject[-1 + arrobject.length], arrclass[-1 + arrclass.length]);
            } else {
                Class class_ = arrclass[-1 + arrclass.length].getComponentType();
                object = Array.newInstance((Class)class_, (int)(1 + (arrobject.length - arrclass.length)));
                for (int i = 0; i < Array.getLength((Object)object); ++i) {
                    Array.set((Object)object, (int)i, (Object)Context.jsToJava(arrobject[i + (-1 + arrclass.length)], class_));
                }
            }
            arrobject2[-1 + arrclass.length] = object;
            arrobject = arrobject2;
            return memberBox.newInstance(arrobject);
        } else {
            Object[] arrobject3 = arrobject;
            for (int i = 0; i < arrobject.length; ++i) {
                Object object = arrobject[i];
                Object object2 = Context.jsToJava(object, arrclass[i]);
                if (object2 == object) continue;
                if (arrobject == arrobject3) {
                    arrobject = (Object[])arrobject3.clone();
                }
                arrobject[i] = object2;
            }
        }
        return memberBox.newInstance(arrobject);
    }

    static Scriptable constructSpecific(Context context, Scriptable scriptable, Object[] arrobject, MemberBox memberBox) {
        Object object = NativeJavaClass.constructInternal(arrobject, memberBox);
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        return context.getWrapFactory().wrapNewObject(context, scriptable2, object);
    }

    private static Class<?> findNestedClass(Class<?> class_, String string2) {
        String string3 = class_.getName() + '$' + string2;
        ClassLoader classLoader = class_.getClassLoader();
        if (classLoader == null) {
            return Kit.classOrNull(string3);
        }
        return Kit.classOrNull(classLoader, string3);
    }

    @Override
    public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (arrobject.length == 1 && arrobject[0] instanceof Scriptable) {
            Class<?> class_ = this.getClassObject();
            Scriptable scriptable3 = (Scriptable)arrobject[0];
            do {
                if (!(scriptable3 instanceof Wrapper) || !class_.isInstance(((Wrapper)((Object)scriptable3)).unwrap())) continue;
                return scriptable3;
            } while ((scriptable3 = scriptable3.getPrototype()) != null);
        }
        return this.construct(context, scriptable, arrobject);
    }

    @Override
    public Scriptable construct(Context context, Scriptable scriptable, Object[] arrobject) {
        Class<?> class_;
        String string2;
        block7 : {
            class_ = this.getClassObject();
            int n = class_.getModifiers();
            if (!Modifier.isInterface((int)n) && !Modifier.isAbstract((int)n)) {
                NativeJavaMethod nativeJavaMethod = this.members.ctors;
                int n2 = nativeJavaMethod.findCachedFunction(context, arrobject);
                if (n2 < 0) {
                    String string3 = NativeJavaMethod.scriptSignature(arrobject);
                    throw Context.reportRuntimeError2("msg.no.java.ctor", class_.getName(), string3);
                }
                return NativeJavaClass.constructSpecific(context, scriptable, arrobject, nativeJavaMethod.methods[n2]);
            }
            if (arrobject.length == 0) {
                throw Context.reportRuntimeError0("msg.adapter.zero.args");
            }
            Scriptable scriptable2 = ScriptableObject.getTopLevelScope(this);
            string2 = "";
            try {
                if ("Dalvik".equals((Object)System.getProperty((String)"java.vm.name")) && class_.isInterface()) {
                    Object object = NativeJavaClass.createInterfaceAdapter(class_, ScriptableObject.ensureScriptableObject(arrobject[0]));
                    return context.getWrapFactory().wrapAsJavaObject(context, scriptable, object, null);
                }
                Object object = scriptable2.get("JavaAdapter", scriptable2);
                if (object != NOT_FOUND) {
                    Function function = (Function)object;
                    Object[] arrobject2 = new Object[]{this, arrobject[0]};
                    Scriptable scriptable3 = function.construct(context, scriptable2, arrobject2);
                    return scriptable3;
                }
            }
            catch (Exception exception) {
                String string4 = exception.getMessage();
                if (string4 == null) break block7;
                string2 = string4;
            }
        }
        throw Context.reportRuntimeError2("msg.cant.instantiate", string2, class_.getName());
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Object get(String string2, Scriptable scriptable) {
        if (string2.equals((Object)"prototype")) {
            return null;
        }
        if (this.staticFieldAndMethods != null) {
            Object object = this.staticFieldAndMethods.get((Object)string2);
            if (object != null) return object;
        }
        if (this.members.has(string2, true)) {
            return this.members.get(this, string2, this.javaObject, true);
        }
        Context context = Context.getContext();
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        WrapFactory wrapFactory = context.getWrapFactory();
        if (javaClassPropertyName.equals((Object)string2)) {
            return wrapFactory.wrap(context, scriptable2, this.javaObject, ScriptRuntime.ClassClass);
        }
        Class<?> class_ = NativeJavaClass.findNestedClass(this.getClassObject(), string2);
        if (class_ == null) throw this.members.reportMemberNotFound(string2);
        Scriptable scriptable3 = wrapFactory.wrapJavaClass(context, scriptable2, class_);
        scriptable3.setParentScope(this);
        return scriptable3;
    }

    @Override
    public String getClassName() {
        return "JavaClass";
    }

    public Class<?> getClassObject() {
        return (Class)super.unwrap();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Object getDefaultValue(Class<?> class_) {
        if (class_ == null) return ((NativeJavaClass)this).toString();
        if (class_ == ScriptRuntime.StringClass) {
            return ((NativeJavaClass)this).toString();
        }
        if (class_ == ScriptRuntime.BooleanClass) {
            return Boolean.TRUE;
        }
        if (class_ != ScriptRuntime.NumberClass) return this;
        return ScriptRuntime.NaNobj;
    }

    @Override
    public Object[] getIds() {
        return this.members.getIds(true);
    }

    @Override
    public boolean has(String string2, Scriptable scriptable) {
        return this.members.has(string2, true) || javaClassPropertyName.equals((Object)string2);
    }

    @Override
    public boolean hasInstance(Scriptable scriptable) {
        if (scriptable instanceof Wrapper && !(scriptable instanceof NativeJavaClass)) {
            Object object = ((Wrapper)((Object)scriptable)).unwrap();
            return this.getClassObject().isInstance(object);
        }
        return false;
    }

    @Override
    protected void initMembers() {
        Class class_ = (Class)this.javaObject;
        this.members = JavaMembers.lookupClass(this.parent, class_, class_, this.isAdapter);
        this.staticFieldAndMethods = this.members.getFieldAndMethodsObjects(this, (Object)class_, true);
    }

    @Override
    public void put(String string2, Scriptable scriptable, Object object) {
        this.members.put(this, string2, this.javaObject, object, true);
    }

    public String toString() {
        return "[JavaClass " + this.getClassObject().getName() + "]";
    }
}

