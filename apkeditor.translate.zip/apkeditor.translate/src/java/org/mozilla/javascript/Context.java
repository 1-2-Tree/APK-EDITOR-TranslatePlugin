/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.beans.PropertyChangeEvent
 *  java.beans.PropertyChangeListener
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.PrintWriter
 *  java.io.Reader
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Deprecated
 *  java.lang.Error
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SecurityException
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.net.URL
 *  java.util.Enumeration
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Set
 *  java.util.jar.Attributes
 *  java.util.jar.Manifest
 */
package org.mozilla.javascript;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.Manifest;
import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.ClassShutter;
import org.mozilla.javascript.CompilerEnvirons;
import org.mozilla.javascript.ContextAction;
import org.mozilla.javascript.ContextFactory;
import org.mozilla.javascript.ContextListener;
import org.mozilla.javascript.ContinuationPending;
import org.mozilla.javascript.DefaultErrorReporter;
import org.mozilla.javascript.ErrorReporter;
import org.mozilla.javascript.Evaluator;
import org.mozilla.javascript.EvaluatorException;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.GeneratedClassLoader;
import org.mozilla.javascript.IRFactory;
import org.mozilla.javascript.InterpretedFunction;
import org.mozilla.javascript.Interpreter;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.NativeCall;
import org.mozilla.javascript.NativeContinuation;
import org.mozilla.javascript.NativeFunction;
import org.mozilla.javascript.NativeJavaObject;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.ObjArray;
import org.mozilla.javascript.ObjToIntMap;
import org.mozilla.javascript.Parser;
import org.mozilla.javascript.RegExpProxy;
import org.mozilla.javascript.RhinoException;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.SecurityController;
import org.mozilla.javascript.TopLevel;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.VMBridge;
import org.mozilla.javascript.WrapFactory;
import org.mozilla.javascript.WrappedException;
import org.mozilla.javascript.ast.AstRoot;
import org.mozilla.javascript.ast.ScriptNode;
import org.mozilla.javascript.debug.DebuggableScript;
import org.mozilla.javascript.debug.Debugger;
import org.mozilla.javascript.xml.XMLLib;

public class Context {
    public static final int FEATURE_DYNAMIC_SCOPE = 7;
    public static final int FEATURE_E4X = 6;
    public static final int FEATURE_ENHANCED_JAVA_ACCESS = 13;
    public static final int FEATURE_LOCATION_INFORMATION_IN_ERROR = 10;
    public static final int FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME = 2;
    public static final int FEATURE_NON_ECMA_GET_YEAR = 1;
    public static final int FEATURE_PARENT_PROTO_PROPERTIES = 5;
    @Deprecated
    public static final int FEATURE_PARENT_PROTO_PROPRTIES = 5;
    public static final int FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER = 3;
    public static final int FEATURE_STRICT_EVAL = 9;
    public static final int FEATURE_STRICT_MODE = 11;
    public static final int FEATURE_STRICT_VARS = 8;
    public static final int FEATURE_TO_STRING_AS_SOURCE = 4;
    public static final int FEATURE_V8_EXTENSIONS = 14;
    public static final int FEATURE_WARNING_AS_ERROR = 12;
    public static final int VERSION_1_0 = 100;
    public static final int VERSION_1_1 = 110;
    public static final int VERSION_1_2 = 120;
    public static final int VERSION_1_3 = 130;
    public static final int VERSION_1_4 = 140;
    public static final int VERSION_1_5 = 150;
    public static final int VERSION_1_6 = 160;
    public static final int VERSION_1_7 = 170;
    public static final int VERSION_1_8 = 180;
    public static final int VERSION_DEFAULT = 0;
    public static final int VERSION_ES6 = 200;
    public static final int VERSION_UNKNOWN = -1;
    private static Class<?> codegenClass;
    public static final Object[] emptyArgs;
    public static final String errorReporterProperty = "error reporter";
    private static String implementationVersion;
    private static Class<?> interpreterClass;
    public static final String languageVersionProperty = "language version";
    Set<String> activationNames;
    private ClassLoader applicationClassLoader;
    XMLLib cachedXMLLib;
    private ClassShutter classShutter;
    NativeCall currentActivationCall;
    Debugger debugger;
    private Object debuggerData;
    private int enterCount;
    private ErrorReporter errorReporter;
    private final ContextFactory factory;
    public boolean generateObserverCount = false;
    private boolean generatingDebug;
    private boolean generatingDebugChanged;
    private boolean generatingSource = true;
    private boolean hasClassShutter;
    int instructionCount;
    int instructionThreshold;
    Object interpreterSecurityDomain;
    boolean isContinuationsTopCall;
    ObjToIntMap iterating;
    Object lastInterpreterFrame;
    private Locale locale;
    private int maximumInterpreterStackDepth;
    private int optimizationLevel;
    ObjArray previousInterpreterInvocations;
    private Object propertyListeners;
    RegExpProxy regExpProxy;
    int scratchIndex;
    Scriptable scratchScriptable;
    long scratchUint32;
    private Object sealKey;
    private boolean sealed;
    private SecurityController securityController;
    private Map<Object, Object> threadLocalMap;
    Scriptable topCallScope;
    BaseFunction typeErrorThrower;
    boolean useDynamicScope;
    int version;
    private WrapFactory wrapFactory;

    static {
        emptyArgs = ScriptRuntime.emptyArgs;
        codegenClass = Kit.classOrNull("org.mozilla.javascript.optimizer.Codegen");
        interpreterClass = Kit.classOrNull("org.mozilla.javascript.Interpreter");
    }

    @Deprecated
    public Context() {
        this(ContextFactory.getGlobal());
    }

    /*
     * Enabled aggressive block sorting
     */
    protected Context(ContextFactory contextFactory) {
        if (contextFactory == null) {
            throw new IllegalArgumentException("factory == null");
        }
        this.factory = contextFactory;
        this.version = 0;
        Class<?> class_ = codegenClass;
        int n = 0;
        if (class_ == null) {
            n = -1;
        }
        this.optimizationLevel = n;
        this.maximumInterpreterStackDepth = Integer.MAX_VALUE;
    }

    @Deprecated
    public static void addContextListener(ContextListener contextListener) {
        if ("org.mozilla.javascript.tools.debugger.Main".equals((Object)contextListener.getClass().getName())) {
            Class class_ = contextListener.getClass();
            Class[] arrclass = new Class[]{Kit.classOrNull("org.mozilla.javascript.ContextFactory")};
            Object[] arrobject = new Object[]{ContextFactory.getGlobal()};
            try {
                class_.getMethod("attachTo", arrclass).invoke((Object)contextListener, arrobject);
                return;
            }
            catch (Exception exception) {
                RuntimeException runtimeException = new RuntimeException();
                Kit.initCause(runtimeException, exception);
                throw runtimeException;
            }
        }
        ContextFactory.getGlobal().addListener(contextListener);
    }

    @Deprecated
    public static Object call(ContextAction contextAction) {
        return Context.call(ContextFactory.getGlobal(), contextAction);
    }

    public static Object call(ContextFactory contextFactory, final Callable callable, final Scriptable scriptable, final Scriptable scriptable2, final Object[] arrobject) {
        if (contextFactory == null) {
            contextFactory = ContextFactory.getGlobal();
        }
        return Context.call(contextFactory, new ContextAction(){

            @Override
            public Object run(Context context) {
                return callable.call(context, scriptable, scriptable2, arrobject);
            }
        });
    }

    static Object call(ContextFactory contextFactory, ContextAction contextAction) {
        Context context = Context.enter(null, contextFactory);
        try {
            Object object = contextAction.run(context);
            return object;
        }
        finally {
            Context.exit();
        }
    }

    public static void checkLanguageVersion(int n) {
        if (Context.isValidLanguageVersion(n)) {
            return;
        }
        throw new IllegalArgumentException("Bad language version: " + n);
    }

    public static void checkOptimizationLevel(int n) {
        if (Context.isValidOptimizationLevel(n)) {
            return;
        }
        throw new IllegalArgumentException("Optimization level outside [-1..9]: " + n);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Object compileImpl(Scriptable scriptable, Reader reader, String string2, String string3, int n, Object object, boolean bl, Evaluator evaluator, ErrorReporter errorReporter) throws IOException {
        boolean bl2;
        boolean bl3;
        if (string3 == null) {
            string3 = "unnamed script";
        }
        if (object != null && this.getSecurityController() == null) {
            throw new IllegalArgumentException("securityDomain should be null if setSecurityController() was never called");
        }
        boolean bl4 = string2 == null;
        if (!(bl4 ^ (bl3 = reader == null))) {
            Kit.codeBug();
        }
        if (!((bl2 = scriptable == null) ^ bl)) {
            Kit.codeBug();
        }
        CompilerEnvirons compilerEnvirons = new CompilerEnvirons();
        compilerEnvirons.initFromContext(this);
        if (errorReporter == null) {
            errorReporter = compilerEnvirons.getErrorReporter();
        }
        if (this.debugger != null && reader != null) {
            string2 = Kit.readReader(reader);
            reader = null;
        }
        Parser parser = new Parser(compilerEnvirons, errorReporter);
        if (bl) {
            parser.calledByCompileFunction = true;
        }
        AstRoot astRoot = string2 != null ? parser.parse(string2, string3, n) : parser.parse(reader, string3, n);
        if (bl && (astRoot.getFirstChild() == null || astRoot.getFirstChild().getType() != 109)) {
            throw new IllegalArgumentException("compileFunction only accepts source with single JS function: " + string2);
        }
        ScriptNode scriptNode = new IRFactory(compilerEnvirons, errorReporter).transformTree(astRoot);
        if (evaluator == null) {
            evaluator = this.createCompiler();
        }
        String string4 = scriptNode.getEncodedSource();
        Object object2 = evaluator.compile(compilerEnvirons, scriptNode, string4, bl);
        if (this.debugger != null) {
            if (string2 == null) {
                Kit.codeBug();
            }
            if (!(object2 instanceof DebuggableScript)) {
                throw new RuntimeException("NOT SUPPORTED");
            }
            Context.notifyDebugger_r(this, (DebuggableScript)object2, string2);
        }
        if (bl) {
            return evaluator.createFunctionObject(this, scriptable, object2, object);
        }
        return evaluator.createScriptObject(object2, object);
    }

    private Evaluator createCompiler() {
        int n = this.optimizationLevel;
        Evaluator evaluator = null;
        if (n >= 0) {
            Class<?> class_ = codegenClass;
            evaluator = null;
            if (class_ != null) {
                evaluator = (Evaluator)Kit.newInstanceOrNull(codegenClass);
            }
        }
        if (evaluator == null) {
            evaluator = Context.createInterpreter();
        }
        return evaluator;
    }

    static Evaluator createInterpreter() {
        return (Evaluator)Kit.newInstanceOrNull(interpreterClass);
    }

    public static Context enter() {
        return Context.enter(null);
    }

    @Deprecated
    public static Context enter(Context context) {
        return Context.enter(context, ContextFactory.getGlobal());
    }

    /*
     * Enabled aggressive block sorting
     */
    static final Context enter(Context context, ContextFactory contextFactory) {
        Object object = VMBridge.instance.getThreadContextHelper();
        Context context2 = VMBridge.instance.getContext(object);
        if (context2 != null) {
            context = context2;
        } else {
            if (context == null) {
                context = contextFactory.makeContext();
                if (context.enterCount != 0) {
                    throw new IllegalStateException("factory.makeContext() returned Context instance already associated with some thread");
                }
                contextFactory.onContextCreated(context);
                if (contextFactory.isSealed() && !context.isSealed()) {
                    context.seal(null);
                }
            } else if (context.enterCount != 0) {
                throw new IllegalStateException("can not use Context instance already associated with some thread");
            }
            VMBridge.instance.setContext(object, context);
        }
        context.enterCount = 1 + context.enterCount;
        return context;
    }

    public static void exit() {
        int n;
        Object object = VMBridge.instance.getThreadContextHelper();
        Context context = VMBridge.instance.getContext(object);
        if (context == null) {
            throw new IllegalStateException("Calling Context.exit without previous Context.enter");
        }
        if (context.enterCount < 1) {
            Kit.codeBug();
        }
        context.enterCount = n = -1 + context.enterCount;
        if (n == 0) {
            VMBridge.instance.setContext(object, null);
            context.factory.onContextReleased(context);
        }
    }

    private void firePropertyChangeImpl(Object object, String string2, Object object2, Object object3) {
        int n = 0;
        Object object4;
        while ((object4 = Kit.getListener(object, n)) != null) {
            if (object4 instanceof PropertyChangeListener) {
                ((PropertyChangeListener)object4).propertyChange(new PropertyChangeEvent((Object)this, string2, object2, object3));
            }
            ++n;
        }
        return;
    }

    static Context getContext() {
        Context context = Context.getCurrentContext();
        if (context == null) {
            throw new RuntimeException("No Context associated with current Thread");
        }
        return context;
    }

    public static Context getCurrentContext() {
        Object object = VMBridge.instance.getThreadContextHelper();
        return VMBridge.instance.getContext(object);
    }

    public static DebuggableScript getDebuggableView(Script script) {
        if (script instanceof NativeFunction) {
            return ((NativeFunction)((Object)script)).getDebuggableView();
        }
        return null;
    }

    static String getSourcePositionFromStack(int[] arrn) {
        Evaluator evaluator;
        Context context = Context.getCurrentContext();
        if (context == null) {
            return null;
        }
        if (context.lastInterpreterFrame != null && (evaluator = Context.createInterpreter()) != null) {
            return evaluator.getSourcePositionFromStack(context, arrn);
        }
        for (StackTraceElement stackTraceElement : new Throwable().getStackTrace()) {
            int n;
            String string2 = stackTraceElement.getFileName();
            if (string2 == null || string2.endsWith(".java") || (n = stackTraceElement.getLineNumber()) < 0) continue;
            arrn[0] = n;
            return string2;
        }
        return null;
    }

    public static Object getUndefinedValue() {
        return Undefined.instance;
    }

    public static boolean isValidLanguageVersion(int n) {
        switch (n) {
            default: {
                return false;
            }
            case 0: 
            case 100: 
            case 110: 
            case 120: 
            case 130: 
            case 140: 
            case 150: 
            case 160: 
            case 170: 
            case 180: 
            case 200: 
        }
        return true;
    }

    public static boolean isValidOptimizationLevel(int n) {
        return -1 <= n && n <= 9;
    }

    public static Object javaToJS(Object object, Scriptable scriptable) {
        if (object instanceof String || object instanceof Number || object instanceof Boolean || object instanceof Scriptable) {
            return object;
        }
        if (object instanceof Character) {
            return String.valueOf((char)((Character)object).charValue());
        }
        Context context = Context.getContext();
        return context.getWrapFactory().wrap(context, scriptable, object, null);
    }

    public static Object jsToJava(Object object, Class<?> class_) throws EvaluatorException {
        return NativeJavaObject.coerceTypeImpl(class_, object);
    }

    private static void notifyDebugger_r(Context context, DebuggableScript debuggableScript, String string2) {
        context.debugger.handleCompilationDone(context, debuggableScript, string2);
        for (int i = 0; i != debuggableScript.getFunctionCount(); ++i) {
            Context.notifyDebugger_r(context, debuggableScript.getFunction(i), string2);
        }
    }

    static void onSealedMutation() {
        throw new IllegalStateException();
    }

    @Deprecated
    public static void removeContextListener(ContextListener contextListener) {
        ContextFactory.getGlobal().addListener(contextListener);
    }

    public static void reportError(String string2) {
        int[] arrn = new int[]{0};
        Context.reportError(string2, Context.getSourcePositionFromStack(arrn), arrn[0], null, 0);
    }

    public static void reportError(String string2, String string3, int n, String string4, int n2) {
        Context context = Context.getCurrentContext();
        if (context != null) {
            context.getErrorReporter().error(string2, string3, n, string4, n2);
            return;
        }
        throw new EvaluatorException(string2, string3, n, string4, n2);
    }

    public static EvaluatorException reportRuntimeError(String string2) {
        int[] arrn = new int[]{0};
        return Context.reportRuntimeError(string2, Context.getSourcePositionFromStack(arrn), arrn[0], null, 0);
    }

    public static EvaluatorException reportRuntimeError(String string2, String string3, int n, String string4, int n2) {
        Context context = Context.getCurrentContext();
        if (context != null) {
            return context.getErrorReporter().runtimeError(string2, string3, n, string4, n2);
        }
        throw new EvaluatorException(string2, string3, n, string4, n2);
    }

    static EvaluatorException reportRuntimeError0(String string2) {
        return Context.reportRuntimeError(ScriptRuntime.getMessage0(string2));
    }

    static EvaluatorException reportRuntimeError1(String string2, Object object) {
        return Context.reportRuntimeError(ScriptRuntime.getMessage1(string2, object));
    }

    static EvaluatorException reportRuntimeError2(String string2, Object object, Object object2) {
        return Context.reportRuntimeError(ScriptRuntime.getMessage2(string2, object, object2));
    }

    static EvaluatorException reportRuntimeError3(String string2, Object object, Object object2, Object object3) {
        return Context.reportRuntimeError(ScriptRuntime.getMessage3(string2, object, object2, object3));
    }

    static EvaluatorException reportRuntimeError4(String string2, Object object, Object object2, Object object3, Object object4) {
        return Context.reportRuntimeError(ScriptRuntime.getMessage4(string2, object, object2, object3, object4));
    }

    public static void reportWarning(String string2) {
        int[] arrn = new int[]{0};
        Context.reportWarning(string2, Context.getSourcePositionFromStack(arrn), arrn[0], null, 0);
    }

    public static void reportWarning(String string2, String string3, int n, String string4, int n2) {
        Context context = Context.getContext();
        if (context.hasFeature(12)) {
            Context.reportError(string2, string3, n, string4, n2);
            return;
        }
        context.getErrorReporter().warning(string2, string3, n, string4, n2);
    }

    public static void reportWarning(String string2, Throwable throwable) {
        int[] arrn = new int[]{0};
        String string3 = Context.getSourcePositionFromStack(arrn);
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter((Writer)stringWriter);
        printWriter.println(string2);
        throwable.printStackTrace(printWriter);
        printWriter.flush();
        Context.reportWarning(stringWriter.toString(), string3, arrn[0], null, 0);
    }

    @Deprecated
    public static void setCachingEnabled(boolean bl) {
    }

    public static RuntimeException throwAsScriptRuntimeEx(Throwable throwable) {
        Context context;
        while (throwable instanceof InvocationTargetException) {
            throwable = ((InvocationTargetException)throwable).getTargetException();
        }
        if (throwable instanceof Error && ((context = Context.getContext()) == null || !context.hasFeature(13))) {
            throw (Error)throwable;
        }
        if (throwable instanceof RhinoException) {
            throw (RhinoException)((Object)throwable);
        }
        throw new WrappedException(throwable);
    }

    public static boolean toBoolean(Object object) {
        return ScriptRuntime.toBoolean(object);
    }

    public static double toNumber(Object object) {
        return ScriptRuntime.toNumber(object);
    }

    public static Scriptable toObject(Object object, Scriptable scriptable) {
        return ScriptRuntime.toObject(scriptable, object);
    }

    @Deprecated
    public static Scriptable toObject(Object object, Scriptable scriptable, Class<?> class_) {
        return ScriptRuntime.toObject(scriptable, object);
    }

    public static String toString(Object object) {
        return ScriptRuntime.toString(object);
    }

    @Deprecated
    public static Object toType(Object object, Class<?> class_) throws IllegalArgumentException {
        try {
            Object object2 = Context.jsToJava(object, class_);
            return object2;
        }
        catch (EvaluatorException evaluatorException) {
            IllegalArgumentException illegalArgumentException = new IllegalArgumentException(evaluatorException.getMessage());
            Kit.initCause((RuntimeException)illegalArgumentException, (Throwable)((Object)evaluatorException));
            throw illegalArgumentException;
        }
    }

    public void addActivationName(String string2) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        if (this.activationNames == null) {
            this.activationNames = new HashSet();
        }
        this.activationNames.add((Object)string2);
    }

    public final void addPropertyChangeListener(PropertyChangeListener propertyChangeListener) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        this.propertyListeners = Kit.addListener(this.propertyListeners, (Object)propertyChangeListener);
    }

    public Object callFunctionWithContinuations(Callable callable, Scriptable scriptable, Object[] arrobject) throws ContinuationPending {
        if (!(callable instanceof InterpretedFunction)) {
            throw new IllegalArgumentException("Function argument was not created by interpreted mode ");
        }
        if (ScriptRuntime.hasTopCall(this)) {
            throw new IllegalStateException("Cannot have any pending top calls when executing a script with continuations");
        }
        this.isContinuationsTopCall = true;
        return ScriptRuntime.doTopCall(callable, this, scriptable, scriptable, arrobject);
    }

    public ContinuationPending captureContinuation() {
        return new ContinuationPending(Interpreter.captureContinuation(this));
    }

    public final Function compileFunction(Scriptable scriptable, String string2, String string3, int n, Object object) {
        return this.compileFunction(scriptable, string2, null, null, string3, n, object);
    }

    final Function compileFunction(Scriptable scriptable, String string2, Evaluator evaluator, ErrorReporter errorReporter, String string3, int n, Object object) {
        try {
            Function function = (Function)this.compileImpl(scriptable, null, string2, string3, n, object, true, evaluator, errorReporter);
            return function;
        }
        catch (IOException iOException) {
            throw new RuntimeException();
        }
    }

    public final Script compileReader(Reader reader, String string2, int n, Object object) throws IOException {
        if (n < 0) {
            n = 0;
        }
        return (Script)this.compileImpl(null, reader, null, string2, n, object, false, null, null);
    }

    @Deprecated
    public final Script compileReader(Scriptable scriptable, Reader reader, String string2, int n, Object object) throws IOException {
        return this.compileReader(reader, string2, n, object);
    }

    public final Script compileString(String string2, String string3, int n, Object object) {
        if (n < 0) {
            n = 0;
        }
        return this.compileString(string2, null, null, string3, n, object);
    }

    final Script compileString(String string2, Evaluator evaluator, ErrorReporter errorReporter, String string3, int n, Object object) {
        try {
            Script script = (Script)this.compileImpl(null, null, string2, string3, n, object, false, evaluator, errorReporter);
            return script;
        }
        catch (IOException iOException) {
            throw new RuntimeException();
        }
    }

    public GeneratedClassLoader createClassLoader(ClassLoader classLoader) {
        return this.getFactory().createClassLoader(classLoader);
    }

    public final String decompileFunction(Function function, int n) {
        if (function instanceof BaseFunction) {
            return ((BaseFunction)function).decompile(n, 0);
        }
        return "function " + function.getClassName() + "() {\n\t[native code]\n}\n";
    }

    public final String decompileFunctionBody(Function function, int n) {
        if (function instanceof BaseFunction) {
            return ((BaseFunction)function).decompile(n, 1);
        }
        return "[native code]\n";
    }

    public final String decompileScript(Script script, int n) {
        return ((NativeFunction)((Object)script)).decompile(n, 0);
    }

    public final Object evaluateReader(Scriptable scriptable, Reader reader, String string2, int n, Object object) throws IOException {
        Script script = this.compileReader(scriptable, reader, string2, n, object);
        if (script != null) {
            return script.exec(this, scriptable);
        }
        return null;
    }

    public final Object evaluateString(Scriptable scriptable, String string2, String string3, int n, Object object) {
        Script script = this.compileString(string2, string3, n, object);
        if (script != null) {
            return script.exec(this, scriptable);
        }
        return null;
    }

    public Object executeScriptWithContinuations(Script script, Scriptable scriptable) throws ContinuationPending {
        if (!(script instanceof InterpretedFunction) || !((InterpretedFunction)script).isScript()) {
            throw new IllegalArgumentException("Script argument was not a script or was not created by interpreted mode ");
        }
        return this.callFunctionWithContinuations((InterpretedFunction)script, scriptable, ScriptRuntime.emptyArgs);
    }

    final void firePropertyChange(String string2, Object object, Object object2) {
        Object object3 = this.propertyListeners;
        if (object3 != null) {
            this.firePropertyChangeImpl(object3, string2, object, object2);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final ClassLoader getApplicationClassLoader() {
        if (this.applicationClassLoader == null) {
            ContextFactory contextFactory = this.getFactory();
            ClassLoader classLoader = contextFactory.getApplicationClassLoader();
            if (classLoader == null) {
                ClassLoader classLoader2 = VMBridge.instance.getCurrentThreadClassLoader();
                if (classLoader2 != null && Kit.testIfCanLoadRhinoClasses(classLoader2)) {
                    return classLoader2;
                }
                Class class_ = contextFactory.getClass();
                classLoader = class_ != ScriptRuntime.ContextFactoryClass ? class_.getClassLoader() : this.getClass().getClassLoader();
            }
            this.applicationClassLoader = classLoader;
        }
        return this.applicationClassLoader;
    }

    final ClassShutter getClassShutter() {
        Context context = this;
        synchronized (context) {
            ClassShutter classShutter = this.classShutter;
            return classShutter;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final ClassShutterSetter getClassShutterSetter() {
        Context context = this;
        synchronized (context) {
            block6 : {
                boolean bl = this.hasClassShutter;
                if (!bl) break block6;
                return null;
            }
            this.hasClassShutter = true;
            ClassShutterSetter classShutterSetter = new ClassShutterSetter(){

                @Override
                public ClassShutter getClassShutter() {
                    return Context.this.classShutter;
                }

                @Override
                public void setClassShutter(ClassShutter classShutter) {
                    Context.this.classShutter = classShutter;
                }
            };
            return classShutterSetter;
        }
    }

    public final Debugger getDebugger() {
        return this.debugger;
    }

    public final Object getDebuggerContextData() {
        return this.debuggerData;
    }

    public XMLLib.Factory getE4xImplementationFactory() {
        return this.getFactory().getE4xImplementationFactory();
    }

    public final Object[] getElements(Scriptable scriptable) {
        return ScriptRuntime.getArrayElements(scriptable);
    }

    public final ErrorReporter getErrorReporter() {
        if (this.errorReporter == null) {
            return DefaultErrorReporter.instance;
        }
        return this.errorReporter;
    }

    public final ContextFactory getFactory() {
        return this.factory;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final String getImplementationVersion() {
        String string2;
        InputStream inputStream;
        Enumeration enumeration;
        if (implementationVersion != null) return implementationVersion;
        try {
            enumeration = Context.class.getClassLoader().getResources("META-INF/MANIFEST.MF");
        }
        catch (IOException iOException) {
            return null;
        }
        while (enumeration.hasMoreElements()) {
            block14 : {
                URL uRL = (URL)enumeration.nextElement();
                inputStream = null;
                inputStream = uRL.openStream();
                Attributes attributes = new Manifest(inputStream).getMainAttributes();
                if (!"Mozilla Rhino".equals((Object)attributes.getValue("Implementation-Title"))) break block14;
                string2 = implementationVersion = "Rhino " + attributes.getValue("Implementation-Version") + " " + attributes.getValue("Built-Date").replaceAll("-", " ");
                if (inputStream == null) return string2;
                inputStream.close();
                return string2;
            }
            if (inputStream == null) continue;
            try {
                inputStream.close();
            }
            catch (IOException iOException) {}
            continue;
            catch (IOException iOException) {
                if (inputStream == null) continue;
                try {
                    inputStream.close();
                }
                catch (IOException iOException2) {}
            }
        }
        return implementationVersion;
        catch (Throwable throwable) {
            if (inputStream == null) throw throwable;
            try {
                inputStream.close();
            }
            catch (IOException iOException) {
                throw throwable;
            }
            throw throwable;
            catch (IOException iOException) {
                return string2;
            }
        }
    }

    public final int getInstructionObserverThreshold() {
        return this.instructionThreshold;
    }

    public final int getLanguageVersion() {
        return this.version;
    }

    public final Locale getLocale() {
        if (this.locale == null) {
            this.locale = Locale.getDefault();
        }
        return this.locale;
    }

    public final int getMaximumInterpreterStackDepth() {
        return this.maximumInterpreterStackDepth;
    }

    public final int getOptimizationLevel() {
        return this.optimizationLevel;
    }

    RegExpProxy getRegExpProxy() {
        Class<?> class_;
        if (this.regExpProxy == null && (class_ = Kit.classOrNull("org.mozilla.javascript.regexp.RegExpImpl")) != null) {
            this.regExpProxy = (RegExpProxy)Kit.newInstanceOrNull(class_);
        }
        return this.regExpProxy;
    }

    SecurityController getSecurityController() {
        SecurityController securityController = SecurityController.global();
        if (securityController != null) {
            return securityController;
        }
        return this.securityController;
    }

    public final Object getThreadLocal(Object object) {
        if (this.threadLocalMap == null) {
            return null;
        }
        return this.threadLocalMap.get(object);
    }

    public final WrapFactory getWrapFactory() {
        if (this.wrapFactory == null) {
            this.wrapFactory = new WrapFactory();
        }
        return this.wrapFactory;
    }

    public boolean hasFeature(int n) {
        return this.getFactory().hasFeature(this, n);
    }

    public final Scriptable initSafeStandardObjects(ScriptableObject scriptableObject) {
        return this.initSafeStandardObjects(scriptableObject, false);
    }

    public final ScriptableObject initSafeStandardObjects() {
        return this.initSafeStandardObjects(null, false);
    }

    public ScriptableObject initSafeStandardObjects(ScriptableObject scriptableObject, boolean bl) {
        return ScriptRuntime.initSafeStandardObjects(this, scriptableObject, bl);
    }

    public final Scriptable initStandardObjects(ScriptableObject scriptableObject) {
        return this.initStandardObjects(scriptableObject, false);
    }

    public final ScriptableObject initStandardObjects() {
        return this.initStandardObjects(null, false);
    }

    public ScriptableObject initStandardObjects(ScriptableObject scriptableObject, boolean bl) {
        return ScriptRuntime.initStandardObjects(this, scriptableObject, bl);
    }

    public final boolean isActivationNeeded(String string2) {
        return this.activationNames != null && this.activationNames.contains((Object)string2);
    }

    public final boolean isGeneratingDebug() {
        return this.generatingDebug;
    }

    public final boolean isGeneratingDebugChanged() {
        return this.generatingDebugChanged;
    }

    public final boolean isGeneratingSource() {
        return this.generatingSource;
    }

    public final boolean isSealed() {
        return this.sealed;
    }

    final boolean isVersionECMA1() {
        return this.version == 0 || this.version >= 130;
    }

    public Scriptable newArray(Scriptable scriptable, int n) {
        NativeArray nativeArray = new NativeArray(n);
        ScriptRuntime.setBuiltinProtoAndParent(nativeArray, scriptable, TopLevel.Builtins.Array);
        return nativeArray;
    }

    public Scriptable newArray(Scriptable scriptable, Object[] arrobject) {
        if (arrobject.getClass().getComponentType() != ScriptRuntime.ObjectClass) {
            throw new IllegalArgumentException();
        }
        NativeArray nativeArray = new NativeArray(arrobject);
        ScriptRuntime.setBuiltinProtoAndParent(nativeArray, scriptable, TopLevel.Builtins.Array);
        return nativeArray;
    }

    public Scriptable newObject(Scriptable scriptable) {
        NativeObject nativeObject = new NativeObject();
        ScriptRuntime.setBuiltinProtoAndParent(nativeObject, scriptable, TopLevel.Builtins.Object);
        return nativeObject;
    }

    public Scriptable newObject(Scriptable scriptable, String string2) {
        return this.newObject(scriptable, string2, ScriptRuntime.emptyArgs);
    }

    public Scriptable newObject(Scriptable scriptable, String string2, Object[] arrobject) {
        return ScriptRuntime.newObject(this, scriptable, string2, arrobject);
    }

    protected void observeInstructionCount(int n) {
        this.getFactory().observeInstructionCount(this, n);
    }

    public final void putThreadLocal(Object object, Object object2) {
        Context context = this;
        synchronized (context) {
            if (this.sealed) {
                Context.onSealedMutation();
            }
            if (this.threadLocalMap == null) {
                this.threadLocalMap = new HashMap();
            }
            this.threadLocalMap.put(object, object2);
            return;
        }
    }

    public void removeActivationName(String string2) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        if (this.activationNames != null) {
            this.activationNames.remove((Object)string2);
        }
    }

    public final void removePropertyChangeListener(PropertyChangeListener propertyChangeListener) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        this.propertyListeners = Kit.removeListener(this.propertyListeners, (Object)propertyChangeListener);
    }

    public final void removeThreadLocal(Object object) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        if (this.threadLocalMap == null) {
            return;
        }
        this.threadLocalMap.remove(object);
    }

    public Object resumeContinuation(Object object, Scriptable scriptable, Object object2) throws ContinuationPending {
        Object[] arrobject = new Object[]{object2};
        return Interpreter.restartContinuation((NativeContinuation)object, this, scriptable, arrobject);
    }

    public final void seal(Object object) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        this.sealed = true;
        this.sealKey = object;
    }

    public final void setApplicationClassLoader(ClassLoader classLoader) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        if (classLoader == null) {
            this.applicationClassLoader = null;
            return;
        }
        if (!Kit.testIfCanLoadRhinoClasses(classLoader)) {
            throw new IllegalArgumentException("Loader can not resolve Rhino classes");
        }
        this.applicationClassLoader = classLoader;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void setClassShutter(ClassShutter classShutter) {
        Context context = this;
        synchronized (context) {
            if (this.sealed) {
                Context.onSealedMutation();
            }
            if (classShutter == null) {
                throw new IllegalArgumentException();
            }
            if (this.hasClassShutter) {
                throw new SecurityException("Cannot overwrite existing ClassShutter object");
            }
            this.classShutter = classShutter;
            this.hasClassShutter = true;
            return;
        }
    }

    public final void setDebugger(Debugger debugger, Object object) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        this.debugger = debugger;
        this.debuggerData = object;
    }

    public final ErrorReporter setErrorReporter(ErrorReporter errorReporter) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        if (errorReporter == null) {
            throw new IllegalArgumentException();
        }
        ErrorReporter errorReporter2 = this.getErrorReporter();
        if (errorReporter == errorReporter2) {
            return errorReporter2;
        }
        Object object = this.propertyListeners;
        if (object != null) {
            this.firePropertyChangeImpl(object, errorReporterProperty, errorReporter2, errorReporter);
        }
        this.errorReporter = errorReporter;
        return errorReporter2;
    }

    public void setGenerateObserverCount(boolean bl) {
        this.generateObserverCount = bl;
    }

    public final void setGeneratingDebug(boolean bl) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        this.generatingDebugChanged = true;
        if (bl && this.getOptimizationLevel() > 0) {
            this.setOptimizationLevel(0);
        }
        this.generatingDebug = bl;
    }

    public final void setGeneratingSource(boolean bl) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        this.generatingSource = bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void setInstructionObserverThreshold(int n) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        if (n < 0) {
            throw new IllegalArgumentException();
        }
        this.instructionThreshold = n;
        boolean bl = n > 0;
        this.setGenerateObserverCount(bl);
    }

    public void setLanguageVersion(int n) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        Context.checkLanguageVersion(n);
        Object object = this.propertyListeners;
        if (object != null && n != this.version) {
            this.firePropertyChangeImpl(object, languageVersionProperty, this.version, n);
        }
        this.version = n;
    }

    public final Locale setLocale(Locale locale) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        Locale locale2 = this.locale;
        this.locale = locale;
        return locale2;
    }

    public final void setMaximumInterpreterStackDepth(int n) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        if (this.optimizationLevel != -1) {
            throw new IllegalStateException("Cannot set maximumInterpreterStackDepth when optimizationLevel != -1");
        }
        if (n < 1) {
            throw new IllegalArgumentException("Cannot set maximumInterpreterStackDepth to less than 1");
        }
        this.maximumInterpreterStackDepth = n;
    }

    public final void setOptimizationLevel(int n) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        if (n == -2) {
            n = -1;
        }
        Context.checkOptimizationLevel(n);
        if (codegenClass == null) {
            n = -1;
        }
        this.optimizationLevel = n;
    }

    public final void setSecurityController(SecurityController securityController) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        if (securityController == null) {
            throw new IllegalArgumentException();
        }
        if (this.securityController != null) {
            throw new SecurityException("Can not overwrite existing SecurityController object");
        }
        if (SecurityController.hasGlobal()) {
            throw new SecurityException("Can not overwrite existing global SecurityController object");
        }
        this.securityController = securityController;
    }

    public final void setWrapFactory(WrapFactory wrapFactory) {
        if (this.sealed) {
            Context.onSealedMutation();
        }
        if (wrapFactory == null) {
            throw new IllegalArgumentException();
        }
        this.wrapFactory = wrapFactory;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean stringIsCompilableUnit(String string2) {
        boolean bl = false;
        CompilerEnvirons compilerEnvirons = new CompilerEnvirons();
        compilerEnvirons.initFromContext(this);
        compilerEnvirons.setGeneratingSource(false);
        Parser parser = new Parser(compilerEnvirons, DefaultErrorReporter.instance);
        try {
            parser.parse(string2, null, 1);
        }
        catch (EvaluatorException evaluatorException) {
            bl = true;
            return !bl || !parser.eof();
        }
        do {
            return !bl || !parser.eof();
            break;
        } while (true);
    }

    public final void unseal(Object object) {
        if (object == null) {
            throw new IllegalArgumentException();
        }
        if (this.sealKey != object) {
            throw new IllegalArgumentException();
        }
        if (!this.sealed) {
            throw new IllegalStateException();
        }
        this.sealed = false;
        this.sealKey = null;
    }

    public static interface ClassShutterSetter {
        public ClassShutter getClassShutter();

        public void setClassShutter(ClassShutter var1);
    }

}

