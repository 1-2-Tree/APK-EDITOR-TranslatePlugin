/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.SecurityException
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Member
 *  java.lang.reflect.Method
 *  java.lang.reflect.Modifier
 */
package org.mozilla.javascript;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContinuationPending;
import org.mozilla.javascript.JavaMembers;
import org.mozilla.javascript.VMBridge;

final class MemberBox
implements Serializable {
    private static final Class<?>[] primitives;
    static final long serialVersionUID = 6358550398665688245L;
    transient Class<?>[] argTypes;
    transient Object delegateTo;
    private transient Member memberObject;
    transient boolean vararg;

    static {
        Class[] arrclass = new Class[]{Boolean.TYPE, Byte.TYPE, Character.TYPE, Double.TYPE, Float.TYPE, Integer.TYPE, Long.TYPE, Short.TYPE, Void.TYPE};
        primitives = arrclass;
    }

    MemberBox(Constructor<?> constructor) {
        this.init(constructor);
    }

    MemberBox(Method method) {
        this.init(method);
    }

    private void init(Constructor<?> constructor) {
        this.memberObject = constructor;
        this.argTypes = constructor.getParameterTypes();
        this.vararg = VMBridge.instance.isVarArgs((Member)constructor);
    }

    private void init(Method method) {
        this.memberObject = method;
        this.argTypes = method.getParameterTypes();
        this.vararg = VMBridge.instance.isVarArgs((Member)method);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Member readMember(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        if (!objectInputStream.readBoolean()) {
            return null;
        }
        boolean bl = objectInputStream.readBoolean();
        String string2 = (String)objectInputStream.readObject();
        Class class_ = (Class)objectInputStream.readObject();
        Class<?>[] arrclass = MemberBox.readParameters(objectInputStream);
        if (!bl) return class_.getConstructor(arrclass);
        try {
            return class_.getMethod(string2, arrclass);
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new IOException("Cannot find member: " + (Object)((Object)noSuchMethodException));
        }
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        Member member = MemberBox.readMember(objectInputStream);
        if (member instanceof Method) {
            this.init((Method)member);
            return;
        }
        this.init((Constructor)member);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Class<?>[] readParameters(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        Class[] arrclass = new Class[objectInputStream.readShort()];
        int n = 0;
        while (n < arrclass.length) {
            arrclass[n] = !objectInputStream.readBoolean() ? (Class)objectInputStream.readObject() : primitives[objectInputStream.readByte()];
            ++n;
        }
        return arrclass;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static Method searchAccessibleMethod(Method method, Class<?>[] arrclass) {
        int n = method.getModifiers();
        if (!Modifier.isPublic((int)n)) return null;
        if (Modifier.isStatic((int)n)) return null;
        Class class_ = method.getDeclaringClass();
        if (Modifier.isPublic((int)class_.getModifiers())) return null;
        String string2 = method.getName();
        Class[] arrclass2 = class_.getInterfaces();
        int n2 = arrclass2.length;
        for (int i = 0; i != n2; ++i) {
            Class class_2 = arrclass2[i];
            if (!Modifier.isPublic((int)class_2.getModifiers())) continue;
            try {
                return class_2.getMethod(string2, arrclass);
            }
            catch (NoSuchMethodException noSuchMethodException) {
                // empty catch block
                continue;
            }
            catch (SecurityException securityException) {}
        }
        while ((class_ = class_.getSuperclass()) != null) {
            if (!Modifier.isPublic((int)class_.getModifiers())) continue;
            try {
                boolean bl;
                Method method2 = class_.getMethod(string2, arrclass);
                int n3 = method2.getModifiers();
                if (!Modifier.isPublic((int)n3) || (bl = Modifier.isStatic((int)n3))) continue;
                return method2;
            }
            catch (NoSuchMethodException noSuchMethodException) {
                continue;
            }
            break;
        }
        return null;
    }

    private static void writeMember(ObjectOutputStream objectOutputStream, Member member) throws IOException {
        if (member == null) {
            objectOutputStream.writeBoolean(false);
            return;
        }
        objectOutputStream.writeBoolean(true);
        if (!(member instanceof Method) && !(member instanceof Constructor)) {
            throw new IllegalArgumentException("not Method or Constructor");
        }
        objectOutputStream.writeBoolean(member instanceof Method);
        objectOutputStream.writeObject((Object)member.getName());
        objectOutputStream.writeObject((Object)member.getDeclaringClass());
        if (member instanceof Method) {
            MemberBox.writeParameters(objectOutputStream, ((Method)member).getParameterTypes());
            return;
        }
        MemberBox.writeParameters(objectOutputStream, ((Constructor)member).getParameterTypes());
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
        MemberBox.writeMember(objectOutputStream, this.memberObject);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static void writeParameters(ObjectOutputStream var0, Class<?>[] var1_1) throws IOException {
        block4 : {
            var0.writeShort(var1_1.length);
            var2_2 = 0;
            block0 : while (var2_2 < var1_1.length) {
                var3_3 = var1_1[var2_2];
                var4_4 = var3_3.isPrimitive();
                var0.writeBoolean(var4_4);
                if (var4_4) break block4;
                var0.writeObject(var3_3);
lbl9: // 2 sources:
                do {
                    ++var2_2;
                    continue block0;
                    break;
                } while (true);
            }
            return;
        }
        var5_5 = 0;
        while (var5_5 < MemberBox.primitives.length) {
            if (var3_3.equals(MemberBox.primitives[var5_5])) {
                var0.writeByte(var5_5);
                ** continue;
            }
            ++var5_5;
        }
        throw new IllegalArgumentException("Primitive " + var3_3 + " not found");
    }

    Constructor<?> ctor() {
        return (Constructor)this.memberObject;
    }

    Class<?> getDeclaringClass() {
        return this.memberObject.getDeclaringClass();
    }

    String getName() {
        return this.memberObject.getName();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    Object invoke(Object object, Object[] arrobject) {
        Method method = this.method();
        try {
            try {
                return method.invoke(object, arrobject);
            }
            catch (IllegalAccessException illegalAccessException) {
                Method method2 = MemberBox.searchAccessibleMethod(method, this.argTypes);
                if (method2 == null) {
                    if (VMBridge.instance.tryToMakeAccessible((Object)method)) return method.invoke(object, arrobject);
                    throw Context.throwAsScriptRuntimeEx(illegalAccessException);
                }
                this.memberObject = method2;
                method = method2;
                return method.invoke(object, arrobject);
            }
        }
        catch (InvocationTargetException invocationTargetException) {
            Throwable throwable = invocationTargetException;
            while ((throwable = throwable.getTargetException()) instanceof InvocationTargetException) {
            }
            if (!(throwable instanceof ContinuationPending)) throw Context.throwAsScriptRuntimeEx(throwable);
            throw (ContinuationPending)((Object)throwable);
        }
        catch (Exception exception) {
            throw Context.throwAsScriptRuntimeEx(exception);
        }
    }

    boolean isCtor() {
        return this.memberObject instanceof Constructor;
    }

    boolean isMethod() {
        return this.memberObject instanceof Method;
    }

    boolean isStatic() {
        return Modifier.isStatic((int)this.memberObject.getModifiers());
    }

    Member member() {
        return this.memberObject;
    }

    Method method() {
        return (Method)this.memberObject;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    Object newInstance(Object[] arrobject) {
        Constructor<?> constructor = this.ctor();
        try {
            try {
                return constructor.newInstance(arrobject);
            }
            catch (IllegalAccessException illegalAccessException) {
                if (VMBridge.instance.tryToMakeAccessible(constructor)) return constructor.newInstance(arrobject);
                throw Context.throwAsScriptRuntimeEx(illegalAccessException);
            }
        }
        catch (Exception exception) {
            throw Context.throwAsScriptRuntimeEx(exception);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    String toJavaDeclaration() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.isMethod()) {
            Method method = this.method();
            stringBuilder.append((Object)method.getReturnType());
            stringBuilder.append(' ');
            stringBuilder.append(method.getName());
        } else {
            String string2 = this.ctor().getDeclaringClass().getName();
            int n = string2.lastIndexOf(46);
            if (n >= 0) {
                string2 = string2.substring(n + 1);
            }
            stringBuilder.append(string2);
        }
        stringBuilder.append(JavaMembers.liveConnectSignature(this.argTypes));
        return stringBuilder.toString();
    }

    public String toString() {
        return this.memberObject.toString();
    }
}

