/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.util.Arrays
 */
package org.mozilla.javascript;

import java.util.Arrays;
import org.mozilla.javascript.Wrapper;

class ResolvedOverload {
    final int index;
    final Class<?>[] types;

    /*
     * Enabled aggressive block sorting
     */
    ResolvedOverload(Object[] arrobject, int n) {
        this.index = n;
        this.types = new Class[arrobject.length];
        int n2 = 0;
        int n3 = arrobject.length;
        while (n2 < n3) {
            Object object = arrobject[n2];
            if (object instanceof Wrapper) {
                object = ((Wrapper)object).unwrap();
            }
            Class<?>[] arrclass = this.types;
            Class class_ = object == null ? null : object.getClass();
            arrclass[n2] = class_;
            ++n2;
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean equals(Object object) {
        block3 : {
            block2 : {
                if (!(object instanceof ResolvedOverload)) break block2;
                ResolvedOverload resolvedOverload = (ResolvedOverload)object;
                if (Arrays.equals((Object[])this.types, (Object[])resolvedOverload.types) && this.index == resolvedOverload.index) break block3;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Arrays.hashCode((Object[])this.types);
    }

    /*
     * Enabled aggressive block sorting
     */
    boolean matches(Object[] arrobject) {
        if (arrobject.length == this.types.length) {
            int n = 0;
            int n2 = arrobject.length;
            do {
                if (n >= n2) {
                    return true;
                }
                Object object = arrobject[n];
                if (object instanceof Wrapper) {
                    object = ((Wrapper)object).unwrap();
                }
                if (object == null) {
                    if (this.types[n] != null) break;
                } else if (object.getClass() != this.types[n]) {
                    return false;
                }
                ++n;
            } while (true);
        }
        return false;
    }
}

