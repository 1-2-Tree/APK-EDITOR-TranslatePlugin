/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.NativeError;
import org.mozilla.javascript.RhinoException;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;

public class JavaScriptException
extends RhinoException {
    static final long serialVersionUID = -7666130513694669293L;
    private Object value;

    @Deprecated
    public JavaScriptException(Object object) {
        this(object, "", 0);
    }

    public JavaScriptException(Object object, String string2, int n) {
        this.recordErrorOrigin(string2, n, null, 0);
        this.value = object;
        if (object instanceof NativeError && Context.getContext().hasFeature(10)) {
            NativeError nativeError = (NativeError)object;
            if (!nativeError.has("fileName", nativeError)) {
                nativeError.put("fileName", nativeError, string2);
            }
            if (!nativeError.has("lineNumber", nativeError)) {
                nativeError.put("lineNumber", nativeError, n);
            }
            nativeError.setStackProvider(this);
        }
    }

    @Override
    public String details() {
        if (this.value == null) {
            return "null";
        }
        if (this.value instanceof NativeError) {
            return this.value.toString();
        }
        try {
            String string2 = ScriptRuntime.toString(this.value);
            return string2;
        }
        catch (RuntimeException runtimeException) {
            if (this.value instanceof Scriptable) {
                return ScriptRuntime.defaultObjectToString((Scriptable)this.value);
            }
            return this.value.toString();
        }
    }

    @Deprecated
    public int getLineNumber() {
        return this.lineNumber();
    }

    @Deprecated
    public String getSourceName() {
        return this.sourceName();
    }

    public Object getValue() {
        return this.value;
    }
}

