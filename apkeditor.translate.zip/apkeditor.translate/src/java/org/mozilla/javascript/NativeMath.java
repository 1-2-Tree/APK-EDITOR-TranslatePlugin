/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalStateException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.typedarrays.Conversions;

final class NativeMath
extends IdScriptableObject {
    private static final int Id_E = 30;
    private static final int Id_LN10 = 32;
    private static final int Id_LN2 = 33;
    private static final int Id_LOG10E = 35;
    private static final int Id_LOG2E = 34;
    private static final int Id_PI = 31;
    private static final int Id_SQRT1_2 = 36;
    private static final int Id_SQRT2 = 37;
    private static final int Id_abs = 2;
    private static final int Id_acos = 3;
    private static final int Id_asin = 4;
    private static final int Id_atan = 5;
    private static final int Id_atan2 = 6;
    private static final int Id_cbrt = 20;
    private static final int Id_ceil = 7;
    private static final int Id_cos = 8;
    private static final int Id_cosh = 21;
    private static final int Id_exp = 9;
    private static final int Id_expm1 = 22;
    private static final int Id_floor = 10;
    private static final int Id_hypot = 23;
    private static final int Id_imul = 28;
    private static final int Id_log = 11;
    private static final int Id_log10 = 25;
    private static final int Id_log1p = 24;
    private static final int Id_max = 12;
    private static final int Id_min = 13;
    private static final int Id_pow = 14;
    private static final int Id_random = 15;
    private static final int Id_round = 16;
    private static final int Id_sin = 17;
    private static final int Id_sinh = 26;
    private static final int Id_sqrt = 18;
    private static final int Id_tan = 19;
    private static final int Id_tanh = 27;
    private static final int Id_toSource = 1;
    private static final int Id_trunc = 29;
    private static final int LAST_METHOD_ID = 29;
    private static final Object MATH_TAG = "Math";
    private static final int MAX_ID = 37;
    static final long serialVersionUID = -8838847185801131569L;

    private NativeMath() {
    }

    static void init(Scriptable scriptable, boolean bl) {
        NativeMath nativeMath = new NativeMath();
        nativeMath.activatePrototypeMap(37);
        nativeMath.setPrototype(NativeMath.getObjectPrototype(scriptable));
        nativeMath.setParentScope(scriptable);
        if (bl) {
            nativeMath.sealObject();
        }
        ScriptableObject.defineProperty(scriptable, "Math", nativeMath, 2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private double js_hypot(Object[] arrobject) {
        if (arrobject == null) {
            return 0.0;
        }
        double d = 0.0;
        int n = arrobject.length;
        int n2 = 0;
        while (n2 < n) {
            double d2 = ScriptRuntime.toNumber(arrobject[n2]);
            if (d2 == ScriptRuntime.NaN) return d2;
            if (d2 == Double.POSITIVE_INFINITY) return Double.POSITIVE_INFINITY;
            if (d2 == Double.NEGATIVE_INFINITY) {
                return Double.POSITIVE_INFINITY;
            }
            d += d2 * d2;
            ++n2;
        }
        return Math.sqrt((double)d);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Object js_imul(Object[] arrobject) {
        long l;
        if (arrobject == null || arrobject.length < 2) {
            return ScriptRuntime.wrapNumber(ScriptRuntime.NaN);
        }
        long l2 = Conversions.toUint32(arrobject[0]) * Conversions.toUint32(arrobject[1]) % 0x100000000L;
        if (l2 >= 0x80000000L) {
            l = l2 - 0x100000000L;
            do {
                return ScriptRuntime.toNumber(l);
                break;
            } while (true);
        }
        l = l2;
        return ScriptRuntime.toNumber(l);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private double js_pow(double d, double d2) {
        if (d2 != d2) {
            return d2;
        }
        if (d2 == 0.0) {
            return 1.0;
        }
        if (d == 0.0) {
            if (1.0 / d > 0.0) {
                if (!(d2 > 0.0)) return Double.POSITIVE_INFINITY;
                return 0.0;
            }
            long l = (long)d2;
            if ((double)l == d2 && (1L & l) != 0L) {
                if (!(d2 > 0.0)) return Double.NEGATIVE_INFINITY;
                return 0.0;
            }
            if (!(d2 > 0.0)) return Double.POSITIVE_INFINITY;
            return 0.0;
        }
        double d3 = Math.pow((double)d, (double)d2);
        if (d3 == d3) return d3;
        if (d2 == Double.POSITIVE_INFINITY) {
            if (d < -1.0) return Double.POSITIVE_INFINITY;
            if (1.0 < d) {
                return Double.POSITIVE_INFINITY;
            }
            if (!(-1.0 < d)) return d3;
            if (!(d < 1.0)) return d3;
            return 0.0;
        }
        if (d2 == Double.NEGATIVE_INFINITY) {
            if (d < -1.0) return 0.0;
            if (1.0 < d) {
                return 0.0;
            }
            if (!(-1.0 < d)) return d3;
            if (!(d < 1.0)) return d3;
            return Double.POSITIVE_INFINITY;
        }
        if (d == Double.POSITIVE_INFINITY) {
            if (!(d2 > 0.0)) return 0.0;
            return Double.POSITIVE_INFINITY;
        }
        if (d != Double.NEGATIVE_INFINITY) return d3;
        long l = (long)d2;
        if ((double)l == d2 && (1L & l) != 0L) {
            if (!(d2 > 0.0)) return 0.0;
            return Double.NEGATIVE_INFINITY;
        }
        if (!(d2 > 0.0)) return 0.0;
        return Double.POSITIVE_INFINITY;
    }

    private double js_trunc(double d) {
        if (d < 0.0) {
            return Math.ceil((double)d);
        }
        return Math.floor((double)d);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        double d;
        if (!idFunctionObject.hasTag(MATH_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                throw new IllegalStateException(String.valueOf((int)n));
            }
            case 1: {
                return "Math";
            }
            case 2: {
                d = ScriptRuntime.toNumber(arrobject, 0);
                if (d == 0.0) {
                    d = 0.0;
                    return ScriptRuntime.wrapNumber(d);
                }
                if (!(d < 0.0)) return ScriptRuntime.wrapNumber(d);
                d = -d;
                return ScriptRuntime.wrapNumber(d);
            }
            case 3: 
            case 4: {
                double d2 = ScriptRuntime.toNumber(arrobject, 0);
                if (d2 == d2 && -1.0 <= d2 && d2 <= 1.0) {
                    if (n == 3) {
                        d = Math.acos((double)d2);
                        return ScriptRuntime.wrapNumber(d);
                    }
                    d = Math.asin((double)d2);
                    return ScriptRuntime.wrapNumber(d);
                }
                d = Double.NaN;
                return ScriptRuntime.wrapNumber(d);
            }
            case 5: {
                d = Math.atan((double)ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d);
            }
            case 6: {
                d = Math.atan2((double)ScriptRuntime.toNumber(arrobject, 0), (double)ScriptRuntime.toNumber(arrobject, 1));
                return ScriptRuntime.wrapNumber(d);
            }
            case 20: {
                d = Math.cbrt((double)ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d);
            }
            case 7: {
                d = Math.ceil((double)ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d);
            }
            case 8: {
                double d3 = ScriptRuntime.toNumber(arrobject, 0);
                if (d3 != Double.POSITIVE_INFINITY && d3 != Double.NEGATIVE_INFINITY) {
                    d = Math.cos((double)d3);
                    return ScriptRuntime.wrapNumber(d);
                }
                d = Double.NaN;
                return ScriptRuntime.wrapNumber(d);
            }
            case 21: {
                d = Math.cosh((double)ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d);
            }
            case 23: {
                d = this.js_hypot(arrobject);
                return ScriptRuntime.wrapNumber(d);
            }
            case 9: {
                d = ScriptRuntime.toNumber(arrobject, 0);
                if (d == Double.POSITIVE_INFINITY) {
                    return ScriptRuntime.wrapNumber(d);
                }
                if (d == Double.NEGATIVE_INFINITY) {
                    d = 0.0;
                    return ScriptRuntime.wrapNumber(d);
                }
                d = Math.exp((double)d);
                return ScriptRuntime.wrapNumber(d);
            }
            case 22: {
                d = Math.expm1((double)ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d);
            }
            case 10: {
                d = Math.floor((double)ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d);
            }
            case 28: {
                return this.js_imul(arrobject);
            }
            case 11: {
                double d4 = ScriptRuntime.toNumber(arrobject, 0);
                if (d4 < 0.0) {
                    d = Double.NaN;
                    return ScriptRuntime.wrapNumber(d);
                }
                d = Math.log((double)d4);
                return ScriptRuntime.wrapNumber(d);
            }
            case 24: {
                d = Math.log1p((double)ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d);
            }
            case 25: {
                d = Math.log10((double)ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d);
            }
            case 12: 
            case 13: {
                d = n == 12 ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY;
                int n2 = 0;
                while (n2 != arrobject.length) {
                    double d5 = ScriptRuntime.toNumber(arrobject[n2]);
                    if (d5 != d5) {
                        d = d5;
                        return ScriptRuntime.wrapNumber(d);
                    }
                    d = n == 12 ? Math.max((double)d, (double)d5) : Math.min((double)d, (double)d5);
                    ++n2;
                }
                return ScriptRuntime.wrapNumber(d);
            }
            case 14: {
                d = this.js_pow(ScriptRuntime.toNumber(arrobject, 0), ScriptRuntime.toNumber(arrobject, 1));
                return ScriptRuntime.wrapNumber(d);
            }
            case 15: {
                d = Math.random();
                return ScriptRuntime.wrapNumber(d);
            }
            case 16: {
                d = ScriptRuntime.toNumber(arrobject, 0);
                if (d != d) return ScriptRuntime.wrapNumber(d);
                if (d == Double.POSITIVE_INFINITY) return ScriptRuntime.wrapNumber(d);
                if (d == Double.NEGATIVE_INFINITY) return ScriptRuntime.wrapNumber(d);
                long l = Math.round((double)d);
                if (l != 0L) {
                    d = l;
                    return ScriptRuntime.wrapNumber(d);
                }
                if (d < 0.0) {
                    d = ScriptRuntime.negativeZero;
                    return ScriptRuntime.wrapNumber(d);
                }
                if (d == 0.0) return ScriptRuntime.wrapNumber(d);
                d = 0.0;
                return ScriptRuntime.wrapNumber(d);
            }
            case 17: {
                double d6 = ScriptRuntime.toNumber(arrobject, 0);
                if (d6 != Double.POSITIVE_INFINITY && d6 != Double.NEGATIVE_INFINITY) {
                    d = Math.sin((double)d6);
                    return ScriptRuntime.wrapNumber(d);
                }
                d = Double.NaN;
                return ScriptRuntime.wrapNumber(d);
            }
            case 26: {
                d = Math.sinh((double)ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d);
            }
            case 18: {
                d = Math.sqrt((double)ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d);
            }
            case 19: {
                d = Math.tan((double)ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d);
            }
            case 27: {
                d = Math.tanh((double)ScriptRuntime.toNumber(arrobject, 0));
                return ScriptRuntime.wrapNumber(d);
            }
            case 29: 
        }
        d = this.js_trunc(ScriptRuntime.toNumber(arrobject, 0));
        return ScriptRuntime.wrapNumber(d);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        block0 : switch (n) {
            case 1: {
                char c = string2.charAt(0);
                string3 = null;
                n2 = 0;
                if (c != 'E') break;
                return 30;
            }
            case 2: {
                char c = string2.charAt(0);
                string3 = null;
                n2 = 0;
                if (c != 'P') break;
                char c2 = string2.charAt(1);
                string3 = null;
                n2 = 0;
                if (c2 != 'I') break;
                return 31;
            }
            case 3: {
                switch (string2.charAt(0)) {
                    default: {
                        return 0;
                    }
                    case 'L': {
                        char c = string2.charAt(2);
                        string3 = null;
                        n2 = 0;
                        if (c != '2') break block0;
                        char c3 = string2.charAt(1);
                        string3 = null;
                        n2 = 0;
                        if (c3 != 'N') break block0;
                        return 33;
                    }
                    case 'a': {
                        char c = string2.charAt(2);
                        string3 = null;
                        n2 = 0;
                        if (c != 's') break block0;
                        char c4 = string2.charAt(1);
                        string3 = null;
                        n2 = 0;
                        if (c4 != 'b') break block0;
                        return 2;
                    }
                    case 'c': {
                        char c = string2.charAt(2);
                        string3 = null;
                        n2 = 0;
                        if (c != 's') break block0;
                        char c5 = string2.charAt(1);
                        string3 = null;
                        n2 = 0;
                        if (c5 != 'o') break block0;
                        return 8;
                    }
                    case 'e': {
                        char c = string2.charAt(2);
                        string3 = null;
                        n2 = 0;
                        if (c != 'p') break block0;
                        char c6 = string2.charAt(1);
                        string3 = null;
                        n2 = 0;
                        if (c6 != 'x') break block0;
                        return 9;
                    }
                    case 'l': {
                        char c = string2.charAt(2);
                        string3 = null;
                        n2 = 0;
                        if (c != 'g') break block0;
                        char c7 = string2.charAt(1);
                        string3 = null;
                        n2 = 0;
                        if (c7 != 'o') break block0;
                        return 11;
                    }
                    case 'm': {
                        char c = string2.charAt(2);
                        if (c == 'n') {
                            char c8 = string2.charAt(1);
                            string3 = null;
                            n2 = 0;
                            if (c8 != 'i') break block0;
                            return 13;
                        }
                        string3 = null;
                        n2 = 0;
                        if (c != 'x') break block0;
                        char c9 = string2.charAt(1);
                        string3 = null;
                        n2 = 0;
                        if (c9 != 'a') break block0;
                        return 12;
                    }
                    case 'p': {
                        char c = string2.charAt(2);
                        string3 = null;
                        n2 = 0;
                        if (c != 'w') break block0;
                        char c10 = string2.charAt(1);
                        string3 = null;
                        n2 = 0;
                        if (c10 != 'o') break block0;
                        return 14;
                    }
                    case 's': {
                        char c = string2.charAt(2);
                        string3 = null;
                        n2 = 0;
                        if (c != 'n') break block0;
                        char c11 = string2.charAt(1);
                        string3 = null;
                        n2 = 0;
                        if (c11 != 'i') break block0;
                        return 17;
                    }
                    case 't': 
                }
                char c = string2.charAt(2);
                string3 = null;
                n2 = 0;
                if (c != 'n') break;
                char c12 = string2.charAt(1);
                string3 = null;
                n2 = 0;
                if (c12 != 'a') break;
                return 19;
            }
            case 4: {
                switch (string2.charAt(1)) {
                    default: {
                        return 0;
                    }
                    case 'N': {
                        string3 = "LN10";
                        n2 = 32;
                        break block0;
                    }
                    case 'a': {
                        string3 = "tanh";
                        n2 = 27;
                        break block0;
                    }
                    case 'b': {
                        string3 = "cbrt";
                        n2 = 20;
                        break block0;
                    }
                    case 'c': {
                        string3 = "acos";
                        n2 = 3;
                        break block0;
                    }
                    case 'e': {
                        string3 = "ceil";
                        n2 = 7;
                        break block0;
                    }
                    case 'i': {
                        string3 = "sinh";
                        n2 = 26;
                        break block0;
                    }
                    case 'm': {
                        string3 = "imul";
                        n2 = 28;
                        break block0;
                    }
                    case 'o': {
                        string3 = "cosh";
                        n2 = 21;
                        break block0;
                    }
                    case 'q': {
                        string3 = "sqrt";
                        n2 = 18;
                        break block0;
                    }
                    case 's': {
                        string3 = "asin";
                        n2 = 4;
                        break block0;
                    }
                    case 't': 
                }
                string3 = "atan";
                n2 = 5;
                break;
            }
            case 5: {
                switch (string2.charAt(0)) {
                    default: {
                        return 0;
                    }
                    case 'L': {
                        string3 = "LOG2E";
                        n2 = 34;
                        break block0;
                    }
                    case 'S': {
                        string3 = "SQRT2";
                        n2 = 37;
                        break block0;
                    }
                    case 'a': {
                        string3 = "atan2";
                        n2 = 6;
                        break block0;
                    }
                    case 'e': {
                        string3 = "expm1";
                        n2 = 22;
                        break block0;
                    }
                    case 'f': {
                        string3 = "floor";
                        n2 = 10;
                        break block0;
                    }
                    case 'h': {
                        string3 = "hypot";
                        n2 = 23;
                        break block0;
                    }
                    case 'l': {
                        char c = string2.charAt(4);
                        if (c == '0') {
                            string3 = "log10";
                            n2 = 25;
                            break block0;
                        }
                        string3 = null;
                        n2 = 0;
                        if (c != 'p') break block0;
                        string3 = "log1p";
                        n2 = 24;
                        break block0;
                    }
                    case 'r': {
                        string3 = "round";
                        n2 = 16;
                        break block0;
                    }
                    case 't': 
                }
                string3 = "trunc";
                n2 = 29;
                break;
            }
            case 6: {
                char c = string2.charAt(0);
                if (c == 'L') {
                    string3 = "LOG10E";
                    n2 = 35;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'r') break;
                string3 = "random";
                n2 = 15;
                break;
            }
            case 7: {
                string3 = "SQRT1_2";
                n2 = 36;
                break;
            }
            case 8: {
                string3 = "toSource";
                n2 = 1;
                break;
            }
        }
        if (string3 == null) return n2;
        if (string3 == string2) return n2;
        if (string3.equals((Object)string2)) return n2;
        return 0;
    }

    @Override
    public String getClassName() {
        return "Math";
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        double d;
        String string2;
        if (n <= 29) {
            int n2;
            String string3;
            switch (n) {
                default: {
                    throw new IllegalStateException(String.valueOf((int)n));
                }
                case 1: {
                    n2 = 0;
                    string3 = "toSource";
                    break;
                }
                case 2: {
                    n2 = 1;
                    string3 = "abs";
                    break;
                }
                case 3: {
                    n2 = 1;
                    string3 = "acos";
                    break;
                }
                case 4: {
                    n2 = 1;
                    string3 = "asin";
                    break;
                }
                case 5: {
                    n2 = 1;
                    string3 = "atan";
                    break;
                }
                case 6: {
                    n2 = 2;
                    string3 = "atan2";
                    break;
                }
                case 20: {
                    n2 = 1;
                    string3 = "cbrt";
                    break;
                }
                case 7: {
                    n2 = 1;
                    string3 = "ceil";
                    break;
                }
                case 8: {
                    n2 = 1;
                    string3 = "cos";
                    break;
                }
                case 21: {
                    n2 = 1;
                    string3 = "cosh";
                    break;
                }
                case 9: {
                    n2 = 1;
                    string3 = "exp";
                    break;
                }
                case 22: {
                    n2 = 1;
                    string3 = "expm1";
                    break;
                }
                case 10: {
                    n2 = 1;
                    string3 = "floor";
                    break;
                }
                case 23: {
                    n2 = 2;
                    string3 = "hypot";
                    break;
                }
                case 28: {
                    n2 = 2;
                    string3 = "imul";
                    break;
                }
                case 11: {
                    n2 = 1;
                    string3 = "log";
                    break;
                }
                case 24: {
                    n2 = 1;
                    string3 = "log1p";
                    break;
                }
                case 25: {
                    n2 = 1;
                    string3 = "log10";
                    break;
                }
                case 12: {
                    n2 = 2;
                    string3 = "max";
                    break;
                }
                case 13: {
                    n2 = 2;
                    string3 = "min";
                    break;
                }
                case 14: {
                    n2 = 2;
                    string3 = "pow";
                    break;
                }
                case 15: {
                    string3 = "random";
                    n2 = 0;
                    break;
                }
                case 16: {
                    n2 = 1;
                    string3 = "round";
                    break;
                }
                case 17: {
                    n2 = 1;
                    string3 = "sin";
                    break;
                }
                case 26: {
                    n2 = 1;
                    string3 = "sinh";
                    break;
                }
                case 18: {
                    n2 = 1;
                    string3 = "sqrt";
                    break;
                }
                case 19: {
                    n2 = 1;
                    string3 = "tan";
                    break;
                }
                case 27: {
                    n2 = 1;
                    string3 = "tanh";
                    break;
                }
                case 29: {
                    n2 = 1;
                    string3 = "trunc";
                }
            }
            this.initPrototypeMethod(MATH_TAG, n, string3, n2);
            return;
        }
        switch (n) {
            default: {
                throw new IllegalStateException(String.valueOf((int)n));
            }
            case 30: {
                d = 2.718281828459045;
                string2 = "E";
                break;
            }
            case 31: {
                d = 3.141592653589793;
                string2 = "PI";
                break;
            }
            case 32: {
                d = 2.302585092994046;
                string2 = "LN10";
                break;
            }
            case 33: {
                d = 0.6931471805599453;
                string2 = "LN2";
                break;
            }
            case 34: {
                d = 1.4426950408889634;
                string2 = "LOG2E";
                break;
            }
            case 35: {
                d = 0.4342944819032518;
                string2 = "LOG10E";
                break;
            }
            case 36: {
                d = 0.7071067811865476;
                string2 = "SQRT1_2";
                break;
            }
            case 37: {
                d = 1.4142135623730951;
                string2 = "SQRT2";
            }
        }
        this.initPrototypeValue(n, string2, (Object)ScriptRuntime.wrapNumber(d), 7);
    }
}

