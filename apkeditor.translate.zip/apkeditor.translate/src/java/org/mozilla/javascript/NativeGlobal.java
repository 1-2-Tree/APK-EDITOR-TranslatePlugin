/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript;

import java.io.Serializable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.EcmaError;
import org.mozilla.javascript.IdFunctionCall;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.NativeError;
import org.mozilla.javascript.NativeNumber;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.TopLevel;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.xml.XMLLib;

public class NativeGlobal
implements Serializable,
IdFunctionCall {
    private static final Object FTAG = "Global";
    private static final int INVALID_UTF8 = Integer.MAX_VALUE;
    private static final int Id_decodeURI = 1;
    private static final int Id_decodeURIComponent = 2;
    private static final int Id_encodeURI = 3;
    private static final int Id_encodeURIComponent = 4;
    private static final int Id_escape = 5;
    private static final int Id_eval = 6;
    private static final int Id_isFinite = 7;
    private static final int Id_isNaN = 8;
    private static final int Id_isXMLName = 9;
    private static final int Id_new_CommonError = 14;
    private static final int Id_parseFloat = 10;
    private static final int Id_parseInt = 11;
    private static final int Id_unescape = 12;
    private static final int Id_uneval = 13;
    private static final int LAST_SCOPE_FUNCTION_ID = 13;
    private static final String URI_DECODE_RESERVED = ";/?:@&=+$,#";
    static final long serialVersionUID = 6080442165748707530L;

    @Deprecated
    public static EcmaError constructError(Context context, String string2, String string3, Scriptable scriptable) {
        return ScriptRuntime.constructError(string2, string3);
    }

    @Deprecated
    public static EcmaError constructError(Context context, String string2, String string3, Scriptable scriptable, String string4, int n, int n2, String string5) {
        return ScriptRuntime.constructError(string2, string3, string4, n, string5, n2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static String decode(String var0, boolean var1_1) {
        block31 : {
            block29 : {
                var2_2 = null;
                var3_3 = 0;
                var4_4 = var0.length();
                var5_5 = 0;
                block0 : do {
                    if (var3_3 == var4_4) ** GOTO lbl59
                    var7_6 = var0.charAt(var3_3);
                    if (var7_6 != '%') {
                        if (var2_2 != null) {
                            var15_14 = var5_5 + 1;
                            var2_2[var5_5] = var7_6;
                        } else {
                            var15_14 = var5_5;
                        }
                        ++var3_3;
                    } else {
                        if (var2_2 == null) {
                            var2_2 = new char[var4_4];
                            var0.getChars(0, var3_3, var2_2, 0);
                            var5_5 = var3_3;
                        }
                        var8_7 = var3_3;
                        if (var3_3 + 3 > var4_4) {
                            throw NativeGlobal.uriError();
                        }
                        var9_8 = NativeGlobal.unHex(var0.charAt(var3_3 + 1), var0.charAt(var3_3 + 2));
                        if (var9_8 < 0) {
                            throw NativeGlobal.uriError();
                        }
                        var3_3 += 3;
                        if ((var9_8 & 128) == 0) {
                            var14_13 = (char)var9_8;
                            break;
                        }
                        if ((var9_8 & 192) == 128) {
                            throw NativeGlobal.uriError();
                        }
                        if ((var9_8 & 32) == 0) {
                            var10_9 = 1;
                            var11_10 = var9_8 & 31;
                            var12_11 = 128;
                        } else if ((var9_8 & 16) == 0) {
                            var10_9 = 2;
                            var11_10 = var9_8 & 15;
                            var12_11 = 2048;
                        } else if ((var9_8 & 8) == 0) {
                            var10_9 = 3;
                            var11_10 = var9_8 & 7;
                            var12_11 = 65536;
                        } else if ((var9_8 & 4) == 0) {
                            var10_9 = 4;
                            var11_10 = var9_8 & 3;
                            var12_11 = 2097152;
                        } else {
                            if ((var9_8 & 2) != 0) throw NativeGlobal.uriError();
                            var10_9 = 5;
                            var11_10 = var9_8 & 1;
                            var12_11 = 67108864;
                        }
                        if (var3_3 + var10_9 * 3 > var4_4) {
                            throw NativeGlobal.uriError();
                        }
                        break block29;
lbl59: // 1 sources:
                        if (var2_2 != null) return new String(var2_2, 0, var5_5);
                        return var0;
                    }
lbl61: // 3 sources:
                    do {
                        var5_5 = var15_14;
                        continue block0;
                        break;
                    } while (true);
                    break;
                } while (true);
lbl64: // 3 sources:
                do {
                    block30 : {
                        if (!var1_1 || ";/?:@&=+$,#".indexOf((int)var14_13) < 0) break block30;
                        for (var16_15 = var8_7; var16_15 != var3_3; ++var16_15) {
                            var17_16 = var5_5 + 1;
                            var2_2[var5_5] = var0.charAt(var16_15);
                            var5_5 = var17_16;
                        }
                        var15_14 = var5_5;
                        ** GOTO lbl61
                    }
                    var15_14 = var5_5 + 1;
                    var2_2[var5_5] = var14_13;
                    ** continue;
                    break;
                } while (true);
            }
            for (var13_12 = 0; var13_12 != var10_9; var3_3 += 3, ++var13_12) {
                if (var0.charAt(var3_3) != '%') {
                    throw NativeGlobal.uriError();
                }
                var21_20 = NativeGlobal.unHex(var0.charAt(var3_3 + 1), var0.charAt(var3_3 + 2));
                if (var21_20 < 0) throw NativeGlobal.uriError();
                if ((var21_20 & 192) != 128) {
                    throw NativeGlobal.uriError();
                }
                var11_10 = var11_10 << 6 | var21_20 & 63;
            }
            if (var11_10 < var12_11 || var11_10 >= 55296 && var11_10 <= 57343) {
                var11_10 = Integer.MAX_VALUE;
            } else if (var11_10 == 65534 || var11_10 == 65535) {
                var11_10 = 65533;
            }
            if (var11_10 < 65536) break block31;
            var18_17 = var11_10 - 65536;
            if (var18_17 > 1048575) {
                throw NativeGlobal.uriError();
            }
            var19_18 = (char)(55296 + (var18_17 >>> 10));
            var14_13 = (char)(56320 + (var18_17 & 1023));
            var20_19 = var5_5 + 1;
            var2_2[var5_5] = var19_18;
            var5_5 = var20_19;
            ** GOTO lbl64
        }
        var14_13 = (char)var11_10;
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String encode(String string2, boolean bl) {
        byte[] arrby = null;
        StringBuilder stringBuilder = null;
        int n = string2.length();
        for (int i = 0; i != n; ++i) {
            int n2;
            int n3 = string2.charAt(i);
            if (NativeGlobal.encodeUnescaped((char)n3, bl)) {
                if (stringBuilder == null) continue;
                stringBuilder.append((char)n3);
                continue;
            }
            if (stringBuilder == null) {
                stringBuilder = new StringBuilder(n + 3);
                stringBuilder.append(string2);
                stringBuilder.setLength(i);
                arrby = new byte[6];
            }
            if (56320 <= n3 && n3 <= 57343) {
                throw NativeGlobal.uriError();
            }
            if (n3 < 55296 || 56319 < n3) {
                n2 = n3;
            } else {
                if (++i == n) {
                    throw NativeGlobal.uriError();
                }
                char c = string2.charAt(i);
                if ('\udc00' > c || c > '\udfff') {
                    throw NativeGlobal.uriError();
                }
                n2 = 65536 + ((n3 - 55296 << 10) + (c - 56320));
            }
            int n4 = NativeGlobal.oneUcs4ToUtf8Char(arrby, n2);
            for (int j = 0; j < n4; ++j) {
                int n5 = 255 & arrby[j];
                stringBuilder.append('%');
                stringBuilder.append(NativeGlobal.toHexChar(n5 >>> 4));
                stringBuilder.append(NativeGlobal.toHexChar(n5 & 15));
            }
        }
        if (stringBuilder == null) {
            return string2;
        }
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean encodeUnescaped(char c, boolean bl) {
        block5 : {
            block4 : {
                if ('A' <= c && c <= 'Z' || 'a' <= c && c <= 'z' || '0' <= c && c <= '9' || "-_.!~*'()".indexOf((int)c) >= 0) break block4;
                if (!bl) {
                    return false;
                }
                if (URI_DECODE_RESERVED.indexOf((int)c) < 0) break block5;
            }
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void init(Context context, Scriptable scriptable, boolean bl) {
        NativeGlobal nativeGlobal = new NativeGlobal();
        for (int i = 1; i <= 13; ++i) {
            String string2;
            int n = 1;
            switch (i) {
                default: {
                    throw Kit.codeBug();
                }
                case 1: {
                    string2 = "decodeURI";
                    break;
                }
                case 2: {
                    string2 = "decodeURIComponent";
                    break;
                }
                case 3: {
                    string2 = "encodeURI";
                    break;
                }
                case 4: {
                    string2 = "encodeURIComponent";
                    break;
                }
                case 5: {
                    string2 = "escape";
                    break;
                }
                case 6: {
                    string2 = "eval";
                    break;
                }
                case 7: {
                    string2 = "isFinite";
                    break;
                }
                case 8: {
                    string2 = "isNaN";
                    break;
                }
                case 9: {
                    string2 = "isXMLName";
                    break;
                }
                case 10: {
                    string2 = "parseFloat";
                    break;
                }
                case 11: {
                    string2 = "parseInt";
                    n = 2;
                    break;
                }
                case 12: {
                    string2 = "unescape";
                    break;
                }
                case 13: {
                    string2 = "uneval";
                }
            }
            IdFunctionObject idFunctionObject = new IdFunctionObject(nativeGlobal, FTAG, i, string2, n, scriptable);
            if (bl) {
                idFunctionObject.sealObject();
            }
            idFunctionObject.exportAsScopeProperty();
        }
        ScriptableObject.defineProperty(scriptable, "NaN", (Object)ScriptRuntime.NaNobj, 7);
        ScriptableObject.defineProperty(scriptable, "Infinity", (Object)ScriptRuntime.wrapNumber(Double.POSITIVE_INFINITY), 7);
        ScriptableObject.defineProperty(scriptable, "undefined", Undefined.instance, 7);
        TopLevel.NativeErrors[] arrnativeErrors = TopLevel.NativeErrors.values();
        int n = arrnativeErrors.length;
        int n2 = 0;
        while (n2 < n) {
            TopLevel.NativeErrors nativeErrors = arrnativeErrors[n2];
            if (nativeErrors != TopLevel.NativeErrors.Error) {
                String string3 = nativeErrors.name();
                ScriptableObject scriptableObject = (ScriptableObject)ScriptRuntime.newBuiltinObject(context, scriptable, TopLevel.Builtins.Error, ScriptRuntime.emptyArgs);
                scriptableObject.put("name", (Scriptable)scriptableObject, (Object)string3);
                scriptableObject.put("message", (Scriptable)scriptableObject, (Object)"");
                IdFunctionObject idFunctionObject = new IdFunctionObject(nativeGlobal, FTAG, 14, string3, 1, scriptable);
                idFunctionObject.markAsConstructor(scriptableObject);
                scriptableObject.put("constructor", (Scriptable)scriptableObject, (Object)idFunctionObject);
                scriptableObject.setAttributes("constructor", 2);
                if (bl) {
                    scriptableObject.sealObject();
                    idFunctionObject.sealObject();
                }
                idFunctionObject.exportAsScopeProperty();
            }
            ++n2;
        }
        return;
    }

    static boolean isEvalFunction(Object object) {
        IdFunctionObject idFunctionObject;
        return object instanceof IdFunctionObject && (idFunctionObject = (IdFunctionObject)object).hasTag(FTAG) && idFunctionObject.methodId() == 6;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private Object js_escape(Object[] var1_1) {
        var2_2 = ScriptRuntime.toString(var1_1, 0);
        var3_3 = 7;
        if (var1_1.length > 1) {
            var19_4 = ScriptRuntime.toNumber(var1_1[1]);
            if (var19_4 != var19_4) throw Context.reportRuntimeError0("msg.bad.esc.mask");
            var3_3 = (int)var19_4;
            if ((double)var3_3 != var19_4) throw Context.reportRuntimeError0("msg.bad.esc.mask");
            if ((var3_3 & -8) != 0) {
                throw Context.reportRuntimeError0("msg.bad.esc.mask");
            }
        }
        var4_5 = null;
        var5_6 = 0;
        var6_7 = var2_2.length();
        block0 : do {
            block14 : {
                block12 : {
                    block13 : {
                        block11 : {
                            if (var5_6 == var6_7) {
                                if (var4_5 != null) return var4_5.toString();
                                return var2_2;
                            }
                            var7_8 = var2_2.charAt(var5_6);
                            if (var3_3 == 0 || !(var7_8 >= '0' && var7_8 <= '9' || var7_8 >= 'A' && var7_8 <= 'Z' || var7_8 >= 'a' && var7_8 <= 'z' || var7_8 == '@' || var7_8 == '*' || var7_8 == '_' || var7_8 == '-' || var7_8 == '.') && ((var3_3 & 4) == 0 || var7_8 != '/' && var7_8 != '+')) break block11;
                            if (var4_5 != null) {
                                var4_5.append(var7_8);
                            }
                            ** GOTO lbl43
                        }
                        if (var4_5 == null) {
                            var4_5 = new StringBuilder(var6_7 + 3);
                            var4_5.append(var2_2);
                            var4_5.setLength(var5_6);
                        }
                        if (var7_8 >= '\u0100') break block12;
                        if (var7_8 != ' ' || var3_3 != 2) break block13;
                        var4_5.append('+');
                        ** GOTO lbl43
                    }
                    var4_5.append('%');
                    var11_9 = 2;
                    break block14;
                }
                var4_5.append('%');
                var4_5.append('u');
                var11_9 = 4;
            }
            var12_10 = 4 * (var11_9 - 1);
            do {
                block15 : {
                    if (var12_10 >= 0) break block15;
lbl43: // 3 sources:
                    ++var5_6;
                    continue block0;
                }
                var13_11 = 15 & var7_8 >> var12_10;
                var14_12 = var13_11 < 10 ? var13_11 + 48 : var13_11 + 55;
                var4_5.append((char)var14_12);
                var12_10 -= 4;
            } while (true);
            break;
        } while (true);
    }

    private Object js_eval(Context context, Scriptable scriptable, Object[] arrobject) {
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        return ScriptRuntime.evalSpecial(context, scriptable2, scriptable2, arrobject, "eval code", 1);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static Object js_parseFloat(Object[] var0) {
        block21 : {
            if (var0.length < 1) {
                return ScriptRuntime.NaNobj;
            }
            var1_1 = ScriptRuntime.toString(var0[0]);
            var2_2 = var1_1.length();
            var3_3 = 0;
            do {
                if (var3_3 == var2_2) {
                    return ScriptRuntime.NaNobj;
                }
                var4_4 = var1_1.charAt(var3_3);
                if (!ScriptRuntime.isStrWhiteSpaceChar(var4_4)) {
                    var5_5 = var3_3;
                    if (var4_4 == '+' || var4_4 == '-') {
                        if (++var5_5 != var2_2) break;
                        return ScriptRuntime.NaNobj;
                    }
                    break block21;
                }
                ++var3_3;
            } while (true);
            var4_4 = var1_1.charAt(var5_5);
        }
        if (var4_4 == 'I') {
            if (var5_5 + 8 > var2_2) return ScriptRuntime.NaNobj;
            if (var1_1.regionMatches(var5_5, "Infinity", 0, 8) == false) return ScriptRuntime.NaNobj;
            if (var1_1.charAt(var3_3) == '-') {
                var12_6 = Double.NEGATIVE_INFINITY;
                return ScriptRuntime.wrapNumber(var12_6);
            }
            var12_6 = Double.POSITIVE_INFINITY;
            return ScriptRuntime.wrapNumber(var12_6);
        }
        var6_7 = -1;
        var7_8 = -1;
        var8_9 = false;
        block9 : while (var5_5 < var2_2) {
            block22 : {
                switch (var1_1.charAt(var5_5)) {
                    case '.': {
                        if (var6_7 != -1) ** GOTO lbl45
                        var6_7 = var5_5;
                        break block22;
                    }
                    case 'E': 
                    case 'e': {
                        if (var7_8 != -1 || var5_5 == var2_2 - 1) ** GOTO lbl45
                        var7_8 = var5_5;
                        break block22;
                    }
                    case '+': 
                    case '-': {
                        if (var7_8 != var5_5 - 1) ** GOTO lbl45
                        if (var5_5 != var2_2 - 1) break block22;
                        --var5_5;
                    }
lbl45: // 5 sources:
                    default: {
                        break block9;
                    }
                    {
                    }
                    case '0': 
                    case '1': 
                    case '2': 
                    case '3': 
                    case '4': 
                    case '5': 
                    case '6': 
                    case '7': 
                    case '8': 
                    case '9': 
                }
                if (var7_8 != -1) {
                    var8_9 = true;
                }
            }
            ++var5_5;
        }
        if (var7_8 != -1 && !var8_9) {
            var5_5 = var7_8;
        }
        var9_10 = var1_1.substring(var3_3, var5_5);
        try {
            return Double.valueOf((String)var9_10);
        }
        catch (NumberFormatException var10_12) {
            return ScriptRuntime.NaNobj;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static Object js_parseInt(Object[] arrobject) {
        char c;
        String string2 = ScriptRuntime.toString(arrobject, 0);
        int n = ScriptRuntime.toInt32(arrobject, 1);
        int n2 = string2.length();
        if (n2 == 0) {
            return ScriptRuntime.NaNobj;
        }
        int n3 = 0;
        while (ScriptRuntime.isStrWhiteSpaceChar(c = string2.charAt(n3)) && ++n3 < n2) {
        }
        boolean bl = false;
        if (c == '+' || (bl = c == '-')) {
            ++n3;
        }
        if (n == 0) {
            n = -1;
        } else {
            char c2;
            if (n < 2 || n > 36) {
                return ScriptRuntime.NaNobj;
            }
            if (n == 16 && n2 - n3 > 1 && string2.charAt(n3) == '0' && ((c2 = string2.charAt(n3 + 1)) == 'x' || c2 == 'X')) {
                n3 += 2;
            }
        }
        if (n == -1) {
            n = 10;
            if (n2 - n3 > 1 && string2.charAt(n3) == '0') {
                char c3 = string2.charAt(n3 + 1);
                if (c3 == 'x' || c3 == 'X') {
                    n = 16;
                    n3 += 2;
                } else if ('0' <= c3 && c3 <= '9') {
                    n = 8;
                    ++n3;
                }
            }
        }
        double d = ScriptRuntime.stringToNumber(string2, n3, n);
        if (bl) {
            d = -d;
        }
        return ScriptRuntime.wrapNumber(d);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Object js_unescape(Object[] arrobject) {
        String string2 = ScriptRuntime.toString(arrobject, 0);
        int n = string2.indexOf(37);
        if (n < 0) return string2;
        int n2 = string2.length();
        char[] arrc = string2.toCharArray();
        int n3 = n;
        int n4 = n;
        while (n4 != n2) {
            char c = arrc[n4];
            if (c == '%' && ++n4 != n2) {
                int n5;
                int n6;
                if (arrc[n4] == 'u') {
                    n6 = n4 + 1;
                    n5 = n4 + 5;
                } else {
                    n6 = n4;
                    n5 = n4 + 2;
                }
                if (n5 <= n2) {
                    int n7 = 0;
                    for (int i = n6; i != n5; ++i) {
                        n7 = Kit.xDigitToInt(arrc[i], n7);
                    }
                    if (n7 >= 0) {
                        c = (char)n7;
                        n4 = n5;
                    }
                }
            }
            arrc[n3] = c;
            ++n3;
        }
        return new String(arrc, 0, n3);
    }

    private static int oneUcs4ToUtf8Char(byte[] arrby, int n) {
        if ((n & -128) == 0) {
            arrby[0] = (byte)n;
            return 1;
        }
        int n2 = n >>> 11;
        int n3 = 2;
        while (n2 != 0) {
            n2 >>>= 5;
            ++n3;
        }
        int n4 = n3;
        while (--n4 > 0) {
            arrby[n4] = (byte)(128 | n & 63);
            n >>>= 6;
        }
        arrby[0] = (byte)(n + (256 - (1 << 8 - n3)));
        return n3;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static char toHexChar(int n) {
        int n2;
        if (n >> 4 != 0) {
            Kit.codeBug();
        }
        if (n < 10) {
            n2 = n + 48;
            do {
                return (char)n2;
                break;
            } while (true);
        }
        n2 = 65 + (n - 10);
        return (char)n2;
    }

    private static int unHex(char c) {
        if ('A' <= c && c <= 'F') {
            return 10 + (c - 65);
        }
        if ('a' <= c && c <= 'f') {
            return 10 + (c - 97);
        }
        if ('0' <= c && c <= '9') {
            return c - 48;
        }
        return -1;
    }

    private static int unHex(char c, char c2) {
        int n = NativeGlobal.unHex(c);
        int n2 = NativeGlobal.unHex(c2);
        if (n >= 0 && n2 >= 0) {
            return n2 | n << 4;
        }
        return -1;
    }

    private static EcmaError uriError() {
        return ScriptRuntime.constructError("URIError", ScriptRuntime.getMessage0("msg.bad.uri"));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(FTAG)) throw idFunctionObject.unknown();
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                throw idFunctionObject.unknown();
            }
            case 1: 
            case 2: {
                boolean bl;
                String string2 = ScriptRuntime.toString(arrobject, 0);
                if (n == 1) {
                    bl = true;
                    do {
                        return NativeGlobal.decode(string2, bl);
                        break;
                    } while (true);
                }
                bl = false;
                return NativeGlobal.decode(string2, bl);
            }
            case 3: 
            case 4: {
                boolean bl;
                String string3 = ScriptRuntime.toString(arrobject, 0);
                if (n == 3) {
                    bl = true;
                    do {
                        return NativeGlobal.encode(string3, bl);
                        break;
                    } while (true);
                }
                bl = false;
                return NativeGlobal.encode(string3, bl);
            }
            case 5: {
                return this.js_escape(arrobject);
            }
            case 6: {
                return this.js_eval(context, scriptable, arrobject);
            }
            case 7: {
                if (arrobject.length >= 1) return NativeNumber.isFinite(arrobject[0]);
                return Boolean.FALSE;
            }
            case 8: {
                boolean bl;
                if (arrobject.length < 1) {
                    bl = true;
                    do {
                        return ScriptRuntime.wrapBoolean(bl);
                        break;
                    } while (true);
                }
                double d = ScriptRuntime.toNumber(arrobject[0]);
                if (d != d) {
                    bl = true;
                    return ScriptRuntime.wrapBoolean(bl);
                }
                bl = false;
                return ScriptRuntime.wrapBoolean(bl);
            }
            case 9: {
                Object object;
                if (arrobject.length == 0) {
                    object = Undefined.instance;
                    do {
                        return ScriptRuntime.wrapBoolean(XMLLib.extractFromScope(scriptable).isXMLName(context, object));
                        break;
                    } while (true);
                }
                object = arrobject[0];
                return ScriptRuntime.wrapBoolean(XMLLib.extractFromScope(scriptable).isXMLName(context, object));
            }
            case 10: {
                return NativeGlobal.js_parseFloat(arrobject);
            }
            case 11: {
                return NativeGlobal.js_parseInt(arrobject);
            }
            case 12: {
                return this.js_unescape(arrobject);
            }
            case 13: {
                Object object;
                if (arrobject.length != 0) {
                    object = arrobject[0];
                    do {
                        return ScriptRuntime.uneval(context, scriptable, object);
                        break;
                    } while (true);
                }
                object = Undefined.instance;
                return ScriptRuntime.uneval(context, scriptable, object);
            }
            case 14: 
        }
        return NativeError.make(context, scriptable, idFunctionObject, arrobject);
    }
}

