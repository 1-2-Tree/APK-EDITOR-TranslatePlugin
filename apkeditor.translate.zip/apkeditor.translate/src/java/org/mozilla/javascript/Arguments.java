/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.NativeCall;
import org.mozilla.javascript.NativeFunction;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.UniqueTag;

final class Arguments
extends IdScriptableObject {
    private static final String FTAG = "Arguments";
    private static final int Id_callee = 1;
    private static final int Id_caller = 3;
    private static final int Id_length = 2;
    private static final int MAX_INSTANCE_ID = 3;
    static final long serialVersionUID = 4275508002492040609L;
    private NativeCall activation;
    private Object[] args;
    private int calleeAttr = 2;
    private Object calleeObj;
    private int callerAttr = 2;
    private Object callerObj;
    private int lengthAttr = 2;
    private Object lengthObj;

    public Arguments(NativeCall nativeCall) {
        this.activation = nativeCall;
        Scriptable scriptable = nativeCall.getParentScope();
        this.setParentScope(scriptable);
        this.setPrototype(ScriptableObject.getObjectPrototype(scriptable));
        this.args = nativeCall.originalArgs;
        this.lengthObj = this.args.length;
        NativeFunction nativeFunction = nativeCall.function;
        this.calleeObj = nativeFunction;
        int n = nativeFunction.getLanguageVersion();
        if (n <= 130 && n != 0) {
            this.callerObj = null;
            return;
        }
        this.callerObj = NOT_FOUND;
    }

    private Object arg(int n) {
        if (n < 0 || this.args.length <= n) {
            return NOT_FOUND;
        }
        return this.args[n];
    }

    private Object getFromActivation(int n) {
        String string2 = this.activation.function.getParamOrVarName(n);
        return this.activation.get(string2, this.activation);
    }

    private void putIntoActivation(int n, Object object) {
        String string2 = this.activation.function.getParamOrVarName(n);
        this.activation.put(string2, this.activation, object);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void removeArg(int n) {
        Arguments arguments = this;
        synchronized (arguments) {
            if (this.args[n] != NOT_FOUND) {
                if (this.args == this.activation.originalArgs) {
                    this.args = (Object[])this.args.clone();
                }
                this.args[n] = NOT_FOUND;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void replaceArg(int n, Object object) {
        if (this.sharedWithActivation(n)) {
            this.putIntoActivation(n, object);
        }
        Arguments arguments = this;
        synchronized (arguments) {
            if (this.args == this.activation.originalArgs) {
                this.args = (Object[])this.args.clone();
            }
            this.args[n] = object;
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean sharedWithActivation(int n) {
        NativeFunction nativeFunction = this.activation.function;
        int n2 = nativeFunction.getParamCount();
        if (n >= n2) return false;
        if (n >= n2 - 1) return true;
        String string2 = nativeFunction.getParamOrVarName(n);
        for (int i = n + 1; i < n2; ++i) {
            if (!string2.equals((Object)nativeFunction.getParamOrVarName(i))) continue;
            return false;
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void defineOwnProperty(Context context, Object object, ScriptableObject scriptableObject, boolean bl) {
        int n;
        block5 : {
            block4 : {
                super.defineOwnProperty(context, object, scriptableObject, bl);
                double d = ScriptRuntime.toNumber(object);
                n = (int)d;
                if (d != (double)n || this.arg(n) == NOT_FOUND) break block4;
                if (this.isAccessorDescriptor(scriptableObject)) {
                    this.removeArg(n);
                    return;
                }
                Object object2 = Arguments.getProperty((Scriptable)scriptableObject, "value");
                if (object2 == NOT_FOUND) break block4;
                this.replaceArg(n, object2);
                if (Arguments.isFalse(Arguments.getProperty((Scriptable)scriptableObject, "writable"))) break block5;
            }
            return;
        }
        this.removeArg(n);
    }

    @Override
    public void delete(int n) {
        if (n >= 0 && n < this.args.length) {
            this.removeArg(n);
        }
        super.delete(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findInstanceIdInfo(String string2) {
        int n;
        int n2 = string2.length();
        String string3 = null;
        int n3 = 0;
        if (n2 == 6) {
            char c = string2.charAt(5);
            if (c == 'e') {
                string3 = "callee";
                n3 = 1;
            } else if (c == 'h') {
                string3 = "length";
                n3 = 2;
            } else {
                string3 = null;
                n3 = 0;
                if (c == 'r') {
                    string3 = "caller";
                    n3 = 3;
                }
            }
        }
        if (string3 != null && string3 != string2 && !string3.equals((Object)string2)) {
            n3 = 0;
        }
        if (n3 == 0) {
            return super.findInstanceIdInfo(string2);
        }
        switch (n3) {
            default: {
                throw new IllegalStateException();
            }
            case 1: {
                n = this.calleeAttr;
                return Arguments.instanceIdInfo(n, n3);
            }
            case 3: {
                n = this.callerAttr;
                return Arguments.instanceIdInfo(n, n3);
            }
            case 2: 
        }
        n = this.lengthAttr;
        return Arguments.instanceIdInfo(n, n3);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Object get(int n, Scriptable scriptable) {
        Object object = this.arg(n);
        if (object == NOT_FOUND) {
            return super.get(n, scriptable);
        }
        if (!this.sharedWithActivation(n)) return object;
        return this.getFromActivation(n);
    }

    @Override
    public String getClassName() {
        return FTAG;
    }

    @Override
    Object[] getIds(boolean bl) {
        Object[] arrobject = super.getIds(bl);
        if (this.args.length != 0) {
            boolean[] arrbl = new boolean[this.args.length];
            int n = this.args.length;
            for (int i = 0; i != arrobject.length; ++i) {
                int n2;
                Object object = arrobject[i];
                if (!(object instanceof Integer) || (n2 = ((Integer)object).intValue()) < 0 || n2 >= this.args.length || arrbl[n2]) continue;
                arrbl[n2] = true;
                --n;
            }
            if (!bl) {
                for (int i = 0; i < arrbl.length; ++i) {
                    if (arrbl[i] || !super.has(i, (Scriptable)this)) continue;
                    arrbl[i] = true;
                    --n;
                }
            }
            if (n != 0) {
                Object[] arrobject2 = new Object[n + arrobject.length];
                System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)n, (int)arrobject.length);
                arrobject = arrobject2;
                int n3 = 0;
                for (int i = 0; i != this.args.length; ++i) {
                    if (arrbl != null && arrbl[i]) continue;
                    arrobject[n3] = i;
                    ++n3;
                }
                if (n3 != n) {
                    Kit.codeBug();
                }
            }
        }
        return arrobject;
    }

    @Override
    protected String getInstanceIdName(int n) {
        switch (n) {
            default: {
                return null;
            }
            case 1: {
                return "callee";
            }
            case 2: {
                return "length";
            }
            case 3: 
        }
        return "caller";
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected Object getInstanceIdValue(int n) {
        switch (n) {
            default: {
                return super.getInstanceIdValue(n);
            }
            case 1: {
                return this.calleeObj;
            }
            case 2: {
                return this.lengthObj;
            }
            case 3: 
        }
        Object object = this.callerObj;
        if (object == UniqueTag.NULL_VALUE) {
            return null;
        }
        if (object != null) return object;
        NativeCall nativeCall = this.activation.parentActivationCall;
        if (nativeCall == null) return object;
        return nativeCall.get("arguments", nativeCall);
    }

    @Override
    protected int getMaxInstanceId() {
        return 3;
    }

    @Override
    protected ScriptableObject getOwnPropertyDescriptor(Context context, Object object) {
        int n;
        double d = ScriptRuntime.toNumber(object);
        if (d != (double)(n = (int)d)) {
            return super.getOwnPropertyDescriptor(context, object);
        }
        Object object2 = this.arg(n);
        if (object2 == NOT_FOUND) {
            return super.getOwnPropertyDescriptor(context, object);
        }
        if (this.sharedWithActivation(n)) {
            object2 = this.getFromActivation(n);
        }
        if (super.has(n, (Scriptable)this)) {
            ScriptableObject scriptableObject = super.getOwnPropertyDescriptor(context, object);
            scriptableObject.put("value", (Scriptable)scriptableObject, object2);
            return scriptableObject;
        }
        Scriptable scriptable = this.getParentScope();
        if (scriptable == null) {
            scriptable = this;
        }
        return Arguments.buildDataDescriptor(scriptable, object2, 0);
    }

    @Override
    public boolean has(int n, Scriptable scriptable) {
        if (this.arg(n) != NOT_FOUND) {
            return true;
        }
        return super.has(n, scriptable);
    }

    @Override
    public void put(int n, Scriptable scriptable, Object object) {
        if (this.arg(n) == NOT_FOUND) {
            super.put(n, scriptable, object);
            return;
        }
        this.replaceArg(n, object);
    }

    @Override
    protected void setInstanceIdAttributes(int n, int n2) {
        switch (n) {
            default: {
                super.setInstanceIdAttributes(n, n2);
                return;
            }
            case 1: {
                this.calleeAttr = n2;
                return;
            }
            case 2: {
                this.lengthAttr = n2;
                return;
            }
            case 3: 
        }
        this.callerAttr = n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void setInstanceIdValue(int n, Object object) {
        switch (n) {
            default: {
                super.setInstanceIdValue(n, object);
                return;
            }
            case 1: {
                this.calleeObj = object;
                return;
            }
            case 2: {
                this.lengthObj = object;
                return;
            }
            case 3: 
        }
        if (object == null) {
            object = UniqueTag.NULL_VALUE;
        }
        this.callerObj = object;
    }
}

