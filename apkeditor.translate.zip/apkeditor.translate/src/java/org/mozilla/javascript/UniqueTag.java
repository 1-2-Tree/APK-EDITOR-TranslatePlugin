/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript;

import java.io.Serializable;
import org.mozilla.javascript.Kit;

public final class UniqueTag
implements Serializable {
    public static final UniqueTag DOUBLE_MARK;
    private static final int ID_DOUBLE_MARK = 3;
    private static final int ID_NOT_FOUND = 1;
    private static final int ID_NULL_VALUE = 2;
    public static final UniqueTag NOT_FOUND;
    public static final UniqueTag NULL_VALUE;
    static final long serialVersionUID = -4320556826714577259L;
    private final int tagId;

    static {
        NOT_FOUND = new UniqueTag(1);
        NULL_VALUE = new UniqueTag(2);
        DOUBLE_MARK = new UniqueTag(3);
    }

    private UniqueTag(int n) {
        this.tagId = n;
    }

    public Object readResolve() {
        switch (this.tagId) {
            default: {
                throw new IllegalStateException(String.valueOf((int)this.tagId));
            }
            case 1: {
                return NOT_FOUND;
            }
            case 2: {
                return NULL_VALUE;
            }
            case 3: 
        }
        return DOUBLE_MARK;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public String toString() {
        String string2;
        switch (this.tagId) {
            default: {
                throw Kit.codeBug();
            }
            case 1: {
                string2 = "NOT_FOUND";
                do {
                    return super.toString() + ": " + string2;
                    break;
                } while (true);
            }
            case 2: {
                string2 = "NULL_VALUE";
                return super.toString() + ": " + string2;
            }
            case 3: 
        }
        string2 = "DOUBLE_MARK";
        return super.toString() + ": " + string2;
    }
}

