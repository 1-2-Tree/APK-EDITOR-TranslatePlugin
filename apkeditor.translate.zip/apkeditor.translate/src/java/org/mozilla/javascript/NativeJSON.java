/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.Stack
 */
package org.mozilla.javascript;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.NativeBoolean;
import org.mozilla.javascript.NativeNumber;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.NativeString;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.json.JsonParser;

public final class NativeJSON
extends IdScriptableObject {
    private static final int Id_parse = 2;
    private static final int Id_stringify = 3;
    private static final int Id_toSource = 1;
    private static final Object JSON_TAG = "JSON";
    private static final int LAST_METHOD_ID = 3;
    private static final int MAX_ID = 3;
    private static final int MAX_STRINGIFY_GAP_LENGTH = 10;
    static final long serialVersionUID = -4567599697595654984L;

    private NativeJSON() {
    }

    static void init(Scriptable scriptable, boolean bl) {
        NativeJSON nativeJSON = new NativeJSON();
        nativeJSON.activatePrototypeMap(3);
        nativeJSON.setPrototype(NativeJSON.getObjectPrototype(scriptable));
        nativeJSON.setParentScope(scriptable);
        if (bl) {
            nativeJSON.sealObject();
        }
        ScriptableObject.defineProperty(scriptable, "JSON", nativeJSON, 2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String ja(NativeArray nativeArray, StringifyState stringifyState) {
        String string2;
        if (stringifyState.stack.search((Object)nativeArray) != -1) {
            throw ScriptRuntime.typeError0("msg.cyclic.value");
        }
        stringifyState.stack.push((Object)nativeArray);
        String string3 = stringifyState.indent;
        stringifyState.indent = stringifyState.indent + stringifyState.gap;
        LinkedList linkedList = new LinkedList();
        long l = nativeArray.getLength();
        for (long i = 0L; i < l; ++i) {
            Object object = i > Integer.MAX_VALUE ? NativeJSON.str(Long.toString((long)i), nativeArray, stringifyState) : NativeJSON.str((int)i, nativeArray, stringifyState);
            if (object == Undefined.instance) {
                linkedList.add((Object)"null");
                continue;
            }
            linkedList.add(object);
        }
        if (linkedList.isEmpty()) {
            string2 = "[]";
        } else if (stringifyState.gap.length() == 0) {
            string2 = '[' + NativeJSON.join((Collection<Object>)linkedList, ",") + ']';
        } else {
            String string4 = NativeJSON.join((Collection<Object>)linkedList, ",\n" + stringifyState.indent);
            string2 = "[\n" + stringifyState.indent + string4 + '\n' + string3 + ']';
        }
        stringifyState.stack.pop();
        stringifyState.indent = string3;
        return string2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String jo(Scriptable scriptable, StringifyState stringifyState) {
        String string2;
        if (stringifyState.stack.search((Object)scriptable) != -1) {
            throw ScriptRuntime.typeError0("msg.cyclic.value");
        }
        stringifyState.stack.push((Object)scriptable);
        String string3 = stringifyState.indent;
        stringifyState.indent = stringifyState.indent + stringifyState.gap;
        Object[] arrobject = stringifyState.propertyList != null ? stringifyState.propertyList.toArray() : scriptable.getIds();
        LinkedList linkedList = new LinkedList();
        for (Object object : arrobject) {
            Object object2 = NativeJSON.str(object, scriptable, stringifyState);
            if (object2 == Undefined.instance) continue;
            String string4 = NativeJSON.quote(object.toString()) + ":";
            if (stringifyState.gap.length() > 0) {
                string4 = string4 + " ";
            }
            linkedList.add((Object)(string4 + object2));
        }
        if (linkedList.isEmpty()) {
            string2 = "{}";
        } else if (stringifyState.gap.length() == 0) {
            string2 = '{' + NativeJSON.join((Collection<Object>)linkedList, ",") + '}';
        } else {
            String string5 = NativeJSON.join((Collection<Object>)linkedList, ",\n" + stringifyState.indent);
            string2 = "{\n" + stringifyState.indent + string5 + '\n' + string3 + '}';
        }
        stringifyState.stack.pop();
        stringifyState.indent = string3;
        return string2;
    }

    private static String join(Collection<Object> collection, String string2) {
        if (collection == null || collection.isEmpty()) {
            return "";
        }
        Iterator iterator = collection.iterator();
        if (!iterator.hasNext()) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder(iterator.next().toString());
        while (iterator.hasNext()) {
            stringBuilder.append(string2).append(iterator.next().toString());
        }
        return stringBuilder.toString();
    }

    private static Object parse(Context context, Scriptable scriptable, String string2) {
        try {
            Object object = new JsonParser(context, scriptable).parseValue(string2);
            return object;
        }
        catch (JsonParser.ParseException parseException) {
            throw ScriptRuntime.constructError("SyntaxError", parseException.getMessage());
        }
    }

    public static Object parse(Context context, Scriptable scriptable, String string2, Callable callable) {
        Object object = NativeJSON.parse(context, scriptable, string2);
        Scriptable scriptable2 = context.newObject(scriptable);
        scriptable2.put("", scriptable2, object);
        return NativeJSON.walk(context, scriptable, callable, scriptable2, "");
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String quote(String string2) {
        StringBuilder stringBuilder = new StringBuilder(2 + string2.length());
        stringBuilder.append('\"');
        int n = string2.length();
        int n2 = 0;
        do {
            block11 : {
                if (n2 >= n) {
                    stringBuilder.append('\"');
                    return stringBuilder.toString();
                }
                char c = string2.charAt(n2);
                switch (c) {
                    default: {
                        if (c >= ' ') break;
                        stringBuilder.append("\\u");
                        Object[] arrobject = new Object[]{(int)c};
                        stringBuilder.append(String.format((String)"%04x", (Object[])arrobject));
                        break block11;
                    }
                    case '\"': {
                        stringBuilder.append("\\\"");
                        break block11;
                    }
                    case '\\': {
                        stringBuilder.append("\\\\");
                        break block11;
                    }
                    case '\b': {
                        stringBuilder.append("\\b");
                        break block11;
                    }
                    case '\f': {
                        stringBuilder.append("\\f");
                        break block11;
                    }
                    case '\n': {
                        stringBuilder.append("\\n");
                        break block11;
                    }
                    case '\r': {
                        stringBuilder.append("\\r");
                        break block11;
                    }
                    case '\t': {
                        stringBuilder.append("\\t");
                        break block11;
                    }
                }
                stringBuilder.append(c);
            }
            ++n2;
        } while (true);
    }

    private static String repeat(char c, int n) {
        char[] arrc = new char[n];
        Arrays.fill((char[])arrc, (char)c);
        return new String(arrc);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object str(Object object, Scriptable scriptable, StringifyState stringifyState) {
        Object object2 = object instanceof String ? NativeJSON.getProperty(scriptable, (String)object) : NativeJSON.getProperty(scriptable, ((Number)object).intValue());
        if (object2 instanceof Scriptable && NativeJSON.getProperty((Scriptable)object2, "toJSON") instanceof Callable) {
            object2 = NativeJSON.callMethod(stringifyState.cx, (Scriptable)object2, "toJSON", new Object[]{object});
        }
        if (stringifyState.replacer != null) {
            object2 = stringifyState.replacer.call(stringifyState.cx, stringifyState.scope, scriptable, new Object[]{object, object2});
        }
        if (object2 instanceof NativeNumber) {
            object2 = ScriptRuntime.toNumber(object2);
        } else if (object2 instanceof NativeString) {
            object2 = ScriptRuntime.toString(object2);
        } else if (object2 instanceof NativeBoolean) {
            object2 = ((NativeBoolean)object2).getDefaultValue(ScriptRuntime.BooleanClass);
        }
        if (object2 == null) {
            return "null";
        }
        if (object2.equals((Object)Boolean.TRUE)) {
            return "true";
        }
        if (object2.equals((Object)Boolean.FALSE)) {
            return "false";
        }
        if (object2 instanceof CharSequence) {
            return NativeJSON.quote(object2.toString());
        }
        if (object2 instanceof Number) {
            double d = ((Number)object2).doubleValue();
            if (d == d && d != Double.POSITIVE_INFINITY && d != Double.NEGATIVE_INFINITY) {
                return ScriptRuntime.toString(object2);
            }
            return "null";
        }
        if (object2 instanceof Scriptable && !(object2 instanceof Callable)) {
            if (object2 instanceof NativeArray) {
                return NativeJSON.ja((NativeArray)object2, stringifyState);
            }
            return NativeJSON.jo((Scriptable)object2, stringifyState);
        }
        return Undefined.instance;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static Object stringify(Context var0, Scriptable var1_1, Object var2_2, Object var3_3, Object var4_4) {
        block14 : {
            var5_5 = "";
            var6_6 = null;
            if (!(var3_3 instanceof Callable)) break block14;
            var8_7 = (Callable)var3_3;
            ** GOTO lbl-1000
        }
        var7_12 = var3_3 instanceof NativeArray;
        var8_7 = null;
        var6_6 = null;
        if (var7_12) {
            var6_6 = new LinkedList();
            var9_13 = (NativeArray)var3_3;
            var10_14 = var9_13.getIndexIds();
            var11_15 = var10_14.length;
            var12_16 = 0;
        } else lbl-1000: // 3 sources:
        {
            do {
                if (var4_4 instanceof NativeNumber) {
                    var4_4 = ScriptRuntime.toNumber(var4_4);
                } else if (var4_4 instanceof NativeString) {
                    var4_4 = ScriptRuntime.toString(var4_4);
                }
                if (var4_4 instanceof Number) {
                    var19_8 = Math.min((int)10, (int)((int)ScriptRuntime.toInteger(var4_4)));
                    var5_5 = var19_8 > 0 ? NativeJSON.repeat(' ', var19_8) : "";
                    var16_9 = var19_8;
                } else if (var4_4 instanceof String && (var5_5 = (String)var4_4).length() > 10) {
                    var5_5 = var5_5.substring(0, 10);
                    var16_9 = var4_4;
                } else {
                    var16_9 = var4_4;
                }
                var17_10 = new StringifyState(var0, var1_1, "", var5_5, var8_7, (List<Object>)var6_6, var16_9);
                var18_11 = new NativeObject();
                var18_11.setParentScope(var1_1);
                var18_11.setPrototype(ScriptableObject.getObjectPrototype(var1_1));
                var18_11.defineProperty("", var2_2, 0);
                return NativeJSON.str("", var18_11, var17_10);
                break;
            } while (true);
        }
        do {
            var8_7 = null;
            if (var12_16 >= var11_15) ** continue;
            var13_17 = var9_13.get(var10_14[var12_16], var9_13);
            if (var13_17 instanceof String || var13_17 instanceof Number) {
                var6_6.add(var13_17);
            } else if (var13_17 instanceof NativeString || var13_17 instanceof NativeNumber) {
                var6_6.add((Object)ScriptRuntime.toString(var13_17));
            }
            ++var12_16;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object walk(Context context, Scriptable scriptable, Callable callable, Scriptable scriptable2, Object object) {
        Object[] arrobject;
        int n;
        Object object2 = object instanceof Number ? scriptable2.get(((Number)object).intValue(), scriptable2) : scriptable2.get((String)object, scriptable2);
        if (!(object2 instanceof Scriptable)) return callable.call(context, scriptable, scriptable2, new Object[]{object, object2});
        Scriptable scriptable3 = (Scriptable)object2;
        if (!(scriptable3 instanceof NativeArray)) {
            arrobject = scriptable3.getIds();
            n = arrobject.length;
        } else {
            long l = ((NativeArray)scriptable3).getLength();
            for (long i = 0L; i < l; ++i) {
                if (i > Integer.MAX_VALUE) {
                    String string2 = Long.toString((long)i);
                    Object object3 = NativeJSON.walk(context, scriptable, callable, scriptable3, string2);
                    if (object3 == Undefined.instance) {
                        scriptable3.delete(string2);
                        continue;
                    }
                    scriptable3.put(string2, scriptable3, object3);
                    continue;
                }
                int n2 = (int)i;
                Object object4 = NativeJSON.walk(context, scriptable, callable, scriptable3, n2);
                if (object4 == Undefined.instance) {
                    scriptable3.delete(n2);
                    continue;
                }
                scriptable3.put(n2, scriptable3, object4);
            }
            return callable.call(context, scriptable, scriptable2, new Object[]{object, object2});
        }
        for (int i = 0; i < n; ++i) {
            Object object5 = arrobject[i];
            Object object6 = NativeJSON.walk(context, scriptable, callable, scriptable3, object5);
            if (object6 == Undefined.instance) {
                if (object5 instanceof Number) {
                    scriptable3.delete(((Number)object5).intValue());
                    continue;
                }
                scriptable3.delete((String)object5);
                continue;
            }
            if (object5 instanceof Number) {
                scriptable3.put(((Number)object5).intValue(), scriptable3, object6);
                continue;
            }
            scriptable3.put((String)object5, scriptable3, object6);
        }
        return callable.call(context, scriptable, scriptable2, new Object[]{object, object2});
    }

    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(JSON_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                throw new IllegalStateException(String.valueOf((int)n));
            }
            case 1: {
                return "JSON";
            }
            case 2: {
                String string2 = ScriptRuntime.toString(arrobject, 0);
                int n2 = arrobject.length;
                Object object = null;
                if (n2 > 1) {
                    object = arrobject[1];
                }
                if (object instanceof Callable) {
                    return NativeJSON.parse(context, scriptable, string2, (Callable)object);
                }
                return NativeJSON.parse(context, scriptable, string2);
            }
            case 3: 
        }
        int n3 = arrobject.length;
        Object object = null;
        Object object2 = null;
        Object object3 = null;
        switch (n3) {
            default: {
                object2 = arrobject[2];
            }
            case 2: {
                object = arrobject[1];
            }
            case 1: {
                object3 = arrobject[0];
            }
            case 0: 
        }
        return NativeJSON.stringify(context, scriptable, object3, object, object2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        switch (n) {
            case 5: {
                string3 = "parse";
                n2 = 2;
                break;
            }
            case 8: {
                string3 = "toSource";
                n2 = 1;
                break;
            }
            case 9: {
                string3 = "stringify";
                n2 = 3;
                break;
            }
        }
        if (string3 == null) return n2;
        if (string3 == string2) return n2;
        if (string3.equals((Object)string2)) return n2;
        return 0;
    }

    @Override
    public String getClassName() {
        return "JSON";
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        if (n > 3) {
            throw new IllegalStateException(String.valueOf((int)n));
        }
        switch (n) {
            default: {
                throw new IllegalStateException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 0;
                string2 = "toSource";
                break;
            }
            case 2: {
                n2 = 2;
                string2 = "parse";
                break;
            }
            case 3: {
                n2 = 3;
                string2 = "stringify";
            }
        }
        this.initPrototypeMethod(JSON_TAG, n, string2, n2);
    }

    private static class StringifyState {
        Context cx;
        String gap;
        String indent;
        List<Object> propertyList;
        Callable replacer;
        Scriptable scope;
        Object space;
        Stack<Scriptable> stack = new Stack();

        StringifyState(Context context, Scriptable scriptable, String string2, String string3, Callable callable, List<Object> list, Object object) {
            this.cx = context;
            this.scope = scriptable;
            this.indent = string2;
            this.gap = string3;
            this.replacer = callable;
            this.propertyList = list;
            this.space = object;
        }
    }

}

