/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.security.AccessController
 *  java.security.PrivilegedAction
 */
package org.mozilla.javascript;

import java.lang.reflect.Method;
import java.security.AccessController;
import java.security.PrivilegedAction;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.ConsString;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextAction;
import org.mozilla.javascript.DefiningClassLoader;
import org.mozilla.javascript.GeneratedClassLoader;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.xml.XMLLib;

public class ContextFactory {
    private static ContextFactory global = new ContextFactory();
    private static volatile boolean hasCustomGlobal;
    private ClassLoader applicationClassLoader;
    private boolean disabledListening;
    private volatile Object listeners;
    private final Object listenersLock = new Object();
    private volatile boolean sealed;

    public static ContextFactory getGlobal() {
        return global;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static GlobalSetter getGlobalSetter() {
        Class<ContextFactory> class_ = ContextFactory.class;
        synchronized (ContextFactory.class) {
            if (hasCustomGlobal) {
                throw new IllegalStateException();
            }
            hasCustomGlobal = true;
            return new 1GlobalSetterImpl();
        }
    }

    public static boolean hasExplicitGlobal() {
        return hasCustomGlobal;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void initGlobal(ContextFactory contextFactory) {
        Class<ContextFactory> class_ = ContextFactory.class;
        synchronized (ContextFactory.class) {
            if (contextFactory == null) {
                throw new IllegalArgumentException();
            }
            if (hasCustomGlobal) {
                throw new IllegalStateException();
            }
            hasCustomGlobal = true;
            global = contextFactory;
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return;
        }
    }

    private boolean isDom3Present() {
        Class<?> class_ = Kit.classOrNull("org.w3c.dom.Node");
        if (class_ == null) {
            return false;
        }
        try {
            class_.getMethod("getUserData", new Class[]{String.class});
            return true;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            return false;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void addListener(Listener listener) {
        Object object;
        this.checkNotSealed();
        Object object2 = object = this.listenersLock;
        synchronized (object2) {
            if (this.disabledListening) {
                throw new IllegalStateException();
            }
            this.listeners = Kit.addListener(this.listeners, listener);
            return;
        }
    }

    public final Object call(ContextAction contextAction) {
        return Context.call(this, contextAction);
    }

    protected final void checkNotSealed() {
        if (this.sealed) {
            throw new IllegalStateException();
        }
    }

    protected GeneratedClassLoader createClassLoader(final ClassLoader classLoader) {
        return (GeneratedClassLoader)AccessController.doPrivileged((PrivilegedAction)new PrivilegedAction<DefiningClassLoader>(){

            public DefiningClassLoader run() {
                return new DefiningClassLoader(classLoader);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    final void disableContextListening() {
        Object object;
        this.checkNotSealed();
        Object object2 = object = this.listenersLock;
        synchronized (object2) {
            this.disabledListening = true;
            this.listeners = null;
            return;
        }
    }

    protected Object doTopCall(Callable callable, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        Object object = callable.call(context, scriptable, scriptable2, arrobject);
        if (object instanceof ConsString) {
            object = object.toString();
        }
        return object;
    }

    @Deprecated
    public final Context enter() {
        return this.enterContext(null);
    }

    public Context enterContext() {
        return this.enterContext(null);
    }

    public final Context enterContext(Context context) {
        return Context.enter(context, this);
    }

    @Deprecated
    public final void exit() {
        Context.exit();
    }

    public final ClassLoader getApplicationClassLoader() {
        return this.applicationClassLoader;
    }

    protected XMLLib.Factory getE4xImplementationFactory() {
        if (this.isDom3Present()) {
            return XMLLib.Factory.create("org.mozilla.javascript.xmlimpl.XMLLibImpl");
        }
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean hasFeature(Context context, int n) {
        boolean bl = true;
        boolean bl2 = false;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                int n2 = context.getLanguageVersion();
                if (n2 != 100 && n2 != 110) {
                    bl2 = false;
                    if (n2 != 120) return bl2;
                }
                bl2 = bl;
            }
            case 2: 
            case 7: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 12: 
            case 13: {
                return bl2;
            }
            case 3: {
                return bl;
            }
            case 4: {
                if (context.getLanguageVersion() != 120) return false;
                return bl;
            }
            case 5: {
                return bl;
            }
            case 6: {
                int n3 = context.getLanguageVersion();
                if (n3 == 0) return bl;
                bl2 = false;
                if (n3 < 160) return bl2;
                return bl;
            }
            case 14: 
        }
        return bl;
    }

    public final void initApplicationClassLoader(ClassLoader classLoader) {
        if (classLoader == null) {
            throw new IllegalArgumentException("loader is null");
        }
        if (!Kit.testIfCanLoadRhinoClasses(classLoader)) {
            throw new IllegalArgumentException("Loader can not resolve Rhino classes");
        }
        if (this.applicationClassLoader != null) {
            throw new IllegalStateException("applicationClassLoader can only be set once");
        }
        this.checkNotSealed();
        this.applicationClassLoader = classLoader;
    }

    public final boolean isSealed() {
        return this.sealed;
    }

    protected Context makeContext() {
        return new Context(this);
    }

    protected void observeInstructionCount(Context context, int n) {
    }

    protected void onContextCreated(Context context) {
        Object object = this.listeners;
        int n = 0;
        Listener listener;
        while ((listener = (Listener)Kit.getListener(object, n)) != null) {
            listener.contextCreated(context);
            ++n;
        }
        return;
    }

    protected void onContextReleased(Context context) {
        Object object = this.listeners;
        int n = 0;
        Listener listener;
        while ((listener = (Listener)Kit.getListener(object, n)) != null) {
            listener.contextReleased(context);
            ++n;
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void removeListener(Listener listener) {
        Object object;
        this.checkNotSealed();
        Object object2 = object = this.listenersLock;
        synchronized (object2) {
            if (this.disabledListening) {
                throw new IllegalStateException();
            }
            this.listeners = Kit.removeListener(this.listeners, listener);
            return;
        }
    }

    public final void seal() {
        this.checkNotSealed();
        this.sealed = true;
    }

    class 1GlobalSetterImpl
    implements GlobalSetter {
        1GlobalSetterImpl() {
        }

        @Override
        public ContextFactory getContextFactoryGlobal() {
            return global;
        }

        @Override
        public void setContextFactoryGlobal(ContextFactory contextFactory) {
            if (contextFactory == null) {
                contextFactory = new ContextFactory();
            }
            global = contextFactory;
        }
    }

    public static interface GlobalSetter {
        public ContextFactory getContextFactoryGlobal();

        public void setContextFactoryGlobal(ContextFactory var1);
    }

    public static interface Listener {
        public void contextCreated(Context var1);

        public void contextReleased(Context var1);
    }

}

