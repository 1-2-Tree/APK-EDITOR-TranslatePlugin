/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.lang.ref.SoftReference
 *  java.lang.reflect.UndeclaredThrowableException
 *  java.net.URL
 *  java.security.AccessController
 *  java.security.CodeSource
 *  java.security.PrivilegedAction
 *  java.security.PrivilegedActionException
 *  java.security.PrivilegedExceptionAction
 *  java.security.SecureClassLoader
 *  java.util.Map
 *  java.util.WeakHashMap
 */
package org.mozilla.javascript;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.lang.reflect.UndeclaredThrowableException;
import java.net.URL;
import java.security.AccessController;
import java.security.CodeSource;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.security.SecureClassLoader;
import java.util.Map;
import java.util.WeakHashMap;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public abstract class SecureCaller {
    private static final Map<CodeSource, Map<ClassLoader, SoftReference<SecureCaller>>> callers;
    private static final byte[] secureCallerImplBytecode;

    static {
        secureCallerImplBytecode = SecureCaller.loadBytecode();
        callers = new WeakHashMap();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static Object callSecurely(final CodeSource codeSource, Callable callable, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        Map<CodeSource, Map<ClassLoader, SoftReference<SecureCaller>>> map;
        Map map2;
        final ClassLoader classLoader = (ClassLoader)AccessController.doPrivileged((PrivilegedAction)new PrivilegedAction<Object>(Thread.currentThread()){
            final /* synthetic */ Thread val$thread;
            {
                this.val$thread = thread;
            }

            public Object run() {
                return this.val$thread.getContextClassLoader();
            }
        });
        Map<CodeSource, Map<ClassLoader, SoftReference<SecureCaller>>> map3 = map = callers;
        synchronized (map3) {
            map2 = (Map)callers.get((Object)codeSource);
            if (map2 == null) {
                map2 = new WeakHashMap();
                callers.put((Object)codeSource, (Object)map2);
            }
        }
        Map map4 = map2;
        synchronized (map4) {
            SecureCaller secureCaller;
            block9 : {
                SoftReference softReference = (SoftReference)map2.get((Object)classLoader);
                secureCaller = softReference != null ? (SecureCaller)softReference.get() : null;
                if (secureCaller != null) break block9;
                try {
                    secureCaller = (SecureCaller)AccessController.doPrivileged((PrivilegedExceptionAction)new PrivilegedExceptionAction<Object>(){

                        /*
                         * Enabled force condition propagation
                         * Lifted jumps to return sites
                         */
                        public Object run() throws Exception {
                            ClassLoader classLoader2;
                            Class class_ = this.getClass();
                            if (classLoader.loadClass(class_.getName()) != class_) {
                                classLoader2 = class_.getClassLoader();
                                do {
                                    return new SecureClassLoaderImpl(classLoader2).defineAndLinkClass(SecureCaller.class.getName() + "Impl", secureCallerImplBytecode, codeSource).newInstance();
                                    break;
                                } while (true);
                            }
                            classLoader2 = classLoader;
                            return new SecureClassLoaderImpl(classLoader2).defineAndLinkClass(SecureCaller.class.getName() + "Impl", secureCallerImplBytecode, codeSource).newInstance();
                        }
                    });
                    map2.put((Object)classLoader, (Object)new SoftReference((Object)secureCaller));
                }
                catch (PrivilegedActionException privilegedActionException) {
                    throw new UndeclaredThrowableException(privilegedActionException.getCause());
                }
            }
            return secureCaller.call(callable, context, scriptable, scriptable2, arrobject);
        }
    }

    private static byte[] loadBytecode() {
        return (byte[])AccessController.doPrivileged((PrivilegedAction)new PrivilegedAction<Object>(){

            public Object run() {
                return SecureCaller.loadBytecodePrivileged();
            }
        });
    }

    private static byte[] loadBytecodePrivileged() {
        int n;
        ByteArrayOutputStream byteArrayOutputStream;
        URL uRL = SecureCaller.class.getResource("SecureCallerImpl.clazz");
        InputStream inputStream = uRL.openStream();
        try {
            byteArrayOutputStream = new ByteArrayOutputStream();
            do {
                if ((n = inputStream.read()) != -1) break block9;
                break;
            } while (true);
        }
        catch (Throwable throwable) {
            try {
                inputStream.close();
                throw throwable;
            }
            catch (IOException iOException) {
                throw new UndeclaredThrowableException((Throwable)iOException);
            }
        }
        {
            block9 : {
                byte[] arrby = byteArrayOutputStream.toByteArray();
                inputStream.close();
                return arrby;
            }
            byteArrayOutputStream.write(n);
            continue;
        }
    }

    public abstract Object call(Callable var1, Context var2, Scriptable var3, Scriptable var4, Object[] var5);

    private static class SecureClassLoaderImpl
    extends SecureClassLoader {
        SecureClassLoaderImpl(ClassLoader classLoader) {
            super(classLoader);
        }

        Class<?> defineAndLinkClass(String string2, byte[] arrby, CodeSource codeSource) {
            Class class_ = this.defineClass(string2, arrby, 0, arrby.length, codeSource);
            this.resolveClass(class_);
            return class_;
        }
    }

}

