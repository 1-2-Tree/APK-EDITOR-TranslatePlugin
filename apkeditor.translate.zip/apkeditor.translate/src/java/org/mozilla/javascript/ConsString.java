/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript;

import java.io.Serializable;

public class ConsString
implements CharSequence,
Serializable {
    private static final long serialVersionUID = -8432806714471372570L;
    private int depth;
    private final int length;
    private CharSequence s1;
    private CharSequence s2;

    public ConsString(CharSequence charSequence, CharSequence charSequence2) {
        this.s1 = charSequence;
        this.s2 = charSequence2;
        this.length = charSequence.length() + charSequence2.length();
        this.depth = 1;
        if (charSequence instanceof ConsString) {
            this.depth += ((ConsString)charSequence).depth;
        }
        if (charSequence2 instanceof ConsString) {
            this.depth += ((ConsString)charSequence2).depth;
        }
        if (this.depth > 2000) {
            this.flatten();
        }
    }

    private static void appendFragment(CharSequence charSequence, StringBuilder stringBuilder) {
        if (charSequence instanceof ConsString) {
            ((ConsString)charSequence).appendTo(stringBuilder);
            return;
        }
        stringBuilder.append(charSequence);
    }

    private void appendTo(StringBuilder stringBuilder) {
        ConsString consString = this;
        synchronized (consString) {
            ConsString.appendFragment(this.s1, stringBuilder);
            ConsString.appendFragment(this.s2, stringBuilder);
            return;
        }
    }

    private String flatten() {
        ConsString consString = this;
        synchronized (consString) {
            if (this.depth > 0) {
                StringBuilder stringBuilder = new StringBuilder(this.length);
                this.appendTo(stringBuilder);
                this.s1 = stringBuilder.toString();
                this.s2 = "";
                this.depth = 0;
            }
            String string2 = (String)this.s1;
            return string2;
        }
    }

    private Object writeReplace() {
        return this.toString();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public char charAt(int n) {
        String string2;
        if (this.depth == 0) {
            string2 = (String)this.s1;
            do {
                return string2.charAt(n);
                break;
            } while (true);
        }
        string2 = this.flatten();
        return string2.charAt(n);
    }

    public int length() {
        return this.length;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public CharSequence subSequence(int n, int n2) {
        String string2;
        if (this.depth == 0) {
            string2 = (String)this.s1;
            do {
                return string2.substring(n, n2);
                break;
            } while (true);
        }
        string2 = this.flatten();
        return string2.substring(n, n2);
    }

    public String toString() {
        if (this.depth == 0) {
            return (String)this.s1;
        }
        return this.flatten();
    }
}

