/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package org.mozilla.javascript;

import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

public class BoundFunction
extends BaseFunction {
    static final long serialVersionUID = 2118137342826470729L;
    private final Object[] boundArgs;
    private final Scriptable boundThis;
    private final int length;
    private final Callable targetFunction;

    /*
     * Enabled aggressive block sorting
     */
    public BoundFunction(Context context, Scriptable scriptable, Callable callable, Scriptable scriptable2, Object[] arrobject) {
        this.targetFunction = callable;
        this.boundThis = scriptable2;
        this.boundArgs = arrobject;
        this.length = callable instanceof BaseFunction ? Math.max((int)0, (int)(((BaseFunction)callable).getLength() - arrobject.length)) : 0;
        ScriptRuntime.setFunctionProtoAndParent(this, scriptable);
        BaseFunction baseFunction = ScriptRuntime.typeErrorThrower(context);
        NativeObject nativeObject = new NativeObject();
        nativeObject.put("get", nativeObject, baseFunction);
        nativeObject.put("set", nativeObject, baseFunction);
        nativeObject.put("enumerable", nativeObject, false);
        nativeObject.put("configurable", nativeObject, false);
        nativeObject.preventExtensions();
        this.defineOwnProperty(context, "caller", nativeObject, false);
        this.defineOwnProperty(context, "arguments", nativeObject, false);
    }

    private Object[] concat(Object[] arrobject, Object[] arrobject2) {
        Object[] arrobject3 = new Object[arrobject.length + arrobject2.length];
        System.arraycopy((Object)arrobject, (int)0, (Object)arrobject3, (int)0, (int)arrobject.length);
        System.arraycopy((Object)arrobject2, (int)0, (Object)arrobject3, (int)arrobject.length, (int)arrobject2.length);
        return arrobject3;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        Scriptable scriptable3;
        if (this.boundThis != null) {
            scriptable3 = this.boundThis;
            do {
                return this.targetFunction.call(context, scriptable, scriptable3, this.concat(this.boundArgs, arrobject));
                break;
            } while (true);
        }
        scriptable3 = ScriptRuntime.getTopCallScope(context);
        return this.targetFunction.call(context, scriptable, scriptable3, this.concat(this.boundArgs, arrobject));
    }

    @Override
    public Scriptable construct(Context context, Scriptable scriptable, Object[] arrobject) {
        if (this.targetFunction instanceof Function) {
            return ((Function)this.targetFunction).construct(context, scriptable, this.concat(this.boundArgs, arrobject));
        }
        throw ScriptRuntime.typeError0("msg.not.ctor");
    }

    @Override
    public int getLength() {
        return this.length;
    }

    @Override
    public boolean hasInstance(Scriptable scriptable) {
        if (this.targetFunction instanceof Function) {
            return ((Function)this.targetFunction).hasInstance(scriptable);
        }
        throw ScriptRuntime.typeError0("msg.not.ctor");
    }
}

