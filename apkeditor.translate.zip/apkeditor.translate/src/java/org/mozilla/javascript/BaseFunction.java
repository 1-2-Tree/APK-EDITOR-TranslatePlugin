/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 */
package org.mozilla.javascript;

import org.mozilla.javascript.BoundFunction;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.DefaultErrorReporter;
import org.mozilla.javascript.Delegator;
import org.mozilla.javascript.ErrorReporter;
import org.mozilla.javascript.Evaluator;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.NativeCall;
import org.mozilla.javascript.NativeFunction;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.UniqueTag;

public class BaseFunction
extends IdScriptableObject
implements Function {
    private static final Object FUNCTION_TAG = "Function";
    private static final int Id_apply = 4;
    private static final int Id_arguments = 5;
    private static final int Id_arity = 2;
    private static final int Id_bind = 6;
    private static final int Id_call = 5;
    private static final int Id_constructor = 1;
    private static final int Id_length = 1;
    private static final int Id_name = 3;
    private static final int Id_prototype = 4;
    private static final int Id_toSource = 3;
    private static final int Id_toString = 2;
    private static final int MAX_INSTANCE_ID = 5;
    private static final int MAX_PROTOTYPE_ID = 6;
    static final long serialVersionUID = 5311394446546053859L;
    private int argumentsAttributes = 6;
    private Object argumentsObj = NOT_FOUND;
    private Object prototypeProperty;
    private int prototypePropertyAttributes = 6;

    public BaseFunction() {
    }

    public BaseFunction(Scriptable scriptable, Scriptable scriptable2) {
        super(scriptable, scriptable2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Object getArguments() {
        Object object = this.defaultHas("arguments") ? this.defaultGet("arguments") : this.argumentsObj;
        if (object != NOT_FOUND) {
            return object;
        }
        NativeCall nativeCall = ScriptRuntime.findFunctionActivation(Context.getContext(), this);
        if (nativeCall != null) return nativeCall.get("arguments", nativeCall);
        return null;
    }

    static void init(Scriptable scriptable, boolean bl) {
        BaseFunction baseFunction = new BaseFunction();
        baseFunction.prototypePropertyAttributes = 7;
        baseFunction.exportAsJSClass(6, scriptable, bl);
    }

    static boolean isApply(IdFunctionObject idFunctionObject) {
        return idFunctionObject.hasTag(FUNCTION_TAG) && idFunctionObject.methodId() == 4;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static boolean isApplyOrCall(IdFunctionObject idFunctionObject) {
        if (!idFunctionObject.hasTag(FUNCTION_TAG)) return false;
        switch (idFunctionObject.methodId()) {
            default: {
                return false;
            }
            case 4: 
            case 5: 
        }
        return true;
    }

    private static Object jsConstructor(Context context, Scriptable scriptable, Object[] arrobject) {
        int n = arrobject.length;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("function ");
        if (context.getLanguageVersion() != 120) {
            stringBuilder.append("anonymous");
        }
        stringBuilder.append('(');
        for (int i = 0; i < n - 1; ++i) {
            if (i > 0) {
                stringBuilder.append(',');
            }
            stringBuilder.append(ScriptRuntime.toString(arrobject[i]));
        }
        stringBuilder.append(") {");
        if (n != 0) {
            stringBuilder.append(ScriptRuntime.toString(arrobject[n - 1]));
        }
        stringBuilder.append("\n}");
        String string2 = stringBuilder.toString();
        int[] arrn = new int[1];
        String string3 = Context.getSourcePositionFromStack(arrn);
        if (string3 == null) {
            string3 = "<eval'ed string>";
            arrn[0] = 1;
        }
        String string4 = ScriptRuntime.makeUrlForGeneratedScript(false, string3, arrn[0]);
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        ErrorReporter errorReporter = DefaultErrorReporter.forEval(context.getErrorReporter());
        Evaluator evaluator = Context.createInterpreter();
        if (evaluator == null) {
            throw new JavaScriptException("Interpreter not present", string3, arrn[0]);
        }
        return context.compileFunction(scriptable2, string2, evaluator, errorReporter, string4, 1, null);
    }

    private BaseFunction realFunction(Scriptable scriptable, IdFunctionObject idFunctionObject) {
        Object object = scriptable.getDefaultValue(ScriptRuntime.FunctionClass);
        if (object instanceof Delegator) {
            object = ((Delegator)object).getDelegee();
        }
        if (object instanceof BaseFunction) {
            return (BaseFunction)object;
        }
        throw ScriptRuntime.typeError1("msg.incompat.call", idFunctionObject.getFunctionName());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Object setupDefaultPrototype() {
        BaseFunction baseFunction = this;
        synchronized (baseFunction) {
            if (this.prototypeProperty != null) {
                return this.prototypeProperty;
            }
            NativeObject nativeObject = new NativeObject();
            nativeObject.defineProperty("constructor", this, 2);
            this.prototypeProperty = nativeObject;
            Scriptable scriptable = BaseFunction.getObjectPrototype(this);
            if (scriptable == nativeObject) return nativeObject;
            nativeObject.setPrototype(scriptable);
            return nativeObject;
        }
    }

    @Override
    public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        return Undefined.instance;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Scriptable construct(Context context, Scriptable scriptable, Object[] arrobject) {
        Scriptable scriptable2;
        Scriptable scriptable3 = this.createObject(context, scriptable);
        if (scriptable3 != null) {
            Object object = this.call(context, scriptable, scriptable3, arrobject);
            if (!(object instanceof Scriptable)) return scriptable3;
            return (Scriptable)object;
        }
        Object object = this.call(context, scriptable, null, arrobject);
        if (!(object instanceof Scriptable)) {
            throw new IllegalStateException("Bad implementaion of call as constructor, name=" + this.getFunctionName() + " in " + this.getClass().getName());
        }
        scriptable3 = (Scriptable)object;
        if (scriptable3.getPrototype() == null && scriptable3 != (scriptable2 = this.getClassPrototype())) {
            scriptable3.setPrototype(scriptable2);
        }
        if (scriptable3.getParentScope() != null) return scriptable3;
        Scriptable scriptable4 = this.getParentScope();
        if (scriptable3 == scriptable4) return scriptable3;
        scriptable3.setParentScope(scriptable4);
        return scriptable3;
    }

    public Scriptable createObject(Context context, Scriptable scriptable) {
        NativeObject nativeObject = new NativeObject();
        nativeObject.setPrototype(this.getClassPrototype());
        nativeObject.setParentScope(this.getParentScope());
        return nativeObject;
    }

    /*
     * Enabled aggressive block sorting
     */
    String decompile(int n, int n2) {
        StringBuilder stringBuilder = new StringBuilder();
        boolean bl = (n2 & 1) != 0;
        if (!bl) {
            stringBuilder.append("function ");
            stringBuilder.append(this.getFunctionName());
            stringBuilder.append("() {\n\t");
        }
        stringBuilder.append("[native code, arity=");
        stringBuilder.append(this.getArity());
        stringBuilder.append("]\n");
        if (!bl) {
            stringBuilder.append("}\n");
        }
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        Scriptable scriptable3;
        Object[] arrobject2;
        if (!idFunctionObject.hasTag(FUNCTION_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                return BaseFunction.jsConstructor(context, scriptable, arrobject);
            }
            case 2: {
                return this.realFunction(scriptable2, idFunctionObject).decompile(ScriptRuntime.toInt32(arrobject, 0), 0);
            }
            case 3: {
                BaseFunction baseFunction = this.realFunction(scriptable2, idFunctionObject);
                int n2 = 2;
                int n3 = arrobject.length;
                int n4 = 0;
                if (n3 == 0) return baseFunction.decompile(n4, n2);
                n4 = ScriptRuntime.toInt32(arrobject[0]);
                if (n4 >= 0) {
                    n2 = 0;
                    return baseFunction.decompile(n4, n2);
                }
                n4 = 0;
                return baseFunction.decompile(n4, n2);
            }
            case 4: 
            case 5: {
                boolean bl;
                if (n == 4) {
                    bl = true;
                    return ScriptRuntime.applyOrCall(bl, context, scriptable, scriptable2, arrobject);
                }
                bl = false;
                return ScriptRuntime.applyOrCall(bl, context, scriptable, scriptable2, arrobject);
            }
            case 6: 
        }
        if (!(scriptable2 instanceof Callable)) {
            throw ScriptRuntime.notFunctionError(scriptable2);
        }
        Callable callable = (Callable)((Object)scriptable2);
        int n5 = arrobject.length;
        if (n5 > 0) {
            scriptable3 = ScriptRuntime.toObjectOrNull(context, arrobject[0], scriptable);
            arrobject2 = new Object[n5 - 1];
            System.arraycopy((Object)arrobject, (int)1, (Object)arrobject2, (int)0, (int)(n5 - 1));
            return new BoundFunction(context, scriptable, callable, scriptable3, arrobject2);
        }
        arrobject2 = ScriptRuntime.emptyArgs;
        scriptable3 = null;
        return new BoundFunction(context, scriptable, callable, scriptable3, arrobject2);
    }

    @Override
    protected void fillConstructorProperties(IdFunctionObject idFunctionObject) {
        idFunctionObject.setPrototype(this);
        super.fillConstructorProperties(idFunctionObject);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findInstanceIdInfo(String string2) {
        int n;
        int n2 = string2.length();
        String string3 = null;
        int n3 = 0;
        switch (n2) {
            case 4: {
                string3 = "name";
                n3 = 3;
                break;
            }
            case 5: {
                string3 = "arity";
                n3 = 2;
                break;
            }
            case 6: {
                string3 = "length";
                n3 = 1;
                break;
            }
            case 9: {
                char c = string2.charAt(0);
                if (c == 'a') {
                    string3 = "arguments";
                    n3 = 5;
                    break;
                }
                string3 = null;
                n3 = 0;
                if (c != 'p') break;
                string3 = "prototype";
                n3 = 4;
            }
        }
        if (string3 != null && string3 != string2 && !string3.equals((Object)string2)) {
            n3 = 0;
        }
        if (n3 == 0) {
            return super.findInstanceIdInfo(string2);
        }
        switch (n3) {
            default: {
                throw new IllegalStateException();
            }
            case 1: 
            case 2: 
            case 3: {
                n = 7;
                return BaseFunction.instanceIdInfo(n, n3);
            }
            case 4: {
                boolean bl = this.hasPrototypeProperty();
                int n4 = 0;
                if (!bl) return n4;
                n = this.prototypePropertyAttributes;
                return BaseFunction.instanceIdInfo(n, n3);
            }
            case 5: 
        }
        n = this.argumentsAttributes;
        return BaseFunction.instanceIdInfo(n, n3);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        switch (n) {
            case 4: {
                char c = string2.charAt(0);
                if (c == 'b') {
                    string3 = "bind";
                    n2 = 6;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'c') break;
                string3 = "call";
                n2 = 5;
                break;
            }
            case 5: {
                string3 = "apply";
                n2 = 4;
                break;
            }
            case 8: {
                char c = string2.charAt(3);
                if (c == 'o') {
                    string3 = "toSource";
                    n2 = 3;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "toString";
                n2 = 2;
                break;
            }
            case 11: {
                string3 = "constructor";
                n2 = 1;
                break;
            }
        }
        if (string3 == null) return n2;
        if (string3 == string2) return n2;
        if (string3.equals((Object)string2)) return n2;
        return 0;
    }

    public int getArity() {
        return 0;
    }

    @Override
    public String getClassName() {
        return "Function";
    }

    protected Scriptable getClassPrototype() {
        Object object = this.getPrototypeProperty();
        if (object instanceof Scriptable) {
            return (Scriptable)object;
        }
        return ScriptableObject.getObjectPrototype(this);
    }

    public String getFunctionName() {
        return "";
    }

    @Override
    protected String getInstanceIdName(int n) {
        switch (n) {
            default: {
                return super.getInstanceIdName(n);
            }
            case 1: {
                return "length";
            }
            case 2: {
                return "arity";
            }
            case 3: {
                return "name";
            }
            case 4: {
                return "prototype";
            }
            case 5: 
        }
        return "arguments";
    }

    @Override
    protected Object getInstanceIdValue(int n) {
        switch (n) {
            default: {
                return super.getInstanceIdValue(n);
            }
            case 1: {
                return ScriptRuntime.wrapInt(this.getLength());
            }
            case 2: {
                return ScriptRuntime.wrapInt(this.getArity());
            }
            case 3: {
                return this.getFunctionName();
            }
            case 4: {
                return this.getPrototypeProperty();
            }
            case 5: 
        }
        return this.getArguments();
    }

    public int getLength() {
        return 0;
    }

    @Override
    protected int getMaxInstanceId() {
        return 5;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected Object getPrototypeProperty() {
        Object object = this.prototypeProperty;
        if (object == null) {
            if (!(this instanceof NativeFunction)) return Undefined.instance;
            return this.setupDefaultPrototype();
        }
        if (object != UniqueTag.NULL_VALUE) return object;
        return null;
    }

    @Override
    public String getTypeOf() {
        if (this.avoidObjectDetection()) {
            return "undefined";
        }
        return "function";
    }

    @Override
    public boolean hasInstance(Scriptable scriptable) {
        Object object = ScriptableObject.getProperty((Scriptable)this, "prototype");
        if (object instanceof Scriptable) {
            return ScriptRuntime.jsDelegatesTo(scriptable, (Scriptable)object);
        }
        throw ScriptRuntime.typeError1("msg.instanceof.bad.prototype", this.getFunctionName());
    }

    protected boolean hasPrototypeProperty() {
        return this.prototypeProperty != null || this instanceof NativeFunction;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 1;
                string2 = "constructor";
                break;
            }
            case 2: {
                string2 = "toString";
                n2 = 0;
                break;
            }
            case 3: {
                n2 = 1;
                string2 = "toSource";
                break;
            }
            case 4: {
                n2 = 2;
                string2 = "apply";
                break;
            }
            case 5: {
                n2 = 1;
                string2 = "call";
                break;
            }
            case 6: {
                n2 = 1;
                string2 = "bind";
            }
        }
        this.initPrototypeMethod(FUNCTION_TAG, n, string2, n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setImmunePrototypeProperty(Object object) {
        if ((1 & this.prototypePropertyAttributes) != 0) {
            throw new IllegalStateException();
        }
        if (object == null) {
            object = UniqueTag.NULL_VALUE;
        }
        this.prototypeProperty = object;
        this.prototypePropertyAttributes = 7;
    }

    @Override
    protected void setInstanceIdAttributes(int n, int n2) {
        switch (n) {
            default: {
                super.setInstanceIdAttributes(n, n2);
                return;
            }
            case 4: {
                this.prototypePropertyAttributes = n2;
                return;
            }
            case 5: 
        }
        this.argumentsAttributes = n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void setInstanceIdValue(int n, Object object) {
        switch (n) {
            default: {
                super.setInstanceIdValue(n, object);
                return;
            }
            case 4: {
                if ((1 & this.prototypePropertyAttributes) != 0) return;
                {
                    if (object == null) {
                        object = UniqueTag.NULL_VALUE;
                    }
                    this.prototypeProperty = object;
                    return;
                }
            }
            case 1: 
            case 2: 
            case 3: {
                return;
            }
            case 5: {
                if (object == NOT_FOUND) {
                    Kit.codeBug();
                }
                if (this.defaultHas("arguments")) {
                    this.defaultPut("arguments", object);
                    return;
                }
                if ((1 & this.argumentsAttributes) != 0) return;
                this.argumentsObj = object;
                return;
            }
        }
    }
}

