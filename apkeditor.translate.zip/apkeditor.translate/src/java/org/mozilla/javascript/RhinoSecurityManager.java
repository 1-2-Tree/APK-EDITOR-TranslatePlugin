/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.SecurityManager
 */
package org.mozilla.javascript;

import org.mozilla.javascript.InterpretedFunction;
import org.mozilla.javascript.NativeFunction;
import org.mozilla.javascript.PolicySecurityController;

public class RhinoSecurityManager
extends SecurityManager {
    protected Class<?> getCurrentScriptClass() {
        for (Class class_ : this.getClassContext()) {
            if ((class_ == InterpretedFunction.class || !NativeFunction.class.isAssignableFrom(class_)) && !PolicySecurityController.SecureCaller.class.isAssignableFrom(class_)) continue;
            return class_;
        }
        return null;
    }
}

