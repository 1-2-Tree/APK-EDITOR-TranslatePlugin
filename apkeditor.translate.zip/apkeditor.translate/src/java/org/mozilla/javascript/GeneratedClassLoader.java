/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript;

public interface GeneratedClassLoader {
    public Class<?> defineClass(String var1, byte[] var2);

    public void linkClass(Class<?> var1);
}

