/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.String
 */
package org.mozilla.javascript;

import org.mozilla.javascript.RhinoException;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;

public class EcmaError
extends RhinoException {
    static final long serialVersionUID = -6261226256957286699L;
    private String errorMessage;
    private String errorName;

    EcmaError(String string2, String string3, String string4, int n, String string5, int n2) {
        this.recordErrorOrigin(string4, n, string5, n2);
        this.errorName = string2;
        this.errorMessage = string3;
    }

    @Deprecated
    public EcmaError(Scriptable scriptable, String string2, int n, int n2, String string3) {
        this("InternalError", ScriptRuntime.toString(scriptable), string2, n, string3, n2);
    }

    @Override
    public String details() {
        return this.errorName + ": " + this.errorMessage;
    }

    @Deprecated
    public int getColumnNumber() {
        return this.columnNumber();
    }

    public String getErrorMessage() {
        return this.errorMessage;
    }

    @Deprecated
    public Scriptable getErrorObject() {
        return null;
    }

    @Deprecated
    public int getLineNumber() {
        return this.lineNumber();
    }

    @Deprecated
    public String getLineSource() {
        return this.lineSource();
    }

    public String getName() {
        return this.errorName;
    }

    @Deprecated
    public String getSourceName() {
        return this.sourceName();
    }
}

