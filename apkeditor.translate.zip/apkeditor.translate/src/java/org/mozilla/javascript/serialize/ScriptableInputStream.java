/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.ObjectInputStream
 *  java.io.ObjectStreamClass
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.ClassNotFoundException
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript.serialize;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.UniqueTag;
import org.mozilla.javascript.serialize.ScriptableOutputStream;

public class ScriptableInputStream
extends ObjectInputStream {
    private ClassLoader classLoader;
    private Scriptable scope;

    public ScriptableInputStream(InputStream inputStream, Scriptable scriptable) throws IOException {
        super(inputStream);
        this.scope = scriptable;
        this.enableResolveObject(true);
        Context context = Context.getCurrentContext();
        if (context != null) {
            this.classLoader = context.getApplicationClassLoader();
        }
    }

    protected Class<?> resolveClass(ObjectStreamClass objectStreamClass) throws IOException, ClassNotFoundException {
        String string2 = objectStreamClass.getName();
        if (this.classLoader != null) {
            try {
                Class class_ = this.classLoader.loadClass(string2);
                return class_;
            }
            catch (ClassNotFoundException classNotFoundException) {
                // empty catch block
            }
        }
        return super.resolveClass(objectStreamClass);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected Object resolveObject(Object object) throws IOException {
        if (object instanceof ScriptableOutputStream.PendingLookup) {
            String string2 = ((ScriptableOutputStream.PendingLookup)object).getName();
            object = ScriptableOutputStream.lookupQualifiedName(this.scope, string2);
            if (object != Scriptable.NOT_FOUND) return object;
            throw new IOException("Object " + string2 + " not found upon " + "deserialization.");
        }
        if (object instanceof UniqueTag) {
            return ((UniqueTag)object).readResolve();
        }
        if (!(object instanceof Undefined)) return object;
        return ((Undefined)object).readResolve();
    }
}

