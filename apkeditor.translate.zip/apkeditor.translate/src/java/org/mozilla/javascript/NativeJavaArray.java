/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.reflect.Array
 */
package org.mozilla.javascript;

import java.lang.reflect.Array;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.NativeJavaObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.WrapFactory;
import org.mozilla.javascript.Wrapper;

public class NativeJavaArray
extends NativeJavaObject {
    static final long serialVersionUID = -924022554283675333L;
    Object array;
    Class<?> cls;
    int length;

    public NativeJavaArray(Scriptable scriptable, Object object) {
        super(scriptable, null, ScriptRuntime.ObjectClass);
        Class class_ = object.getClass();
        if (!class_.isArray()) {
            throw new RuntimeException("Array expected");
        }
        this.array = object;
        this.length = Array.getLength((Object)object);
        this.cls = class_.getComponentType();
    }

    public static NativeJavaArray wrap(Scriptable scriptable, Object object) {
        return new NativeJavaArray(scriptable, object);
    }

    @Override
    public Object get(int n, Scriptable scriptable) {
        if (n >= 0 && n < this.length) {
            Context context = Context.getContext();
            Object object = Array.get((Object)this.array, (int)n);
            return context.getWrapFactory().wrap(context, this, object, this.cls);
        }
        return Undefined.instance;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object get(String string2, Scriptable scriptable) {
        void var3_4;
        if (string2.equals((Object)"length")) {
            Integer n = this.length;
            return var3_4;
        } else {
            Object object = super.get(string2, scriptable);
            if (object != NOT_FOUND || ScriptableObject.hasProperty(this.getPrototype(), string2)) return var3_4;
            {
                throw Context.reportRuntimeError2("msg.java.member.not.found", this.array.getClass().getName(), string2);
            }
        }
    }

    @Override
    public String getClassName() {
        return "JavaArray";
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Object getDefaultValue(Class<?> class_) {
        if (class_ == null) return ((NativeJavaArray)this).array.toString();
        if (class_ == ScriptRuntime.StringClass) {
            return ((NativeJavaArray)this).array.toString();
        }
        if (class_ == ScriptRuntime.BooleanClass) {
            return Boolean.TRUE;
        }
        if (class_ != ScriptRuntime.NumberClass) return this;
        return ScriptRuntime.NaNobj;
    }

    @Override
    public Object[] getIds() {
        Object[] arrobject = new Object[this.length];
        int n = this.length;
        while (--n >= 0) {
            arrobject[n] = n;
        }
        return arrobject;
    }

    @Override
    public Scriptable getPrototype() {
        if (this.prototype == null) {
            this.prototype = ScriptableObject.getArrayPrototype(this.getParentScope());
        }
        return this.prototype;
    }

    @Override
    public boolean has(int n, Scriptable scriptable) {
        return n >= 0 && n < this.length;
    }

    @Override
    public boolean has(String string2, Scriptable scriptable) {
        return string2.equals((Object)"length") || super.has(string2, scriptable);
    }

    @Override
    public boolean hasInstance(Scriptable scriptable) {
        if (!(scriptable instanceof Wrapper)) {
            return false;
        }
        Object object = ((Wrapper)((Object)scriptable)).unwrap();
        return this.cls.isInstance(object);
    }

    @Override
    public void put(int n, Scriptable scriptable, Object object) {
        if (n >= 0 && n < this.length) {
            Array.set((Object)this.array, (int)n, (Object)Context.jsToJava(object, this.cls));
            return;
        }
        throw Context.reportRuntimeError2("msg.java.array.index.out.of.bounds", String.valueOf((int)n), String.valueOf((int)(-1 + this.length)));
    }

    @Override
    public void put(String string2, Scriptable scriptable, Object object) {
        if (!string2.equals((Object)"length")) {
            throw Context.reportRuntimeError1("msg.java.array.member.not.found", string2);
        }
    }

    @Override
    public Object unwrap() {
        return this.array;
    }
}

