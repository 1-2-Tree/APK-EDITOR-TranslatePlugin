/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.Arrays
 */
package org.mozilla.javascript.v8dtoa;

import java.util.Arrays;

public class FastDtoaBuilder {
    static final char[] digits = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
    final char[] chars = new char[25];
    int end = 0;
    boolean formatted = false;
    int point;

    /*
     * Enabled aggressive block sorting
     */
    private void toExponentialFormat(int n, int n2) {
        if (this.end - n > 1) {
            int n3 = n + 1;
            System.arraycopy((Object)this.chars, (int)n3, (Object)this.chars, (int)(n3 + 1), (int)(this.end - n3));
            this.chars[n3] = 46;
            this.end = 1 + this.end;
        }
        char[] arrc = this.chars;
        int n4 = this.end;
        this.end = n4 + 1;
        arrc[n4] = 101;
        int n5 = 43;
        int n6 = n2 - 1;
        if (n6 < 0) {
            n5 = 45;
            n6 = -n6;
        }
        char[] arrc2 = this.chars;
        int n7 = this.end;
        this.end = n7 + 1;
        arrc2[n7] = n5;
        int n8 = n6 > 99 ? 2 + this.end : (n6 > 9 ? 1 + this.end : this.end);
        this.end = n8 + 1;
        do {
            int n9 = n6 % 10;
            char[] arrc3 = this.chars;
            int n10 = n8 - 1;
            arrc3[n8] = digits[n9];
            if ((n6 /= 10) == 0) {
                return;
            }
            n8 = n10;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void toFixedFormat(int n, int n2) {
        if (this.point >= this.end) {
            if (this.point <= this.end) return;
            Arrays.fill((char[])this.chars, (int)this.end, (int)this.point, (char)'0');
            this.end += this.point - this.end;
            return;
        }
        if (n2 > 0) {
            System.arraycopy((Object)this.chars, (int)this.point, (Object)this.chars, (int)(1 + this.point), (int)(this.end - this.point));
            this.chars[this.point] = 46;
            this.end = 1 + this.end;
            return;
        }
        int n3 = n + 2 - n2;
        System.arraycopy((Object)this.chars, (int)n, (Object)this.chars, (int)n3, (int)(this.end - n));
        this.chars[n] = 48;
        this.chars[n + 1] = 46;
        if (n2 < 0) {
            Arrays.fill((char[])this.chars, (int)(n + 2), (int)n3, (char)'0');
        }
        this.end += 2 - n2;
    }

    void append(char c) {
        char[] arrc = this.chars;
        int n = this.end;
        this.end = n + 1;
        arrc[n] = c;
    }

    void decreaseLast() {
        char[] arrc = this.chars;
        int n = -1 + this.end;
        arrc[n] = (char)(-1 + arrc[n]);
    }

    /*
     * Enabled aggressive block sorting
     */
    public String format() {
        if (!this.formatted) {
            int n = this.chars[0] == '-' ? 1 : 0;
            int n2 = this.point - n;
            if (n2 < -5 || n2 > 21) {
                this.toExponentialFormat(n, n2);
            } else {
                this.toFixedFormat(n, n2);
            }
            this.formatted = true;
        }
        return new String(this.chars, 0, this.end);
    }

    public void reset() {
        this.end = 0;
        this.formatted = false;
    }

    public String toString() {
        return "[chars:" + new String(this.chars, 0, this.end) + ", point:" + this.point + "]";
    }
}

