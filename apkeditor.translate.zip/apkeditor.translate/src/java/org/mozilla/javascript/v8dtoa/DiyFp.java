/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript.v8dtoa;

class DiyFp {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    static final int kSignificandSize = 64;
    static final long kUint64MSB = Long.MIN_VALUE;
    private int e;
    private long f;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !DiyFp.class.desiredAssertionStatus();
        $assertionsDisabled = bl;
    }

    DiyFp() {
        this.f = 0L;
        this.e = 0;
    }

    DiyFp(long l, int n) {
        this.f = l;
        this.e = n;
    }

    static DiyFp minus(DiyFp diyFp, DiyFp diyFp2) {
        DiyFp diyFp3 = new DiyFp(diyFp.f, diyFp.e);
        diyFp3.subtract(diyFp2);
        return diyFp3;
    }

    static DiyFp normalize(DiyFp diyFp) {
        DiyFp diyFp2 = new DiyFp(diyFp.f, diyFp.e);
        diyFp2.normalize();
        return diyFp2;
    }

    static DiyFp times(DiyFp diyFp, DiyFp diyFp2) {
        DiyFp diyFp3 = new DiyFp(diyFp.f, diyFp.e);
        diyFp3.multiply(diyFp2);
        return diyFp3;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean uint64_gte(long l, long l2) {
        if (l == l2) return true;
        boolean bl = l > l2;
        boolean bl2 = l < 0L;
        boolean bl3 = bl ^ bl2;
        boolean bl4 = l2 < 0L;
        boolean bl5 = bl4 ^ bl3;
        boolean bl6 = false;
        if (!bl5) return bl6;
        return true;
    }

    int e() {
        return this.e;
    }

    long f() {
        return this.f;
    }

    void multiply(DiyFp diyFp) {
        long l = this.f >>> 32;
        long l2 = 0xFFFFFFFFL & this.f;
        long l3 = diyFp.f >>> 32;
        long l4 = 0xFFFFFFFFL & diyFp.f;
        long l5 = l * l3;
        long l6 = l2 * l3;
        long l7 = l * l4;
        long l8 = 0x80000000L + ((l2 * l4 >>> 32) + (0xFFFFFFFFL & l7) + (0xFFFFFFFFL & l6));
        long l9 = l5 + (l7 >>> 32) + (l6 >>> 32) + (l8 >>> 32);
        this.e += 64 + diyFp.e;
        this.f = l9;
    }

    void normalize() {
        if (!$assertionsDisabled && this.f == 0L) {
            throw new AssertionError();
        }
        long l = this.f;
        int n = this.e;
        while ((-18014398509481984L & l) == 0L) {
            l <<= 10;
            n -= 10;
        }
        while ((Long.MIN_VALUE & l) == 0L) {
            l <<= 1;
            --n;
        }
        this.f = l;
        this.e = n;
    }

    void setE(int n) {
        this.e = n;
    }

    void setF(long l) {
        this.f = l;
    }

    void subtract(DiyFp diyFp) {
        if (!$assertionsDisabled && this.e != diyFp.e) {
            throw new AssertionError();
        }
        if (!$assertionsDisabled && !DiyFp.uint64_gte(this.f, diyFp.f)) {
            throw new AssertionError();
        }
        this.f -= diyFp.f;
    }

    public String toString() {
        return "[DiyFp f:" + this.f + ", e:" + this.e + "]";
    }
}

