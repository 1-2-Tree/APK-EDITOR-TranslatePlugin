/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Object
 */
package org.mozilla.javascript.v8dtoa;

public final class DoubleConversion {
    private static final int kDenormalExponent = -1074;
    private static final int kExponentBias = 1075;
    private static final long kExponentMask = 9218868437227405312L;
    private static final long kHiddenBit = 0x10000000000000L;
    private static final int kPhysicalSignificandSize = 52;
    private static final long kSignMask = Long.MIN_VALUE;
    private static final long kSignificandMask = 0xFFFFFFFFFFFFFL;
    private static final int kSignificandSize = 53;

    private DoubleConversion() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int doubleToInt32(double d) {
        long l;
        int n = (int)d;
        if ((double)n == d) {
            return n;
        }
        long l2 = Double.doubleToLongBits((double)d);
        int n2 = DoubleConversion.exponent(l2);
        if (n2 <= -53 || n2 > 31) {
            return 0;
        }
        long l3 = DoubleConversion.significand(l2);
        int n3 = DoubleConversion.sign(l2);
        if (n2 < 0) {
            l = l3 >> -n2;
            do {
                return n3 * (int)l;
                break;
            } while (true);
        }
        l = l3 << n2;
        return n3 * (int)l;
    }

    private static int exponent(long l) {
        if (DoubleConversion.isDenormal(l)) {
            return -1074;
        }
        return -1075 + (int)((9218868437227405312L & l) >> 52);
    }

    private static boolean isDenormal(long l) {
        return (9218868437227405312L & l) == 0L;
    }

    private static int sign(long l) {
        if ((Long.MIN_VALUE & l) == 0L) {
            return 1;
        }
        return -1;
    }

    private static long significand(long l) {
        long l2 = l & 0xFFFFFFFFFFFFFL;
        if (!DoubleConversion.isDenormal(l)) {
            l2 += 0x10000000000000L;
        }
        return l2;
    }
}

