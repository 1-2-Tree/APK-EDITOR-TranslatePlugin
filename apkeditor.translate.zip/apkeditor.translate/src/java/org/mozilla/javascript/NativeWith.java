/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package org.mozilla.javascript;

import java.io.Serializable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionCall;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

public class NativeWith
implements Scriptable,
IdFunctionCall,
Serializable {
    private static final Object FTAG = "With";
    private static final int Id_constructor = 1;
    private static final long serialVersionUID = 1L;
    protected Scriptable parent;
    protected Scriptable prototype;

    private NativeWith() {
    }

    protected NativeWith(Scriptable scriptable, Scriptable scriptable2) {
        this.parent = scriptable;
        this.prototype = scriptable2;
    }

    static void init(Scriptable scriptable, boolean bl) {
        NativeWith nativeWith = new NativeWith();
        nativeWith.setParentScope(scriptable);
        nativeWith.setPrototype(ScriptableObject.getObjectPrototype(scriptable));
        IdFunctionObject idFunctionObject = new IdFunctionObject(nativeWith, FTAG, 1, "With", 0, scriptable);
        idFunctionObject.markAsConstructor(nativeWith);
        if (bl) {
            idFunctionObject.sealObject();
        }
        idFunctionObject.exportAsScopeProperty();
    }

    static boolean isWithFunction(Object object) {
        if (object instanceof IdFunctionObject) {
            IdFunctionObject idFunctionObject = (IdFunctionObject)object;
            return idFunctionObject.hasTag(FTAG) && idFunctionObject.methodId() == 1;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    static Object newWithSpecial(Context context, Scriptable scriptable, Object[] arrobject) {
        ScriptRuntime.checkDeprecated(context, "With");
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        NativeWith nativeWith = new NativeWith();
        Scriptable scriptable3 = arrobject.length == 0 ? ScriptableObject.getObjectPrototype(scriptable2) : ScriptRuntime.toObject(context, scriptable2, arrobject[0]);
        nativeWith.setPrototype(scriptable3);
        nativeWith.setParentScope(scriptable2);
        return nativeWith;
    }

    @Override
    public void delete(int n) {
        this.prototype.delete(n);
    }

    @Override
    public void delete(String string2) {
        this.prototype.delete(string2);
    }

    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (idFunctionObject.hasTag(FTAG) && idFunctionObject.methodId() == 1) {
            throw Context.reportRuntimeError1("msg.cant.call.indirect", "With");
        }
        throw idFunctionObject.unknown();
    }

    @Override
    public Object get(int n, Scriptable scriptable) {
        if (scriptable == this) {
            scriptable = this.prototype;
        }
        return this.prototype.get(n, scriptable);
    }

    @Override
    public Object get(String string2, Scriptable scriptable) {
        if (scriptable == this) {
            scriptable = this.prototype;
        }
        return this.prototype.get(string2, scriptable);
    }

    @Override
    public String getClassName() {
        return "With";
    }

    @Override
    public Object getDefaultValue(Class<?> class_) {
        return this.prototype.getDefaultValue(class_);
    }

    @Override
    public Object[] getIds() {
        return this.prototype.getIds();
    }

    @Override
    public Scriptable getParentScope() {
        return this.parent;
    }

    @Override
    public Scriptable getPrototype() {
        return this.prototype;
    }

    @Override
    public boolean has(int n, Scriptable scriptable) {
        return this.prototype.has(n, this.prototype);
    }

    @Override
    public boolean has(String string2, Scriptable scriptable) {
        return this.prototype.has(string2, this.prototype);
    }

    @Override
    public boolean hasInstance(Scriptable scriptable) {
        return this.prototype.hasInstance(scriptable);
    }

    @Override
    public void put(int n, Scriptable scriptable, Object object) {
        if (scriptable == this) {
            scriptable = this.prototype;
        }
        this.prototype.put(n, scriptable, object);
    }

    @Override
    public void put(String string2, Scriptable scriptable, Object object) {
        if (scriptable == this) {
            scriptable = this.prototype;
        }
        this.prototype.put(string2, scriptable, object);
    }

    @Override
    public void setParentScope(Scriptable scriptable) {
        this.parent = scriptable;
    }

    @Override
    public void setPrototype(Scriptable scriptable) {
        this.prototype = scriptable;
    }

    protected Object updateDotQuery(boolean bl) {
        throw new IllegalStateException();
    }
}

