/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Void
 *  java.lang.reflect.AccessibleObject
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Field
 *  java.lang.reflect.Member
 *  java.lang.reflect.Method
 *  java.lang.reflect.Modifier
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package org.mozilla.javascript;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.mozilla.javascript.BeanProperty;
import org.mozilla.javascript.ClassCache;
import org.mozilla.javascript.ClassShutter;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextFactory;
import org.mozilla.javascript.FieldAndMethods;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.MemberBox;
import org.mozilla.javascript.NativeJavaConstructor;
import org.mozilla.javascript.NativeJavaMethod;
import org.mozilla.javascript.ObjArray;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.WrapFactory;

class JavaMembers {
    private Class<?> cl;
    NativeJavaMethod ctors;
    private Map<String, FieldAndMethods> fieldAndMethods;
    private Map<String, Object> members;
    private Map<String, FieldAndMethods> staticFieldAndMethods;
    private Map<String, Object> staticMembers;

    JavaMembers(Scriptable scriptable, Class<?> class_) {
        this(scriptable, class_, false);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    JavaMembers(Scriptable scriptable, Class<?> class_, boolean bl) {
        try {
            Context context = ContextFactory.getGlobal().enterContext();
            ClassShutter classShutter = context.getClassShutter();
            if (classShutter != null && !classShutter.visibleToScripts(class_.getName())) {
                throw Context.reportRuntimeError1("msg.access.prohibited", class_.getName());
            }
            this.members = new HashMap();
            this.staticMembers = new HashMap();
            this.cl = class_;
            this.reflect(scriptable, bl, context.hasFeature(13));
            return;
        }
        finally {
            Context.exit();
        }
    }

    /*
     * Exception decompiling
     */
    private static void discoverAccessibleMethods(Class<?> var0, Map<MethodSignature, Method> var1_1, boolean var2_2, boolean var3_3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [1[TRYBLOCK]], but top level block is 2[CATCHBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    private static Method[] discoverAccessibleMethods(Class<?> class_, boolean bl, boolean bl2) {
        HashMap hashMap = new HashMap();
        JavaMembers.discoverAccessibleMethods(class_, (Map<MethodSignature, Method>)hashMap, bl, bl2);
        return (Method[])hashMap.values().toArray((Object[])new Method[hashMap.size()]);
    }

    private static MemberBox extractGetMethod(MemberBox[] arrmemberBox, boolean bl) {
        for (MemberBox memberBox : arrmemberBox) {
            if (memberBox.argTypes.length != 0 || bl && !memberBox.isStatic()) continue;
            if (memberBox.method().getReturnType() == Void.TYPE) break;
            return memberBox;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static MemberBox extractSetMethod(Class<?> class_, MemberBox[] arrmemberBox, boolean bl) {
        int n = 1;
        while (n <= 2) {
            for (MemberBox memberBox : arrmemberBox) {
                Class<?>[] arrclass;
                if (bl && !memberBox.isStatic() || (arrclass = memberBox.argTypes).length != 1) continue;
                if (n == 1) {
                    if (arrclass[0] != class_) continue;
                    return memberBox;
                } else {
                    if (n != 2) {
                        Kit.codeBug();
                    }
                    if (!arrclass[0].isAssignableFrom(class_)) continue;
                }
                return memberBox;
            }
            ++n;
        }
        return null;
    }

    private static MemberBox extractSetMethod(MemberBox[] arrmemberBox, boolean bl) {
        for (MemberBox memberBox : arrmemberBox) {
            if (bl && !memberBox.isStatic() || memberBox.method().getReturnType() != Void.TYPE || memberBox.argTypes.length != 1) continue;
            return memberBox;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private MemberBox findExplicitFunction(String string2, boolean bl) {
        MemberBox[] arrmemberBox;
        int n = string2.indexOf(40);
        if (n < 0) {
            return null;
        }
        Map<String, Object> map = bl ? this.staticMembers : this.members;
        boolean bl2 = bl && n == 0;
        if (bl2) {
            arrmemberBox = this.ctors.methods;
        } else {
            String string3 = string2.substring(0, n);
            Object object = map.get((Object)string3);
            if (!bl && object == null) {
                object = this.staticMembers.get((Object)string3);
            }
            boolean bl3 = object instanceof NativeJavaMethod;
            arrmemberBox = null;
            if (bl3) {
                arrmemberBox = ((NativeJavaMethod)object).methods;
            }
        }
        if (arrmemberBox == null) return null;
        MemberBox[] arrmemberBox2 = arrmemberBox;
        int n2 = arrmemberBox2.length;
        int n3 = 0;
        while (n3 < n2) {
            MemberBox memberBox = arrmemberBox2[n3];
            String string4 = JavaMembers.liveConnectSignature(memberBox.argTypes);
            if (n + string4.length() == string2.length()) {
                if (string2.regionMatches(n, string4, 0, string4.length())) return memberBox;
            }
            ++n3;
        }
        return null;
    }

    private MemberBox findGetter(boolean bl, Map<String, Object> map, String string2, String string3) {
        Object object;
        String string4 = string2.concat(string3);
        if (map.containsKey((Object)string4) && (object = map.get((Object)string4)) instanceof NativeJavaMethod) {
            return JavaMembers.extractGetMethod(((NativeJavaMethod)object).methods, bl);
        }
        return null;
    }

    private Constructor<?>[] getAccessibleConstructors(boolean bl) {
        if (bl && this.cl != ScriptRuntime.ClassClass) {
            try {
                Constructor[] arrconstructor = this.cl.getDeclaredConstructors();
                AccessibleObject.setAccessible((AccessibleObject[])arrconstructor, (boolean)true);
                return arrconstructor;
            }
            catch (SecurityException securityException) {
                Context.reportWarning("Could not access constructor  of class " + this.cl.getName() + " due to lack of privileges.");
            }
        }
        return this.cl.getConstructors();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private Field[] getAccessibleFields(boolean var1_1, boolean var2_2) {
        block10 : {
            if (!var2_2) {
                if (var1_1 == false) return this.cl.getFields();
            }
            try {
                var3_3 = new ArrayList();
                var5_4 = this.cl;
lbl6: // 2 sources:
                do {
                    if (var5_4 == null) {
                        return (Field[])var3_3.toArray((Object[])new Field[var3_3.size()]);
                    }
                    var6_5 = var5_4.getDeclaredFields();
                    var7_6 = var6_5.length;
                    var8_7 = 0;
                    break block10;
                    break;
                } while (true);
            }
            catch (SecurityException var4_11) {
                // empty catch block
            }
            return this.cl.getFields();
        }
        do {
            if (var8_7 < var7_6) {
                var9_8 = var6_5[var8_7];
                var10_9 = var9_8.getModifiers();
                if (var2_2 || Modifier.isPublic((int)var10_9) || Modifier.isProtected((int)var10_9)) {
                    if (!var9_8.isAccessible()) {
                        var9_8.setAccessible(true);
                    }
                    var3_3.add((Object)var9_8);
                }
            } else {
                var5_4 = var5_4.getSuperclass();
                ** continue;
            }
            ++var8_7;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Object getExplicitFunction(Scriptable scriptable, String string2, Object object, boolean bl) {
        Map<String, Object> map = bl ? this.staticMembers : this.members;
        MemberBox memberBox = this.findExplicitFunction(string2, bl);
        Object object2 = null;
        if (memberBox == null) return object2;
        {
            Scriptable scriptable2 = ScriptableObject.getFunctionPrototype(scriptable);
            if (memberBox.isCtor()) {
                NativeJavaConstructor nativeJavaConstructor = new NativeJavaConstructor(memberBox);
                nativeJavaConstructor.setPrototype(scriptable2);
                object2 = nativeJavaConstructor;
                map.put((Object)string2, (Object)nativeJavaConstructor);
                return object2;
            } else {
                object2 = map.get((Object)memberBox.getName());
                if (!(object2 instanceof NativeJavaMethod) || ((NativeJavaMethod)object2).methods.length <= 1) return object2;
                {
                    NativeJavaMethod nativeJavaMethod = new NativeJavaMethod(memberBox, string2);
                    nativeJavaMethod.setPrototype(scriptable2);
                    map.put((Object)string2, (Object)nativeJavaMethod);
                    return nativeJavaMethod;
                }
            }
        }
    }

    static String javaSignature(Class<?> class_) {
        if (!class_.isArray()) {
            return class_.getName();
        }
        int n = 0;
        do {
            ++n;
        } while ((class_ = class_.getComponentType()).isArray());
        String string2 = class_.getName();
        if (n == 1) {
            return string2.concat("[]");
        }
        StringBuilder stringBuilder = new StringBuilder(string2.length() + n * "[]".length());
        stringBuilder.append(string2);
        while (n != 0) {
            --n;
            stringBuilder.append("[]");
        }
        return stringBuilder.toString();
    }

    static String liveConnectSignature(Class<?>[] arrclass) {
        int n = arrclass.length;
        if (n == 0) {
            return "()";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('(');
        for (int i = 0; i != n; ++i) {
            if (i != 0) {
                stringBuilder.append(',');
            }
            stringBuilder.append(JavaMembers.javaSignature(arrclass[i]));
        }
        stringBuilder.append(')');
        return stringBuilder.toString();
    }

    static JavaMembers lookupClass(Scriptable scriptable, Class<?> class_, Class<?> class_2, boolean bl) {
        ClassCache classCache = ClassCache.get(scriptable);
        Map<Class<?>, JavaMembers> map = classCache.getClassCacheMap();
        Class<?> class_3 = class_;
        do {
            JavaMembers javaMembers;
            JavaMembers javaMembers2;
            if ((javaMembers2 = (JavaMembers)map.get(class_3)) != null) {
                if (class_3 != class_) {
                    map.put(class_, (Object)javaMembers2);
                }
                return javaMembers2;
            }
            try {
                javaMembers = new JavaMembers(classCache.getAssociatedScope(), class_3, bl);
            }
            catch (SecurityException securityException) {
                block12 : {
                    Class<?> class_4;
                    block11 : {
                        if (class_2 != null && class_2.isInterface()) {
                            class_3 = class_2;
                            class_2 = null;
                            continue;
                        }
                        class_4 = class_3.getSuperclass();
                        if (class_4 != null) break block11;
                        if (!class_3.isInterface()) break block12;
                        class_4 = ScriptRuntime.ObjectClass;
                    }
                    class_3 = class_4;
                    continue;
                }
                throw securityException;
            }
            if (classCache.isCachingEnabled()) {
                map.put(class_3, (Object)javaMembers);
                if (class_3 != class_) {
                    map.put(class_, (Object)javaMembers);
                }
            }
            return javaMembers;
            break;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void reflect(Scriptable scriptable, boolean bl, boolean bl2) {
        for (Method method : JavaMembers.discoverAccessibleMethods(this.cl, bl, bl2)) {
            ObjArray objArray;
            String string2;
            Map<String, Object> map = Modifier.isStatic((int)method.getModifiers()) ? this.staticMembers : this.members;
            Object object = map.get((Object)(string2 = method.getName()));
            if (object == null) {
                map.put((Object)string2, (Object)method);
                continue;
            }
            if (object instanceof ObjArray) {
                objArray = (ObjArray)object;
            } else {
                if (!(object instanceof Method)) {
                    Kit.codeBug();
                }
                objArray = new ObjArray();
                objArray.add(object);
                map.put((Object)string2, (Object)objArray);
            }
            objArray.add((Object)method);
        }
        int n = 0;
        do {
            if (n == 2) break;
            boolean bl3 = n == 0;
            Map<String, Object> map = bl3 ? this.staticMembers : this.members;
            for (Map.Entry entry : map.entrySet()) {
                MemberBox[] arrmemberBox;
                Object object = entry.getValue();
                if (object instanceof Method) {
                    MemberBox memberBox = new MemberBox((Method)object);
                    arrmemberBox = new MemberBox[]{memberBox};
                } else {
                    ObjArray objArray = (ObjArray)object;
                    int n2 = objArray.size();
                    if (n2 < 2) {
                        Kit.codeBug();
                    }
                    arrmemberBox = new MemberBox[n2];
                    for (int i = 0; i != n2; ++i) {
                        MemberBox memberBox;
                        Method method = (Method)objArray.get(i);
                        arrmemberBox[i] = memberBox = new MemberBox(method);
                    }
                }
                NativeJavaMethod nativeJavaMethod = new NativeJavaMethod(arrmemberBox);
                if (scriptable != null) {
                    ScriptRuntime.setFunctionProtoAndParent(nativeJavaMethod, scriptable);
                }
                Object object2 = entry.getKey();
                map.put(object2, (Object)nativeJavaMethod);
            }
            ++n;
        } while (true);
        Field[] arrfield = this.getAccessibleFields(bl, bl2);
        int n3 = arrfield.length;
        int n4 = 0;
        do {
            block35 : {
                Field field;
                Object object;
                String string3;
                Map<String, Object> map;
                block36 : {
                    Object object3;
                    FieldAndMethods fieldAndMethods;
                    block37 : {
                        block38 : {
                            if (n4 >= n3) break;
                            field = arrfield[n4];
                            string3 = field.getName();
                            int n5 = field.getModifiers();
                            try {
                                boolean bl4 = Modifier.isStatic((int)n5);
                                map = bl4 ? this.staticMembers : this.members;
                                object = map.get((Object)string3);
                                if (object == null) {
                                    map.put((Object)string3, (Object)field);
                                    break block35;
                                }
                                if (!(object instanceof NativeJavaMethod)) break block36;
                                fieldAndMethods = new FieldAndMethods(scriptable, ((NativeJavaMethod)object).methods, field);
                                object3 = bl4 ? this.staticFieldAndMethods : this.fieldAndMethods;
                                if (object3 != null) break block37;
                                object3 = new HashMap();
                                if (!bl4) break block38;
                                this.staticFieldAndMethods = object3;
                                break block37;
                            }
                            catch (SecurityException securityException) {
                                Context.reportWarning("Could not access field " + string3 + " of class " + this.cl.getName() + " due to lack of privileges.");
                            }
                        }
                        this.fieldAndMethods = object3;
                    }
                    object3.put((Object)string3, (Object)fieldAndMethods);
                    map.put((Object)string3, (Object)fieldAndMethods);
                    break block35;
                }
                if (object instanceof Field) {
                    if (((Field)object).getDeclaringClass().isAssignableFrom(field.getDeclaringClass())) {
                        map.put((Object)string3, (Object)field);
                    }
                } else {
                    Kit.codeBug();
                }
            }
            ++n4;
        } while (true);
        int n6 = 0;
        do {
            boolean bl5;
            Map<String, Object> map;
            HashMap hashMap;
            Iterator iterator;
            if (n6 != 2) {
                bl5 = n6 == 0;
                map = bl5 ? this.staticMembers : this.members;
                hashMap = new HashMap();
                iterator = map.keySet().iterator();
            } else {
                Constructor<?>[] arrconstructor = this.getAccessibleConstructors(bl2);
                MemberBox[] arrmemberBox = new MemberBox[arrconstructor.length];
                int n7 = 0;
                do {
                    int n8;
                    if (n7 == (n8 = arrconstructor.length)) {
                        NativeJavaMethod nativeJavaMethod;
                        this.ctors = nativeJavaMethod = new NativeJavaMethod(arrmemberBox, this.cl.getSimpleName());
                        return;
                    }
                    arrmemberBox[n7] = new MemberBox(arrconstructor[n7]);
                    ++n7;
                } while (true);
            }
            while (iterator.hasNext()) {
                Object object;
                int n9;
                String string4;
                String string5 = (String)iterator.next();
                boolean bl6 = string5.startsWith("get");
                boolean bl7 = string5.startsWith("set");
                boolean bl8 = string5.startsWith("is");
                if (!bl6 && !bl8 && !bl7 || (string4 = string5.substring(n9 = bl8 ? 2 : 3)).length() == 0) continue;
                String string6 = string4;
                char c = string4.charAt(0);
                if (Character.isUpperCase((char)c)) {
                    if (string4.length() == 1) {
                        string6 = string4.toLowerCase();
                    } else if (!Character.isUpperCase((char)string4.charAt(1))) {
                        string6 = Character.toLowerCase((char)c) + string4.substring(1);
                    }
                }
                if (hashMap.containsKey((Object)string6) || (object = map.get((Object)string6)) != null && (!bl2 || !(object instanceof Member) || !Modifier.isPrivate((int)((Member)object).getModifiers()))) continue;
                MemberBox memberBox = this.findGetter(bl5, map, "get", string4);
                if (memberBox == null) {
                    memberBox = this.findGetter(bl5, map, "is", string4);
                }
                String string7 = "set".concat(string4);
                boolean bl9 = map.containsKey((Object)string7);
                MemberBox memberBox2 = null;
                NativeJavaMethod nativeJavaMethod = null;
                if (bl9) {
                    Object object4 = map.get((Object)string7);
                    boolean bl10 = object4 instanceof NativeJavaMethod;
                    memberBox2 = null;
                    nativeJavaMethod = null;
                    if (bl10) {
                        NativeJavaMethod nativeJavaMethod2 = (NativeJavaMethod)object4;
                        memberBox2 = memberBox != null ? JavaMembers.extractSetMethod(memberBox.method().getReturnType(), nativeJavaMethod2.methods, bl5) : JavaMembers.extractSetMethod(nativeJavaMethod2.methods, bl5);
                        int n10 = nativeJavaMethod2.methods.length;
                        nativeJavaMethod = null;
                        if (n10 > 1) {
                            nativeJavaMethod = nativeJavaMethod2;
                        }
                    }
                }
                hashMap.put((Object)string6, (Object)new BeanProperty(memberBox, memberBox2, nativeJavaMethod));
            }
            for (String string8 : hashMap.keySet()) {
                Object object = hashMap.get((Object)string8);
                map.put((Object)string8, object);
            }
            ++n6;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    Object get(Scriptable scriptable, String string2, Object object, boolean bl) {
        Object object2;
        Class class_;
        Map<String, Object> map = bl ? this.staticMembers : this.members;
        Object object3 = map.get((Object)string2);
        if (!bl && object3 == null) {
            object3 = this.staticMembers.get((Object)string2);
        }
        if (object3 == null && (object3 = this.getExplicitFunction(scriptable, string2, object, bl)) == null) {
            return Scriptable.NOT_FOUND;
        }
        if (object3 instanceof Scriptable) {
            return object3;
        }
        Context context = Context.getContext();
        try {
            Class class_2;
            BeanProperty beanProperty;
            if (object3 instanceof BeanProperty) {
                beanProperty = (BeanProperty)object3;
                if (beanProperty.getter == null) {
                    return Scriptable.NOT_FOUND;
                }
            } else {
                Class class_3;
                Field field = (Field)object3;
                if (bl) {
                    object = null;
                }
                object2 = field.get(object);
                class_ = class_3 = field.getType();
            }
            object2 = beanProperty.getter.invoke(object, Context.emptyArgs);
            class_ = class_2 = beanProperty.getter.method().getReturnType();
        }
        catch (Exception exception) {
            throw Context.throwAsScriptRuntimeEx(exception);
        }
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        return context.getWrapFactory().wrap(context, scriptable2, object2, class_);
    }

    /*
     * Enabled aggressive block sorting
     */
    Map<String, FieldAndMethods> getFieldAndMethodsObjects(Scriptable scriptable, Object object, boolean bl) {
        Map<String, FieldAndMethods> map = bl ? this.staticFieldAndMethods : this.fieldAndMethods;
        if (map == null) {
            return null;
        }
        HashMap hashMap = new HashMap(map.size());
        Iterator iterator = map.values().iterator();
        while (iterator.hasNext()) {
            FieldAndMethods fieldAndMethods = (FieldAndMethods)iterator.next();
            FieldAndMethods fieldAndMethods2 = new FieldAndMethods(scriptable, fieldAndMethods.methods, fieldAndMethods.field);
            fieldAndMethods2.javaObject = object;
            hashMap.put((Object)fieldAndMethods.field.getName(), (Object)fieldAndMethods2);
        }
        return hashMap;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    Object[] getIds(boolean bl) {
        Map<String, Object> map;
        if (bl) {
            map = this.staticMembers;
            do {
                return map.keySet().toArray(new Object[map.size()]);
                break;
            } while (true);
        }
        map = this.members;
        return map.keySet().toArray(new Object[map.size()]);
    }

    /*
     * Enabled aggressive block sorting
     */
    boolean has(String string2, boolean bl) {
        Map<String, Object> map = bl ? this.staticMembers : this.members;
        return map.get((Object)string2) != null || this.findExplicitFunction(string2, bl) != null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void put(Scriptable scriptable, String string2, Object object, Object object2, boolean bl) {
        Map<String, Object> map = bl ? this.staticMembers : this.members;
        Object object3 = map.get((Object)string2);
        if (!bl && object3 == null) {
            object3 = this.staticMembers.get((Object)string2);
        }
        if (object3 == null) {
            throw this.reportMemberNotFound(string2);
        }
        if (object3 instanceof FieldAndMethods) {
            object3 = ((FieldAndMethods)map.get((Object)string2)).field;
        }
        if (object3 instanceof BeanProperty) {
            BeanProperty beanProperty = (BeanProperty)object3;
            if (beanProperty.setter == null) {
                throw this.reportMemberNotFound(string2);
            }
            if (beanProperty.setters != null && object2 != null) {
                Object[] arrobject = new Object[]{object2};
                beanProperty.setters.call(Context.getContext(), ScriptableObject.getTopLevelScope(scriptable), scriptable, arrobject);
                return;
            }
            Class<?> class_ = beanProperty.setter.argTypes[0];
            Object[] arrobject = new Object[]{Context.jsToJava(object2, class_)};
            try {
                beanProperty.setter.invoke(object, arrobject);
                return;
            }
            catch (Exception exception) {
                throw Context.throwAsScriptRuntimeEx(exception);
            }
        }
        if (!(object3 instanceof Field)) {
            String string3;
            if (object3 == null) {
                string3 = "msg.java.internal.private";
                throw Context.reportRuntimeError1(string3, string2);
            }
            string3 = "msg.java.method.assign";
            throw Context.reportRuntimeError1(string3, string2);
        }
        Field field = (Field)object3;
        Object object4 = Context.jsToJava(object2, field.getType());
        try {
            field.set(object, object4);
            return;
        }
        catch (IllegalAccessException illegalAccessException) {
            if ((16 & field.getModifiers()) != 0) return;
            throw Context.throwAsScriptRuntimeEx(illegalAccessException);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            throw Context.reportRuntimeError3("msg.java.internal.field.type", object2.getClass().getName(), (Object)field, object.getClass().getName());
        }
    }

    RuntimeException reportMemberNotFound(String string2) {
        return Context.reportRuntimeError2("msg.java.member.not.found", this.cl.getName(), string2);
    }

    private static final class MethodSignature {
        private final Class<?>[] args;
        private final String name;

        private MethodSignature(String string2, Class<?>[] arrclass) {
            this.name = string2;
            this.args = arrclass;
        }

        MethodSignature(Method method) {
            this(method.getName(), method.getParameterTypes());
        }

        public boolean equals(Object object) {
            boolean bl = object instanceof MethodSignature;
            boolean bl2 = false;
            if (bl) {
                MethodSignature methodSignature = (MethodSignature)object;
                boolean bl3 = methodSignature.name.equals((Object)this.name);
                bl2 = false;
                if (bl3) {
                    boolean bl4 = Arrays.equals((Object[])this.args, (Object[])methodSignature.args);
                    bl2 = false;
                    if (bl4) {
                        bl2 = true;
                    }
                }
            }
            return bl2;
        }

        public int hashCode() {
            return this.name.hashCode() ^ this.args.length;
        }
    }

}

