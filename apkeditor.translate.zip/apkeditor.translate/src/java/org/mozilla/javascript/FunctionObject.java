/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.Void
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Member
 *  java.lang.reflect.Method
 *  java.lang.reflect.Modifier
 */
package org.mozilla.javascript;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.ConsString;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.MemberBox;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.WrapFactory;

public class FunctionObject
extends BaseFunction {
    public static final int JAVA_BOOLEAN_TYPE = 3;
    public static final int JAVA_DOUBLE_TYPE = 4;
    public static final int JAVA_INT_TYPE = 2;
    public static final int JAVA_OBJECT_TYPE = 6;
    public static final int JAVA_SCRIPTABLE_TYPE = 5;
    public static final int JAVA_STRING_TYPE = 1;
    public static final int JAVA_UNSUPPORTED_TYPE = 0;
    private static final short VARARGS_CTOR = -2;
    private static final short VARARGS_METHOD = -1;
    private static boolean sawSecurityException = false;
    static final long serialVersionUID = -5332312783643935019L;
    private String functionName;
    private transient boolean hasVoidReturn;
    private boolean isStatic;
    MemberBox member;
    private int parmsLength;
    private transient int returnTypeTag;
    private transient byte[] typeTags;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public FunctionObject(String var1_1, Member var2_2, Scriptable var3_3) {
        block16 : {
            super();
            if (var2_2 instanceof Constructor) {
                this.member = new MemberBox((Constructor)var2_2);
                this.isStatic = true;
            } else {
                this.member = new MemberBox((Method)var2_2);
                this.isStatic = this.member.isStatic();
            }
            var4_4 = this.member.getName();
            this.functionName = var1_1;
            var5_5 = this.member.argTypes;
            var6_6 = var5_5.length;
            if (var6_6 != 4 || !var5_5[1].isArray() && !var5_5[2].isArray()) break block16;
            if (var5_5[1].isArray()) {
                if (this.isStatic == false) throw Context.reportRuntimeError1("msg.varargs.ctor", var4_4);
                if (var5_5[0] != ScriptRuntime.ContextClass) throw Context.reportRuntimeError1("msg.varargs.ctor", var4_4);
                if (var5_5[1].getComponentType() != ScriptRuntime.ObjectClass) throw Context.reportRuntimeError1("msg.varargs.ctor", var4_4);
                if (var5_5[2] != ScriptRuntime.FunctionClass) throw Context.reportRuntimeError1("msg.varargs.ctor", var4_4);
                if (var5_5[3] != Boolean.TYPE) {
                    throw Context.reportRuntimeError1("msg.varargs.ctor", var4_4);
                }
                this.parmsLength = -2;
            } else {
                if (this.isStatic == false) throw Context.reportRuntimeError1("msg.varargs.fun", var4_4);
                if (var5_5[0] != ScriptRuntime.ContextClass) throw Context.reportRuntimeError1("msg.varargs.fun", var4_4);
                if (var5_5[1] != ScriptRuntime.ScriptableClass) throw Context.reportRuntimeError1("msg.varargs.fun", var4_4);
                if (var5_5[2].getComponentType() != ScriptRuntime.ObjectClass) throw Context.reportRuntimeError1("msg.varargs.fun", var4_4);
                if (var5_5[3] != ScriptRuntime.FunctionClass) {
                    throw Context.reportRuntimeError1("msg.varargs.fun", var4_4);
                }
                this.parmsLength = -1;
            }
            ** GOTO lbl37
        }
        this.parmsLength = var6_6;
        if (var6_6 <= 0) ** GOTO lbl37
        this.typeTags = new byte[var6_6];
        var7_8 = 0;
        do {
            block17 : {
                if (var7_8 != var6_6) break block17;
lbl37: // 4 sources:
                if (this.member.isMethod()) {
                    var10_7 = this.member.method().getReturnType();
                    if (var10_7 == Void.TYPE) {
                        this.hasVoidReturn = true;
                    } else {
                        this.returnTypeTag = FunctionObject.getTypeTag(var10_7);
                    }
                } else {
                    var9_10 = this.member.getDeclaringClass();
                    if (!ScriptRuntime.ScriptableClass.isAssignableFrom(var9_10)) {
                        throw Context.reportRuntimeError1("msg.bad.ctor.return", var9_10.getName());
                    }
                }
                ScriptRuntime.setFunctionProtoAndParent(this, var3_3);
                return;
            }
            var8_9 = FunctionObject.getTypeTag(var5_5[var7_8]);
            if (var8_9 == 0) {
                throw Context.reportRuntimeError2("msg.bad.parms", var5_5[var7_8].getName(), var4_4);
            }
            this.typeTags[var7_8] = (byte)var8_9;
            ++var7_8;
        } while (true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Object convertArg(Context context, Scriptable scriptable, Object object, int n) {
        switch (n) {
            default: {
                throw new IllegalArgumentException();
            }
            case 1: {
                if (!(object instanceof String)) return ScriptRuntime.toString(object);
            }
            case 6: {
                return object;
            }
            case 2: {
                if (object instanceof Integer) return object;
                return ScriptRuntime.toInt32(object);
            }
            case 3: {
                if (object instanceof Boolean) return object;
                if (!ScriptRuntime.toBoolean(object)) return Boolean.FALSE;
                return Boolean.TRUE;
            }
            case 4: {
                if (object instanceof Double) return object;
                return new Double(ScriptRuntime.toNumber(object));
            }
            case 5: 
        }
        return ScriptRuntime.toObjectOrNull(context, object, scriptable);
    }

    @Deprecated
    public static Object convertArg(Context context, Scriptable scriptable, Object object, Class<?> class_) {
        int n = FunctionObject.getTypeTag(class_);
        if (n == 0) {
            throw Context.reportRuntimeError1("msg.cant.convert", class_.getName());
        }
        return FunctionObject.convertArg(context, scriptable, object, n);
    }

    static Method findSingleMethod(Method[] arrmethod, String string2) {
        Method method = null;
        int n = arrmethod.length;
        for (int i = 0; i != n; ++i) {
            Method method2 = arrmethod[i];
            if (method2 == null || !string2.equals((Object)method2.getName())) continue;
            if (method != null) {
                throw Context.reportRuntimeError2("msg.no.overload", string2, method2.getDeclaringClass().getName());
            }
            method = method2;
        }
        return method;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static Method[] getMethodList(Class<?> class_) {
        Method[] arrmethod;
        try {
            boolean bl = sawSecurityException;
            arrmethod = null;
            if (!bl) {
                Method[] arrmethod2;
                arrmethod = arrmethod2 = class_.getDeclaredMethods();
            }
        }
        catch (SecurityException securityException) {
            sawSecurityException = true;
            arrmethod = null;
        }
        if (arrmethod == null) {
            arrmethod = class_.getMethods();
        }
        int n = 0;
        for (int i = 0; i < arrmethod.length; ++i) {
            if (sawSecurityException ? arrmethod[i].getDeclaringClass() != class_ : !Modifier.isPublic((int)arrmethod[i].getModifiers())) {
                arrmethod[i] = null;
                continue;
            }
            ++n;
        }
        Method[] arrmethod3 = new Method[n];
        int n2 = 0;
        int n3 = 0;
        while (n3 < arrmethod.length) {
            if (arrmethod[n3] != null) {
                int n4 = n2 + 1;
                arrmethod3[n2] = arrmethod[n3];
                n2 = n4;
            }
            ++n3;
        }
        return arrmethod3;
    }

    public static int getTypeTag(Class<?> class_) {
        if (class_ == ScriptRuntime.StringClass) {
            return 1;
        }
        if (class_ == ScriptRuntime.IntegerClass || class_ == Integer.TYPE) {
            return 2;
        }
        if (class_ == ScriptRuntime.BooleanClass || class_ == Boolean.TYPE) {
            return 3;
        }
        if (class_ == ScriptRuntime.DoubleClass || class_ == Double.TYPE) {
            return 4;
        }
        if (ScriptRuntime.ScriptableClass.isAssignableFrom(class_)) {
            return 5;
        }
        if (class_ == ScriptRuntime.ObjectClass) {
            return 6;
        }
        return 0;
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        Class class_;
        block6 : {
            block5 : {
                objectInputStream.defaultReadObject();
                if (this.parmsLength > 0) {
                    Class<?>[] arrclass = this.member.argTypes;
                    this.typeTags = new byte[this.parmsLength];
                    for (int i = 0; i != this.parmsLength; ++i) {
                        this.typeTags[i] = (byte)FunctionObject.getTypeTag(arrclass[i]);
                    }
                }
                if (!this.member.isMethod()) break block5;
                class_ = this.member.method().getReturnType();
                if (class_ != Void.TYPE) break block6;
                this.hasVoidReturn = true;
            }
            return;
        }
        this.returnTypeTag = FunctionObject.getTypeTag(class_);
    }

    public void addAsConstructor(Scriptable scriptable, Scriptable scriptable2) {
        this.initAsConstructor(scriptable, scriptable2);
        FunctionObject.defineProperty(scriptable, scriptable2.getClassName(), this, 2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public Object call(Context var1_1, Scriptable var2_2, Scriptable var3_3, Object[] var4_4) {
        block18 : {
            block16 : {
                block14 : {
                    block17 : {
                        block15 : {
                            block13 : {
                                var5_5 = var4_4.length;
                                for (var6_6 = 0; var6_6 < var5_5; ++var6_6) {
                                    if (!(var4_4[var6_6] instanceof ConsString)) continue;
                                    var4_4[var6_6] = var4_4[var6_6].toString();
                                }
                                if (this.parmsLength >= 0) break block13;
                                if (this.parmsLength == -1) {
                                    var19_7 = new Object[]{var1_1, var3_3, var4_4, this};
                                    var10_8 = this.member.invoke(null, var19_7);
                                    var11_9 = true;
                                } else {
                                    var20_10 = var3_3 == null;
                                    var21_11 = var20_10 != false ? Boolean.TRUE : Boolean.FALSE;
                                    var22_12 = new Object[]{var1_1, var4_4, this, var21_11};
                                    var10_8 = this.member.isCtor() != false ? this.member.newInstance(var22_12) : this.member.invoke(null, var22_12);
                                    var11_9 = false;
                                }
                                break block14;
                            }
                            if (!this.isStatic && !(var15_13 = this.member.getDeclaringClass()).isInstance((Object)var3_3)) {
                                var16_14 = var3_3;
                                var17_15 = false;
                                if (var16_14 == var2_2) {
                                    var18_16 = this.getParentScope();
                                    var17_15 = false;
                                    if (var2_2 != var18_16 && (var17_15 = var15_13.isInstance((Object)var18_16))) {
                                        var3_3 = var18_16;
                                    }
                                }
                                if (!var17_15) {
                                    throw ScriptRuntime.typeError1("msg.incompat.call", this.functionName);
                                }
                            }
                            if (this.parmsLength != var5_5) break block15;
                            var7_17 = var4_4;
                            for (var12_18 = 0; var12_18 != this.parmsLength; ++var12_18) {
                                var13_19 = var4_4[var12_18];
                                var14_20 = FunctionObject.convertArg(var1_1, var2_2, var13_19, this.typeTags[var12_18]);
                                if (var13_19 == var14_20) continue;
                                if (var7_17 == var4_4) {
                                    var7_17 = (Object[])var4_4.clone();
                                }
                                var7_17[var12_18] = var14_20;
                            }
                            break block16;
                        }
                        if (this.parmsLength != 0) break block17;
                        var7_17 = ScriptRuntime.emptyArgs;
                        break block16;
                    }
                    var7_17 = new Object[this.parmsLength];
                    var8_21 = 0;
                    break block18;
                }
lbl49: // 3 sources:
                do {
                    if (var11_9 == false) return var10_8;
                    if (this.hasVoidReturn) {
                        return Undefined.instance;
                    }
                    if (this.returnTypeTag != 0) return var10_8;
                    return var1_1.getWrapFactory().wrap(var1_1, var2_2, var10_8, null);
                    break;
                } while (true);
            }
            do {
                block19 : {
                    if (!this.member.isMethod()) break block19;
                    var10_8 = this.member.invoke(var3_3, var7_17);
                    var11_9 = true;
                    ** GOTO lbl49
                }
                var10_8 = this.member.newInstance(var7_17);
                var11_9 = false;
                ** continue;
                break;
            } while (true);
        }
        do {
            if (var8_21 == this.parmsLength) ** continue;
            var9_22 = var8_21 < var5_5 ? var4_4[var8_21] : Undefined.instance;
            var7_17[var8_21] = FunctionObject.convertArg(var1_1, var2_2, var9_22, this.typeTags[var8_21]);
            ++var8_21;
        } while (true);
    }

    @Override
    public Scriptable createObject(Context context, Scriptable scriptable) {
        Scriptable scriptable2;
        if (this.member.isCtor() || this.parmsLength == -2) {
            return null;
        }
        try {
            scriptable2 = (Scriptable)this.member.getDeclaringClass().newInstance();
        }
        catch (Exception exception) {
            throw Context.throwAsScriptRuntimeEx(exception);
        }
        scriptable2.setPrototype(this.getClassPrototype());
        scriptable2.setParentScope(this.getParentScope());
        return scriptable2;
    }

    @Override
    public int getArity() {
        if (this.parmsLength < 0) {
            return 1;
        }
        return this.parmsLength;
    }

    @Override
    public String getFunctionName() {
        if (this.functionName == null) {
            return "";
        }
        return this.functionName;
    }

    @Override
    public int getLength() {
        return this.getArity();
    }

    public Member getMethodOrConstructor() {
        if (this.member.isMethod()) {
            return this.member.method();
        }
        return this.member.ctor();
    }

    void initAsConstructor(Scriptable scriptable, Scriptable scriptable2) {
        ScriptRuntime.setFunctionProtoAndParent(this, scriptable);
        this.setImmunePrototypeProperty(scriptable2);
        scriptable2.setParentScope(this);
        FunctionObject.defineProperty(scriptable2, "constructor", this, 7);
        this.setParentScope(scriptable);
    }

    boolean isVarArgsConstructor() {
        return this.parmsLength == -2;
    }

    boolean isVarArgsMethod() {
        return this.parmsLength == -1;
    }
}

