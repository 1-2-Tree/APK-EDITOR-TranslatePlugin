/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.SecurityException
 *  java.lang.String
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Callable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.GeneratedClassLoader;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.Scriptable;

public abstract class SecurityController {
    private static SecurityController global;

    public static GeneratedClassLoader createLoader(ClassLoader classLoader, Object object) {
        SecurityController securityController;
        Context context = Context.getContext();
        if (classLoader == null) {
            classLoader = context.getApplicationClassLoader();
        }
        if ((securityController = context.getSecurityController()) == null) {
            return context.createClassLoader(classLoader);
        }
        return securityController.createClassLoader(classLoader, securityController.getDynamicSecurityDomain(object));
    }

    public static Class<?> getStaticSecurityDomainClass() {
        SecurityController securityController = Context.getContext().getSecurityController();
        if (securityController == null) {
            return null;
        }
        return securityController.getStaticSecurityDomainClassInternal();
    }

    static SecurityController global() {
        return global;
    }

    public static boolean hasGlobal() {
        return global != null;
    }

    public static void initGlobal(SecurityController securityController) {
        if (securityController == null) {
            throw new IllegalArgumentException();
        }
        if (global != null) {
            throw new SecurityException("Cannot overwrite already installed global SecurityController");
        }
        global = securityController;
    }

    public Object callWithDomain(Object object, Context context, final Callable callable, Scriptable scriptable, final Scriptable scriptable2, final Object[] arrobject) {
        return this.execWithDomain(context, scriptable, new Script(){

            @Override
            public Object exec(Context context, Scriptable scriptable) {
                return callable.call(context, scriptable, scriptable2, arrobject);
            }
        }, object);
    }

    public abstract GeneratedClassLoader createClassLoader(ClassLoader var1, Object var2);

    @Deprecated
    public Object execWithDomain(Context context, Scriptable scriptable, Script script, Object object) {
        throw new IllegalStateException("callWithDomain should be overridden");
    }

    public abstract Object getDynamicSecurityDomain(Object var1);

    public Class<?> getStaticSecurityDomainClassInternal() {
        return null;
    }

}

