/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.IndexOutOfBoundsException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.UnsupportedOperationException
 *  java.lang.reflect.Array
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Comparator
 *  java.util.Iterator
 *  java.util.LinkedHashSet
 *  java.util.List
 *  java.util.ListIterator
 *  java.util.NoSuchElementException
 */
package org.mozilla.javascript;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.NativeFunction;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.NativeString;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.TopLevel;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.Wrapper;

public class NativeArray
extends IdScriptableObject
implements List {
    private static final Object ARRAY_TAG = "Array";
    private static final int ConstructorId_concat = -13;
    private static final int ConstructorId_every = -17;
    private static final int ConstructorId_filter = -18;
    private static final int ConstructorId_find = -22;
    private static final int ConstructorId_findIndex = -23;
    private static final int ConstructorId_forEach = -19;
    private static final int ConstructorId_indexOf = -15;
    private static final int ConstructorId_isArray = -26;
    private static final int ConstructorId_join = -5;
    private static final int ConstructorId_lastIndexOf = -16;
    private static final int ConstructorId_map = -20;
    private static final int ConstructorId_pop = -9;
    private static final int ConstructorId_push = -8;
    private static final int ConstructorId_reduce = -24;
    private static final int ConstructorId_reduceRight = -25;
    private static final int ConstructorId_reverse = -6;
    private static final int ConstructorId_shift = -10;
    private static final int ConstructorId_slice = -14;
    private static final int ConstructorId_some = -21;
    private static final int ConstructorId_sort = -7;
    private static final int ConstructorId_splice = -12;
    private static final int ConstructorId_unshift = -11;
    private static final int DEFAULT_INITIAL_CAPACITY = 10;
    private static final double GROW_FACTOR = 1.5;
    private static final int Id_concat = 13;
    private static final int Id_constructor = 1;
    private static final int Id_every = 17;
    private static final int Id_filter = 18;
    private static final int Id_find = 22;
    private static final int Id_findIndex = 23;
    private static final int Id_forEach = 19;
    private static final int Id_indexOf = 15;
    private static final int Id_join = 5;
    private static final int Id_lastIndexOf = 16;
    private static final int Id_length = 1;
    private static final int Id_map = 20;
    private static final int Id_pop = 9;
    private static final int Id_push = 8;
    private static final int Id_reduce = 24;
    private static final int Id_reduceRight = 25;
    private static final int Id_reverse = 6;
    private static final int Id_shift = 10;
    private static final int Id_slice = 14;
    private static final int Id_some = 21;
    private static final int Id_sort = 7;
    private static final int Id_splice = 12;
    private static final int Id_toLocaleString = 3;
    private static final int Id_toSource = 4;
    private static final int Id_toString = 2;
    private static final int Id_unshift = 11;
    private static final int MAX_INSTANCE_ID = 1;
    private static final int MAX_PRE_GROW_SIZE = 1431655764;
    private static final int MAX_PROTOTYPE_ID = 25;
    private static final Integer NEGATIVE_ONE = -1;
    private static int maximumInitialCapacity = 0;
    static final long serialVersionUID = 7331366857676127338L;
    private Object[] dense;
    private boolean denseOnly;
    private long length;
    private int lengthAttr = 6;

    static {
        maximumInitialCapacity = 10000;
    }

    /*
     * Enabled aggressive block sorting
     */
    public NativeArray(long l) {
        boolean bl = l <= (long)maximumInitialCapacity;
        this.denseOnly = bl;
        if (this.denseOnly) {
            int n = (int)l;
            if (n < 10) {
                n = 10;
            }
            this.dense = new Object[n];
            Arrays.fill((Object[])this.dense, (Object)Scriptable.NOT_FOUND);
        }
        this.length = l;
    }

    public NativeArray(Object[] arrobject) {
        this.denseOnly = true;
        this.dense = arrobject;
        this.length = arrobject.length;
    }

    private ScriptableObject defaultIndexPropertyDescriptor(Object object) {
        Scriptable scriptable = this.getParentScope();
        if (scriptable == null) {
            scriptable = this;
        }
        NativeObject nativeObject = new NativeObject();
        ScriptRuntime.setBuiltinProtoAndParent(nativeObject, scriptable, TopLevel.Builtins.Object);
        nativeObject.defineProperty("value", object, 0);
        nativeObject.defineProperty("writable", true, 0);
        nativeObject.defineProperty("enumerable", true, 0);
        nativeObject.defineProperty("configurable", true, 0);
        return nativeObject;
    }

    private static void defineElem(Context context, Scriptable scriptable, long l, Object object) {
        if (l > Integer.MAX_VALUE) {
            scriptable.put(Long.toString((long)l), scriptable, object);
            return;
        }
        scriptable.put((int)l, scriptable, object);
    }

    private static void deleteElem(Scriptable scriptable, long l) {
        int n = (int)l;
        if ((long)n == l) {
            scriptable.delete(n);
            return;
        }
        scriptable.delete(Long.toString((long)l));
    }

    private boolean ensureCapacity(int n) {
        if (n > this.dense.length) {
            if (n > 1431655764) {
                this.denseOnly = false;
                return false;
            }
            Object[] arrobject = new Object[Math.max((int)n, (int)((int)(1.5 * (double)this.dense.length)))];
            System.arraycopy((Object)this.dense, (int)0, (Object)arrobject, (int)0, (int)this.dense.length);
            Arrays.fill((Object[])arrobject, (int)this.dense.length, (int)arrobject.length, (Object)Scriptable.NOT_FOUND);
            this.dense = arrobject;
        }
        return true;
    }

    private static Object getElem(Context context, Scriptable scriptable, long l) {
        Object object = NativeArray.getRawElem(scriptable, l);
        if (object != Scriptable.NOT_FOUND) {
            return object;
        }
        return Undefined.instance;
    }

    static long getLengthProperty(Context context, Scriptable scriptable) {
        if (scriptable instanceof NativeString) {
            return ((NativeString)scriptable).getLength();
        }
        if (scriptable instanceof NativeArray) {
            return ((NativeArray)scriptable).getLength();
        }
        Object object = ScriptableObject.getProperty(scriptable, "length");
        if (object == Scriptable.NOT_FOUND) {
            return 0L;
        }
        return ScriptRuntime.toUint32(object);
    }

    static int getMaximumInitialCapacity() {
        return maximumInitialCapacity;
    }

    private static Object getRawElem(Scriptable scriptable, long l) {
        if (l > Integer.MAX_VALUE) {
            return ScriptableObject.getProperty(scriptable, Long.toString((long)l));
        }
        return ScriptableObject.getProperty(scriptable, (int)l);
    }

    static void init(Scriptable scriptable, boolean bl) {
        new NativeArray(0L).exportAsJSClass(25, scriptable, bl);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static Object iterativeMethod(Context var0, int var1_1, Scriptable var2_2, Scriptable var3_3, Object[] var4_4) {
        block28 : {
            block27 : {
                var5_5 = NativeArray.getLengthProperty(var0, var3_3);
                var7_6 = var4_4.length > 0 ? var4_4[0] : Undefined.instance;
                if (var7_6 == null) throw ScriptRuntime.notFunctionError(var7_6);
                if (!(var7_6 instanceof Function)) {
                    throw ScriptRuntime.notFunctionError(var7_6);
                }
                if (!(var1_1 != 22 && var1_1 != 23 || var7_6 instanceof NativeFunction)) {
                    throw ScriptRuntime.notFunctionError(var7_6);
                }
                var8_7 = (Function)var7_6;
                var9_8 = ScriptableObject.getTopLevelScope(var8_7);
                var10_9 = var4_4.length < 2 || var4_4[1] == null || var4_4[1] == Undefined.instance ? var9_8 : ScriptRuntime.toObject(var0, var2_2, var4_4[1]);
                if ((22 == var1_1 || 23 == var1_1) && var10_9 == var3_3) {
                    throw ScriptRuntime.typeError("Array.prototype method called on null or undefined");
                }
                if (var1_1 == 18) break block27;
                var11_10 = null;
                if (var1_1 != 20) break block28;
            }
            var21_11 = var1_1 == 20 ? (int)var5_5 : 0;
            var11_10 = var0.newArray(var2_2, var21_11);
        }
        var14_13 = 0L;
        for (var12_12 = 0L; var12_12 < var5_5; ++var12_12) {
            block30 : {
                block31 : {
                    block29 : {
                        var16_14 = new Object[3];
                        var17_15 = NativeArray.getRawElem(var3_3, var12_12);
                        if (var17_15 != Scriptable.NOT_FOUND) break block29;
                        var19_17 = var14_13;
                        break block30;
                    }
                    var16_14[0] = var17_15;
                    var16_14[1] = var12_12;
                    var16_14[2] = var3_3;
                    var18_16 = var8_7.call(var0, var9_8, var10_9, var16_14);
                    switch (var1_1) {
                        case 17: {
                            if (!ScriptRuntime.toBoolean(var18_16)) {
                                return Boolean.FALSE;
                            }
                            ** GOTO lbl56
                        }
                        case 18: {
                            if (!ScriptRuntime.toBoolean(var18_16)) ** GOTO lbl56
                            var19_17 = var14_13 + 1L;
                            NativeArray.defineElem(var0, var11_10, var14_13, var16_14[0]);
                            break block30;
                        }
                        case 19: {
                            var19_17 = var14_13;
                            break block30;
                        }
                        case 20: {
                            NativeArray.defineElem(var0, var11_10, var12_12, var18_16);
                            var19_17 = var14_13;
                            break block30;
                        }
                        case 21: {
                            if (ScriptRuntime.toBoolean(var18_16)) {
                                return Boolean.TRUE;
                            }
                            ** GOTO lbl56
                        }
                        case 22: {
                            if (ScriptRuntime.toBoolean(var18_16)) {
                                return var17_15;
                            }
                        }
lbl56: // 6 sources:
                        default: {
                            break block31;
                        }
                        case 23: 
                    }
                    if (ScriptRuntime.toBoolean(var18_16)) {
                        return ScriptRuntime.wrapNumber(var12_12);
                    }
                }
                var19_17 = var14_13;
            }
            var14_13 = var19_17;
        }
        switch (var1_1) {
            default: {
                return Undefined.instance;
            }
            case 17: {
                return Boolean.TRUE;
            }
            case 18: 
            case 20: {
                return var11_10;
            }
            case 21: {
                return Boolean.FALSE;
            }
            case 23: 
        }
        return ScriptRuntime.wrapNumber(-1.0);
    }

    private static Object jsConstructor(Context context, Scriptable scriptable, Object[] arrobject) {
        if (arrobject.length == 0) {
            return new NativeArray(0L);
        }
        if (context.getLanguageVersion() == 120) {
            return new NativeArray(arrobject);
        }
        Object object = arrobject[0];
        if (arrobject.length > 1 || !(object instanceof Number)) {
            return new NativeArray(arrobject);
        }
        long l = ScriptRuntime.toUint32(object);
        if ((double)l != ((Number)object).doubleValue()) {
            throw ScriptRuntime.constructError("RangeError", ScriptRuntime.getMessage0("msg.arraylength.bad"));
        }
        return new NativeArray(l);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Scriptable js_concat(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        long l;
        Scriptable scriptable3;
        block14 : {
            int n;
            boolean bl;
            NativeArray nativeArray;
            int n2;
            block13 : {
                block12 : {
                    scriptable3 = context.newArray(NativeArray.getTopLevelScope(scriptable), 0);
                    if (!(scriptable2 instanceof NativeArray) || !(scriptable3 instanceof NativeArray)) break block12;
                    NativeArray nativeArray2 = (NativeArray)scriptable2;
                    nativeArray = (NativeArray)scriptable3;
                    if (!nativeArray2.denseOnly || !nativeArray.denseOnly) break block12;
                    bl = true;
                    n2 = (int)nativeArray2.length;
                    for (int i = 0; i < arrobject.length && bl; ++i) {
                        if (arrobject[i] instanceof NativeArray) {
                            NativeArray nativeArray3 = (NativeArray)arrobject[i];
                            bl = nativeArray3.denseOnly;
                            n2 = (int)((long)n2 + nativeArray3.length);
                            continue;
                        }
                        ++n2;
                    }
                    if (!bl || !nativeArray.ensureCapacity(n2)) break block12;
                    System.arraycopy((Object)nativeArray2.dense, (int)0, (Object)nativeArray.dense, (int)0, (int)((int)nativeArray2.length));
                    n = (int)nativeArray2.length;
                    break block13;
                }
                if (NativeArray.js_isArray(scriptable2)) {
                    long l2 = NativeArray.getLengthProperty(context, scriptable2);
                    for (l = 0L; l < l2; ++l) {
                        Object object = NativeArray.getRawElem(scriptable2, l);
                        if (object == NOT_FOUND) continue;
                        NativeArray.defineElem(context, scriptable3, l, object);
                    }
                } else {
                    long l3 = 0L + 1L;
                    NativeArray.defineElem(context, scriptable3, 0L, scriptable2);
                    l = l3;
                }
                break block14;
            }
            for (int i = 0; i < arrobject.length && bl; ++i) {
                if (arrobject[i] instanceof NativeArray) {
                    NativeArray nativeArray4 = (NativeArray)arrobject[i];
                    System.arraycopy((Object)nativeArray4.dense, (int)0, (Object)nativeArray.dense, (int)n, (int)((int)nativeArray4.length));
                    n += (int)nativeArray4.length;
                    continue;
                }
                Object[] arrobject2 = nativeArray.dense;
                int n3 = n + 1;
                arrobject2[n] = arrobject[i];
                n = n3;
            }
            nativeArray.length = n2;
            return scriptable3;
        }
        int n = 0;
        do {
            if (n >= arrobject.length) {
                NativeArray.setLengthProperty(context, scriptable3, l);
                return scriptable3;
            }
            if (NativeArray.js_isArray(arrobject[n])) {
                Scriptable scriptable4 = (Scriptable)arrobject[n];
                long l4 = NativeArray.getLengthProperty(context, scriptable4);
                for (long i = 0L; i < l4; ++i, ++l) {
                    Object object = NativeArray.getRawElem(scriptable4, i);
                    if (object == NOT_FOUND) continue;
                    NativeArray.defineElem(context, scriptable3, l, object);
                }
            } else {
                long l5 = l + 1L;
                Object object = arrobject[n];
                NativeArray.defineElem(context, scriptable3, l, object);
                l = l5;
            }
            ++n;
        } while (true);
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Object js_indexOf(Context var0, Scriptable var1_1, Object[] var2_2) {
        block9 : {
            block10 : {
                block8 : {
                    if (var2_2.length > 0) {
                        var3_3 = var2_2[0];
lbl3: // 2 sources:
                        do {
                            var4_4 = NativeArray.getLengthProperty(var0, var1_1);
                            if (var2_2.length >= 2) break block8;
                            var6_5 = 0L;
lbl7: // 2 sources:
                            while (var1_1 instanceof NativeArray) {
                                var11_6 = (NativeArray)var1_1;
                                if (!var11_6.denseOnly) break block9;
                                var12_7 = var11_6.getPrototype();
                                var13_8 = (int)var6_5;
lbl12: // 2 sources:
                                while ((long)var13_8 < var4_4) {
                                    var14_9 = var11_6.dense[var13_8];
                                    if (var14_9 == NativeArray.NOT_FOUND && var12_7 != null) {
                                        var14_9 = ScriptableObject.getProperty(var12_7, var13_8);
                                    }
                                    if (var14_9 != NativeArray.NOT_FOUND && ScriptRuntime.shallowEq(var14_9, var3_3)) {
                                        return (long)var13_8;
                                    }
                                    break block10;
                                }
                                return NativeArray.NEGATIVE_ONE;
                            }
                            break block9;
                            break;
                        } while (true);
                    }
                    var3_3 = Undefined.instance;
                    ** while (true)
                }
                var6_5 = (long)ScriptRuntime.toInteger(var2_2[1]);
                if (var6_5 < 0L && (var6_5 += var4_4) < 0L) {
                    var6_5 = 0L;
                }
                if (var6_5 <= var4_4 - 1L) ** GOTO lbl7
                return NativeArray.NEGATIVE_ONE;
            }
            ++var13_8;
            ** GOTO lbl12
        }
        for (var8_10 = var6_5; var8_10 < var4_4; ++var8_10) {
            var10_11 = NativeArray.getRawElem(var1_1, var8_10);
            if (var10_11 == NativeArray.NOT_FOUND || !ScriptRuntime.shallowEq(var10_11, var3_3)) continue;
            return var8_10;
        }
        return NativeArray.NEGATIVE_ONE;
    }

    private static boolean js_isArray(Object object) {
        if (!(object instanceof Scriptable)) {
            return false;
        }
        return "Array".equals((Object)((Scriptable)object).getClassName());
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String js_join(Context context, Scriptable scriptable, Object[] arrobject) {
        int n;
        long l = NativeArray.getLengthProperty(context, scriptable);
        if (l != (long)(n = (int)l)) {
            throw Context.reportRuntimeError1("msg.arraylength.too.big", String.valueOf((long)l));
        }
        String string2 = arrobject.length < 1 || arrobject[0] == Undefined.instance ? "," : ScriptRuntime.toString(arrobject[0]);
        if (scriptable instanceof NativeArray) {
            NativeArray nativeArray = (NativeArray)scriptable;
            if (nativeArray.denseOnly) {
                StringBuilder stringBuilder = new StringBuilder();
                int n2 = 0;
                do {
                    Object object;
                    if (n2 >= n) {
                        return stringBuilder.toString();
                    }
                    if (n2 != 0) {
                        stringBuilder.append(string2);
                    }
                    if (n2 < nativeArray.dense.length && (object = nativeArray.dense[n2]) != null && object != Undefined.instance && object != Scriptable.NOT_FOUND) {
                        stringBuilder.append(ScriptRuntime.toString(object));
                    }
                    ++n2;
                } while (true);
            }
        }
        if (n == 0) {
            return "";
        }
        String[] arrstring = new String[n];
        int n3 = 0;
        for (int i = 0; i != n; ++i) {
            Object object = NativeArray.getElem(context, scriptable, i);
            if (object == null || object == Undefined.instance) continue;
            String string3 = ScriptRuntime.toString(object);
            n3 += string3.length();
            arrstring[i] = string3;
        }
        StringBuilder stringBuilder = new StringBuilder(n3 + (n - 1) * string2.length());
        int n4 = 0;
        while (n4 != n) {
            String string4;
            if (n4 != 0) {
                stringBuilder.append(string2);
            }
            if ((string4 = arrstring[n4]) != null) {
                stringBuilder.append(string4);
            }
            ++n4;
        }
        return stringBuilder.toString();
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Object js_lastIndexOf(Context var0, Scriptable var1_1, Object[] var2_2) {
        block9 : {
            block10 : {
                block11 : {
                    block8 : {
                        if (var2_2.length > 0) {
                            var3_3 = var2_2[0];
lbl3: // 2 sources:
                            do {
                                var4_4 = NativeArray.getLengthProperty(var0, var1_1);
                                if (var2_2.length >= 2) break block8;
                                var6_5 = var4_4 - 1L;
lbl7: // 2 sources:
                                while (var1_1 instanceof NativeArray) {
                                    var11_6 = (NativeArray)var1_1;
                                    if (!var11_6.denseOnly) break block9;
                                    var12_7 = var11_6.getPrototype();
                                    var13_8 = (int)var6_5;
lbl12: // 2 sources:
                                    while (var13_8 >= 0) {
                                        var14_9 = var11_6.dense[var13_8];
                                        if (var14_9 == NativeArray.NOT_FOUND && var12_7 != null) {
                                            var14_9 = ScriptableObject.getProperty(var12_7, var13_8);
                                        }
                                        if (var14_9 != NativeArray.NOT_FOUND && ScriptRuntime.shallowEq(var14_9, var3_3)) {
                                            return (long)var13_8;
                                        }
                                        break block10;
                                    }
                                    return NativeArray.NEGATIVE_ONE;
                                }
                                break block9;
                                break;
                            } while (true);
                        }
                        var3_3 = Undefined.instance;
                        ** while (true)
                    }
                    var6_5 = (long)ScriptRuntime.toInteger(var2_2[1]);
                    if (var6_5 < var4_4) break block11;
                    var6_5 = var4_4 - 1L;
lbl27: // 3 sources:
                    while (var6_5 < 0L) {
                        return NativeArray.NEGATIVE_ONE;
                    }
                    ** GOTO lbl7
                }
                if (var6_5 >= 0L) ** GOTO lbl27
                var6_5 += var4_4;
                ** GOTO lbl27
            }
            --var13_8;
            ** GOTO lbl12
        }
        for (var8_10 = var6_5; var8_10 >= 0L; --var8_10) {
            var10_11 = NativeArray.getRawElem(var1_1, var8_10);
            if (var10_11 == NativeArray.NOT_FOUND || !ScriptRuntime.shallowEq(var10_11, var3_3)) continue;
            return var8_10;
        }
        return NativeArray.NEGATIVE_ONE;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object js_pop(Context context, Scriptable scriptable, Object[] arrobject) {
        long l;
        Object object;
        if (scriptable instanceof NativeArray) {
            NativeArray nativeArray = (NativeArray)scriptable;
            if (nativeArray.denseOnly && nativeArray.length > 0L) {
                --nativeArray.length;
                Object object2 = nativeArray.dense[(int)nativeArray.length];
                nativeArray.dense[(int)nativeArray.length] = NOT_FOUND;
                return object2;
            }
        }
        if ((l = NativeArray.getLengthProperty(context, scriptable)) > 0L) {
            object = NativeArray.getElem(context, scriptable, --l);
            NativeArray.deleteElem(scriptable, l);
        } else {
            object = Undefined.instance;
        }
        NativeArray.setLengthProperty(context, scriptable, l);
        return object;
    }

    private static Object js_push(Context context, Scriptable scriptable, Object[] arrobject) {
        if (scriptable instanceof NativeArray) {
            NativeArray nativeArray = (NativeArray)scriptable;
            if (nativeArray.denseOnly && nativeArray.ensureCapacity((int)nativeArray.length + arrobject.length)) {
                for (int i = 0; i < arrobject.length; ++i) {
                    Object[] arrobject2 = nativeArray.dense;
                    long l = nativeArray.length;
                    nativeArray.length = 1L + l;
                    arrobject2[(int)l] = arrobject[i];
                }
                return ScriptRuntime.wrapNumber(nativeArray.length);
            }
        }
        long l = NativeArray.getLengthProperty(context, scriptable);
        for (int i = 0; i < arrobject.length; ++i) {
            NativeArray.setElem(context, scriptable, l + (long)i, arrobject[i]);
        }
        Object object = NativeArray.setLengthProperty(context, scriptable, l + (long)arrobject.length);
        if (context.getLanguageVersion() == 120) {
            if (arrobject.length == 0) {
                return Undefined.instance;
            }
            return arrobject[-1 + arrobject.length];
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static Scriptable js_reverse(Context context, Scriptable scriptable, Object[] arrobject) {
        if (scriptable instanceof NativeArray) {
            NativeArray nativeArray = (NativeArray)scriptable;
            if (nativeArray.denseOnly) {
                int n = 0;
                int n2 = -1 + (int)nativeArray.length;
                while (n < n2) {
                    Object object = nativeArray.dense[n];
                    nativeArray.dense[n] = nativeArray.dense[n2];
                    nativeArray.dense[n2] = object;
                    ++n;
                    --n2;
                }
                return scriptable;
            }
        }
        long l = NativeArray.getLengthProperty(context, scriptable);
        long l2 = l / 2L;
        long l3 = 0L;
        while (l3 < l2) {
            long l4 = l - l3 - 1L;
            Object object = NativeArray.getRawElem(scriptable, l3);
            NativeArray.setRawElem(context, scriptable, l3, NativeArray.getRawElem(scriptable, l4));
            NativeArray.setRawElem(context, scriptable, l4, object);
            ++l3;
        }
        return scriptable;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object js_shift(Context context, Scriptable scriptable, Object[] arrobject) {
        long l;
        Object object;
        if (scriptable instanceof NativeArray) {
            NativeArray nativeArray = (NativeArray)scriptable;
            if (nativeArray.denseOnly && nativeArray.length > 0L) {
                --nativeArray.length;
                Object object2 = nativeArray.dense[0];
                System.arraycopy((Object)nativeArray.dense, (int)1, (Object)nativeArray.dense, (int)0, (int)((int)nativeArray.length));
                nativeArray.dense[(int)nativeArray.length] = NOT_FOUND;
                if (object2 != NOT_FOUND) return object2;
                return Undefined.instance;
            }
        }
        if ((l = NativeArray.getLengthProperty(context, scriptable)) > 0L) {
            object = NativeArray.getElem(context, scriptable, 0L);
            if (--l > 0L) {
                for (long i = 1L; i <= l; ++i) {
                    Object object3 = NativeArray.getRawElem(scriptable, i);
                    NativeArray.setRawElem(context, scriptable, i - 1L, object3);
                }
            }
            NativeArray.deleteElem(scriptable, l);
        } else {
            object = Undefined.instance;
        }
        NativeArray.setLengthProperty(context, scriptable, l);
        return object;
    }

    /*
     * Enabled aggressive block sorting
     */
    private Scriptable js_slice(Context context, Scriptable scriptable, Object[] arrobject) {
        long l;
        long l2;
        Scriptable scriptable2 = context.newArray(NativeArray.getTopLevelScope(this), 0);
        long l3 = NativeArray.getLengthProperty(context, scriptable);
        if (arrobject.length == 0) {
            l = 0L;
            l2 = l3;
        } else {
            l = NativeArray.toSliceIndex(ScriptRuntime.toInteger(arrobject[0]), l3);
            l2 = arrobject.length == 1 || arrobject[1] == Undefined.instance ? l3 : NativeArray.toSliceIndex(ScriptRuntime.toInteger(arrobject[1]), l3);
        }
        long l4 = l;
        do {
            if (l4 >= l2) {
                NativeArray.setLengthProperty(context, scriptable2, Math.max((long)0L, (long)(l2 - l)));
                return scriptable2;
            }
            Object object = NativeArray.getRawElem(scriptable, l4);
            if (object != NOT_FOUND) {
                NativeArray.defineElem(context, scriptable2, l4 - l, object);
            }
            ++l4;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Scriptable js_sort(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        int n;
        long l;
        void var4_7;
        if (arrobject.length > 0 && Undefined.instance != arrobject[0]) {
            Callable callable = ScriptRuntime.getValueFunctionAndThis(arrobject[0], context);
            Scriptable scriptable3 = ScriptRuntime.lastStoredScriptable(context);
            Comparator<Object> comparator = new Comparator<Object>(new Object[2], callable, context, scriptable, scriptable3){
                final /* synthetic */ Object[] val$cmpBuf;
                final /* synthetic */ Context val$cx;
                final /* synthetic */ Scriptable val$funThis;
                final /* synthetic */ Callable val$jsCompareFunction;
                final /* synthetic */ Scriptable val$scope;
                {
                    this.val$cmpBuf = arrobject;
                    this.val$jsCompareFunction = callable;
                    this.val$cx = context;
                    this.val$scope = scriptable;
                    this.val$funThis = scriptable2;
                }

                public int compare(Object object, Object object2) {
                    if (object == Scriptable.NOT_FOUND) {
                        return object2 != Scriptable.NOT_FOUND;
                    }
                    if (object2 == Scriptable.NOT_FOUND) {
                        return -1;
                    }
                    if (object == Undefined.instance) {
                        return object2 != Undefined.instance;
                    }
                    if (object2 == Undefined.instance) {
                        return -1;
                    }
                    this.val$cmpBuf[0] = object;
                    this.val$cmpBuf[1] = object2;
                    double d = ScriptRuntime.toNumber(this.val$jsCompareFunction.call(this.val$cx, this.val$scope, this.val$funThis, this.val$cmpBuf));
                    if (d < 0.0) {
                        return -1;
                    }
                    return d > 0.0;
                }
            };
        } else {
            Comparator<Object> comparator = new Comparator<Object>(){

                /*
                 * Enabled aggressive block sorting
                 */
                public int compare(Object object, Object object2) {
                    if (object == Scriptable.NOT_FOUND) {
                        if (object2 == Scriptable.NOT_FOUND) return 0;
                        return 1;
                    }
                    if (object2 == Scriptable.NOT_FOUND) {
                        return -1;
                    }
                    if (object == Undefined.instance) {
                        if (object2 != Undefined.instance) return 1;
                        return 0;
                    }
                    if (object2 != Undefined.instance) return ScriptRuntime.toString(object).compareTo(ScriptRuntime.toString(object2));
                    return -1;
                }
            };
        }
        if ((l = NativeArray.getLengthProperty(context, scriptable2)) != (long)(n = (int)l)) {
            throw Context.reportRuntimeError1("msg.arraylength.too.big", String.valueOf((long)l));
        }
        Object[] arrobject2 = new Object[n];
        for (int i = 0; i != n; ++i) {
            arrobject2[i] = NativeArray.getRawElem(scriptable2, i);
        }
        Arrays.sort((Object[])arrobject2, (Comparator)var4_7);
        int n2 = 0;
        while (n2 < n) {
            NativeArray.setRawElem(context, scriptable2, n2, arrobject2[n2]);
            ++n2;
        }
        return scriptable2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object js_splice(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        int n;
        long l;
        Object object;
        boolean bl = scriptable2 instanceof NativeArray;
        boolean bl2 = false;
        NativeArray nativeArray = null;
        if (bl) {
            nativeArray = (NativeArray)scriptable2;
            bl2 = nativeArray.denseOnly;
        }
        Scriptable scriptable3 = NativeArray.getTopLevelScope(scriptable);
        int n2 = arrobject.length;
        if (n2 == 0) {
            return context.newArray(scriptable3, 0);
        }
        long l2 = NativeArray.getLengthProperty(context, scriptable2);
        long l3 = NativeArray.toSliceIndex(ScriptRuntime.toInteger(arrobject[0]), l2);
        int n3 = n2 - 1;
        if (arrobject.length == 1) {
            l = l2 - l3;
        } else {
            double d = ScriptRuntime.toInteger(arrobject[1]);
            l = d < 0.0 ? 0L : (d > (double)(l2 - l3) ? l2 - l3 : (long)d);
            --n3;
        }
        long l4 = l3 + l;
        if (l != 0L) {
            if (l == 1L && context.getLanguageVersion() == 120) {
                object = NativeArray.getElem(context, scriptable2, l3);
            } else if (bl2) {
                int n4 = (int)(l4 - l3);
                Object[] arrobject2 = new Object[n4];
                System.arraycopy((Object)nativeArray.dense, (int)((int)l3), (Object)arrobject2, (int)0, (int)n4);
                object = context.newArray(scriptable3, arrobject2);
            } else {
                Scriptable scriptable4 = context.newArray(scriptable3, 0);
                for (long i = l3; i != l4; ++i) {
                    Object object2 = NativeArray.getRawElem(scriptable2, i);
                    if (object2 == NOT_FOUND) continue;
                    NativeArray.setElem(context, scriptable4, i - l3, object2);
                }
                NativeArray.setLengthProperty(context, scriptable4, l4 - l3);
                object = scriptable4;
            }
        } else {
            object = context.getLanguageVersion() == 120 ? Undefined.instance : context.newArray(scriptable3, 0);
        }
        long l5 = (long)n3 - l;
        if (bl2 && l2 + l5 < Integer.MAX_VALUE && nativeArray.ensureCapacity(n = (int)(l2 + l5))) {
            long l6;
            System.arraycopy((Object)nativeArray.dense, (int)((int)l4), (Object)nativeArray.dense, (int)((int)(l3 + (long)n3)), (int)((int)(l2 - l4)));
            if (n3 > 0) {
                System.arraycopy((Object)arrobject, (int)2, (Object)nativeArray.dense, (int)((int)l3), (int)n3);
            }
            if (l5 < 0L) {
                Arrays.fill((Object[])nativeArray.dense, (int)((int)(l2 + l5)), (int)((int)l2), (Object)NOT_FOUND);
            }
            nativeArray.length = l6 = l2 + l5;
            return object;
        }
        if (l5 > 0L) {
            for (long i = l2 - 1L; i >= l4; --i) {
                Object object3 = NativeArray.getRawElem(scriptable2, i);
                NativeArray.setRawElem(context, scriptable2, i + l5, object3);
            }
        } else if (l5 < 0L) {
            for (long i = l4; i < l2; ++i) {
                Object object4 = NativeArray.getRawElem(scriptable2, i);
                NativeArray.setRawElem(context, scriptable2, i + l5, object4);
            }
            for (long i = l2 + l5; i < l2; ++i) {
                NativeArray.deleteElem(scriptable2, i);
            }
        }
        int n5 = arrobject.length - n3;
        int n6 = 0;
        do {
            if (n6 >= n3) {
                NativeArray.setLengthProperty(context, scriptable2, l2 + l5);
                return object;
            }
            NativeArray.setElem(context, scriptable2, l3 + (long)n6, arrobject[n6 + n5]);
            ++n6;
        } while (true);
    }

    private static Object js_unshift(Context context, Scriptable scriptable, Object[] arrobject) {
        if (scriptable instanceof NativeArray) {
            NativeArray nativeArray = (NativeArray)scriptable;
            if (nativeArray.denseOnly && nativeArray.ensureCapacity((int)nativeArray.length + arrobject.length)) {
                System.arraycopy((Object)nativeArray.dense, (int)0, (Object)nativeArray.dense, (int)arrobject.length, (int)((int)nativeArray.length));
                for (int i = 0; i < arrobject.length; ++i) {
                    nativeArray.dense[i] = arrobject[i];
                }
                nativeArray.length += (long)arrobject.length;
                return ScriptRuntime.wrapNumber(nativeArray.length);
            }
        }
        long l = NativeArray.getLengthProperty(context, scriptable);
        int n = arrobject.length;
        if (arrobject.length > 0) {
            if (l > 0L) {
                for (long i = l - 1L; i >= 0L; --i) {
                    Object object = NativeArray.getRawElem(scriptable, i);
                    NativeArray.setRawElem(context, scriptable, i + (long)n, object);
                }
            }
            for (int i = 0; i < arrobject.length; ++i) {
                NativeArray.setElem(context, scriptable, i, arrobject[i]);
            }
        }
        return NativeArray.setLengthProperty(context, scriptable, l + (long)arrobject.length);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object reduceMethod(Context context, int n, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        long l = NativeArray.getLengthProperty(context, scriptable2);
        Object object = arrobject.length > 0 ? arrobject[0] : Undefined.instance;
        if (object == null || !(object instanceof Function)) {
            throw ScriptRuntime.notFunctionError(object);
        }
        Function function = (Function)object;
        Scriptable scriptable3 = ScriptableObject.getTopLevelScope(function);
        boolean bl = n == 24;
        Object object2 = arrobject.length > 1 ? arrobject[1] : Scriptable.NOT_FOUND;
        for (long i = 0L; i < l; ++i) {
            long l2 = bl ? i : l - 1L - i;
            Object object3 = NativeArray.getRawElem(scriptable2, l2);
            if (object3 == Scriptable.NOT_FOUND) continue;
            if (object2 == Scriptable.NOT_FOUND) {
                object2 = object3;
                continue;
            }
            Object[] arrobject2 = new Object[]{object2, object3, l2, scriptable2};
            object2 = function.call(context, scriptable3, scriptable3, arrobject2);
        }
        if (object2 == Scriptable.NOT_FOUND) {
            throw ScriptRuntime.typeError0("msg.empty.array.reduce");
        }
        return object2;
    }

    private static void setElem(Context context, Scriptable scriptable, long l, Object object) {
        if (l > Integer.MAX_VALUE) {
            ScriptableObject.putProperty(scriptable, Long.toString((long)l), object);
            return;
        }
        ScriptableObject.putProperty(scriptable, (int)l, object);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void setLength(Object object) {
        if ((1 & this.lengthAttr) != 0) {
            return;
        }
        double d = ScriptRuntime.toNumber(object);
        long l = ScriptRuntime.toUint32(d);
        if ((double)l != d) {
            throw ScriptRuntime.constructError("RangeError", ScriptRuntime.getMessage0("msg.arraylength.bad"));
        }
        if (this.denseOnly) {
            if (l < this.length) {
                Arrays.fill((Object[])this.dense, (int)((int)l), (int)this.dense.length, (Object)NOT_FOUND);
                this.length = l;
                return;
            }
            if (l < 0x55555554L && (double)l < 1.5 * (double)this.length && this.ensureCapacity((int)l)) {
                this.length = l;
                return;
            }
            this.denseOnly = false;
        }
        if (l < this.length) {
            if (this.length - l <= 4096L) {
                for (long i = l; i < this.length; ++i) {
                    NativeArray.deleteElem(this, i);
                }
            } else {
                Object[] arrobject = this.getIds();
                for (int i = 0; i < arrobject.length; ++i) {
                    Object object2 = arrobject[i];
                    if (object2 instanceof String) {
                        String string2 = (String)object2;
                        if (NativeArray.toArrayIndex(string2) < l) continue;
                        this.delete(string2);
                        continue;
                    }
                    int n = (Integer)object2;
                    if ((long)n < l) continue;
                    this.delete(n);
                }
            }
        }
        this.length = l;
    }

    private static Object setLengthProperty(Context context, Scriptable scriptable, long l) {
        Number number = ScriptRuntime.wrapNumber(l);
        ScriptableObject.putProperty(scriptable, "length", (Object)number);
        return number;
    }

    static void setMaximumInitialCapacity(int n) {
        maximumInitialCapacity = n;
    }

    private static void setRawElem(Context context, Scriptable scriptable, long l, Object object) {
        if (object == NOT_FOUND) {
            NativeArray.deleteElem(scriptable, l);
            return;
        }
        NativeArray.setElem(context, scriptable, l, object);
    }

    private static long toArrayIndex(double d) {
        long l;
        if (d == d && (double)(l = ScriptRuntime.toUint32(d)) == d && l != 0xFFFFFFFFL) {
            return l;
        }
        return -1L;
    }

    private static long toArrayIndex(Object object) {
        if (object instanceof String) {
            return NativeArray.toArrayIndex((String)object);
        }
        if (object instanceof Number) {
            return NativeArray.toArrayIndex(((Number)object).doubleValue());
        }
        return -1L;
    }

    private static long toArrayIndex(String string2) {
        long l = NativeArray.toArrayIndex(ScriptRuntime.toNumber(string2));
        if (Long.toString((long)l).equals((Object)string2)) {
            return l;
        }
        return -1L;
    }

    private static int toDenseIndex(Object object) {
        long l = NativeArray.toArrayIndex(object);
        if (0L <= l && l < Integer.MAX_VALUE) {
            return (int)l;
        }
        return -1;
    }

    private static long toSliceIndex(double d, long l) {
        if (d < 0.0) {
            if (d + (double)l < 0.0) {
                return 0L;
            }
            return (long)(d + (double)l);
        }
        if (d > (double)l) {
            return l;
        }
        return (long)d;
    }

    /*
     * Exception decompiling
     */
    private static String toStringHelper(Context var0, Scriptable var1_1, Scriptable var2_2, boolean var3_3, boolean var4_4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 4[FORLOOP]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    public void add(int n, Object object) {
        throw new UnsupportedOperationException();
    }

    public boolean add(Object object) {
        throw new UnsupportedOperationException();
    }

    public boolean addAll(int n, Collection collection) {
        throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public boolean contains(Object object) {
        return this.indexOf(object) > -1;
    }

    public boolean containsAll(Collection collection) {
        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            if (this.contains(iterator.next())) continue;
            return false;
        }
        return true;
    }

    @Override
    protected void defineOwnProperty(Context context, Object object, ScriptableObject scriptableObject, boolean bl) {
        long l;
        if (this.dense != null) {
            Object[] arrobject = this.dense;
            this.dense = null;
            this.denseOnly = false;
            for (int i = 0; i < arrobject.length; ++i) {
                if (arrobject[i] == NOT_FOUND) continue;
                this.put(i, (Scriptable)this, arrobject[i]);
            }
        }
        if ((l = NativeArray.toArrayIndex(object)) >= this.length) {
            this.length = 1L + l;
        }
        super.defineOwnProperty(context, object, scriptableObject, bl);
    }

    @Override
    public void delete(int n) {
        if (!(this.dense == null || n < 0 || n >= this.dense.length || this.isSealed() || !this.denseOnly && this.isGetterOrSetter(null, n, true))) {
            this.dense[n] = NOT_FOUND;
            return;
        }
        super.delete(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        boolean bl = true;
        if (!idFunctionObject.hasTag(ARRAY_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        block22 : do {
            switch (n) {
                default: {
                    throw new IllegalArgumentException(String.valueOf((int)n));
                }
                case -25: 
                case -24: 
                case -23: 
                case -22: 
                case -21: 
                case -20: 
                case -19: 
                case -18: 
                case -17: 
                case -16: 
                case -15: 
                case -14: 
                case -13: 
                case -12: 
                case -11: 
                case -10: 
                case -9: 
                case -8: 
                case -7: 
                case -6: 
                case -5: {
                    if (arrobject.length > 0) {
                        scriptable2 = ScriptRuntime.toObject(context, scriptable, arrobject[0]);
                        Object[] arrobject2 = new Object[-1 + arrobject.length];
                        for (int i = 0; i < arrobject2.length; ++i) {
                            arrobject2[i] = arrobject[i + 1];
                        }
                        arrobject = arrobject2;
                    }
                    n = -n;
                    continue block22;
                }
                case -26: {
                    if (arrobject.length > 0 && NativeArray.js_isArray(arrobject[0])) {
                        return bl;
                    }
                    bl = false;
                    return bl;
                }
                case 1: {
                    boolean bl2 = scriptable2 == null ? bl : false;
                    if (bl2) return NativeArray.jsConstructor(context, scriptable, arrobject);
                    return idFunctionObject.construct(context, scriptable, arrobject);
                }
                case 2: {
                    return NativeArray.toStringHelper(context, scriptable, scriptable2, context.hasFeature(4), false);
                }
                case 3: {
                    return NativeArray.toStringHelper(context, scriptable, scriptable2, false, bl);
                }
                case 4: {
                    return NativeArray.toStringHelper(context, scriptable, scriptable2, bl, false);
                }
                case 5: {
                    return NativeArray.js_join(context, scriptable2, arrobject);
                }
                case 6: {
                    return NativeArray.js_reverse(context, scriptable2, arrobject);
                }
                case 7: {
                    return NativeArray.js_sort(context, scriptable, scriptable2, arrobject);
                }
                case 8: {
                    return NativeArray.js_push(context, scriptable2, arrobject);
                }
                case 9: {
                    return NativeArray.js_pop(context, scriptable2, arrobject);
                }
                case 10: {
                    return NativeArray.js_shift(context, scriptable2, arrobject);
                }
                case 11: {
                    return NativeArray.js_unshift(context, scriptable2, arrobject);
                }
                case 12: {
                    return NativeArray.js_splice(context, scriptable, scriptable2, arrobject);
                }
                case 13: {
                    return NativeArray.js_concat(context, scriptable, scriptable2, arrobject);
                }
                case 14: {
                    return this.js_slice(context, scriptable2, arrobject);
                }
                case 15: {
                    return NativeArray.js_indexOf(context, scriptable2, arrobject);
                }
                case 16: {
                    return NativeArray.js_lastIndexOf(context, scriptable2, arrobject);
                }
                case 17: 
                case 18: 
                case 19: 
                case 20: 
                case 21: 
                case 22: 
                case 23: {
                    return NativeArray.iterativeMethod(context, n, scriptable, scriptable2, arrobject);
                }
                case 24: 
                case 25: 
            }
            break;
        } while (true);
        return NativeArray.reduceMethod(context, n, scriptable, scriptable2, arrobject);
    }

    @Override
    protected void fillConstructorProperties(IdFunctionObject idFunctionObject) {
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -5, "join", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -6, "reverse", 0);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -7, "sort", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -8, "push", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -9, "pop", 0);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -10, "shift", 0);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -11, "unshift", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -12, "splice", 2);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -13, "concat", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -14, "slice", 2);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -15, "indexOf", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -16, "lastIndexOf", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -17, "every", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -18, "filter", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -19, "forEach", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -20, "map", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -21, "some", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -22, "find", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -23, "findIndex", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -24, "reduce", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -25, "reduceRight", 1);
        this.addIdFunctionProperty(idFunctionObject, ARRAY_TAG, -26, "isArray", 1);
        super.fillConstructorProperties(idFunctionObject);
    }

    @Override
    protected int findInstanceIdInfo(String string2) {
        if (string2.equals((Object)"length")) {
            return NativeArray.instanceIdInfo(this.lengthAttr, 1);
        }
        return super.findInstanceIdInfo(string2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        block0 : switch (n) {
            case 3: {
                char c = string2.charAt(0);
                if (c == 'm') {
                    char c2 = string2.charAt(2);
                    string3 = null;
                    n2 = 0;
                    if (c2 != 'p') break;
                    char c3 = string2.charAt(1);
                    string3 = null;
                    n2 = 0;
                    if (c3 != 'a') break;
                    return 20;
                }
                string3 = null;
                n2 = 0;
                if (c != 'p') break;
                char c4 = string2.charAt(2);
                string3 = null;
                n2 = 0;
                if (c4 != 'p') break;
                char c5 = string2.charAt(1);
                string3 = null;
                n2 = 0;
                if (c5 != 'o') break;
                return 9;
            }
            case 4: {
                switch (string2.charAt(2)) {
                    default: {
                        return 0;
                    }
                    case 'i': {
                        string3 = "join";
                        n2 = 5;
                        break block0;
                    }
                    case 'm': {
                        string3 = "some";
                        n2 = 21;
                        break block0;
                    }
                    case 'n': {
                        string3 = "find";
                        n2 = 22;
                        break block0;
                    }
                    case 'r': {
                        string3 = "sort";
                        n2 = 7;
                        break block0;
                    }
                    case 's': 
                }
                string3 = "push";
                n2 = 8;
                break;
            }
            case 5: {
                char c = string2.charAt(1);
                if (c == 'h') {
                    string3 = "shift";
                    n2 = 10;
                    break;
                }
                if (c == 'l') {
                    string3 = "slice";
                    n2 = 14;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'v') break;
                string3 = "every";
                n2 = 17;
                break;
            }
            case 6: {
                switch (string2.charAt(0)) {
                    default: {
                        return 0;
                    }
                    case 'c': {
                        string3 = "concat";
                        n2 = 13;
                        break block0;
                    }
                    case 'f': {
                        string3 = "filter";
                        n2 = 18;
                        break block0;
                    }
                    case 'r': {
                        string3 = "reduce";
                        n2 = 24;
                        break block0;
                    }
                    case 's': 
                }
                string3 = "splice";
                n2 = 12;
                break;
            }
            case 7: {
                switch (string2.charAt(0)) {
                    default: {
                        return 0;
                    }
                    case 'f': {
                        string3 = "forEach";
                        n2 = 19;
                        break block0;
                    }
                    case 'i': {
                        string3 = "indexOf";
                        n2 = 15;
                        break block0;
                    }
                    case 'r': {
                        string3 = "reverse";
                        n2 = 6;
                        break block0;
                    }
                    case 'u': 
                }
                string3 = "unshift";
                n2 = 11;
                break;
            }
            case 8: {
                char c = string2.charAt(3);
                if (c == 'o') {
                    string3 = "toSource";
                    n2 = 4;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "toString";
                n2 = 2;
                break;
            }
            case 9: {
                string3 = "findIndex";
                n2 = 23;
                break;
            }
            case 11: {
                char c = string2.charAt(0);
                if (c == 'c') {
                    string3 = "constructor";
                    n2 = 1;
                    break;
                }
                if (c == 'l') {
                    string3 = "lastIndexOf";
                    n2 = 16;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'r') break;
                string3 = "reduceRight";
                n2 = 25;
                break;
            }
            case 14: {
                string3 = "toLocaleString";
                n2 = 3;
                break;
            }
        }
        if (string3 == null) return n2;
        if (string3 == string2) return n2;
        if (string3.equals((Object)string2)) return n2;
        return 0;
    }

    public Object get(int n) {
        return this.get((long)n);
    }

    @Override
    public Object get(int n, Scriptable scriptable) {
        if (!this.denseOnly && this.isGetterOrSetter(null, n, false)) {
            return super.get(n, scriptable);
        }
        if (this.dense != null && n >= 0 && n < this.dense.length) {
            return this.dense[n];
        }
        return super.get(n, scriptable);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public Object get(long l) {
        if (l < 0L) throw new IndexOutOfBoundsException();
        if (l >= this.length) {
            throw new IndexOutOfBoundsException();
        }
        Object object = NativeArray.getRawElem(this, l);
        if (object == Scriptable.NOT_FOUND) return null;
        if (object == Undefined.instance) {
            return null;
        }
        if (!(object instanceof Wrapper)) return object;
        return ((Wrapper)object).unwrap();
    }

    @Override
    public Object[] getAllIds() {
        LinkedHashSet linkedHashSet = new LinkedHashSet((Collection)Arrays.asList((Object[])this.getIds()));
        linkedHashSet.addAll((Collection)Arrays.asList((Object[])super.getAllIds()));
        return linkedHashSet.toArray();
    }

    @Override
    public int getAttributes(int n) {
        if (this.dense != null && n >= 0 && n < this.dense.length && this.dense[n] != NOT_FOUND) {
            return 0;
        }
        return super.getAttributes(n);
    }

    @Override
    public String getClassName() {
        return "Array";
    }

    @Override
    public Object getDefaultValue(Class<?> class_) {
        if (class_ == ScriptRuntime.NumberClass && Context.getContext().getLanguageVersion() == 120) {
            return this.length;
        }
        return super.getDefaultValue(class_);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object[] getIds() {
        Object[] arrobject;
        int n;
        block7 : {
            block6 : {
                arrobject = super.getIds();
                if (this.dense == null) break block6;
                n = this.dense.length;
                long l = this.length;
                if ((long)n > l) {
                    n = (int)l;
                }
                if (n != 0) break block7;
            }
            return arrobject;
        }
        int n2 = arrobject.length;
        Object[] arrobject2 = new Object[n + n2];
        int n3 = 0;
        for (int i = 0; i != n; ++i) {
            if (this.dense[i] == NOT_FOUND) continue;
            arrobject2[n3] = i;
            ++n3;
        }
        if (n3 != n) {
            Object[] arrobject3 = new Object[n3 + n2];
            System.arraycopy((Object)arrobject2, (int)0, (Object)arrobject3, (int)0, (int)n3);
            arrobject2 = arrobject3;
        }
        System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)n3, (int)n2);
        return arrobject2;
    }

    public Integer[] getIndexIds() {
        Object[] arrobject = this.getIds();
        ArrayList arrayList = new ArrayList(arrobject.length);
        for (Object object : arrobject) {
            int n = ScriptRuntime.toInt32(object);
            if (n < 0 || !ScriptRuntime.toString(n).equals((Object)ScriptRuntime.toString(object))) continue;
            arrayList.add((Object)n);
        }
        return (Integer[])arrayList.toArray((Object[])new Integer[arrayList.size()]);
    }

    @Override
    protected String getInstanceIdName(int n) {
        if (n == 1) {
            return "length";
        }
        return super.getInstanceIdName(n);
    }

    @Override
    protected Object getInstanceIdValue(int n) {
        if (n == 1) {
            return ScriptRuntime.wrapNumber(this.length);
        }
        return super.getInstanceIdValue(n);
    }

    public long getLength() {
        return this.length;
    }

    @Override
    protected int getMaxInstanceId() {
        return 1;
    }

    @Override
    protected ScriptableObject getOwnPropertyDescriptor(Context context, Object object) {
        int n;
        if (this.dense != null && (n = NativeArray.toDenseIndex(object)) >= 0 && n < this.dense.length && this.dense[n] != NOT_FOUND) {
            return this.defaultIndexPropertyDescriptor(this.dense[n]);
        }
        return super.getOwnPropertyDescriptor(context, object);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean has(int n, Scriptable scriptable) {
        if (!this.denseOnly && this.isGetterOrSetter(null, n, false)) {
            return super.has(n, scriptable);
        }
        if (this.dense == null) return super.has(n, scriptable);
        if (n < 0) return super.has(n, scriptable);
        if (n >= this.dense.length) return super.has(n, scriptable);
        Object object = this.dense[n];
        Object object2 = NOT_FOUND;
        boolean bl = false;
        if (object == object2) return bl;
        return true;
    }

    public int indexOf(Object object) {
        long l = this.length;
        if (l > Integer.MAX_VALUE) {
            throw new IllegalStateException();
        }
        int n = (int)l;
        if (object == null) {
            for (int i = 0; i < n; ++i) {
                if (this.get(i) != null) continue;
                return i;
            }
        } else {
            for (int i = 0; i < n; ++i) {
                if (!object.equals(this.get(i))) continue;
                return i;
            }
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 1;
                string2 = "constructor";
                break;
            }
            case 2: {
                string2 = "toString";
                n2 = 0;
                break;
            }
            case 3: {
                string2 = "toLocaleString";
                n2 = 0;
                break;
            }
            case 4: {
                string2 = "toSource";
                n2 = 0;
                break;
            }
            case 5: {
                n2 = 1;
                string2 = "join";
                break;
            }
            case 6: {
                string2 = "reverse";
                n2 = 0;
                break;
            }
            case 7: {
                n2 = 1;
                string2 = "sort";
                break;
            }
            case 8: {
                n2 = 1;
                string2 = "push";
                break;
            }
            case 9: {
                string2 = "pop";
                n2 = 0;
                break;
            }
            case 10: {
                string2 = "shift";
                n2 = 0;
                break;
            }
            case 11: {
                n2 = 1;
                string2 = "unshift";
                break;
            }
            case 12: {
                n2 = 2;
                string2 = "splice";
                break;
            }
            case 13: {
                n2 = 1;
                string2 = "concat";
                break;
            }
            case 14: {
                n2 = 2;
                string2 = "slice";
                break;
            }
            case 15: {
                n2 = 1;
                string2 = "indexOf";
                break;
            }
            case 16: {
                n2 = 1;
                string2 = "lastIndexOf";
                break;
            }
            case 17: {
                n2 = 1;
                string2 = "every";
                break;
            }
            case 18: {
                n2 = 1;
                string2 = "filter";
                break;
            }
            case 19: {
                n2 = 1;
                string2 = "forEach";
                break;
            }
            case 20: {
                n2 = 1;
                string2 = "map";
                break;
            }
            case 21: {
                n2 = 1;
                string2 = "some";
                break;
            }
            case 22: {
                n2 = 1;
                string2 = "find";
                break;
            }
            case 23: {
                n2 = 1;
                string2 = "findIndex";
                break;
            }
            case 24: {
                n2 = 1;
                string2 = "reduce";
                break;
            }
            case 25: {
                n2 = 1;
                string2 = "reduceRight";
            }
        }
        this.initPrototypeMethod(ARRAY_TAG, n, string2, n2);
    }

    @Override
    public boolean isEmpty() {
        return this.length == 0L;
    }

    public Iterator iterator() {
        return this.listIterator(0);
    }

    @Deprecated
    public long jsGet_length() {
        return this.getLength();
    }

    public int lastIndexOf(Object object) {
        long l = this.length;
        if (l > Integer.MAX_VALUE) {
            throw new IllegalStateException();
        }
        int n = (int)l;
        if (object == null) {
            for (int i = n - 1; i >= 0; --i) {
                if (this.get(i) != null) continue;
                return i;
            }
        } else {
            for (int i = n - 1; i >= 0; --i) {
                if (!object.equals(this.get(i))) continue;
                return i;
            }
        }
        return -1;
    }

    public ListIterator listIterator() {
        return this.listIterator(0);
    }

    public ListIterator listIterator(final int n) {
        long l = this.length;
        if (l > Integer.MAX_VALUE) {
            throw new IllegalStateException();
        }
        final int n2 = (int)l;
        if (n < 0 || n > n2) {
            throw new IndexOutOfBoundsException("Index: " + n);
        }
        return new ListIterator(){
            int cursor;
            {
                this.cursor = n;
            }

            public void add(Object object) {
                throw new UnsupportedOperationException();
            }

            public boolean hasNext() {
                return this.cursor < n2;
            }

            public boolean hasPrevious() {
                return this.cursor > 0;
            }

            public Object next() {
                if (this.cursor == n2) {
                    throw new NoSuchElementException();
                }
                NativeArray nativeArray = NativeArray.this;
                int n3 = this.cursor;
                this.cursor = n3 + 1;
                return nativeArray.get(n3);
            }

            public int nextIndex() {
                return this.cursor;
            }

            public Object previous() {
                int n3;
                if (this.cursor == 0) {
                    throw new NoSuchElementException();
                }
                NativeArray nativeArray = NativeArray.this;
                this.cursor = n3 = -1 + this.cursor;
                return nativeArray.get(n3);
            }

            public int previousIndex() {
                return -1 + this.cursor;
            }

            public void remove() {
                throw new UnsupportedOperationException();
            }

            public void set(Object object) {
                throw new UnsupportedOperationException();
            }
        };
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void put(int n, Scriptable scriptable, Object object) {
        if (!(scriptable != this || this.isSealed() || this.dense == null || n < 0 || !this.denseOnly && this.isGetterOrSetter(null, n, true))) {
            if (!this.isExtensible() && this.length <= (long)n) return;
            if (n < this.dense.length) {
                this.dense[n] = object;
                if (this.length > (long)n) return;
                {
                    this.length = 1L + (long)n;
                    return;
                }
            }
            if (this.denseOnly && (double)n < 1.5 * (double)this.dense.length && this.ensureCapacity(n + 1)) {
                this.dense[n] = object;
                this.length = 1L + (long)n;
                return;
            }
            this.denseOnly = false;
        }
        super.put(n, scriptable, object);
        if (scriptable != this || (1 & this.lengthAttr) != 0 || this.length > (long)n) {
            return;
        }
        this.length = 1L + (long)n;
    }

    @Override
    public void put(String string2, Scriptable scriptable, Object object) {
        long l;
        super.put(string2, scriptable, object);
        if (scriptable == this && (l = NativeArray.toArrayIndex(string2)) >= this.length) {
            this.length = 1L + l;
            this.denseOnly = false;
        }
    }

    public Object remove(int n) {
        throw new UnsupportedOperationException();
    }

    public boolean remove(Object object) {
        throw new UnsupportedOperationException();
    }

    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    public Object set(int n, Object object) {
        throw new UnsupportedOperationException();
    }

    void setDenseOnly(boolean bl) {
        if (bl && !this.denseOnly) {
            throw new IllegalArgumentException();
        }
        this.denseOnly = bl;
    }

    @Override
    protected void setInstanceIdAttributes(int n, int n2) {
        if (n == 1) {
            this.lengthAttr = n2;
        }
    }

    @Override
    protected void setInstanceIdValue(int n, Object object) {
        if (n == 1) {
            this.setLength(object);
            return;
        }
        super.setInstanceIdValue(n, object);
    }

    @Override
    public int size() {
        long l = this.length;
        if (l > Integer.MAX_VALUE) {
            throw new IllegalStateException();
        }
        return (int)l;
    }

    public List subList(int n, int n2) {
        throw new UnsupportedOperationException();
    }

    public Object[] toArray() {
        return this.toArray(ScriptRuntime.emptyArgs);
    }

    /*
     * Enabled aggressive block sorting
     */
    public Object[] toArray(Object[] arrobject) {
        long l = this.length;
        if (l > Integer.MAX_VALUE) {
            throw new IllegalStateException();
        }
        int n = (int)l;
        Object[] arrobject2 = arrobject.length >= n ? arrobject : (Object[])Array.newInstance((Class)arrobject.getClass().getComponentType(), (int)n);
        int n2 = 0;
        while (n2 < n) {
            arrobject2[n2] = this.get(n2);
            ++n2;
        }
        return arrobject2;
    }

}

