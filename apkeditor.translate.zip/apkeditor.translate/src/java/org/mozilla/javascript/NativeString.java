/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.Collator
 *  java.text.Normalizer
 *  java.text.Normalizer$Form
 *  java.util.Locale
 */
package org.mozilla.javascript;

import java.text.Collator;
import java.text.Normalizer;
import java.util.Locale;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.regexp.NativeRegExp;

final class NativeString
extends IdScriptableObject {
    private static final int ConstructorId_charAt = -5;
    private static final int ConstructorId_charCodeAt = -6;
    private static final int ConstructorId_concat = -14;
    private static final int ConstructorId_equalsIgnoreCase = -30;
    private static final int ConstructorId_fromCharCode = -1;
    private static final int ConstructorId_indexOf = -7;
    private static final int ConstructorId_lastIndexOf = -8;
    private static final int ConstructorId_localeCompare = -34;
    private static final int ConstructorId_match = -31;
    private static final int ConstructorId_replace = -33;
    private static final int ConstructorId_search = -32;
    private static final int ConstructorId_slice = -15;
    private static final int ConstructorId_split = -9;
    private static final int ConstructorId_substr = -13;
    private static final int ConstructorId_substring = -10;
    private static final int ConstructorId_toLocaleLowerCase = -35;
    private static final int ConstructorId_toLowerCase = -11;
    private static final int ConstructorId_toUpperCase = -12;
    private static final int Id_anchor = 28;
    private static final int Id_big = 21;
    private static final int Id_blink = 22;
    private static final int Id_bold = 16;
    private static final int Id_charAt = 5;
    private static final int Id_charCodeAt = 6;
    private static final int Id_codePointAt = 45;
    private static final int Id_concat = 14;
    private static final int Id_constructor = 1;
    private static final int Id_endsWith = 42;
    private static final int Id_equals = 29;
    private static final int Id_equalsIgnoreCase = 30;
    private static final int Id_fixed = 18;
    private static final int Id_fontcolor = 26;
    private static final int Id_fontsize = 25;
    private static final int Id_includes = 40;
    private static final int Id_indexOf = 7;
    private static final int Id_italics = 17;
    private static final int Id_lastIndexOf = 8;
    private static final int Id_length = 1;
    private static final int Id_link = 27;
    private static final int Id_localeCompare = 34;
    private static final int Id_match = 31;
    private static final int Id_normalize = 43;
    private static final int Id_repeat = 44;
    private static final int Id_replace = 33;
    private static final int Id_search = 32;
    private static final int Id_slice = 15;
    private static final int Id_small = 20;
    private static final int Id_split = 9;
    private static final int Id_startsWith = 41;
    private static final int Id_strike = 19;
    private static final int Id_sub = 24;
    private static final int Id_substr = 13;
    private static final int Id_substring = 10;
    private static final int Id_sup = 23;
    private static final int Id_toLocaleLowerCase = 35;
    private static final int Id_toLocaleUpperCase = 36;
    private static final int Id_toLowerCase = 11;
    private static final int Id_toSource = 3;
    private static final int Id_toString = 2;
    private static final int Id_toUpperCase = 12;
    private static final int Id_trim = 37;
    private static final int Id_trimLeft = 38;
    private static final int Id_trimRight = 39;
    private static final int Id_valueOf = 4;
    private static final int MAX_INSTANCE_ID = 1;
    private static final int MAX_PROTOTYPE_ID = 45;
    private static final Object STRING_TAG = "String";
    static final long serialVersionUID = 920268368584188687L;
    private CharSequence string;

    NativeString(CharSequence charSequence) {
        this.string = charSequence;
    }

    static void init(Scriptable scriptable, boolean bl) {
        new NativeString("").exportAsJSClass(45, scriptable, bl);
    }

    private static String js_concat(String string2, Object[] arrobject) {
        int n = arrobject.length;
        if (n == 0) {
            return string2;
        }
        if (n == 1) {
            return string2.concat(ScriptRuntime.toString(arrobject[0]));
        }
        int n2 = string2.length();
        String[] arrstring = new String[n];
        for (int i = 0; i != n; ++i) {
            String string3;
            arrstring[i] = string3 = ScriptRuntime.toString(arrobject[i]);
            n2 += string3.length();
        }
        StringBuilder stringBuilder = new StringBuilder(n2);
        stringBuilder.append(string2);
        for (int i = 0; i != n; ++i) {
            stringBuilder.append(arrstring[i]);
        }
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int js_indexOf(int n, String string2, Object[] arrobject) {
        int n2;
        String string3 = ScriptRuntime.toString(arrobject, 0);
        double d = ScriptRuntime.toInteger(arrobject, 1);
        if (d > (double)string2.length() && n != 41 && n != 42) {
            return -1;
        }
        if (d < 0.0) {
            d = 0.0;
        } else if (d > (double)string2.length()) {
            d = string2.length();
        } else if (n == 42 && (d != d || d > (double)string2.length())) {
            d = string2.length();
        }
        if (42 == n) {
            if (arrobject.length == 0 || arrobject.length == 1 || arrobject.length == 2 && arrobject[1] == Undefined.instance) {
                d = string2.length();
            }
            boolean bl = string2.substring(0, (int)d).endsWith(string3);
            n2 = 0;
            if (bl) return n2;
            return -1;
        }
        if (n != 41) {
            return string2.indexOf(string3, (int)d);
        }
        boolean bl = string2.startsWith(string3, (int)d);
        n2 = 0;
        if (bl) return n2;
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int js_lastIndexOf(String string2, Object[] arrobject) {
        String string3 = ScriptRuntime.toString(arrobject, 0);
        double d = ScriptRuntime.toNumber(arrobject, 1);
        if (d == d && !(d > (double)string2.length())) {
            if (!(d < 0.0)) return string2.lastIndexOf(string3, (int)d);
            d = 0.0;
            return string2.lastIndexOf(string3, (int)d);
        }
        d = string2.length();
        return string2.lastIndexOf(string3, (int)d);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static CharSequence js_slice(CharSequence charSequence, Object[] arrobject) {
        double d;
        double d2 = arrobject.length < 1 ? 0.0 : ScriptRuntime.toInteger(arrobject[0]);
        int n = charSequence.length();
        if (d2 < 0.0) {
            if ((d2 += (double)n) < 0.0) {
                d2 = 0.0;
            }
        } else if (d2 > (double)n) {
            d2 = n;
        }
        if (arrobject.length < 2 || arrobject[1] == Undefined.instance) {
            d = n;
            return charSequence.subSequence((int)d2, (int)d);
        }
        d = ScriptRuntime.toInteger(arrobject[1]);
        if (d < 0.0) {
            if ((d += (double)n) < 0.0) {
                d = 0.0;
            }
        } else if (d > (double)n) {
            d = n;
        }
        if (!(d < d2)) return charSequence.subSequence((int)d2, (int)d);
        d = d2;
        return charSequence.subSequence((int)d2, (int)d);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static CharSequence js_substr(CharSequence charSequence, Object[] arrobject) {
        double d;
        if (arrobject.length < 1) {
            return charSequence;
        }
        double d2 = ScriptRuntime.toInteger(arrobject[0]);
        int n = charSequence.length();
        if (d2 < 0.0) {
            if ((d2 += (double)n) < 0.0) {
                d2 = 0.0;
            }
        } else if (d2 > (double)n) {
            d2 = n;
        }
        if (arrobject.length == 1) {
            d = n;
            return charSequence.subSequence((int)d2, (int)d);
        }
        double d3 = ScriptRuntime.toInteger(arrobject[1]);
        if (d3 < 0.0) {
            d3 = 0.0;
        }
        if (!((d = d3 + d2) > (double)n)) return charSequence.subSequence((int)d2, (int)d);
        d = n;
        return charSequence.subSequence((int)d2, (int)d);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static CharSequence js_substring(Context context, CharSequence charSequence, Object[] arrobject) {
        double d;
        int n = charSequence.length();
        double d2 = ScriptRuntime.toInteger(arrobject, 0);
        if (d2 < 0.0) {
            d2 = 0.0;
        } else if (d2 > (double)n) {
            d2 = n;
        }
        if (arrobject.length <= 1 || arrobject[1] == Undefined.instance) {
            d = n;
            return charSequence.subSequence((int)d2, (int)d);
        }
        d = ScriptRuntime.toInteger(arrobject[1]);
        if (d < 0.0) {
            d = 0.0;
        } else if (d > (double)n) {
            d = n;
        }
        if (!(d < d2)) return charSequence.subSequence((int)d2, (int)d);
        if (context.getLanguageVersion() != 120) {
            double d3 = d2;
            d2 = d;
            d = d3;
            return charSequence.subSequence((int)d2, (int)d);
        }
        d = d2;
        return charSequence.subSequence((int)d2, (int)d);
    }

    private static NativeString realThis(Scriptable scriptable, IdFunctionObject idFunctionObject) {
        if (!(scriptable instanceof NativeString)) {
            throw NativeString.incompatibleCallError(idFunctionObject);
        }
        return (NativeString)scriptable;
    }

    private static String tagify(Object object, String string2, String string3, Object[] arrobject) {
        String string4 = ScriptRuntime.toString(object);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('<');
        stringBuilder.append(string2);
        if (string3 != null) {
            stringBuilder.append(' ');
            stringBuilder.append(string3);
            stringBuilder.append("=\"");
            stringBuilder.append(ScriptRuntime.toString(arrobject, 0));
            stringBuilder.append('\"');
        }
        stringBuilder.append('>');
        stringBuilder.append(string4);
        stringBuilder.append("</");
        stringBuilder.append(string2);
        stringBuilder.append('>');
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        double d;
        StringBuilder stringBuilder;
        int n;
        String string2;
        if (!idFunctionObject.hasTag(STRING_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n2 = idFunctionObject.methodId();
        block42 : do {
            switch (n2) {
                default: {
                    throw new IllegalArgumentException("String.prototype has no method: " + idFunctionObject.getFunctionName());
                }
                case -35: 
                case -34: 
                case -33: 
                case -32: 
                case -31: 
                case -30: 
                case -15: 
                case -14: 
                case -13: 
                case -12: 
                case -11: 
                case -10: 
                case -9: 
                case -8: 
                case -7: 
                case -6: 
                case -5: {
                    if (arrobject.length > 0) {
                        int n3;
                        scriptable2 = ScriptRuntime.toObject(context, scriptable, (Object)ScriptRuntime.toCharSequence(arrobject[0]));
                        Object[] arrobject2 = new Object[-1 + arrobject.length];
                        for (int i = 0; i < (n3 = arrobject2.length); ++i) {
                            arrobject2[i] = arrobject[i + 1];
                        }
                        arrobject = arrobject2;
                    } else {
                        scriptable2 = ScriptRuntime.toObject(context, scriptable, (Object)ScriptRuntime.toCharSequence(scriptable2));
                    }
                    n2 = -n2;
                    continue block42;
                }
                case -1: {
                    int n4 = arrobject.length;
                    if (n4 < 1) {
                        return "";
                    }
                    StringBuilder stringBuilder2 = new StringBuilder(n4);
                    int n5 = 0;
                    while (n5 != n4) {
                        stringBuilder2.append(ScriptRuntime.toUint16(arrobject[n5]));
                        ++n5;
                    }
                    return stringBuilder2.toString();
                }
                case 1: {
                    Object object = arrobject.length >= 1 ? ScriptRuntime.toCharSequence(arrobject[0]) : "";
                    if (scriptable2 == null) {
                        return new NativeString((CharSequence)object);
                    }
                    if (object instanceof String) return object;
                    return object.toString();
                }
                case 2: 
                case 4: {
                    CharSequence charSequence = NativeString.realThis((Scriptable)scriptable2, (IdFunctionObject)idFunctionObject).string;
                    if (!(charSequence instanceof String)) return charSequence.toString();
                    return charSequence;
                }
                case 3: {
                    CharSequence charSequence = NativeString.realThis((Scriptable)scriptable2, (IdFunctionObject)idFunctionObject).string;
                    return "(new String(\"" + ScriptRuntime.escapeString(charSequence.toString()) + "\"))";
                }
                case 5: 
                case 6: {
                    CharSequence charSequence = ScriptRuntime.toCharSequence(scriptable2);
                    double d2 = ScriptRuntime.toInteger(arrobject, 0);
                    if (!(d2 < 0.0) && !(d2 >= (double)charSequence.length())) {
                        char c = charSequence.charAt((int)d2);
                        if (n2 != 5) return ScriptRuntime.wrapInt(c);
                        return String.valueOf((char)c);
                    }
                    if (n2 != 5) return ScriptRuntime.NaNobj;
                    return "";
                }
                case 7: {
                    return ScriptRuntime.wrapInt(NativeString.js_indexOf(7, ScriptRuntime.toString(scriptable2), arrobject));
                }
                case 40: 
                case 41: 
                case 42: {
                    boolean bl;
                    String string3 = ScriptRuntime.toString(ScriptRuntime.requireObjectCoercible(scriptable2, idFunctionObject));
                    if (arrobject.length > 0 && arrobject[0] instanceof NativeRegExp) {
                        throw ScriptRuntime.typeError2("msg.first.arg.not.regexp", String.class.getSimpleName(), idFunctionObject.getFunctionName());
                    }
                    int n6 = NativeString.js_indexOf(n2, string3, arrobject);
                    if (n2 == 40) {
                        boolean bl2;
                        if (n6 != -1) {
                            bl2 = true;
                            return bl2;
                        }
                        bl2 = false;
                        return bl2;
                    }
                    if (n2 == 41) {
                        boolean bl3;
                        if (n6 == 0) {
                            bl3 = true;
                            return bl3;
                        }
                        bl3 = false;
                        return bl3;
                    }
                    if (n2 != 42) return ScriptRuntime.wrapInt(NativeString.js_lastIndexOf(ScriptRuntime.toString(scriptable2), arrobject));
                    if (n6 != -1) {
                        bl = true;
                        return bl;
                    }
                    bl = false;
                    return bl;
                }
                case 8: {
                    return ScriptRuntime.wrapInt(NativeString.js_lastIndexOf(ScriptRuntime.toString(scriptable2), arrobject));
                }
                case 9: {
                    return ScriptRuntime.checkRegExpProxy(context).js_split(context, scriptable, ScriptRuntime.toString(scriptable2), arrobject);
                }
                case 10: {
                    return NativeString.js_substring(context, ScriptRuntime.toCharSequence(scriptable2), arrobject);
                }
                case 11: {
                    return ScriptRuntime.toString(scriptable2).toLowerCase(ScriptRuntime.ROOT_LOCALE);
                }
                case 12: {
                    return ScriptRuntime.toString(scriptable2).toUpperCase(ScriptRuntime.ROOT_LOCALE);
                }
                case 13: {
                    return NativeString.js_substr(ScriptRuntime.toCharSequence(scriptable2), arrobject);
                }
                case 14: {
                    return NativeString.js_concat(ScriptRuntime.toString(scriptable2), arrobject);
                }
                case 15: {
                    return NativeString.js_slice(ScriptRuntime.toCharSequence(scriptable2), arrobject);
                }
                case 16: {
                    return NativeString.tagify(scriptable2, "b", null, null);
                }
                case 17: {
                    return NativeString.tagify(scriptable2, "i", null, null);
                }
                case 18: {
                    return NativeString.tagify(scriptable2, "tt", null, null);
                }
                case 19: {
                    return NativeString.tagify(scriptable2, "strike", null, null);
                }
                case 20: {
                    return NativeString.tagify(scriptable2, "small", null, null);
                }
                case 21: {
                    return NativeString.tagify(scriptable2, "big", null, null);
                }
                case 22: {
                    return NativeString.tagify(scriptable2, "blink", null, null);
                }
                case 23: {
                    return NativeString.tagify(scriptable2, "sup", null, null);
                }
                case 24: {
                    return NativeString.tagify(scriptable2, "sub", null, null);
                }
                case 25: {
                    return NativeString.tagify(scriptable2, "font", "size", arrobject);
                }
                case 26: {
                    return NativeString.tagify(scriptable2, "font", "color", arrobject);
                }
                case 27: {
                    return NativeString.tagify(scriptable2, "a", "href", arrobject);
                }
                case 28: {
                    return NativeString.tagify(scriptable2, "a", "name", arrobject);
                }
                case 29: 
                case 30: {
                    boolean bl;
                    String string4 = ScriptRuntime.toString(scriptable2);
                    String string5 = ScriptRuntime.toString(arrobject, 0);
                    if (n2 == 29) {
                        bl = string4.equals((Object)string5);
                        return ScriptRuntime.wrapBoolean(bl);
                    }
                    bl = string4.equalsIgnoreCase(string5);
                    return ScriptRuntime.wrapBoolean(bl);
                }
                case 31: 
                case 32: 
                case 33: {
                    int n7;
                    if (n2 == 31) {
                        n7 = 1;
                        return ScriptRuntime.checkRegExpProxy(context).action(context, scriptable, scriptable2, arrobject, n7);
                    }
                    if (n2 == 32) {
                        n7 = 3;
                        return ScriptRuntime.checkRegExpProxy(context).action(context, scriptable, scriptable2, arrobject, n7);
                    }
                    n7 = 2;
                    return ScriptRuntime.checkRegExpProxy(context).action(context, scriptable, scriptable2, arrobject, n7);
                }
                case 34: {
                    Collator collator = Collator.getInstance((Locale)context.getLocale());
                    collator.setStrength(3);
                    collator.setDecomposition(1);
                    return ScriptRuntime.wrapNumber(collator.compare(ScriptRuntime.toString(scriptable2), ScriptRuntime.toString(arrobject, 0)));
                }
                case 35: {
                    return ScriptRuntime.toString(scriptable2).toLowerCase(context.getLocale());
                }
                case 36: {
                    return ScriptRuntime.toString(scriptable2).toUpperCase(context.getLocale());
                }
                case 37: {
                    int n8;
                    int n9;
                    String string6 = ScriptRuntime.toString(scriptable2);
                    char[] arrc = string6.toCharArray();
                    for (n8 = 0; n8 < (n9 = arrc.length) && ScriptRuntime.isJSWhitespaceOrLineTerminator(arrc[n8]); ++n8) {
                    }
                    int n10 = arrc.length;
                    while (n10 > n8) {
                        if (!ScriptRuntime.isJSWhitespaceOrLineTerminator(arrc[n10 - 1])) return string6.substring(n8, n10);
                        --n10;
                    }
                    return string6.substring(n8, n10);
                }
                case 38: {
                    int n11;
                    int n12;
                    String string7 = ScriptRuntime.toString(scriptable2);
                    char[] arrc = string7.toCharArray();
                    for (n12 = 0; n12 < (n11 = arrc.length) && ScriptRuntime.isJSWhitespaceOrLineTerminator(arrc[n12]); ++n12) {
                    }
                    int n13 = arrc.length;
                    return string7.substring(n12, n13);
                }
                case 39: {
                    String string8 = ScriptRuntime.toString(scriptable2);
                    char[] arrc = string8.toCharArray();
                    int n14 = arrc.length;
                    while (n14 > 0) {
                        if (!ScriptRuntime.isJSWhitespaceOrLineTerminator(arrc[n14 - 1])) return string8.substring(0, n14);
                        --n14;
                    }
                    return string8.substring(0, n14);
                }
                case 43: {
                    Normalizer.Form form;
                    String string9 = ScriptRuntime.toString(arrobject, 0);
                    if (Normalizer.Form.NFD.name().equals((Object)string9)) {
                        form = Normalizer.Form.NFD;
                        return Normalizer.normalize((CharSequence)ScriptRuntime.toString(ScriptRuntime.requireObjectCoercible(scriptable2, idFunctionObject)), (Normalizer.Form)form);
                    }
                    if (Normalizer.Form.NFKC.name().equals((Object)string9)) {
                        form = Normalizer.Form.NFKC;
                        return Normalizer.normalize((CharSequence)ScriptRuntime.toString(ScriptRuntime.requireObjectCoercible(scriptable2, idFunctionObject)), (Normalizer.Form)form);
                    }
                    if (Normalizer.Form.NFKD.name().equals((Object)string9)) {
                        form = Normalizer.Form.NFKD;
                        return Normalizer.normalize((CharSequence)ScriptRuntime.toString(ScriptRuntime.requireObjectCoercible(scriptable2, idFunctionObject)), (Normalizer.Form)form);
                    }
                    if (!Normalizer.Form.NFC.name().equals((Object)string9)) {
                        if (arrobject.length != 0) throw ScriptRuntime.rangeError("The normalization form should be one of NFC, NFD, NFKC, NFKD");
                    }
                    form = Normalizer.Form.NFC;
                    return Normalizer.normalize((CharSequence)ScriptRuntime.toString(ScriptRuntime.requireObjectCoercible(scriptable2, idFunctionObject)), (Normalizer.Form)form);
                }
                case 44: {
                    string2 = ScriptRuntime.toString(ScriptRuntime.requireObjectCoercible(scriptable2, idFunctionObject));
                    d = ScriptRuntime.toInteger(arrobject, 0);
                    if (d == 0.0) {
                        return "";
                    }
                    if (d < 0.0) throw ScriptRuntime.rangeError("Invalid count value");
                    if (d == Double.POSITIVE_INFINITY) {
                        throw ScriptRuntime.rangeError("Invalid count value");
                    }
                    long l = (long)string2.length() * (long)d;
                    if (d >= 2.147483647E9 || l >= Integer.MAX_VALUE) {
                        l = Integer.MAX_VALUE;
                    }
                    stringBuilder = new StringBuilder((int)l);
                    stringBuilder.append(string2);
                    n = 1;
                    while ((double)n <= d / 2.0) {
                        stringBuilder.append((CharSequence)stringBuilder);
                        n *= 2;
                    }
                    break block42;
                }
                case 45: {
                    String string10 = ScriptRuntime.toString(ScriptRuntime.requireObjectCoercible(scriptable2, idFunctionObject));
                    double d3 = ScriptRuntime.toInteger(arrobject, 0);
                    if (d3 < 0.0) return Undefined.instance;
                    if (d3 >= (double)string10.length()) return Undefined.instance;
                    return string10.codePointAt((int)d3);
                }
            }
            break;
        } while (true);
        int n15 = n;
        do {
            int n16 = n15 + 1;
            if (!((double)n15 < d)) return stringBuilder.toString();
            stringBuilder.append(string2);
            n15 = n16;
        } while (true);
    }

    @Override
    protected void fillConstructorProperties(IdFunctionObject idFunctionObject) {
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -1, "fromCharCode", 1);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -5, "charAt", 2);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -6, "charCodeAt", 2);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -7, "indexOf", 2);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -8, "lastIndexOf", 2);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -9, "split", 3);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -10, "substring", 3);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -11, "toLowerCase", 1);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -12, "toUpperCase", 1);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -13, "substr", 3);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -14, "concat", 2);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -15, "slice", 3);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -30, "equalsIgnoreCase", 2);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -31, "match", 2);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -32, "search", 2);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -33, "replace", 2);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -34, "localeCompare", 2);
        this.addIdFunctionProperty(idFunctionObject, STRING_TAG, -35, "toLocaleLowerCase", 1);
        super.fillConstructorProperties(idFunctionObject);
    }

    @Override
    protected int findInstanceIdInfo(String string2) {
        if (string2.equals((Object)"length")) {
            return NativeString.instanceIdInfo(7, 1);
        }
        return super.findInstanceIdInfo(string2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        block0 : switch (n) {
            case 3: {
                char c = string2.charAt(2);
                if (c == 'b') {
                    char c2 = string2.charAt(0);
                    string3 = null;
                    n2 = 0;
                    if (c2 != 's') break;
                    char c3 = string2.charAt(1);
                    string3 = null;
                    n2 = 0;
                    if (c3 != 'u') break;
                    return 24;
                }
                if (c == 'g') {
                    char c4 = string2.charAt(0);
                    string3 = null;
                    n2 = 0;
                    if (c4 != 'b') break;
                    char c5 = string2.charAt(1);
                    string3 = null;
                    n2 = 0;
                    if (c5 != 'i') break;
                    return 21;
                }
                string3 = null;
                n2 = 0;
                if (c != 'p') break;
                char c6 = string2.charAt(0);
                string3 = null;
                n2 = 0;
                if (c6 != 's') break;
                char c7 = string2.charAt(1);
                string3 = null;
                n2 = 0;
                if (c7 != 'u') break;
                return 23;
            }
            case 4: {
                char c = string2.charAt(0);
                if (c == 'b') {
                    string3 = "bold";
                    n2 = 16;
                    break;
                }
                if (c == 'l') {
                    string3 = "link";
                    n2 = 27;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "trim";
                n2 = 37;
                break;
            }
            case 5: {
                switch (string2.charAt(4)) {
                    default: {
                        return 0;
                    }
                    case 'd': {
                        string3 = "fixed";
                        n2 = 18;
                        break block0;
                    }
                    case 'e': {
                        string3 = "slice";
                        n2 = 15;
                        break block0;
                    }
                    case 'h': {
                        string3 = "match";
                        n2 = 31;
                        break block0;
                    }
                    case 'k': {
                        string3 = "blink";
                        n2 = 22;
                        break block0;
                    }
                    case 'l': {
                        string3 = "small";
                        n2 = 20;
                        break block0;
                    }
                    case 't': 
                }
                string3 = "split";
                n2 = 9;
                break;
            }
            case 6: {
                switch (string2.charAt(1)) {
                    default: {
                        return 0;
                    }
                    case 'e': {
                        char c = string2.charAt(0);
                        if (c == 'r') {
                            string3 = "repeat";
                            n2 = 44;
                            break block0;
                        }
                        string3 = null;
                        n2 = 0;
                        if (c != 's') break block0;
                        string3 = "search";
                        n2 = 32;
                        break block0;
                    }
                    case 'h': {
                        string3 = "charAt";
                        n2 = 5;
                        break block0;
                    }
                    case 'n': {
                        string3 = "anchor";
                        n2 = 28;
                        break block0;
                    }
                    case 'o': {
                        string3 = "concat";
                        n2 = 14;
                        break block0;
                    }
                    case 'q': {
                        string3 = "equals";
                        n2 = 29;
                        break block0;
                    }
                    case 't': {
                        string3 = "strike";
                        n2 = 19;
                        break block0;
                    }
                    case 'u': 
                }
                string3 = "substr";
                n2 = 13;
                break;
            }
            case 7: {
                switch (string2.charAt(1)) {
                    default: {
                        return 0;
                    }
                    case 'a': {
                        string3 = "valueOf";
                        n2 = 4;
                        break block0;
                    }
                    case 'e': {
                        string3 = "replace";
                        n2 = 33;
                        break block0;
                    }
                    case 'n': {
                        string3 = "indexOf";
                        n2 = 7;
                        break block0;
                    }
                    case 't': 
                }
                string3 = "italics";
                n2 = 17;
                break;
            }
            case 8: {
                switch (string2.charAt(6)) {
                    default: {
                        return 0;
                    }
                    case 'c': {
                        string3 = "toSource";
                        n2 = 3;
                        break block0;
                    }
                    case 'e': {
                        string3 = "includes";
                        n2 = 40;
                        break block0;
                    }
                    case 'f': {
                        string3 = "trimLeft";
                        n2 = 38;
                        break block0;
                    }
                    case 'n': {
                        string3 = "toString";
                        n2 = 2;
                        break block0;
                    }
                    case 't': {
                        string3 = "endsWith";
                        n2 = 42;
                        break block0;
                    }
                    case 'z': 
                }
                string3 = "fontsize";
                n2 = 25;
                break;
            }
            case 9: {
                switch (string2.charAt(0)) {
                    default: {
                        return 0;
                    }
                    case 'f': {
                        string3 = "fontcolor";
                        n2 = 26;
                        break block0;
                    }
                    case 'n': {
                        string3 = "normalize";
                        n2 = 43;
                        break block0;
                    }
                    case 's': {
                        string3 = "substring";
                        n2 = 10;
                        break block0;
                    }
                    case 't': 
                }
                string3 = "trimRight";
                n2 = 39;
                break;
            }
            case 10: {
                char c = string2.charAt(0);
                if (c == 'c') {
                    string3 = "charCodeAt";
                    n2 = 6;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 's') break;
                string3 = "startsWith";
                n2 = 41;
                break;
            }
            case 11: {
                switch (string2.charAt(2)) {
                    default: {
                        return 0;
                    }
                    case 'L': {
                        string3 = "toLowerCase";
                        n2 = 11;
                        break block0;
                    }
                    case 'U': {
                        string3 = "toUpperCase";
                        n2 = 12;
                        break block0;
                    }
                    case 'd': {
                        string3 = "codePointAt";
                        n2 = 45;
                        break block0;
                    }
                    case 'n': {
                        string3 = "constructor";
                        n2 = 1;
                        break block0;
                    }
                    case 's': 
                }
                string3 = "lastIndexOf";
                n2 = 8;
                break;
            }
            case 13: {
                string3 = "localeCompare";
                n2 = 34;
                break;
            }
            case 16: {
                string3 = "equalsIgnoreCase";
                n2 = 30;
                break;
            }
            case 17: {
                char c = string2.charAt(8);
                if (c == 'L') {
                    string3 = "toLocaleLowerCase";
                    n2 = 35;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'U') break;
                string3 = "toLocaleUpperCase";
                n2 = 36;
                break;
            }
        }
        if (string3 == null) return n2;
        if (string3 == string2) return n2;
        if (string3.equals((Object)string2)) return n2;
        return 0;
    }

    @Override
    public Object get(int n, Scriptable scriptable) {
        if (n >= 0 && n < this.string.length()) {
            return String.valueOf((char)this.string.charAt(n));
        }
        return super.get(n, scriptable);
    }

    @Override
    public String getClassName() {
        return "String";
    }

    @Override
    protected String getInstanceIdName(int n) {
        if (n == 1) {
            return "length";
        }
        return super.getInstanceIdName(n);
    }

    @Override
    protected Object getInstanceIdValue(int n) {
        if (n == 1) {
            return ScriptRuntime.wrapInt(this.string.length());
        }
        return super.getInstanceIdValue(n);
    }

    int getLength() {
        return this.string.length();
    }

    @Override
    protected int getMaxInstanceId() {
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 1;
                string2 = "constructor";
                break;
            }
            case 2: {
                string2 = "toString";
                n2 = 0;
                break;
            }
            case 3: {
                string2 = "toSource";
                n2 = 0;
                break;
            }
            case 4: {
                string2 = "valueOf";
                n2 = 0;
                break;
            }
            case 5: {
                n2 = 1;
                string2 = "charAt";
                break;
            }
            case 6: {
                n2 = 1;
                string2 = "charCodeAt";
                break;
            }
            case 7: {
                n2 = 1;
                string2 = "indexOf";
                break;
            }
            case 8: {
                n2 = 1;
                string2 = "lastIndexOf";
                break;
            }
            case 9: {
                n2 = 2;
                string2 = "split";
                break;
            }
            case 10: {
                n2 = 2;
                string2 = "substring";
                break;
            }
            case 11: {
                string2 = "toLowerCase";
                n2 = 0;
                break;
            }
            case 12: {
                string2 = "toUpperCase";
                n2 = 0;
                break;
            }
            case 13: {
                n2 = 2;
                string2 = "substr";
                break;
            }
            case 14: {
                n2 = 1;
                string2 = "concat";
                break;
            }
            case 15: {
                n2 = 2;
                string2 = "slice";
                break;
            }
            case 16: {
                string2 = "bold";
                n2 = 0;
                break;
            }
            case 17: {
                string2 = "italics";
                n2 = 0;
                break;
            }
            case 18: {
                string2 = "fixed";
                n2 = 0;
                break;
            }
            case 19: {
                string2 = "strike";
                n2 = 0;
                break;
            }
            case 20: {
                string2 = "small";
                n2 = 0;
                break;
            }
            case 21: {
                string2 = "big";
                n2 = 0;
                break;
            }
            case 22: {
                string2 = "blink";
                n2 = 0;
                break;
            }
            case 23: {
                string2 = "sup";
                n2 = 0;
                break;
            }
            case 24: {
                string2 = "sub";
                n2 = 0;
                break;
            }
            case 25: {
                string2 = "fontsize";
                n2 = 0;
                break;
            }
            case 26: {
                string2 = "fontcolor";
                n2 = 0;
                break;
            }
            case 27: {
                string2 = "link";
                n2 = 0;
                break;
            }
            case 28: {
                string2 = "anchor";
                n2 = 0;
                break;
            }
            case 29: {
                n2 = 1;
                string2 = "equals";
                break;
            }
            case 30: {
                n2 = 1;
                string2 = "equalsIgnoreCase";
                break;
            }
            case 31: {
                n2 = 1;
                string2 = "match";
                break;
            }
            case 32: {
                n2 = 1;
                string2 = "search";
                break;
            }
            case 33: {
                n2 = 2;
                string2 = "replace";
                break;
            }
            case 34: {
                n2 = 1;
                string2 = "localeCompare";
                break;
            }
            case 35: {
                string2 = "toLocaleLowerCase";
                n2 = 0;
                break;
            }
            case 36: {
                string2 = "toLocaleUpperCase";
                n2 = 0;
                break;
            }
            case 37: {
                string2 = "trim";
                n2 = 0;
                break;
            }
            case 38: {
                string2 = "trimLeft";
                n2 = 0;
                break;
            }
            case 39: {
                string2 = "trimRight";
                n2 = 0;
                break;
            }
            case 40: {
                n2 = 1;
                string2 = "includes";
                break;
            }
            case 41: {
                n2 = 1;
                string2 = "startsWith";
                break;
            }
            case 42: {
                n2 = 1;
                string2 = "endsWith";
                break;
            }
            case 43: {
                string2 = "normalize";
                n2 = 0;
                break;
            }
            case 44: {
                n2 = 1;
                string2 = "repeat";
                break;
            }
            case 45: {
                n2 = 1;
                string2 = "codePointAt";
            }
        }
        this.initPrototypeMethod(STRING_TAG, n, string2, n2);
    }

    @Override
    public void put(int n, Scriptable scriptable, Object object) {
        if (n >= 0 && n < this.string.length()) {
            return;
        }
        super.put(n, scriptable, object);
    }

    public CharSequence toCharSequence() {
        return this.string;
    }

    public String toString() {
        if (this.string instanceof String) {
            return (String)this.string;
        }
        return this.string.toString();
    }
}

