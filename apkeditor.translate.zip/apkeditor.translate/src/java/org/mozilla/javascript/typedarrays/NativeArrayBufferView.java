/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript.typedarrays;

import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.typedarrays.NativeArrayBuffer;

public abstract class NativeArrayBufferView
extends IdScriptableObject {
    private static final int Id_buffer = 1;
    private static final int Id_byteLength = 3;
    private static final int Id_byteOffset = 2;
    private static final int MAX_INSTANCE_ID = 3;
    private static final long serialVersionUID = 6884475582973958419L;
    protected final NativeArrayBuffer arrayBuffer;
    protected final int byteLength;
    protected final int offset;

    public NativeArrayBufferView() {
        this.arrayBuffer = NativeArrayBuffer.EMPTY_BUFFER;
        this.offset = 0;
        this.byteLength = 0;
    }

    protected NativeArrayBufferView(NativeArrayBuffer nativeArrayBuffer, int n, int n2) {
        this.offset = n;
        this.byteLength = n2;
        this.arrayBuffer = nativeArrayBuffer;
    }

    protected static boolean isArg(Object[] arrobject, int n) {
        return arrobject.length > n && !Undefined.instance.equals(arrobject[n]);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findInstanceIdInfo(String string2) {
        String string3;
        int n;
        int n2 = string2.length();
        if (n2 == 6) {
            string3 = "buffer";
            n = 1;
        } else {
            string3 = null;
            n = 0;
            if (n2 == 10) {
                char c = string2.charAt(4);
                if (c == 'L') {
                    string3 = "byteLength";
                    n = 3;
                } else {
                    string3 = null;
                    n = 0;
                    if (c == 'O') {
                        string3 = "byteOffset";
                        n = 2;
                    }
                }
            }
        }
        if (string3 != null && string3 != string2 && !string3.equals((Object)string2)) {
            n = 0;
        }
        if (n == 0) {
            return super.findInstanceIdInfo(string2);
        }
        return NativeArrayBufferView.instanceIdInfo(5, n);
    }

    public NativeArrayBuffer getBuffer() {
        return this.arrayBuffer;
    }

    public int getByteLength() {
        return this.byteLength;
    }

    public int getByteOffset() {
        return this.offset;
    }

    @Override
    protected String getInstanceIdName(int n) {
        switch (n) {
            default: {
                return super.getInstanceIdName(n);
            }
            case 1: {
                return "buffer";
            }
            case 2: {
                return "byteOffset";
            }
            case 3: 
        }
        return "byteLength";
    }

    @Override
    protected Object getInstanceIdValue(int n) {
        switch (n) {
            default: {
                return super.getInstanceIdValue(n);
            }
            case 1: {
                return this.arrayBuffer;
            }
            case 2: {
                return ScriptRuntime.wrapInt(this.offset);
            }
            case 3: 
        }
        return ScriptRuntime.wrapInt(this.byteLength);
    }

    @Override
    protected int getMaxInstanceId() {
        return 3;
    }
}

