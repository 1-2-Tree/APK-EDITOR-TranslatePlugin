/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.ArrayStoreException
 *  java.lang.Class
 *  java.lang.ClassCastException
 *  java.lang.IllegalArgumentException
 *  java.lang.IndexOutOfBoundsException
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.UnsupportedOperationException
 *  java.lang.reflect.Array
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.ListIterator
 *  java.util.RandomAccess
 */
package org.mozilla.javascript.typedarrays;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ExternalArrayData;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.typedarrays.NativeArrayBuffer;
import org.mozilla.javascript.typedarrays.NativeArrayBufferView;
import org.mozilla.javascript.typedarrays.NativeTypedArrayIterator;

public abstract class NativeTypedArrayView<T>
extends NativeArrayBufferView
implements List<T>,
RandomAccess,
ExternalArrayData {
    private static final int Id_BYTES_PER_ELEMENT = 11;
    private static final int Id_constructor = 1;
    private static final int Id_get = 2;
    private static final int Id_length = 10;
    private static final int Id_set = 3;
    private static final int Id_subarray = 4;
    private static final int MAX_INSTANCE_ID = 11;
    protected static final int MAX_PROTOTYPE_ID = 4;
    protected final int length;

    protected NativeTypedArrayView() {
        this.length = 0;
    }

    protected NativeTypedArrayView(NativeArrayBuffer nativeArrayBuffer, int n, int n2, int n3) {
        super(nativeArrayBuffer, n, n3);
        this.length = n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private NativeTypedArrayView js_constructor(Context context, Scriptable scriptable, Object[] arrobject) {
        NativeTypedArrayView nativeTypedArrayView;
        if (!NativeTypedArrayView.isArg(arrobject, 0)) {
            return this.construct(NativeArrayBuffer.EMPTY_BUFFER, 0, 0);
        }
        if (arrobject[0] instanceof Number || arrobject[0] instanceof String) {
            int n = ScriptRuntime.toInt32(arrobject[0]);
            return this.construct(this.makeArrayBuffer(context, scriptable, n * this.getBytesPerElement()), 0, n);
        }
        if (arrobject[0] instanceof NativeTypedArrayView) {
            NativeTypedArrayView nativeTypedArrayView2 = (NativeTypedArrayView)arrobject[0];
            nativeTypedArrayView = this.construct(this.makeArrayBuffer(context, scriptable, nativeTypedArrayView2.length * this.getBytesPerElement()), 0, nativeTypedArrayView2.length);
            int n = 0;
            while (n < nativeTypedArrayView2.length) {
                nativeTypedArrayView.js_set(n, nativeTypedArrayView2.js_get(n));
                ++n;
            }
            return nativeTypedArrayView;
        }
        if (arrobject[0] instanceof NativeArrayBuffer) {
            NativeArrayBuffer nativeArrayBuffer = (NativeArrayBuffer)arrobject[0];
            int n = NativeTypedArrayView.isArg(arrobject, 1) ? ScriptRuntime.toInt32(arrobject[1]) : 0;
            int n2 = NativeTypedArrayView.isArg(arrobject, 2) ? ScriptRuntime.toInt32(arrobject[2]) * this.getBytesPerElement() : nativeArrayBuffer.getLength() - n;
            if (n < 0) throw ScriptRuntime.constructError("RangeError", "offset out of range");
            if (n > nativeArrayBuffer.buffer.length) {
                throw ScriptRuntime.constructError("RangeError", "offset out of range");
            }
            if (n2 < 0) throw ScriptRuntime.constructError("RangeError", "length out of range");
            if (n + n2 > nativeArrayBuffer.buffer.length) {
                throw ScriptRuntime.constructError("RangeError", "length out of range");
            }
            if (n % this.getBytesPerElement() != 0) {
                throw ScriptRuntime.constructError("RangeError", "offset must be a multiple of the byte size");
            }
            if (n2 % this.getBytesPerElement() == 0) return this.construct(nativeArrayBuffer, n, n2 / this.getBytesPerElement());
            throw ScriptRuntime.constructError("RangeError", "offset and buffer must be a multiple of the byte size");
        }
        if (!(arrobject[0] instanceof NativeArray)) {
            throw ScriptRuntime.constructError("Error", "invalid argument");
        }
        List list = (List)arrobject[0];
        nativeTypedArrayView = this.construct(this.makeArrayBuffer(context, scriptable, list.size() * this.getBytesPerElement()), 0, list.size());
        int n = 0;
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            nativeTypedArrayView.js_set(n, iterator.next());
            ++n;
        }
        return nativeTypedArrayView;
    }

    /*
     * Enabled aggressive block sorting
     */
    private Object js_subarray(Context context, Scriptable scriptable, int n, int n2) {
        int n3 = n < 0 ? n + this.length : n;
        int n4 = n2 < 0 ? n2 + this.length : n2;
        int n5 = Math.max((int)0, (int)n3);
        int n6 = Math.max((int)0, (int)(Math.min((int)this.length, (int)n4) - n5));
        int n7 = Math.min((int)(n5 * this.getBytesPerElement()), (int)this.arrayBuffer.getLength());
        String string2 = this.getClassName();
        Object[] arrobject = new Object[]{this.arrayBuffer, n7, n6};
        return context.newObject(scriptable, string2, arrobject);
    }

    private NativeArrayBuffer makeArrayBuffer(Context context, Scriptable scriptable, int n) {
        Object[] arrobject = new Object[]{n};
        return (NativeArrayBuffer)context.newObject(scriptable, "ArrayBuffer", arrobject);
    }

    private void setRange(NativeArray nativeArray, int n) {
        if (n > this.length) {
            throw ScriptRuntime.constructError("RangeError", "offset out of range");
        }
        if (n + nativeArray.size() > this.length) {
            throw ScriptRuntime.constructError("RangeError", "offset + length out of range");
        }
        int n2 = n;
        Iterator iterator = nativeArray.iterator();
        while (iterator.hasNext()) {
            this.js_set(n2, iterator.next());
            ++n2;
        }
    }

    private void setRange(NativeTypedArrayView nativeTypedArrayView, int n) {
        if (n >= this.length) {
            throw ScriptRuntime.constructError("RangeError", "offset out of range");
        }
        if (nativeTypedArrayView.length > this.length - n) {
            throw ScriptRuntime.constructError("RangeError", "source array too long");
        }
        if (nativeTypedArrayView.arrayBuffer == this.arrayBuffer) {
            Object[] arrobject = new Object[nativeTypedArrayView.length];
            for (int i = 0; i < nativeTypedArrayView.length; ++i) {
                arrobject[i] = nativeTypedArrayView.js_get(i);
            }
            for (int i = 0; i < nativeTypedArrayView.length; ++i) {
                this.js_set(i + n, arrobject[i]);
            }
        } else {
            for (int i = 0; i < nativeTypedArrayView.length; ++i) {
                this.js_set(i + n, nativeTypedArrayView.js_get(i));
            }
        }
    }

    public void add(int n, T t) {
        throw new UnsupportedOperationException();
    }

    public boolean add(T t) {
        throw new UnsupportedOperationException();
    }

    public boolean addAll(int n, Collection<? extends T> collection) {
        throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection<? extends T> collection) {
        throw new UnsupportedOperationException();
    }

    protected boolean checkIndex(int n) {
        return n < 0 || n >= this.length;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    protected abstract NativeTypedArrayView construct(NativeArrayBuffer var1, int var2, int var3);

    public boolean contains(Object object) {
        return this.indexOf(object) >= 0;
    }

    public boolean containsAll(Collection<?> collection) {
        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            if (this.contains(iterator.next())) continue;
            return false;
        }
        return true;
    }

    @Override
    public void delete(int n) {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean equals(Object object) {
        NativeTypedArrayView nativeTypedArrayView;
        try {
            nativeTypedArrayView = (NativeTypedArrayView)object;
            if (this.length != nativeTypedArrayView.length) {
                return false;
            }
        }
        catch (ClassCastException classCastException) {
            // empty catch block
            return false;
        }
        for (int i = 0; i < this.length; ++i) {
            boolean bl = this.js_get(i).equals(nativeTypedArrayView.js_get(i));
            if (!bl) return false;
            {
                continue;
            }
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        int n;
        if (!idFunctionObject.hasTag(this.getClassName())) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n2 = idFunctionObject.methodId();
        switch (n2) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n2));
            }
            case 1: {
                return this.js_constructor(context, scriptable, arrobject);
            }
            case 2: {
                if (arrobject.length <= 0) throw ScriptRuntime.constructError("Error", "invalid arguments");
                return this.realThis(scriptable2, idFunctionObject).js_get(ScriptRuntime.toInt32(arrobject[0]));
            }
            case 3: {
                if (arrobject.length <= 0) throw ScriptRuntime.constructError("Error", "invalid arguments");
                NativeTypedArrayView nativeTypedArrayView = this.realThis(scriptable2, idFunctionObject);
                if (arrobject[0] instanceof NativeTypedArrayView) {
                    int n3 = NativeTypedArrayView.isArg(arrobject, 1) ? ScriptRuntime.toInt32(arrobject[1]) : 0;
                    nativeTypedArrayView.setRange((NativeTypedArrayView)arrobject[0], n3);
                    return Undefined.instance;
                }
                if (arrobject[0] instanceof NativeArray) {
                    int n4 = NativeTypedArrayView.isArg(arrobject, 1) ? ScriptRuntime.toInt32(arrobject[1]) : 0;
                    nativeTypedArrayView.setRange((NativeArray)arrobject[0], n4);
                    return Undefined.instance;
                }
                if (arrobject[0] instanceof Scriptable) {
                    return Undefined.instance;
                }
                if (!NativeTypedArrayView.isArg(arrobject, 2)) throw ScriptRuntime.constructError("Error", "invalid arguments");
                return nativeTypedArrayView.js_set(ScriptRuntime.toInt32(arrobject[0]), arrobject[1]);
            }
            case 4: 
        }
        if (arrobject.length <= 0) throw ScriptRuntime.constructError("Error", "invalid arguments");
        NativeTypedArrayView nativeTypedArrayView = this.realThis(scriptable2, idFunctionObject);
        int n5 = ScriptRuntime.toInt32(arrobject[0]);
        if (NativeTypedArrayView.isArg(arrobject, 1)) {
            n = ScriptRuntime.toInt32(arrobject[1]);
            return nativeTypedArrayView.js_subarray(context, scriptable, n5, n);
        }
        n = nativeTypedArrayView.length;
        return nativeTypedArrayView.js_subarray(context, scriptable, n5, n);
    }

    @Override
    protected void fillConstructorProperties(IdFunctionObject idFunctionObject) {
        idFunctionObject.put("BYTES_PER_ELEMENT", idFunctionObject, (Object)ScriptRuntime.wrapInt(this.getBytesPerElement()));
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findInstanceIdInfo(String string2) {
        String string3;
        int n;
        int n2 = string2.length();
        if (n2 == 6) {
            string3 = "length";
            n = 10;
        } else {
            string3 = null;
            n = 0;
            if (n2 == 17) {
                string3 = "BYTES_PER_ELEMENT";
                n = 11;
            }
        }
        if (string3 != null && string3 != string2 && !string3.equals((Object)string2)) {
            n = 0;
        }
        if (n == 0) {
            return super.findInstanceIdInfo(string2);
        }
        return NativeTypedArrayView.instanceIdInfo(5, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n;
        String string3;
        int n2 = string2.length();
        if (n2 == 3) {
            char c = string2.charAt(0);
            if (c == 'g') {
                char c2 = string2.charAt(2);
                string3 = null;
                n = 0;
                if (c2 == 't') {
                    char c3 = string2.charAt(1);
                    string3 = null;
                    n = 0;
                    if (c3 == 'e') {
                        return 2;
                    }
                }
            } else {
                string3 = null;
                n = 0;
                if (c == 's') {
                    char c4 = string2.charAt(2);
                    string3 = null;
                    n = 0;
                    if (c4 == 't') {
                        char c5 = string2.charAt(1);
                        string3 = null;
                        n = 0;
                        if (c5 == 'e') {
                            return 3;
                        }
                    }
                }
            }
        } else if (n2 == 8) {
            string3 = "subarray";
            n = 4;
        } else {
            string3 = null;
            n = 0;
            if (n2 == 11) {
                string3 = "constructor";
                n = 1;
            }
        }
        if (string3 == null) return n;
        if (string3 == string2) return n;
        if (string3.equals((Object)string2)) return n;
        return 0;
    }

    @Override
    public Object get(int n, Scriptable scriptable) {
        return this.js_get(n);
    }

    @Override
    public Object getArrayElement(int n) {
        return this.js_get(n);
    }

    @Override
    public int getArrayLength() {
        return this.length;
    }

    public abstract int getBytesPerElement();

    @Override
    public Object[] getIds() {
        Object[] arrobject = new Object[this.length];
        for (int i = 0; i < this.length; ++i) {
            arrobject[i] = i;
        }
        return arrobject;
    }

    @Override
    protected String getInstanceIdName(int n) {
        switch (n) {
            default: {
                return super.getInstanceIdName(n);
            }
            case 10: {
                return "length";
            }
            case 11: 
        }
        return "BYTES_PER_ELEMENT";
    }

    @Override
    protected Object getInstanceIdValue(int n) {
        switch (n) {
            default: {
                return super.getInstanceIdValue(n);
            }
            case 10: {
                return ScriptRuntime.wrapInt(this.length);
            }
            case 11: 
        }
        return ScriptRuntime.wrapInt(this.getBytesPerElement());
    }

    @Override
    protected int getMaxInstanceId() {
        return 11;
    }

    @Override
    public boolean has(int n, Scriptable scriptable) {
        return n > 0 && n < this.length;
    }

    public int hashCode() {
        int n = 0;
        for (int i = 0; i < this.length; ++i) {
            n += this.js_get(i).hashCode();
        }
        return 0;
    }

    public int indexOf(Object object) {
        for (int i = 0; i < this.length; ++i) {
            if (!object.equals(this.js_get(i))) continue;
            return i;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 1;
                string2 = "constructor";
                break;
            }
            case 2: {
                n2 = 1;
                string2 = "get";
                break;
            }
            case 3: {
                n2 = 2;
                string2 = "set";
                break;
            }
            case 4: {
                n2 = 2;
                string2 = "subarray";
            }
        }
        this.initPrototypeMethod(this.getClassName(), n, string2, n2);
    }

    @Override
    public boolean isEmpty() {
        return this.length == 0;
    }

    public Iterator<T> iterator() {
        return new NativeTypedArrayIterator<T>(this, 0);
    }

    protected abstract Object js_get(int var1);

    protected abstract Object js_set(int var1, Object var2);

    public int lastIndexOf(Object object) {
        for (int i = -1 + this.length; i >= 0; --i) {
            if (!object.equals(this.js_get(i))) continue;
            return i;
        }
        return -1;
    }

    public ListIterator<T> listIterator() {
        return new NativeTypedArrayIterator<T>(this, 0);
    }

    public ListIterator<T> listIterator(int n) {
        if (this.checkIndex(n)) {
            throw new IndexOutOfBoundsException();
        }
        return new NativeTypedArrayIterator<T>(this, n);
    }

    @Override
    public void put(int n, Scriptable scriptable, Object object) {
        this.js_set(n, object);
    }

    protected abstract NativeTypedArrayView realThis(Scriptable var1, IdFunctionObject var2);

    public T remove(int n) {
        throw new UnsupportedOperationException();
    }

    public boolean remove(Object object) {
        throw new UnsupportedOperationException();
    }

    public boolean removeAll(Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    public boolean retainAll(Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void setArrayElement(int n, Object object) {
        this.js_set(n, object);
    }

    @Override
    public int size() {
        return this.length;
    }

    public List<T> subList(int n, int n2) {
        throw new UnsupportedOperationException();
    }

    public Object[] toArray() {
        Object[] arrobject = new Object[this.length];
        for (int i = 0; i < this.length; ++i) {
            arrobject[i] = this.js_get(i);
        }
        return arrobject;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public <U> U[] toArray(U[] arrU) {
        if (arrU.length >= this.length) {
            U[] arrU2 = arrU;
        } else {
            Object[] arrobject = (Object[])Array.newInstance((Class)arrU.getClass().getComponentType(), (int)this.length);
        }
        int n = 0;
        void var2_3;
        while (n < this.length) {
            try {
                var2_3[n] = this.js_get(n);
                ++n;
            }
            catch (ClassCastException classCastException) {
                throw new ArrayStoreException();
            }
        }
        return var2_3;
    }
}

