/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript.typedarrays;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.typedarrays.ByteIo;
import org.mozilla.javascript.typedarrays.Conversions;
import org.mozilla.javascript.typedarrays.NativeArrayBuffer;
import org.mozilla.javascript.typedarrays.NativeArrayBufferView;

public class NativeDataView
extends NativeArrayBufferView {
    public static final String CLASS_NAME = "DataView";
    private static final int Id_constructor = 1;
    private static final int Id_getFloat32 = 8;
    private static final int Id_getFloat64 = 9;
    private static final int Id_getInt16 = 4;
    private static final int Id_getInt32 = 6;
    private static final int Id_getInt8 = 2;
    private static final int Id_getUint16 = 5;
    private static final int Id_getUint32 = 7;
    private static final int Id_getUint8 = 3;
    private static final int Id_setFloat32 = 16;
    private static final int Id_setFloat64 = 17;
    private static final int Id_setInt16 = 12;
    private static final int Id_setInt32 = 14;
    private static final int Id_setInt8 = 10;
    private static final int Id_setUint16 = 13;
    private static final int Id_setUint32 = 15;
    private static final int Id_setUint8 = 11;
    private static final int MAX_PROTOTYPE_ID = 17;
    private static final long serialVersionUID = 1427967607557438968L;

    public NativeDataView() {
    }

    public NativeDataView(NativeArrayBuffer nativeArrayBuffer, int n, int n2) {
        super(nativeArrayBuffer, n, n2);
    }

    private void checkOffset(Object[] arrobject, int n) {
        if (arrobject.length <= n) {
            throw ScriptRuntime.constructError("TypeError", "missing required offset parameter");
        }
        if (Undefined.instance.equals(arrobject[n])) {
            throw ScriptRuntime.constructError("RangeError", "invalid offset");
        }
    }

    private void checkValue(Object[] arrobject, int n) {
        if (arrobject.length <= n) {
            throw ScriptRuntime.constructError("TypeError", "missing required value parameter");
        }
        if (Undefined.instance.equals(arrobject[n])) {
            throw ScriptRuntime.constructError("RangeError", "invalid value parameter");
        }
    }

    public static void init(Context context, Scriptable scriptable, boolean bl) {
        new NativeDataView().exportAsJSClass(17, scriptable, bl);
    }

    private NativeDataView js_constructor(NativeArrayBuffer nativeArrayBuffer, int n, int n2) {
        if (n2 < 0) {
            throw ScriptRuntime.constructError("RangeError", "length out of range");
        }
        if (n < 0 || n + n2 > nativeArrayBuffer.getLength()) {
            throw ScriptRuntime.constructError("RangeError", "offset out of range");
        }
        return new NativeDataView(nativeArrayBuffer, n, n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Object js_getFloat(int n, Object[] arrobject) {
        int n2 = 1;
        this.checkOffset(arrobject, 0);
        int n3 = ScriptRuntime.toInt32(arrobject[0]);
        this.rangeCheck(n3, n);
        if (!NativeDataView.isArg(arrobject, n2) || n <= n2 || !ScriptRuntime.toBoolean(arrobject[n2])) {
            n2 = 0;
        }
        switch (n) {
            default: {
                throw new AssertionError();
            }
            case 4: {
                return ByteIo.readFloat32(this.arrayBuffer.buffer, n3, (boolean)n2);
            }
            case 8: 
        }
        return ByteIo.readFloat64(this.arrayBuffer.buffer, n3, (boolean)n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Object js_getInt(int n, boolean bl, Object[] arrobject) {
        int n2 = 1;
        this.checkOffset(arrobject, 0);
        int n3 = ScriptRuntime.toInt32(arrobject[0]);
        this.rangeCheck(n3, n);
        if (!NativeDataView.isArg(arrobject, n2) || n <= n2 || !ScriptRuntime.toBoolean(arrobject[n2])) {
            n2 = 0;
        }
        switch (n) {
            default: {
                throw new AssertionError();
            }
            case 1: {
                if (bl) {
                    return ByteIo.readInt8(this.arrayBuffer.buffer, n3);
                }
                return ByteIo.readUint8(this.arrayBuffer.buffer, n3);
            }
            case 2: {
                if (bl) {
                    return ByteIo.readInt16(this.arrayBuffer.buffer, n3, (boolean)n2);
                }
                return ByteIo.readUint16(this.arrayBuffer.buffer, n3, (boolean)n2);
            }
            case 4: 
        }
        if (bl) {
            return ByteIo.readInt32(this.arrayBuffer.buffer, n3, (boolean)n2);
        }
        return ByteIo.readUint32(this.arrayBuffer.buffer, n3, (boolean)n2);
    }

    private void js_setFloat(int n, Object[] arrobject) {
        this.checkOffset(arrobject, 0);
        this.checkValue(arrobject, 1);
        int n2 = ScriptRuntime.toInt32(arrobject[0]);
        this.rangeCheck(n2, n);
        boolean bl = NativeDataView.isArg(arrobject, 2);
        boolean bl2 = false;
        if (bl) {
            bl2 = false;
            if (n > 1) {
                boolean bl3 = ScriptRuntime.toBoolean(arrobject[2]);
                bl2 = false;
                if (bl3) {
                    bl2 = true;
                }
            }
        }
        double d = ScriptRuntime.toNumber(arrobject[1]);
        switch (n) {
            default: {
                throw new AssertionError();
            }
            case 4: {
                ByteIo.writeFloat32(this.arrayBuffer.buffer, n2, d, bl2);
                return;
            }
            case 8: 
        }
        ByteIo.writeFloat64(this.arrayBuffer.buffer, n2, d, bl2);
    }

    private void js_setInt(int n, boolean bl, Object[] arrobject) {
        this.checkOffset(arrobject, 0);
        this.checkValue(arrobject, 1);
        int n2 = ScriptRuntime.toInt32(arrobject[0]);
        this.rangeCheck(n2, n);
        boolean bl2 = NativeDataView.isArg(arrobject, 2);
        boolean bl3 = false;
        if (bl2) {
            bl3 = false;
            if (n > 1) {
                boolean bl4 = ScriptRuntime.toBoolean(arrobject[2]);
                bl3 = false;
                if (bl4) {
                    bl3 = true;
                }
            }
        }
        switch (n) {
            default: {
                throw new AssertionError();
            }
            case 1: {
                if (bl) {
                    ByteIo.writeInt8(this.arrayBuffer.buffer, n2, Conversions.toInt8(arrobject[1]));
                    return;
                }
                ByteIo.writeUint8(this.arrayBuffer.buffer, n2, Conversions.toUint8(arrobject[1]));
                return;
            }
            case 2: {
                if (bl) {
                    ByteIo.writeInt16(this.arrayBuffer.buffer, n2, Conversions.toInt16(arrobject[1]), bl3);
                    return;
                }
                ByteIo.writeUint16(this.arrayBuffer.buffer, n2, Conversions.toUint16(arrobject[1]), bl3);
                return;
            }
            case 4: 
        }
        if (bl) {
            ByteIo.writeInt32(this.arrayBuffer.buffer, n2, Conversions.toInt32(arrobject[1]), bl3);
            return;
        }
        ByteIo.writeUint32(this.arrayBuffer.buffer, n2, Conversions.toUint32(arrobject[1]), bl3);
    }

    private void rangeCheck(int n, int n2) {
        if (n < 0 || n + n2 > this.byteLength) {
            throw ScriptRuntime.constructError("RangeError", "offset out of range");
        }
    }

    private static NativeDataView realThis(Scriptable scriptable, IdFunctionObject idFunctionObject) {
        if (!(scriptable instanceof NativeDataView)) {
            throw NativeDataView.incompatibleCallError(idFunctionObject);
        }
        return (NativeDataView)scriptable;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(this.getClassName())) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                int n2;
                if (!NativeDataView.isArg(arrobject, 0) || !(arrobject[0] instanceof NativeArrayBuffer)) throw ScriptRuntime.constructError("TypeError", "Missing parameters");
                NativeArrayBuffer nativeArrayBuffer = (NativeArrayBuffer)arrobject[0];
                boolean bl = NativeDataView.isArg(arrobject, 1);
                int n3 = 0;
                if (bl) {
                    n3 = ScriptRuntime.toInt32(arrobject[1]);
                }
                if (NativeDataView.isArg(arrobject, 2)) {
                    n2 = ScriptRuntime.toInt32(arrobject[2]);
                    do {
                        return this.js_constructor(nativeArrayBuffer, n3, n2);
                        break;
                    } while (true);
                }
                n2 = nativeArrayBuffer.getLength() - n3;
                return this.js_constructor(nativeArrayBuffer, n3, n2);
            }
            case 2: {
                return NativeDataView.realThis(scriptable2, idFunctionObject).js_getInt(1, true, arrobject);
            }
            case 3: {
                return NativeDataView.realThis(scriptable2, idFunctionObject).js_getInt(1, false, arrobject);
            }
            case 4: {
                return NativeDataView.realThis(scriptable2, idFunctionObject).js_getInt(2, true, arrobject);
            }
            case 5: {
                return NativeDataView.realThis(scriptable2, idFunctionObject).js_getInt(2, false, arrobject);
            }
            case 6: {
                return NativeDataView.realThis(scriptable2, idFunctionObject).js_getInt(4, true, arrobject);
            }
            case 7: {
                return NativeDataView.realThis(scriptable2, idFunctionObject).js_getInt(4, false, arrobject);
            }
            case 8: {
                return NativeDataView.realThis(scriptable2, idFunctionObject).js_getFloat(4, arrobject);
            }
            case 9: {
                return NativeDataView.realThis(scriptable2, idFunctionObject).js_getFloat(8, arrobject);
            }
            case 10: {
                NativeDataView.realThis(scriptable2, idFunctionObject).js_setInt(1, true, arrobject);
                return Undefined.instance;
            }
            case 11: {
                NativeDataView.realThis(scriptable2, idFunctionObject).js_setInt(1, false, arrobject);
                return Undefined.instance;
            }
            case 12: {
                NativeDataView.realThis(scriptable2, idFunctionObject).js_setInt(2, true, arrobject);
                return Undefined.instance;
            }
            case 13: {
                NativeDataView.realThis(scriptable2, idFunctionObject).js_setInt(2, false, arrobject);
                return Undefined.instance;
            }
            case 14: {
                NativeDataView.realThis(scriptable2, idFunctionObject).js_setInt(4, true, arrobject);
                return Undefined.instance;
            }
            case 15: {
                NativeDataView.realThis(scriptable2, idFunctionObject).js_setInt(4, false, arrobject);
                return Undefined.instance;
            }
            case 16: {
                NativeDataView.realThis(scriptable2, idFunctionObject).js_setFloat(4, arrobject);
                return Undefined.instance;
            }
            case 17: 
        }
        NativeDataView.realThis(scriptable2, idFunctionObject).js_setFloat(8, arrobject);
        return Undefined.instance;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        switch (n) {
            case 7: {
                char c = string2.charAt(0);
                if (c == 'g') {
                    string3 = "getInt8";
                    n2 = 2;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 's') break;
                string3 = "setInt8";
                n2 = 10;
                break;
            }
            case 8: {
                char c = string2.charAt(6);
                if (c == '1') {
                    char c2 = string2.charAt(0);
                    if (c2 == 'g') {
                        string3 = "getInt16";
                        n2 = 4;
                        break;
                    }
                    string3 = null;
                    n2 = 0;
                    if (c2 != 's') break;
                    string3 = "setInt16";
                    n2 = 12;
                    break;
                }
                if (c == '3') {
                    char c3 = string2.charAt(0);
                    if (c3 == 'g') {
                        string3 = "getInt32";
                        n2 = 6;
                        break;
                    }
                    string3 = null;
                    n2 = 0;
                    if (c3 != 's') break;
                    string3 = "setInt32";
                    n2 = 14;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                char c4 = string2.charAt(0);
                if (c4 == 'g') {
                    string3 = "getUint8";
                    n2 = 3;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c4 != 's') break;
                string3 = "setUint8";
                n2 = 11;
                break;
            }
            case 9: {
                char c = string2.charAt(0);
                if (c == 'g') {
                    char c5 = string2.charAt(8);
                    if (c5 == '2') {
                        string3 = "getUint32";
                        n2 = 7;
                        break;
                    }
                    string3 = null;
                    n2 = 0;
                    if (c5 != '6') break;
                    string3 = "getUint16";
                    n2 = 5;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 's') break;
                char c6 = string2.charAt(8);
                if (c6 == '2') {
                    string3 = "setUint32";
                    n2 = 15;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c6 != '6') break;
                string3 = "setUint16";
                n2 = 13;
                break;
            }
            case 10: {
                char c = string2.charAt(0);
                if (c == 'g') {
                    char c7 = string2.charAt(9);
                    if (c7 == '2') {
                        string3 = "getFloat32";
                        n2 = 8;
                        break;
                    }
                    string3 = null;
                    n2 = 0;
                    if (c7 != '4') break;
                    string3 = "getFloat64";
                    n2 = 9;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 's') break;
                char c8 = string2.charAt(9);
                if (c8 == '2') {
                    string3 = "setFloat32";
                    n2 = 16;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c8 != '4') break;
                string3 = "setFloat64";
                n2 = 17;
                break;
            }
            case 11: {
                string3 = "constructor";
                n2 = 1;
                break;
            }
        }
        if (string3 == null) return n2;
        if (string3 == string2) return n2;
        if (string3.equals((Object)string2)) return n2;
        return 0;
    }

    @Override
    public String getClassName() {
        return CLASS_NAME;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 1;
                string2 = "constructor";
                break;
            }
            case 2: {
                n2 = 1;
                string2 = "getInt8";
                break;
            }
            case 3: {
                n2 = 1;
                string2 = "getUint8";
                break;
            }
            case 4: {
                n2 = 1;
                string2 = "getInt16";
                break;
            }
            case 5: {
                n2 = 1;
                string2 = "getUint16";
                break;
            }
            case 6: {
                n2 = 1;
                string2 = "getInt32";
                break;
            }
            case 7: {
                n2 = 1;
                string2 = "getUint32";
                break;
            }
            case 8: {
                n2 = 1;
                string2 = "getFloat32";
                break;
            }
            case 9: {
                n2 = 1;
                string2 = "getFloat64";
                break;
            }
            case 10: {
                n2 = 2;
                string2 = "setInt8";
                break;
            }
            case 11: {
                n2 = 2;
                string2 = "setUint8";
                break;
            }
            case 12: {
                n2 = 2;
                string2 = "setInt16";
                break;
            }
            case 13: {
                n2 = 2;
                string2 = "setUint16";
                break;
            }
            case 14: {
                n2 = 2;
                string2 = "setInt32";
                break;
            }
            case 15: {
                n2 = 2;
                string2 = "setUint32";
                break;
            }
            case 16: {
                n2 = 2;
                string2 = "setFloat32";
                break;
            }
            case 17: {
                n2 = 2;
                string2 = "setFloat64";
            }
        }
        this.initPrototypeMethod(this.getClassName(), n, string2, n2);
    }
}

