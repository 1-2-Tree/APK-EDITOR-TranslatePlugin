/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package org.mozilla.javascript.typedarrays;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.typedarrays.NativeArrayBufferView;

public class NativeArrayBuffer
extends IdScriptableObject {
    public static final String CLASS_NAME = "ArrayBuffer";
    private static final int ConstructorId_isView = -3;
    private static final byte[] EMPTY_BUF = new byte[0];
    public static final NativeArrayBuffer EMPTY_BUFFER = new NativeArrayBuffer();
    private static final int Id_byteLength = 1;
    private static final int Id_constructor = 1;
    private static final int Id_isView = 3;
    private static final int Id_slice = 2;
    private static final int MAX_INSTANCE_ID = 1;
    private static final int MAX_PROTOTYPE_ID = 3;
    private static final long serialVersionUID = 3110411773054879549L;
    final byte[] buffer;

    public NativeArrayBuffer() {
        this.buffer = EMPTY_BUF;
    }

    public NativeArrayBuffer(int n) {
        if (n < 0) {
            throw ScriptRuntime.constructError("RangeError", "Negative array length " + n);
        }
        if (n == 0) {
            this.buffer = EMPTY_BUF;
            return;
        }
        this.buffer = new byte[n];
    }

    public static void init(Context context, Scriptable scriptable, boolean bl) {
        new NativeArrayBuffer().exportAsJSClass(3, scriptable, bl);
    }

    private static boolean isArg(Object[] arrobject, int n) {
        return arrobject.length > n && !Undefined.instance.equals(arrobject[n]);
    }

    private static NativeArrayBuffer realThis(Scriptable scriptable, IdFunctionObject idFunctionObject) {
        if (!(scriptable instanceof NativeArrayBuffer)) {
            throw NativeArrayBuffer.incompatibleCallError(idFunctionObject);
        }
        return (NativeArrayBuffer)scriptable;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        int n;
        int n2 = 1;
        if (!idFunctionObject.hasTag(CLASS_NAME)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n3 = idFunctionObject.methodId();
        switch (n3) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n3));
            }
            case -3: {
                if (NativeArrayBuffer.isArg(arrobject, 0) && arrobject[0] instanceof NativeArrayBufferView) {
                    return (boolean)n2;
                }
                n2 = 0;
                return (boolean)n2;
            }
            case 1: {
                int n4;
                if (NativeArrayBuffer.isArg(arrobject, 0)) {
                    n4 = ScriptRuntime.toInt32(arrobject[0]);
                    return new NativeArrayBuffer(n4);
                }
                n4 = 0;
                return new NativeArrayBuffer(n4);
            }
            case 2: 
        }
        NativeArrayBuffer nativeArrayBuffer = NativeArrayBuffer.realThis(scriptable2, idFunctionObject);
        int n5 = NativeArrayBuffer.isArg(arrobject, 0) ? ScriptRuntime.toInt32(arrobject[0]) : 0;
        if (NativeArrayBuffer.isArg(arrobject, n2)) {
            n = ScriptRuntime.toInt32(arrobject[n2]);
            return nativeArrayBuffer.slice(n5, n);
        }
        n = nativeArrayBuffer.buffer.length;
        return nativeArrayBuffer.slice(n5, n);
    }

    @Override
    protected void fillConstructorProperties(IdFunctionObject idFunctionObject) {
        this.addIdFunctionProperty(idFunctionObject, CLASS_NAME, -3, "isView", 1);
    }

    @Override
    protected int findInstanceIdInfo(String string2) {
        if ("byteLength".equals((Object)string2)) {
            return NativeArrayBuffer.instanceIdInfo(5, 1);
        }
        return super.findInstanceIdInfo(string2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        String string3;
        int n;
        int n2 = string2.length();
        if (n2 == 5) {
            string3 = "slice";
            n = 2;
        } else if (n2 == 6) {
            string3 = "isView";
            n = 3;
        } else {
            string3 = null;
            n = 0;
            if (n2 == 11) {
                string3 = "constructor";
                n = 1;
            }
        }
        if (string3 == null) return n;
        if (string3 == string2) return n;
        if (string3.equals((Object)string2)) return n;
        return 0;
    }

    public byte[] getBuffer() {
        return this.buffer;
    }

    @Override
    public String getClassName() {
        return CLASS_NAME;
    }

    @Override
    protected String getInstanceIdName(int n) {
        if (n == 1) {
            return "byteLength";
        }
        return super.getInstanceIdName(n);
    }

    @Override
    protected Object getInstanceIdValue(int n) {
        if (n == 1) {
            return ScriptRuntime.wrapInt(this.buffer.length);
        }
        return super.getInstanceIdValue(n);
    }

    public int getLength() {
        return this.buffer.length;
    }

    @Override
    protected int getMaxInstanceId() {
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 1;
                string2 = "constructor";
                break;
            }
            case 2: {
                n2 = 1;
                string2 = "slice";
            }
        }
        this.initPrototypeMethod(CLASS_NAME, n, string2, n2);
    }

    public NativeArrayBuffer slice(int n, int n2) {
        int n3 = this.buffer.length;
        if (n2 < 0) {
            n2 += this.buffer.length;
        }
        int n4 = Math.max((int)0, (int)Math.min((int)n3, (int)n2));
        if (n < 0) {
            n += this.buffer.length;
        }
        int n5 = Math.min((int)n4, (int)Math.max((int)0, (int)n));
        int n6 = n4 - n5;
        NativeArrayBuffer nativeArrayBuffer = new NativeArrayBuffer(n6);
        System.arraycopy((Object)this.buffer, (int)n5, (Object)nativeArrayBuffer.buffer, (int)0, (int)n6);
        return nativeArrayBuffer;
    }
}

