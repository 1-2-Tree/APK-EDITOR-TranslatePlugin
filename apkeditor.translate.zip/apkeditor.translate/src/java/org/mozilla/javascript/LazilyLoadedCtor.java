/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalStateException
 *  java.lang.InstantiationException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationTargetException
 *  java.security.AccessController
 *  java.security.PrivilegedAction
 */
package org.mozilla.javascript;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.security.AccessController;
import java.security.PrivilegedAction;
import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.RhinoException;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

public final class LazilyLoadedCtor
implements Serializable {
    private static final int STATE_BEFORE_INIT = 0;
    private static final int STATE_INITIALIZING = 1;
    private static final int STATE_WITH_VALUE = 2;
    private static final long serialVersionUID = 1L;
    private final String className;
    private Object initializedValue;
    private final boolean privileged;
    private final String propertyName;
    private final ScriptableObject scope;
    private final boolean sealed;
    private int state;

    public LazilyLoadedCtor(ScriptableObject scriptableObject, String string2, String string3, boolean bl) {
        this(scriptableObject, string2, string3, bl, false);
    }

    LazilyLoadedCtor(ScriptableObject scriptableObject, String string2, String string3, boolean bl, boolean bl2) {
        this.scope = scriptableObject;
        this.propertyName = string2;
        this.className = string3;
        this.sealed = bl;
        this.privileged = bl2;
        this.state = 0;
        scriptableObject.addLazilyInitializedValue(string2, 0, this, 2);
    }

    private Object buildValue() {
        if (this.privileged) {
            return AccessController.doPrivileged((PrivilegedAction)new PrivilegedAction<Object>(){

                public Object run() {
                    return LazilyLoadedCtor.this.buildValue0();
                }
            });
        }
        return this.buildValue0();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Object buildValue0() {
        Class<? extends Scriptable> class_ = this.cast(Kit.classOrNull(this.className));
        if (class_ == null) return Scriptable.NOT_FOUND;
        try {
            Object object;
            BaseFunction baseFunction = ScriptableObject.buildClassCtor(this.scope, class_, this.sealed, false);
            if (baseFunction != null) {
                return baseFunction;
            }
            Object object2 = this.scope.get(this.propertyName, (Scriptable)this.scope);
            if (object2 != (object = Scriptable.NOT_FOUND)) return object2;
            return Scriptable.NOT_FOUND;
        }
        catch (InvocationTargetException invocationTargetException) {
            Throwable throwable = invocationTargetException.getTargetException();
            if (!(throwable instanceof RuntimeException)) return Scriptable.NOT_FOUND;
            throw (RuntimeException)throwable;
        }
        catch (SecurityException securityException) {
            return Scriptable.NOT_FOUND;
        }
        catch (IllegalAccessException illegalAccessException) {
            return Scriptable.NOT_FOUND;
        }
        catch (InstantiationException instantiationException) {
            return Scriptable.NOT_FOUND;
        }
        catch (RhinoException rhinoException) {
            return Scriptable.NOT_FOUND;
        }
    }

    private Class<? extends Scriptable> cast(Class<?> class_) {
        return class_;
    }

    Object getValue() {
        if (this.state != 2) {
            throw new IllegalStateException(this.propertyName);
        }
        return this.initializedValue;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    void init() {
        var5_1 = this;
        // MONITORENTER : var5_1
        if (this.state == 1) {
            throw new IllegalStateException("Recursive initialization for " + this.propertyName);
        }
        if (this.state == 0) {
            this.state = 1;
            var2_2 = Scriptable.NOT_FOUND;
            ** try [egrp 2[TRYBLOCK] [3 : 65->71)] { 
lbl9: // 1 sources:
            this.initializedValue = var4_3 = this.buildValue();
            this.state = 2;
        }
        // MONITOREXIT : var5_1
        return;
lbl13: // 1 sources:
        catch (Throwable var3_4) {
            this.initializedValue = var2_2;
            this.state = 2;
            throw var3_4;
        }
    }

}

