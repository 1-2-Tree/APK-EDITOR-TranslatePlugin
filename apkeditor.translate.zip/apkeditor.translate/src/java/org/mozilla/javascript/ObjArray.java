/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.Serializable
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.IndexOutOfBoundsException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.System
 */
package org.mozilla.javascript;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class ObjArray
implements Serializable {
    private static final int FIELDS_STORE_SIZE = 5;
    static final long serialVersionUID = 4174889037736658296L;
    private transient Object[] data;
    private transient Object f0;
    private transient Object f1;
    private transient Object f2;
    private transient Object f3;
    private transient Object f4;
    private boolean sealed;
    private int size;

    /*
     * Enabled aggressive block sorting
     */
    private void ensureCapacity(int n) {
        int n2 = n - 5;
        if (n2 <= 0) {
            throw new IllegalArgumentException();
        }
        if (this.data == null) {
            int n3 = 10;
            if (n3 < n2) {
                n3 = n2;
            }
            this.data = new Object[n3];
            return;
        }
        int n4 = this.data.length;
        if (n4 >= n2) return;
        int n5 = n4 <= 5 ? 10 : n4 * 2;
        if (n5 < n2) {
            n5 = n2;
        }
        Object[] arrobject = new Object[n5];
        if (this.size > 5) {
            System.arraycopy((Object)this.data, (int)0, (Object)arrobject, (int)0, (int)(-5 + this.size));
        }
        this.data = arrobject;
    }

    private Object getImpl(int n) {
        switch (n) {
            default: {
                return this.data[n - 5];
            }
            case 0: {
                return this.f0;
            }
            case 1: {
                return this.f1;
            }
            case 2: {
                return this.f2;
            }
            case 3: {
                return this.f3;
            }
            case 4: 
        }
        return this.f4;
    }

    private static RuntimeException onEmptyStackTopRead() {
        throw new RuntimeException("Empty stack");
    }

    private static RuntimeException onInvalidIndex(int n, int n2) {
        throw new IndexOutOfBoundsException(n + " \u2209 [0, " + n2 + ')');
    }

    private static RuntimeException onSeledMutation() {
        throw new IllegalStateException("Attempt to modify sealed array");
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        int n = this.size;
        if (n > 5) {
            this.data = new Object[n - 5];
        }
        for (int i = 0; i != n; ++i) {
            this.setImpl(i, objectInputStream.readObject());
        }
    }

    private void setImpl(int n, Object object) {
        switch (n) {
            default: {
                this.data[n - 5] = object;
                return;
            }
            case 0: {
                this.f0 = object;
                return;
            }
            case 1: {
                this.f1 = object;
                return;
            }
            case 2: {
                this.f2 = object;
                return;
            }
            case 3: {
                this.f3 = object;
                return;
            }
            case 4: 
        }
        this.f4 = object;
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
        int n = this.size;
        for (int i = 0; i != n; ++i) {
            objectOutputStream.writeObject(this.getImpl(i));
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void add(int var1_1, Object var2_2) {
        block10 : {
            var3_3 = this.size;
            if (var1_1 < 0) throw ObjArray.onInvalidIndex(var1_1, var3_3 + 1);
            if (var1_1 > var3_3) {
                throw ObjArray.onInvalidIndex(var1_1, var3_3 + 1);
            }
            if (this.sealed) {
                throw ObjArray.onSeledMutation();
            }
            switch (var1_1) {
                default: {
                    break;
                }
                case 0: {
                    if (var3_3 != 0) ** GOTO lbl14
                    this.f0 = var2_2;
                    break block10;
lbl14: // 1 sources:
                    var8_4 = this.f0;
                    this.f0 = var2_2;
                    var2_2 = var8_4;
                }
                case 1: {
                    if (var3_3 != 1) ** GOTO lbl21
                    this.f1 = var2_2;
                    break block10;
lbl21: // 1 sources:
                    var7_5 = this.f1;
                    this.f1 = var2_2;
                    var2_2 = var7_5;
                }
                case 2: {
                    if (var3_3 != 2) ** GOTO lbl28
                    this.f2 = var2_2;
                    break block10;
lbl28: // 1 sources:
                    var6_6 = this.f2;
                    this.f2 = var2_2;
                    var2_2 = var6_6;
                }
                case 3: {
                    if (var3_3 != 3) ** GOTO lbl35
                    this.f3 = var2_2;
                    break block10;
lbl35: // 1 sources:
                    var5_7 = this.f3;
                    this.f3 = var2_2;
                    var2_2 = var5_7;
                }
                case 4: {
                    if (var3_3 != 4) ** GOTO lbl42
                    this.f4 = var2_2;
                    break block10;
lbl42: // 1 sources:
                    var4_8 = this.f4;
                    this.f4 = var2_2;
                    var2_2 = var4_8;
                    var1_1 = 5;
                }
            }
            this.ensureCapacity(var3_3 + 1);
            if (var1_1 != var3_3) {
                System.arraycopy((Object)this.data, (int)(var1_1 - 5), (Object)this.data, (int)(1 + (var1_1 - 5)), (int)(var3_3 - var1_1));
            }
            this.data[var1_1 - 5] = var2_2;
        }
        this.size = var3_3 + 1;
    }

    public final void add(Object object) {
        if (this.sealed) {
            throw ObjArray.onSeledMutation();
        }
        int n = this.size;
        if (n >= 5) {
            this.ensureCapacity(n + 1);
        }
        this.size = n + 1;
        this.setImpl(n, object);
    }

    public final void clear() {
        if (this.sealed) {
            throw ObjArray.onSeledMutation();
        }
        int n = this.size;
        for (int i = 0; i != n; ++i) {
            this.setImpl(i, null);
        }
        this.size = 0;
    }

    public final Object get(int n) {
        if (n < 0 || n >= this.size) {
            throw ObjArray.onInvalidIndex(n, this.size);
        }
        return this.getImpl(n);
    }

    public int indexOf(Object object) {
        int n = this.size;
        for (int i = 0; i != n; ++i) {
            Object object2 = this.getImpl(i);
            if (object2 != object && (object2 == null || !object2.equals(object))) continue;
            return i;
        }
        return -1;
    }

    public final boolean isEmpty() {
        return this.size == 0;
    }

    public final boolean isSealed() {
        return this.sealed;
    }

    public int lastIndexOf(Object object) {
        int n = this.size;
        while (n != 0) {
            Object object2;
            if ((object2 = this.getImpl(--n)) != object && (object2 == null || !object2.equals(object))) continue;
            return n;
        }
        return -1;
    }

    public final Object peek() {
        int n = this.size;
        if (n == 0) {
            throw ObjArray.onEmptyStackTopRead();
        }
        return this.getImpl(n - 1);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final Object pop() {
        Object object;
        if (this.sealed) {
            throw ObjArray.onSeledMutation();
        }
        int n = -1 + this.size;
        switch (n) {
            default: {
                object = this.data[n - 5];
                this.data[n - 5] = null;
                break;
            }
            case -1: {
                throw ObjArray.onEmptyStackTopRead();
            }
            case 0: {
                object = this.f0;
                this.f0 = null;
                break;
            }
            case 1: {
                object = this.f1;
                this.f1 = null;
                break;
            }
            case 2: {
                object = this.f2;
                this.f2 = null;
                break;
            }
            case 3: {
                object = this.f3;
                this.f3 = null;
                break;
            }
            case 4: {
                object = this.f4;
                this.f4 = null;
            }
        }
        this.size = n;
        return object;
    }

    public final void push(Object object) {
        this.add(object);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void remove(int var1_1) {
        block10 : {
            var2_2 = this.size;
            if (var1_1 < 0) throw ObjArray.onInvalidIndex(var1_1, var2_2);
            if (var1_1 >= var2_2) {
                throw ObjArray.onInvalidIndex(var1_1, var2_2);
            }
            if (this.sealed) {
                throw ObjArray.onSeledMutation();
            }
            var3_3 = var2_2 - 1;
            switch (var1_1) {
                default: {
                    break;
                }
                case 0: {
                    if (var3_3 != 0) ** GOTO lbl15
                    this.f0 = null;
                    break block10;
lbl15: // 1 sources:
                    this.f0 = this.f1;
                }
                case 1: {
                    if (var3_3 != 1) ** GOTO lbl20
                    this.f1 = null;
                    break block10;
lbl20: // 1 sources:
                    this.f1 = this.f2;
                }
                case 2: {
                    if (var3_3 != 2) ** GOTO lbl25
                    this.f2 = null;
                    break block10;
lbl25: // 1 sources:
                    this.f2 = this.f3;
                }
                case 3: {
                    if (var3_3 != 3) ** GOTO lbl30
                    this.f3 = null;
                    break block10;
lbl30: // 1 sources:
                    this.f3 = this.f4;
                }
                case 4: {
                    if (var3_3 != 4) ** GOTO lbl35
                    this.f4 = null;
                    break block10;
lbl35: // 1 sources:
                    this.f4 = this.data[0];
                    var1_1 = 5;
                }
            }
            if (var1_1 != var3_3) {
                System.arraycopy((Object)this.data, (int)(1 + (var1_1 - 5)), (Object)this.data, (int)(var1_1 - 5), (int)(var3_3 - var1_1));
            }
            this.data[var3_3 - 5] = null;
        }
        this.size = var3_3;
    }

    public final void seal() {
        this.sealed = true;
    }

    public final void set(int n, Object object) {
        if (n < 0 || n >= this.size) {
            throw ObjArray.onInvalidIndex(n, this.size);
        }
        if (this.sealed) {
            throw ObjArray.onSeledMutation();
        }
        this.setImpl(n, object);
    }

    public final void setSize(int n) {
        if (n < 0) {
            throw new IllegalArgumentException();
        }
        if (this.sealed) {
            throw ObjArray.onSeledMutation();
        }
        int n2 = this.size;
        if (n < n2) {
            for (int i = n; i != n2; ++i) {
                this.setImpl(i, null);
            }
        } else if (n > n2 && n > 5) {
            this.ensureCapacity(n);
        }
        this.size = n;
    }

    public final int size() {
        return this.size;
    }

    public final void toArray(Object[] arrobject) {
        this.toArray(arrobject, 0);
    }

    public final void toArray(Object[] arrobject, int n) {
        int n2 = this.size;
        switch (n2) {
            default: {
                System.arraycopy((Object)this.data, (int)0, (Object)arrobject, (int)(n + 5), (int)(n2 - 5));
            }
            case 5: {
                arrobject[n + 4] = this.f4;
            }
            case 4: {
                arrobject[n + 3] = this.f3;
            }
            case 3: {
                arrobject[n + 2] = this.f2;
            }
            case 2: {
                arrobject[n + 1] = this.f1;
            }
            case 1: {
                arrobject[n + 0] = this.f0;
            }
            case 0: 
        }
    }

    public final Object[] toArray() {
        Object[] arrobject = new Object[this.size];
        this.toArray(arrobject, 0);
        return arrobject;
    }
}

