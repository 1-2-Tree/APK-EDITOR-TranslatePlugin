/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package org.mozilla.javascript;

import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.mozilla.javascript.JavaAdapter;
import org.mozilla.javascript.JavaMembers;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

public class ClassCache
implements Serializable {
    private static final Object AKEY = "ClassCache";
    private static final long serialVersionUID = -8866246036237312215L;
    private Scriptable associatedScope;
    private volatile boolean cachingIsEnabled = true;
    private transient Map<JavaAdapter.JavaAdapterSignature, Class<?>> classAdapterCache;
    private transient Map<Class<?>, JavaMembers> classTable;
    private int generatedClassSerial;
    private transient Map<Class<?>, Object> interfaceAdapterCache;

    public static ClassCache get(Scriptable scriptable) {
        ClassCache classCache = (ClassCache)ScriptableObject.getTopScopeValue(scriptable, AKEY);
        if (classCache == null) {
            throw new RuntimeException("Can't find top level scope for ClassCache.get");
        }
        return classCache;
    }

    public boolean associate(ScriptableObject scriptableObject) {
        if (scriptableObject.getParentScope() != null) {
            throw new IllegalArgumentException();
        }
        if (this == scriptableObject.associateValue(AKEY, this)) {
            this.associatedScope = scriptableObject;
            return true;
        }
        return false;
    }

    void cacheInterfaceAdapter(Class<?> class_, Object object) {
        ClassCache classCache = this;
        synchronized (classCache) {
            if (this.cachingIsEnabled) {
                if (this.interfaceAdapterCache == null) {
                    this.interfaceAdapterCache = new ConcurrentHashMap(16, 0.75f, 1);
                }
                this.interfaceAdapterCache.put(class_, object);
            }
            return;
        }
    }

    public void clearCaches() {
        ClassCache classCache = this;
        synchronized (classCache) {
            this.classTable = null;
            this.classAdapterCache = null;
            this.interfaceAdapterCache = null;
            return;
        }
    }

    Scriptable getAssociatedScope() {
        return this.associatedScope;
    }

    Map<Class<?>, JavaMembers> getClassCacheMap() {
        if (this.classTable == null) {
            this.classTable = new ConcurrentHashMap(16, 0.75f, 1);
        }
        return this.classTable;
    }

    Object getInterfaceAdapter(Class<?> class_) {
        if (this.interfaceAdapterCache == null) {
            return null;
        }
        return this.interfaceAdapterCache.get(class_);
    }

    Map<JavaAdapter.JavaAdapterSignature, Class<?>> getInterfaceAdapterCacheMap() {
        if (this.classAdapterCache == null) {
            this.classAdapterCache = new ConcurrentHashMap(16, 0.75f, 1);
        }
        return this.classAdapterCache;
    }

    public final boolean isCachingEnabled() {
        return this.cachingIsEnabled;
    }

    @Deprecated
    public boolean isInvokerOptimizationEnabled() {
        return false;
    }

    public final int newClassSerialNumber() {
        ClassCache classCache = this;
        synchronized (classCache) {
            int n;
            this.generatedClassSerial = n = 1 + this.generatedClassSerial;
            return n;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setCachingEnabled(boolean bl) {
        ClassCache classCache = this;
        synchronized (classCache) {
            boolean bl2 = this.cachingIsEnabled;
            if (bl != bl2) {
                if (!bl) {
                    this.clearCaches();
                }
                this.cachingIsEnabled = bl;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Deprecated
    public void setInvokerOptimizationEnabled(boolean bl) {
        ClassCache classCache = this;
        // MONITORENTER : classCache
        // MONITOREXIT : classCache
    }
}

