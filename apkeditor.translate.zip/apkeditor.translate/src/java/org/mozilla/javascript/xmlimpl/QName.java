/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.xmlimpl;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.xmlimpl.Namespace;
import org.mozilla.javascript.xmlimpl.XMLLibImpl;
import org.mozilla.javascript.xmlimpl.XmlNode;

final class QName
extends IdScriptableObject {
    private static final int Id_constructor = 1;
    private static final int Id_localName = 1;
    private static final int Id_toSource = 3;
    private static final int Id_toString = 2;
    private static final int Id_uri = 2;
    private static final int MAX_INSTANCE_ID = 2;
    private static final int MAX_PROTOTYPE_ID = 3;
    private static final Object QNAME_TAG = "QName";
    static final long serialVersionUID = 416745167693026750L;
    private XmlNode.QName delegate;
    private XMLLibImpl lib;
    private QName prototype;

    private QName() {
    }

    static QName create(XMLLibImpl xMLLibImpl, Scriptable scriptable, QName qName, XmlNode.QName qName2) {
        QName qName3 = new QName();
        qName3.lib = xMLLibImpl;
        qName3.setParentScope(scriptable);
        qName3.prototype = qName;
        qName3.setPrototype(qName);
        qName3.delegate = qName2;
        return qName3;
    }

    private boolean equals(QName qName) {
        return this.delegate.equals(qName.delegate);
    }

    private Object jsConstructor(Context context, boolean bl, Object[] arrobject) {
        if (!bl && arrobject.length == 1) {
            return this.castToQName(this.lib, context, arrobject[0]);
        }
        if (arrobject.length == 0) {
            return this.constructQName(this.lib, context, Undefined.instance);
        }
        if (arrobject.length == 1) {
            return this.constructQName(this.lib, context, arrobject[0]);
        }
        return this.constructQName(this.lib, context, arrobject[0], arrobject[1]);
    }

    private String js_toSource() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('(');
        QName.toSourceImpl(this.uri(), this.localName(), this.prefix(), stringBuilder);
        stringBuilder.append(')');
        return stringBuilder.toString();
    }

    private QName realThis(Scriptable scriptable, IdFunctionObject idFunctionObject) {
        if (!(scriptable instanceof QName)) {
            throw QName.incompatibleCallError(idFunctionObject);
        }
        return (QName)scriptable;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void toSourceImpl(String string2, String string3, String string4, StringBuilder stringBuilder) {
        stringBuilder.append("new QName(");
        if (string2 == null && string4 == null) {
            if (!"*".equals((Object)string3)) {
                stringBuilder.append("null, ");
            }
        } else {
            Namespace.toSourceImpl(string4, string2, stringBuilder);
            stringBuilder.append(", ");
        }
        stringBuilder.append('\'');
        stringBuilder.append(ScriptRuntime.escapeString(string3, '\''));
        stringBuilder.append("')");
    }

    QName castToQName(XMLLibImpl xMLLibImpl, Context context, Object object) {
        if (object instanceof QName) {
            return (QName)object;
        }
        return this.constructQName(xMLLibImpl, context, object);
    }

    QName constructQName(XMLLibImpl xMLLibImpl, Context context, Object object) {
        return this.constructQName(xMLLibImpl, context, Undefined.instance, object);
    }

    /*
     * Enabled aggressive block sorting
     */
    QName constructQName(XMLLibImpl xMLLibImpl, Context context, Object object, Object object2) {
        String string2;
        String string3;
        if (object2 instanceof QName) {
            if (object == Undefined.instance) {
                return (QName)object2;
            }
            ((QName)object2).localName();
        }
        String string4 = object2 == Undefined.instance ? "" : ScriptRuntime.toString(object2);
        if (object == Undefined.instance) {
            object = "*".equals((Object)string4) ? null : xMLLibImpl.getDefaultNamespace(context);
        }
        Namespace namespace = null;
        if (object != null) {
            namespace = object instanceof Namespace ? (Namespace)object : xMLLibImpl.newNamespace(ScriptRuntime.toString(object));
        }
        String string5 = string4;
        if (object == null) {
            string3 = null;
            string2 = null;
            return this.newQName(xMLLibImpl, string3, string5, string2);
        }
        string3 = namespace.uri();
        string2 = namespace.prefix();
        return this.newQName(xMLLibImpl, string3, string5, string2);
    }

    public boolean equals(Object object) {
        if (!(object instanceof QName)) {
            return false;
        }
        return this.equals((QName)object);
    }

    @Override
    protected Object equivalentValues(Object object) {
        if (!(object instanceof QName)) {
            return Scriptable.NOT_FOUND;
        }
        if (this.equals((QName)object)) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(QNAME_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                boolean bl;
                if (scriptable2 == null) {
                    bl = true;
                    do {
                        return this.jsConstructor(context, bl, arrobject);
                        break;
                    } while (true);
                }
                bl = false;
                return this.jsConstructor(context, bl, arrobject);
            }
            case 2: {
                return this.realThis(scriptable2, idFunctionObject).toString();
            }
            case 3: 
        }
        return this.realThis(scriptable2, idFunctionObject).js_toSource();
    }

    void exportAsJSClass(boolean bl) {
        this.exportAsJSClass(3, this.getParentScope(), bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findInstanceIdInfo(String string2) {
        String string3;
        int n;
        int n2 = string2.length();
        if (n2 == 3) {
            string3 = "uri";
            n = 2;
        } else {
            string3 = null;
            n = 0;
            if (n2 == 9) {
                string3 = "localName";
                n = 1;
            }
        }
        if (string3 != null && string3 != string2 && !string3.equals((Object)string2)) {
            n = 0;
        }
        if (n == 0) {
            return super.findInstanceIdInfo(string2);
        }
        switch (n) {
            default: {
                throw new IllegalStateException();
            }
            case 1: 
            case 2: 
        }
        return QName.instanceIdInfo(5, n + super.getMaxInstanceId());
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        String string3;
        int n;
        int n2 = string2.length();
        if (n2 == 8) {
            char c = string2.charAt(3);
            if (c == 'o') {
                string3 = "toSource";
                n = 3;
            } else {
                string3 = null;
                n = 0;
                if (c == 't') {
                    string3 = "toString";
                    n = 2;
                }
            }
        } else {
            string3 = null;
            n = 0;
            if (n2 == 11) {
                string3 = "constructor";
                n = 1;
            }
        }
        if (string3 == null) return n;
        if (string3 == string2) return n;
        if (string3.equals((Object)string2)) return n;
        return 0;
    }

    @Override
    public String getClassName() {
        return "QName";
    }

    @Override
    public Object getDefaultValue(Class<?> class_) {
        return this.toString();
    }

    final XmlNode.QName getDelegate() {
        return this.delegate;
    }

    @Override
    protected String getInstanceIdName(int n) {
        switch (n - super.getMaxInstanceId()) {
            default: {
                return super.getInstanceIdName(n);
            }
            case 1: {
                return "localName";
            }
            case 2: 
        }
        return "uri";
    }

    @Override
    protected Object getInstanceIdValue(int n) {
        switch (n - super.getMaxInstanceId()) {
            default: {
                return super.getInstanceIdValue(n);
            }
            case 1: {
                return this.localName();
            }
            case 2: 
        }
        return this.uri();
    }

    @Override
    protected int getMaxInstanceId() {
        return 2 + super.getMaxInstanceId();
    }

    public int hashCode() {
        return this.delegate.hashCode();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        int n2;
        String string2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 2;
                string2 = "constructor";
                break;
            }
            case 2: {
                string2 = "toString";
                n2 = 0;
                break;
            }
            case 3: {
                string2 = "toSource";
                n2 = 0;
            }
        }
        this.initPrototypeMethod(QNAME_TAG, n, string2, n2);
    }

    public String localName() {
        if (this.delegate.getLocalName() == null) {
            return "*";
        }
        return this.delegate.getLocalName();
    }

    /*
     * Enabled aggressive block sorting
     */
    QName newQName(XMLLibImpl xMLLibImpl, String string2, String string3, String string4) {
        QName qName = this.prototype;
        if (qName == null) {
            qName = this;
        }
        XmlNode.Namespace namespace = string4 != null ? XmlNode.Namespace.create(string4, string2) : (string2 != null ? XmlNode.Namespace.create(string2) : null);
        if (string3 != null && string3.equals((Object)"*")) {
            string3 = null;
        }
        return QName.create(xMLLibImpl, this.getParentScope(), qName, XmlNode.QName.create(namespace, string3));
    }

    String prefix() {
        if (this.delegate.getNamespace() == null) {
            return null;
        }
        return this.delegate.getNamespace().getPrefix();
    }

    @Deprecated
    final XmlNode.QName toNodeQname() {
        return this.delegate;
    }

    public String toString() {
        if (this.delegate.getNamespace() == null) {
            return "*::" + this.localName();
        }
        if (this.delegate.getNamespace().isGlobal()) {
            return this.localName();
        }
        return this.uri() + "::" + this.localName();
    }

    String uri() {
        if (this.delegate.getNamespace() == null) {
            return null;
        }
        return this.delegate.getNamespace().getUri();
    }
}

