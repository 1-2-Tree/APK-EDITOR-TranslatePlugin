/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript.xmlimpl;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionCall;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.xmlimpl.XML;
import org.mozilla.javascript.xmlimpl.XMLList;
import org.mozilla.javascript.xmlimpl.XmlProcessor;

class XMLCtor
extends IdFunctionObject {
    private static final int Id_defaultSettings = 1;
    private static final int Id_ignoreComments = 1;
    private static final int Id_ignoreProcessingInstructions = 2;
    private static final int Id_ignoreWhitespace = 3;
    private static final int Id_prettyIndent = 4;
    private static final int Id_prettyPrinting = 5;
    private static final int Id_setSettings = 3;
    private static final int Id_settings = 2;
    private static final int MAX_FUNCTION_ID = 3;
    private static final int MAX_INSTANCE_ID = 5;
    private static final Object XMLCTOR_TAG = "XMLCtor";
    static final long serialVersionUID = -8708195078359817341L;
    private XmlProcessor options;

    XMLCtor(XML xML, Object object, int n, int n2) {
        super(xML, object, n, n2);
        this.options = xML.getProcessor();
        this.activatePrototypeMap(3);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void readSettings(Scriptable scriptable) {
        int n = 1;
        do {
            block7 : {
                if (n > 5) {
                    return;
                }
                int n2 = n + super.getMaxInstanceId();
                Object object = ScriptableObject.getProperty(scriptable, this.getInstanceIdName(n2));
                if (object == Scriptable.NOT_FOUND) break block7;
                switch (n) {
                    default: {
                        throw new IllegalStateException();
                    }
                    case 1: 
                    case 2: 
                    case 3: 
                    case 5: {
                        if (object instanceof Boolean) {
                            break;
                        }
                        break block7;
                    }
                    case 4: {
                        if (!(object instanceof Number)) break block7;
                    }
                }
                this.setInstanceIdValue(n2, object);
            }
            ++n;
        } while (true);
    }

    private void writeSetting(Scriptable scriptable) {
        for (int i = 1; i <= 5; ++i) {
            int n = i + super.getMaxInstanceId();
            ScriptableObject.putProperty(scriptable, this.getInstanceIdName(n), this.getInstanceIdValue(n));
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(XMLCTOR_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                this.options.setDefault();
                Scriptable scriptable3 = context.newObject(scriptable);
                this.writeSetting(scriptable3);
                return scriptable3;
            }
            case 2: {
                Scriptable scriptable4 = context.newObject(scriptable);
                this.writeSetting(scriptable4);
                return scriptable4;
            }
            case 3: 
        }
        if (arrobject.length != 0 && arrobject[0] != null && arrobject[0] != Undefined.instance) {
            if (!(arrobject[0] instanceof Scriptable)) return Undefined.instance;
            this.readSettings((Scriptable)arrobject[0]);
            return Undefined.instance;
        }
        this.options.setDefault();
        return Undefined.instance;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findInstanceIdInfo(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        switch (n) {
            case 12: {
                string3 = "prettyIndent";
                n2 = 4;
                break;
            }
            case 14: {
                char c = string2.charAt(0);
                if (c == 'i') {
                    string3 = "ignoreComments";
                    n2 = 1;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'p') break;
                string3 = "prettyPrinting";
                n2 = 5;
                break;
            }
            case 16: {
                string3 = "ignoreWhitespace";
                n2 = 3;
                break;
            }
            case 28: {
                string3 = "ignoreProcessingInstructions";
                n2 = 2;
            }
        }
        if (string3 != null && string3 != string2 && !string3.equals((Object)string2)) {
            n2 = 0;
        }
        if (n2 == 0) {
            return super.findInstanceIdInfo(string2);
        }
        switch (n2) {
            default: {
                throw new IllegalStateException();
            }
            case 1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: 
        }
        return XMLCtor.instanceIdInfo(6, n2 + super.getMaxInstanceId());
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        String string3;
        int n;
        int n2 = string2.length();
        if (n2 == 8) {
            string3 = "settings";
            n = 2;
        } else if (n2 == 11) {
            string3 = "setSettings";
            n = 3;
        } else {
            string3 = null;
            n = 0;
            if (n2 == 15) {
                string3 = "defaultSettings";
                n = 1;
            }
        }
        if (string3 == null) return n;
        if (string3 == string2) return n;
        if (string3.equals((Object)string2)) return n;
        return 0;
    }

    @Override
    protected String getInstanceIdName(int n) {
        switch (n - super.getMaxInstanceId()) {
            default: {
                return super.getInstanceIdName(n);
            }
            case 1: {
                return "ignoreComments";
            }
            case 2: {
                return "ignoreProcessingInstructions";
            }
            case 3: {
                return "ignoreWhitespace";
            }
            case 4: {
                return "prettyIndent";
            }
            case 5: 
        }
        return "prettyPrinting";
    }

    @Override
    protected Object getInstanceIdValue(int n) {
        switch (n - super.getMaxInstanceId()) {
            default: {
                return super.getInstanceIdValue(n);
            }
            case 1: {
                return ScriptRuntime.wrapBoolean(this.options.isIgnoreComments());
            }
            case 2: {
                return ScriptRuntime.wrapBoolean(this.options.isIgnoreProcessingInstructions());
            }
            case 3: {
                return ScriptRuntime.wrapBoolean(this.options.isIgnoreWhitespace());
            }
            case 4: {
                return ScriptRuntime.wrapInt(this.options.getPrettyIndent());
            }
            case 5: 
        }
        return ScriptRuntime.wrapBoolean(this.options.isPrettyPrinting());
    }

    @Override
    protected int getMaxInstanceId() {
        return 5 + super.getMaxInstanceId();
    }

    @Override
    public boolean hasInstance(Scriptable scriptable) {
        return scriptable instanceof XML || scriptable instanceof XMLList;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 0;
                string2 = "defaultSettings";
                break;
            }
            case 2: {
                string2 = "settings";
                n2 = 0;
                break;
            }
            case 3: {
                n2 = 1;
                string2 = "setSettings";
            }
        }
        this.initPrototypeMethod(XMLCTOR_TAG, n, string2, n2);
    }

    @Override
    protected void setInstanceIdValue(int n, Object object) {
        switch (n - super.getMaxInstanceId()) {
            default: {
                super.setInstanceIdValue(n, object);
                return;
            }
            case 1: {
                this.options.setIgnoreComments(ScriptRuntime.toBoolean(object));
                return;
            }
            case 2: {
                this.options.setIgnoreProcessingInstructions(ScriptRuntime.toBoolean(object));
                return;
            }
            case 3: {
                this.options.setIgnoreWhitespace(ScriptRuntime.toBoolean(object));
                return;
            }
            case 4: {
                this.options.setPrettyIndent(ScriptRuntime.toInt32(object));
                return;
            }
            case 5: 
        }
        this.options.setPrettyPrinting(ScriptRuntime.toBoolean(object));
    }
}

