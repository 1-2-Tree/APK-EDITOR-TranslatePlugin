/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.xmlimpl;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.xmlimpl.QName;
import org.mozilla.javascript.xmlimpl.XMLName;
import org.mozilla.javascript.xmlimpl.XmlNode;

class Namespace
extends IdScriptableObject {
    private static final int Id_constructor = 1;
    private static final int Id_prefix = 1;
    private static final int Id_toSource = 3;
    private static final int Id_toString = 2;
    private static final int Id_uri = 2;
    private static final int MAX_INSTANCE_ID = 2;
    private static final int MAX_PROTOTYPE_ID = 3;
    private static final Object NAMESPACE_TAG = "Namespace";
    static final long serialVersionUID = -5765755238131301744L;
    private XmlNode.Namespace ns;
    private Namespace prototype;

    private Namespace() {
    }

    private Namespace constructNamespace() {
        return this.newNamespace("", "");
    }

    /*
     * Enabled aggressive block sorting
     */
    private Namespace constructNamespace(Object object, Object object2) {
        String string2;
        String string3;
        if (object2 instanceof QName) {
            QName qName = (QName)object2;
            string2 = qName.uri();
            if (string2 == null) {
                string2 = qName.toString();
            }
        } else {
            string2 = ScriptRuntime.toString(object2);
        }
        if (string2.length() == 0) {
            if (object == Undefined.instance) {
                string3 = "";
                return this.newNamespace(string3, string2);
            }
            string3 = ScriptRuntime.toString(object);
            if (string3.length() == 0) return this.newNamespace(string3, string2);
            throw ScriptRuntime.typeError("Illegal prefix '" + string3 + "' for 'no namespace'.");
        }
        if (object == Undefined.instance) {
            string3 = "";
            return this.newNamespace(string3, string2);
        }
        if (!XMLName.accept(object)) {
            string3 = "";
            return this.newNamespace(string3, string2);
        }
        string3 = ScriptRuntime.toString(object);
        return this.newNamespace(string3, string2);
    }

    static Namespace create(Scriptable scriptable, Namespace namespace, XmlNode.Namespace namespace2) {
        Namespace namespace3 = new Namespace();
        namespace3.setParentScope(scriptable);
        namespace3.prototype = namespace;
        namespace3.setPrototype(namespace);
        namespace3.ns = namespace2;
        return namespace3;
    }

    private boolean equals(Namespace namespace) {
        return this.uri().equals((Object)namespace.uri());
    }

    private Object jsConstructor(Context context, boolean bl, Object[] arrobject) {
        if (!bl && arrobject.length == 1) {
            return this.castToNamespace(arrobject[0]);
        }
        if (arrobject.length == 0) {
            return this.constructNamespace();
        }
        if (arrobject.length == 1) {
            return this.constructNamespace(arrobject[0]);
        }
        return this.constructNamespace(arrobject[0], arrobject[1]);
    }

    private String js_toSource() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('(');
        Namespace.toSourceImpl(this.ns.getPrefix(), this.ns.getUri(), stringBuilder);
        stringBuilder.append(')');
        return stringBuilder.toString();
    }

    private Namespace realThis(Scriptable scriptable, IdFunctionObject idFunctionObject) {
        if (!(scriptable instanceof Namespace)) {
            throw Namespace.incompatibleCallError(idFunctionObject);
        }
        return (Namespace)scriptable;
    }

    static void toSourceImpl(String string2, String string3, StringBuilder stringBuilder) {
        stringBuilder.append("new Namespace(");
        if (string3.length() == 0) {
            if (!"".equals((Object)string2)) {
                throw new IllegalArgumentException(string2);
            }
        } else {
            stringBuilder.append('\'');
            if (string2 != null) {
                stringBuilder.append(ScriptRuntime.escapeString(string2, '\''));
                stringBuilder.append("', '");
            }
            stringBuilder.append(ScriptRuntime.escapeString(string3, '\''));
            stringBuilder.append('\'');
        }
        stringBuilder.append(')');
    }

    Namespace castToNamespace(Object object) {
        if (object instanceof Namespace) {
            return (Namespace)object;
        }
        return this.constructNamespace(object);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    Namespace constructNamespace(Object object) {
        String string2;
        String string3;
        if (object instanceof Namespace) {
            Namespace namespace = (Namespace)object;
            string2 = namespace.prefix();
            string3 = namespace.uri();
            do {
                return this.newNamespace(string2, string3);
                break;
            } while (true);
        }
        if (object instanceof QName) {
            QName qName = (QName)object;
            string3 = qName.uri();
            if (string3 != null) {
                string2 = qName.prefix();
                return this.newNamespace(string2, string3);
            }
            string3 = qName.toString();
            string2 = null;
            return this.newNamespace(string2, string3);
        }
        string3 = ScriptRuntime.toString(object);
        if (string3.length() == 0) {
            string2 = "";
            return this.newNamespace(string2, string3);
        }
        string2 = null;
        return this.newNamespace(string2, string3);
    }

    public boolean equals(Object object) {
        if (!(object instanceof Namespace)) {
            return false;
        }
        return this.equals((Namespace)object);
    }

    @Override
    protected Object equivalentValues(Object object) {
        if (!(object instanceof Namespace)) {
            return Scriptable.NOT_FOUND;
        }
        if (this.equals((Namespace)object)) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(NAMESPACE_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                boolean bl;
                if (scriptable2 == null) {
                    bl = true;
                    do {
                        return this.jsConstructor(context, bl, arrobject);
                        break;
                    } while (true);
                }
                bl = false;
                return this.jsConstructor(context, bl, arrobject);
            }
            case 2: {
                return this.realThis(scriptable2, idFunctionObject).toString();
            }
            case 3: 
        }
        return this.realThis(scriptable2, idFunctionObject).js_toSource();
    }

    public void exportAsJSClass(boolean bl) {
        this.exportAsJSClass(3, this.getParentScope(), bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findInstanceIdInfo(String string2) {
        String string3;
        int n;
        int n2 = string2.length();
        if (n2 == 3) {
            string3 = "uri";
            n = 2;
        } else {
            string3 = null;
            n = 0;
            if (n2 == 6) {
                string3 = "prefix";
                n = 1;
            }
        }
        if (string3 != null && string3 != string2 && !string3.equals((Object)string2)) {
            n = 0;
        }
        if (n == 0) {
            return super.findInstanceIdInfo(string2);
        }
        switch (n) {
            default: {
                throw new IllegalStateException();
            }
            case 1: 
            case 2: 
        }
        return Namespace.instanceIdInfo(5, n + super.getMaxInstanceId());
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        String string3;
        int n;
        int n2 = string2.length();
        if (n2 == 8) {
            char c = string2.charAt(3);
            if (c == 'o') {
                string3 = "toSource";
                n = 3;
            } else {
                string3 = null;
                n = 0;
                if (c == 't') {
                    string3 = "toString";
                    n = 2;
                }
            }
        } else {
            string3 = null;
            n = 0;
            if (n2 == 11) {
                string3 = "constructor";
                n = 1;
            }
        }
        if (string3 == null) return n;
        if (string3 == string2) return n;
        if (string3.equals((Object)string2)) return n;
        return 0;
    }

    @Override
    public String getClassName() {
        return "Namespace";
    }

    @Override
    public Object getDefaultValue(Class<?> class_) {
        return this.uri();
    }

    final XmlNode.Namespace getDelegate() {
        return this.ns;
    }

    @Override
    protected String getInstanceIdName(int n) {
        switch (n - super.getMaxInstanceId()) {
            default: {
                return super.getInstanceIdName(n);
            }
            case 1: {
                return "prefix";
            }
            case 2: 
        }
        return "uri";
    }

    @Override
    protected Object getInstanceIdValue(int n) {
        switch (n - super.getMaxInstanceId()) {
            default: {
                return super.getInstanceIdValue(n);
            }
            case 1: {
                if (this.ns.getPrefix() == null) {
                    return Undefined.instance;
                }
                return this.ns.getPrefix();
            }
            case 2: 
        }
        return this.ns.getUri();
    }

    @Override
    protected int getMaxInstanceId() {
        return 2 + super.getMaxInstanceId();
    }

    public int hashCode() {
        return this.uri().hashCode();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        int n2;
        String string2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 2;
                string2 = "constructor";
                break;
            }
            case 2: {
                string2 = "toString";
                n2 = 0;
                break;
            }
            case 3: {
                string2 = "toSource";
                n2 = 0;
            }
        }
        this.initPrototypeMethod(NAMESPACE_TAG, n, string2, n2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    Namespace newNamespace(String string2) {
        Namespace namespace;
        if (this.prototype == null) {
            namespace = this;
            do {
                return Namespace.create(this.getParentScope(), namespace, XmlNode.Namespace.create(string2));
                break;
            } while (true);
        }
        namespace = this.prototype;
        return Namespace.create(this.getParentScope(), namespace, XmlNode.Namespace.create(string2));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    Namespace newNamespace(String string2, String string3) {
        Namespace namespace;
        if (string2 == null) {
            return this.newNamespace(string3);
        }
        if (this.prototype == null) {
            namespace = this;
            do {
                return Namespace.create(this.getParentScope(), namespace, XmlNode.Namespace.create(string2, string3));
                break;
            } while (true);
        }
        namespace = this.prototype;
        return Namespace.create(this.getParentScope(), namespace, XmlNode.Namespace.create(string2, string3));
    }

    public String prefix() {
        return this.ns.getPrefix();
    }

    public String toLocaleString() {
        return this.toString();
    }

    public String toString() {
        return this.uri();
    }

    public String uri() {
        return this.ns.getUri();
    }
}

