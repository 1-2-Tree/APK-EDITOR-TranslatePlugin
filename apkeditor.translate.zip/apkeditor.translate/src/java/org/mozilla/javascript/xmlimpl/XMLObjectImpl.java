/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript.xmlimpl;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionCall;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.NativeWith;
import org.mozilla.javascript.Ref;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.xml.XMLObject;
import org.mozilla.javascript.xmlimpl.Namespace;
import org.mozilla.javascript.xmlimpl.QName;
import org.mozilla.javascript.xmlimpl.XML;
import org.mozilla.javascript.xmlimpl.XMLCtor;
import org.mozilla.javascript.xmlimpl.XMLLibImpl;
import org.mozilla.javascript.xmlimpl.XMLList;
import org.mozilla.javascript.xmlimpl.XMLName;
import org.mozilla.javascript.xmlimpl.XMLWithScope;
import org.mozilla.javascript.xmlimpl.XmlNode;
import org.mozilla.javascript.xmlimpl.XmlProcessor;

abstract class XMLObjectImpl
extends XMLObject {
    private static final int Id_addNamespace = 2;
    private static final int Id_appendChild = 3;
    private static final int Id_attribute = 4;
    private static final int Id_attributes = 5;
    private static final int Id_child = 6;
    private static final int Id_childIndex = 7;
    private static final int Id_children = 8;
    private static final int Id_comments = 9;
    private static final int Id_constructor = 1;
    private static final int Id_contains = 10;
    private static final int Id_copy = 11;
    private static final int Id_descendants = 12;
    private static final int Id_elements = 13;
    private static final int Id_hasComplexContent = 18;
    private static final int Id_hasOwnProperty = 17;
    private static final int Id_hasSimpleContent = 19;
    private static final int Id_inScopeNamespaces = 14;
    private static final int Id_insertChildAfter = 15;
    private static final int Id_insertChildBefore = 16;
    private static final int Id_length = 20;
    private static final int Id_localName = 21;
    private static final int Id_name = 22;
    private static final int Id_namespace = 23;
    private static final int Id_namespaceDeclarations = 24;
    private static final int Id_nodeKind = 25;
    private static final int Id_normalize = 26;
    private static final int Id_parent = 27;
    private static final int Id_prependChild = 28;
    private static final int Id_processingInstructions = 29;
    private static final int Id_propertyIsEnumerable = 30;
    private static final int Id_removeNamespace = 31;
    private static final int Id_replace = 32;
    private static final int Id_setChildren = 33;
    private static final int Id_setLocalName = 34;
    private static final int Id_setName = 35;
    private static final int Id_setNamespace = 36;
    private static final int Id_text = 37;
    private static final int Id_toSource = 39;
    private static final int Id_toString = 38;
    private static final int Id_toXMLString = 40;
    private static final int Id_valueOf = 41;
    private static final int MAX_PROTOTYPE_ID = 41;
    private static final Object XMLOBJECT_TAG = "XMLObject";
    private XMLLibImpl lib;
    private boolean prototypeFlag;

    protected XMLObjectImpl(XMLLibImpl xMLLibImpl, Scriptable scriptable, XMLObject xMLObject) {
        this.initialize(xMLLibImpl, scriptable, xMLObject);
    }

    private static Object arg(Object[] arrobject, int n) {
        if (n < arrobject.length) {
            return arrobject[n];
        }
        return Undefined.instance;
    }

    private XMLList getMatches(XMLName xMLName) {
        XMLList xMLList = this.newXMLList();
        this.addMatches(xMLList, xMLName);
        return xMLList;
    }

    private Object[] toObjectArray(Object[] arrobject) {
        Object[] arrobject2 = new Object[arrobject.length];
        for (int i = 0; i < arrobject2.length; ++i) {
            arrobject2[i] = arrobject[i];
        }
        return arrobject2;
    }

    private void xmlMethodNotFound(Object object, String string2) {
        throw ScriptRuntime.notFunctionError(object, string2);
    }

    abstract void addMatches(XMLList var1, XMLName var2);

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object addValues(Context context, boolean bl, Object object) {
        if (object instanceof XMLObject) {
            XMLObject xMLObject;
            void var4_5;
            if (bl) {
                XMLObjectImpl xMLObjectImpl = this;
                xMLObject = (XMLObject)object;
                do {
                    return this.lib.addXMLObjects(context, (XMLObject)var4_5, xMLObject);
                    break;
                } while (true);
            }
            XMLObject xMLObject2 = (XMLObject)object;
            xMLObject = this;
            return this.lib.addXMLObjects(context, (XMLObject)var4_5, xMLObject);
        }
        if (object != Undefined.instance) return super.addValues(context, bl, object);
        return ScriptRuntime.toString(this);
    }

    abstract XMLList child(int var1);

    abstract XMLList child(XMLName var1);

    abstract XMLList children();

    abstract XMLList comments();

    abstract boolean contains(Object var1);

    abstract XMLObjectImpl copy();

    final XML createEmptyXML() {
        return this.newXML(XmlNode.createEmpty(this.getProcessor()));
    }

    final Namespace createNamespace(XmlNode.Namespace namespace) {
        if (namespace == null) {
            return null;
        }
        return this.lib.createNamespaces(new XmlNode.Namespace[]{namespace})[0];
    }

    final Namespace[] createNamespaces(XmlNode.Namespace[] arrnamespace) {
        return this.lib.createNamespaces(arrnamespace);
    }

    @Override
    public void delete(String string2) {
        Context context = Context.getCurrentContext();
        this.deleteXMLProperty(this.lib.toXMLNameFromString(context, string2));
    }

    @Override
    public final boolean delete(Context context, Object object) {
        XMLName xMLName;
        if (context == null) {
            context = Context.getCurrentContext();
        }
        if ((xMLName = this.lib.toXMLNameOrIndex(context, object)) == null) {
            this.delete((int)ScriptRuntime.lastUint32Result(context));
            return true;
        }
        this.deleteXMLProperty(xMLName);
        return true;
    }

    abstract void deleteXMLProperty(XMLName var1);

    final String ecmaEscapeAttributeValue(String string2) {
        String string3 = this.lib.escapeAttributeValue(string2);
        return string3.substring(1, -1 + string3.length());
    }

    final XML ecmaToXml(Object object) {
        return this.lib.ecmaToXml(object);
    }

    abstract XMLList elements(XMLName var1);

    @Override
    public NativeWith enterDotQuery(Scriptable scriptable) {
        XMLWithScope xMLWithScope = new XMLWithScope(this.lib, scriptable, this);
        xMLWithScope.initAsDotQuery();
        return xMLWithScope;
    }

    @Override
    public NativeWith enterWith(Scriptable scriptable) {
        return new XMLWithScope(this.lib, scriptable, this);
    }

    @Override
    protected final Object equivalentValues(Object object) {
        if (this.equivalentXml(object)) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    abstract boolean equivalentXml(Object var1);

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (!idFunctionObject.hasTag(XMLOBJECT_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n = idFunctionObject.methodId();
        if (n == 1) {
            boolean bl;
            if (scriptable2 == null) {
                bl = true;
                return this.jsConstructor(context, bl, arrobject);
            }
            bl = false;
            return this.jsConstructor(context, bl, arrobject);
        }
        if (!(scriptable2 instanceof XMLObjectImpl)) {
            throw XMLObjectImpl.incompatibleCallError(idFunctionObject);
        }
        XMLObjectImpl xMLObjectImpl = (XMLObjectImpl)scriptable2;
        XML xML = xMLObjectImpl.getXML();
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 3: {
                if (xML != null) return xML.appendChild(XMLObjectImpl.arg(arrobject, 0));
                this.xmlMethodNotFound(xMLObjectImpl, "appendChild");
                return xML.appendChild(XMLObjectImpl.arg(arrobject, 0));
            }
            case 2: {
                if (xML != null) return xML.addNamespace(this.lib.castToNamespace(context, XMLObjectImpl.arg(arrobject, 0)));
                this.xmlMethodNotFound(xMLObjectImpl, "addNamespace");
                return xML.addNamespace(this.lib.castToNamespace(context, XMLObjectImpl.arg(arrobject, 0)));
            }
            case 7: {
                if (xML != null) return ScriptRuntime.wrapInt(xML.childIndex());
                this.xmlMethodNotFound(xMLObjectImpl, "childIndex");
                return ScriptRuntime.wrapInt(xML.childIndex());
            }
            case 14: {
                if (xML != null) return context.newArray(scriptable, this.toObjectArray(xML.inScopeNamespaces()));
                this.xmlMethodNotFound(xMLObjectImpl, "inScopeNamespaces");
                return context.newArray(scriptable, this.toObjectArray(xML.inScopeNamespaces()));
            }
            case 15: {
                Object object;
                if (xML == null) {
                    this.xmlMethodNotFound(xMLObjectImpl, "insertChildAfter");
                }
                if ((object = XMLObjectImpl.arg(arrobject, 0)) == null) return xML.insertChildAfter((XML)object, XMLObjectImpl.arg(arrobject, 1));
                if (!(object instanceof XML)) return Undefined.instance;
                return xML.insertChildAfter((XML)object, XMLObjectImpl.arg(arrobject, 1));
            }
            case 16: {
                Object object;
                if (xML == null) {
                    this.xmlMethodNotFound(xMLObjectImpl, "insertChildBefore");
                }
                if ((object = XMLObjectImpl.arg(arrobject, 0)) == null) return xML.insertChildBefore((XML)object, XMLObjectImpl.arg(arrobject, 1));
                if (!(object instanceof XML)) return Undefined.instance;
                return xML.insertChildBefore((XML)object, XMLObjectImpl.arg(arrobject, 1));
            }
            case 21: {
                if (xML != null) return xML.localName();
                this.xmlMethodNotFound(xMLObjectImpl, "localName");
                return xML.localName();
            }
            case 22: {
                if (xML != null) return xML.name();
                this.xmlMethodNotFound(xMLObjectImpl, "name");
                return xML.name();
            }
            case 23: {
                if (xML == null) {
                    this.xmlMethodNotFound(xMLObjectImpl, "namespace");
                }
                String string2 = arrobject.length > 0 ? ScriptRuntime.toString(arrobject[0]) : null;
                Namespace namespace = xML.namespace(string2);
                if (namespace != null) return namespace;
                return Undefined.instance;
            }
            case 24: {
                if (xML != null) return context.newArray(scriptable, this.toObjectArray(xML.namespaceDeclarations()));
                this.xmlMethodNotFound(xMLObjectImpl, "namespaceDeclarations");
                return context.newArray(scriptable, this.toObjectArray(xML.namespaceDeclarations()));
            }
            case 25: {
                if (xML != null) return xML.nodeKind();
                this.xmlMethodNotFound(xMLObjectImpl, "nodeKind");
                return xML.nodeKind();
            }
            case 28: {
                if (xML != null) return xML.prependChild(XMLObjectImpl.arg(arrobject, 0));
                this.xmlMethodNotFound(xMLObjectImpl, "prependChild");
                return xML.prependChild(XMLObjectImpl.arg(arrobject, 0));
            }
            case 31: {
                if (xML != null) return xML.removeNamespace(this.lib.castToNamespace(context, XMLObjectImpl.arg(arrobject, 0)));
                this.xmlMethodNotFound(xMLObjectImpl, "removeNamespace");
                return xML.removeNamespace(this.lib.castToNamespace(context, XMLObjectImpl.arg(arrobject, 0)));
            }
            case 32: {
                if (xML == null) {
                    this.xmlMethodNotFound(xMLObjectImpl, "replace");
                }
                XMLName xMLName = this.lib.toXMLNameOrIndex(context, XMLObjectImpl.arg(arrobject, 0));
                Object object = XMLObjectImpl.arg(arrobject, 1);
                if (xMLName != null) return xML.replace(xMLName, object);
                return xML.replace((int)ScriptRuntime.lastUint32Result(context), object);
            }
            case 33: {
                if (xML != null) return xML.setChildren(XMLObjectImpl.arg(arrobject, 0));
                this.xmlMethodNotFound(xMLObjectImpl, "setChildren");
                return xML.setChildren(XMLObjectImpl.arg(arrobject, 0));
            }
            case 34: {
                Object object;
                if (xML == null) {
                    this.xmlMethodNotFound(xMLObjectImpl, "setLocalName");
                }
                String string3 = (object = XMLObjectImpl.arg(arrobject, 0)) instanceof QName ? ((QName)object).localName() : ScriptRuntime.toString(object);
                xML.setLocalName(string3);
                return Undefined.instance;
            }
            case 35: {
                if (xML == null) {
                    this.xmlMethodNotFound(xMLObjectImpl, "setName");
                }
                Object object = arrobject.length != 0 ? arrobject[0] : Undefined.instance;
                xML.setName(this.lib.constructQName(context, object));
                return Undefined.instance;
            }
            case 36: {
                if (xML == null) {
                    this.xmlMethodNotFound(xMLObjectImpl, "setNamespace");
                }
                xML.setNamespace(this.lib.castToNamespace(context, XMLObjectImpl.arg(arrobject, 0)));
                return Undefined.instance;
            }
            case 4: {
                return xMLObjectImpl.getMatches(XMLName.create(this.lib.toNodeQName(context, XMLObjectImpl.arg(arrobject, 0), true), true, false));
            }
            case 5: {
                return xMLObjectImpl.getMatches(XMLName.create(XmlNode.QName.create(null, null), true, false));
            }
            case 6: {
                XMLName xMLName = this.lib.toXMLNameOrIndex(context, XMLObjectImpl.arg(arrobject, 0));
                if (xMLName != null) return xMLObjectImpl.child(xMLName);
                return xMLObjectImpl.child((int)ScriptRuntime.lastUint32Result(context));
            }
            case 8: {
                return xMLObjectImpl.children();
            }
            case 9: {
                return xMLObjectImpl.comments();
            }
            case 10: {
                return ScriptRuntime.wrapBoolean(xMLObjectImpl.contains(XMLObjectImpl.arg(arrobject, 0)));
            }
            case 11: {
                return xMLObjectImpl.copy();
            }
            case 12: {
                XmlNode.QName qName;
                if (arrobject.length == 0) {
                    qName = XmlNode.QName.create(null, null);
                    return xMLObjectImpl.getMatches(XMLName.create(qName, false, true));
                }
                qName = this.lib.toNodeQName(context, arrobject[0], false);
                return xMLObjectImpl.getMatches(XMLName.create(qName, false, true));
            }
            case 13: {
                XMLName xMLName;
                if (arrobject.length == 0) {
                    xMLName = XMLName.formStar();
                    return xMLObjectImpl.elements(xMLName);
                }
                xMLName = this.lib.toXMLName(context, arrobject[0]);
                return xMLObjectImpl.elements(xMLName);
            }
            case 17: {
                return ScriptRuntime.wrapBoolean(xMLObjectImpl.hasOwnProperty(this.lib.toXMLName(context, XMLObjectImpl.arg(arrobject, 0))));
            }
            case 18: {
                return ScriptRuntime.wrapBoolean(xMLObjectImpl.hasComplexContent());
            }
            case 19: {
                return ScriptRuntime.wrapBoolean(xMLObjectImpl.hasSimpleContent());
            }
            case 20: {
                return ScriptRuntime.wrapInt(xMLObjectImpl.length());
            }
            case 26: {
                xMLObjectImpl.normalize();
                return Undefined.instance;
            }
            case 27: {
                return xMLObjectImpl.parent();
            }
            case 29: {
                XMLName xMLName;
                if (arrobject.length > 0) {
                    xMLName = this.lib.toXMLName(context, arrobject[0]);
                    return xMLObjectImpl.processingInstructions(xMLName);
                }
                xMLName = XMLName.formStar();
                return xMLObjectImpl.processingInstructions(xMLName);
            }
            case 30: {
                return ScriptRuntime.wrapBoolean(xMLObjectImpl.propertyIsEnumerable(XMLObjectImpl.arg(arrobject, 0)));
            }
            case 37: {
                return xMLObjectImpl.text();
            }
            case 38: {
                return xMLObjectImpl.toString();
            }
            case 39: {
                return xMLObjectImpl.toSource(ScriptRuntime.toInt32(arrobject, 0));
            }
            case 40: {
                return xMLObjectImpl.toXMLString();
            }
            case 41: 
        }
        return xMLObjectImpl.valueOf();
    }

    final void exportAsJSClass(boolean bl) {
        this.prototypeFlag = true;
        this.exportAsJSClass(41, this.getParentScope(), bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        int n = string2.length();
        String string3 = null;
        int n2 = 0;
        block0 : switch (n) {
            case 4: {
                char c = string2.charAt(0);
                if (c == 'c') {
                    string3 = "copy";
                    n2 = 11;
                    break;
                }
                if (c == 'n') {
                    string3 = "name";
                    n2 = 22;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 't') break;
                string3 = "text";
                n2 = 37;
                break;
            }
            case 5: {
                string3 = "child";
                n2 = 6;
                break;
            }
            case 6: {
                char c = string2.charAt(0);
                if (c == 'l') {
                    string3 = "length";
                    n2 = 20;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'p') break;
                string3 = "parent";
                n2 = 27;
                break;
            }
            case 7: {
                char c = string2.charAt(0);
                if (c == 'r') {
                    string3 = "replace";
                    n2 = 32;
                    break;
                }
                if (c == 's') {
                    string3 = "setName";
                    n2 = 35;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'v') break;
                string3 = "valueOf";
                n2 = 41;
                break;
            }
            case 8: {
                switch (string2.charAt(2)) {
                    default: {
                        return 0;
                    }
                    case 'S': {
                        char c = string2.charAt(7);
                        if (c == 'e') {
                            string3 = "toSource";
                            n2 = 39;
                            break block0;
                        }
                        string3 = null;
                        n2 = 0;
                        if (c != 'g') break block0;
                        string3 = "toString";
                        n2 = 38;
                        break block0;
                    }
                    case 'd': {
                        string3 = "nodeKind";
                        n2 = 25;
                        break block0;
                    }
                    case 'e': {
                        string3 = "elements";
                        n2 = 13;
                        break block0;
                    }
                    case 'i': {
                        string3 = "children";
                        n2 = 8;
                        break block0;
                    }
                    case 'm': {
                        string3 = "comments";
                        n2 = 9;
                        break block0;
                    }
                    case 'n': 
                }
                string3 = "contains";
                n2 = 10;
                break;
            }
            case 9: {
                switch (string2.charAt(2)) {
                    default: {
                        return 0;
                    }
                    case 'c': {
                        string3 = "localName";
                        n2 = 21;
                        break block0;
                    }
                    case 'm': {
                        string3 = "namespace";
                        n2 = 23;
                        break block0;
                    }
                    case 'r': {
                        string3 = "normalize";
                        n2 = 26;
                        break block0;
                    }
                    case 't': 
                }
                string3 = "attribute";
                n2 = 4;
                break;
            }
            case 10: {
                char c = string2.charAt(0);
                if (c == 'a') {
                    string3 = "attributes";
                    n2 = 5;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'c') break;
                string3 = "childIndex";
                n2 = 7;
                break;
            }
            case 11: {
                switch (string2.charAt(0)) {
                    default: {
                        return 0;
                    }
                    case 'a': {
                        string3 = "appendChild";
                        n2 = 3;
                        break block0;
                    }
                    case 'c': {
                        string3 = "constructor";
                        n2 = 1;
                        break block0;
                    }
                    case 'd': {
                        string3 = "descendants";
                        n2 = 12;
                        break block0;
                    }
                    case 's': {
                        string3 = "setChildren";
                        n2 = 33;
                        break block0;
                    }
                    case 't': 
                }
                string3 = "toXMLString";
                n2 = 40;
                break;
            }
            case 12: {
                char c = string2.charAt(0);
                if (c == 'a') {
                    string3 = "addNamespace";
                    n2 = 2;
                    break;
                }
                if (c == 'p') {
                    string3 = "prependChild";
                    n2 = 28;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 's') break;
                char c2 = string2.charAt(3);
                if (c2 == 'L') {
                    string3 = "setLocalName";
                    n2 = 34;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c2 != 'N') break;
                string3 = "setNamespace";
                n2 = 36;
                break;
            }
            case 14: {
                string3 = "hasOwnProperty";
                n2 = 17;
                break;
            }
            case 15: {
                string3 = "removeNamespace";
                n2 = 31;
                break;
            }
            case 16: {
                char c = string2.charAt(0);
                if (c == 'h') {
                    string3 = "hasSimpleContent";
                    n2 = 19;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'i') break;
                string3 = "insertChildAfter";
                n2 = 15;
                break;
            }
            case 17: {
                char c = string2.charAt(3);
                if (c == 'C') {
                    string3 = "hasComplexContent";
                    n2 = 18;
                    break;
                }
                if (c == 'c') {
                    string3 = "inScopeNamespaces";
                    n2 = 14;
                    break;
                }
                string3 = null;
                n2 = 0;
                if (c != 'e') break;
                string3 = "insertChildBefore";
                n2 = 16;
                break;
            }
            case 20: {
                string3 = "propertyIsEnumerable";
                n2 = 30;
                break;
            }
            case 21: {
                string3 = "namespaceDeclarations";
                n2 = 24;
                break;
            }
            case 22: {
                string3 = "processingInstructions";
                n2 = 29;
                break;
            }
        }
        if (string3 == null) return n2;
        if (string3 == string2) return n2;
        if (string3.equals((Object)string2)) return n2;
        return 0;
    }

    @Override
    public Object get(String string2, Scriptable scriptable) {
        Context context = Context.getCurrentContext();
        return this.getXMLProperty(this.lib.toXMLNameFromString(context, string2));
    }

    @Override
    public final Object get(Context context, Object object) {
        XMLName xMLName;
        if (context == null) {
            context = Context.getCurrentContext();
        }
        if ((xMLName = this.lib.toXMLNameOrIndex(context, object)) == null) {
            Object object2 = this.get((int)ScriptRuntime.lastUint32Result(context), (Scriptable)this);
            if (object2 == Scriptable.NOT_FOUND) {
                object2 = Undefined.instance;
            }
            return object2;
        }
        return this.getXMLProperty(xMLName);
    }

    @Override
    public final Object getDefaultValue(Class<?> class_) {
        return this.toString();
    }

    @Override
    public Object getFunctionProperty(Context context, int n) {
        if (this.isPrototype()) {
            return super.get(n, (Scriptable)this);
        }
        Scriptable scriptable = this.getPrototype();
        if (scriptable instanceof XMLObject) {
            return ((XMLObject)scriptable).getFunctionProperty(context, n);
        }
        return NOT_FOUND;
    }

    @Override
    public Object getFunctionProperty(Context context, String string2) {
        if (this.isPrototype()) {
            return super.get(string2, this);
        }
        Scriptable scriptable = this.getPrototype();
        if (scriptable instanceof XMLObject) {
            return ((XMLObject)scriptable).getFunctionProperty(context, string2);
        }
        return NOT_FOUND;
    }

    XMLLibImpl getLib() {
        return this.lib;
    }

    @Override
    public final Scriptable getParentScope() {
        return super.getParentScope();
    }

    final XmlProcessor getProcessor() {
        return this.lib.getProcessor();
    }

    @Override
    public final Scriptable getPrototype() {
        return super.getPrototype();
    }

    abstract XML getXML();

    abstract Object getXMLProperty(XMLName var1);

    @Override
    public boolean has(String string2, Scriptable scriptable) {
        Context context = Context.getCurrentContext();
        return this.hasXMLProperty(this.lib.toXMLNameFromString(context, string2));
    }

    @Override
    public final boolean has(Context context, Object object) {
        XMLName xMLName;
        if (context == null) {
            context = Context.getCurrentContext();
        }
        if ((xMLName = this.lib.toXMLNameOrIndex(context, object)) == null) {
            return this.has((int)ScriptRuntime.lastUint32Result(context), (Scriptable)this);
        }
        return this.hasXMLProperty(xMLName);
    }

    abstract boolean hasComplexContent();

    @Override
    public final boolean hasInstance(Scriptable scriptable) {
        return super.hasInstance(scriptable);
    }

    abstract boolean hasOwnProperty(XMLName var1);

    abstract boolean hasSimpleContent();

    abstract boolean hasXMLProperty(XMLName var1);

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        int n2;
        String string2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                IdFunctionObject idFunctionObject = this instanceof XML ? new XMLCtor((XML)this, XMLOBJECT_TAG, n, 1) : new IdFunctionObject(this, XMLOBJECT_TAG, n, 1);
                this.initPrototypeConstructor(idFunctionObject);
                return;
            }
            case 2: {
                n2 = 1;
                string2 = "addNamespace";
                break;
            }
            case 3: {
                n2 = 1;
                string2 = "appendChild";
                break;
            }
            case 4: {
                n2 = 1;
                string2 = "attribute";
                break;
            }
            case 5: {
                string2 = "attributes";
                n2 = 0;
                break;
            }
            case 6: {
                n2 = 1;
                string2 = "child";
                break;
            }
            case 7: {
                string2 = "childIndex";
                n2 = 0;
                break;
            }
            case 8: {
                string2 = "children";
                n2 = 0;
                break;
            }
            case 9: {
                string2 = "comments";
                n2 = 0;
                break;
            }
            case 10: {
                n2 = 1;
                string2 = "contains";
                break;
            }
            case 11: {
                string2 = "copy";
                n2 = 0;
                break;
            }
            case 12: {
                n2 = 1;
                string2 = "descendants";
                break;
            }
            case 13: {
                n2 = 1;
                string2 = "elements";
                break;
            }
            case 18: {
                string2 = "hasComplexContent";
                n2 = 0;
                break;
            }
            case 17: {
                n2 = 1;
                string2 = "hasOwnProperty";
                break;
            }
            case 19: {
                string2 = "hasSimpleContent";
                n2 = 0;
                break;
            }
            case 14: {
                string2 = "inScopeNamespaces";
                n2 = 0;
                break;
            }
            case 15: {
                n2 = 2;
                string2 = "insertChildAfter";
                break;
            }
            case 16: {
                n2 = 2;
                string2 = "insertChildBefore";
                break;
            }
            case 20: {
                string2 = "length";
                n2 = 0;
                break;
            }
            case 21: {
                string2 = "localName";
                n2 = 0;
                break;
            }
            case 22: {
                string2 = "name";
                n2 = 0;
                break;
            }
            case 23: {
                n2 = 1;
                string2 = "namespace";
                break;
            }
            case 24: {
                string2 = "namespaceDeclarations";
                n2 = 0;
                break;
            }
            case 25: {
                string2 = "nodeKind";
                n2 = 0;
                break;
            }
            case 26: {
                string2 = "normalize";
                n2 = 0;
                break;
            }
            case 27: {
                string2 = "parent";
                n2 = 0;
                break;
            }
            case 28: {
                n2 = 1;
                string2 = "prependChild";
                break;
            }
            case 29: {
                n2 = 1;
                string2 = "processingInstructions";
                break;
            }
            case 30: {
                n2 = 1;
                string2 = "propertyIsEnumerable";
                break;
            }
            case 31: {
                n2 = 1;
                string2 = "removeNamespace";
                break;
            }
            case 32: {
                n2 = 2;
                string2 = "replace";
                break;
            }
            case 33: {
                n2 = 1;
                string2 = "setChildren";
                break;
            }
            case 34: {
                n2 = 1;
                string2 = "setLocalName";
                break;
            }
            case 35: {
                n2 = 1;
                string2 = "setName";
                break;
            }
            case 36: {
                n2 = 1;
                string2 = "setNamespace";
                break;
            }
            case 37: {
                string2 = "text";
                n2 = 0;
                break;
            }
            case 38: {
                string2 = "toString";
                n2 = 0;
                break;
            }
            case 39: {
                n2 = 1;
                string2 = "toSource";
                break;
            }
            case 40: {
                n2 = 1;
                string2 = "toXMLString";
                break;
            }
            case 41: {
                string2 = "valueOf";
                n2 = 0;
            }
        }
        this.initPrototypeMethod(XMLOBJECT_TAG, n, string2, n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    final void initialize(XMLLibImpl xMLLibImpl, Scriptable scriptable, XMLObject xMLObject) {
        this.setParentScope(scriptable);
        this.setPrototype(xMLObject);
        boolean bl = xMLObject == null;
        this.prototypeFlag = bl;
        this.lib = xMLLibImpl;
    }

    final boolean isPrototype() {
        return this.prototypeFlag;
    }

    protected abstract Object jsConstructor(Context var1, boolean var2, Object[] var3);

    abstract int length();

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Ref memberRef(Context context, Object object, int n) {
        boolean bl = true;
        boolean bl2 = (n & 2) != 0 ? bl : false;
        if ((n & 4) == 0) {
            bl = false;
        }
        if (!bl2 && !bl) {
            throw Kit.codeBug();
        }
        XMLName xMLName = XMLName.create(this.lib.toNodeQName(context, object, bl2), bl2, bl);
        xMLName.initXMLObject(this);
        return xMLName;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Ref memberRef(Context context, Object object, Object object2, int n) {
        boolean bl = true;
        boolean bl2 = (n & 2) != 0 ? bl : false;
        if ((n & 4) == 0) {
            bl = false;
        }
        XMLName xMLName = XMLName.create(this.lib.toNodeQName(context, object, object2), bl2, bl);
        xMLName.initXMLObject(this);
        return xMLName;
    }

    final QName newQName(String string2, String string3, String string4) {
        return this.lib.newQName(string2, string3, string4);
    }

    final QName newQName(XmlNode.QName qName) {
        return this.lib.newQName(qName);
    }

    final XML newTextElementXML(XmlNode xmlNode, XmlNode.QName qName, String string2) {
        return this.lib.newTextElementXML(xmlNode, qName, string2);
    }

    final XML newXML(XmlNode xmlNode) {
        return this.lib.newXML(xmlNode);
    }

    final XML newXMLFromJs(Object object) {
        return this.lib.newXMLFromJs(object);
    }

    final XMLList newXMLList() {
        return this.lib.newXMLList();
    }

    final XMLList newXMLListFrom(Object object) {
        return this.lib.newXMLListFrom(object);
    }

    abstract void normalize();

    abstract Object parent();

    abstract XMLList processingInstructions(XMLName var1);

    abstract boolean propertyIsEnumerable(Object var1);

    @Override
    public void put(String string2, Scriptable scriptable, Object object) {
        Context context = Context.getCurrentContext();
        this.putXMLProperty(this.lib.toXMLNameFromString(context, string2), object);
    }

    @Override
    public final void put(Context context, Object object, Object object2) {
        XMLName xMLName;
        if (context == null) {
            context = Context.getCurrentContext();
        }
        if ((xMLName = this.lib.toXMLNameOrIndex(context, object)) == null) {
            this.put((int)ScriptRuntime.lastUint32Result(context), (Scriptable)this, object2);
            return;
        }
        this.putXMLProperty(xMLName, object2);
    }

    abstract void putXMLProperty(XMLName var1, Object var2);

    @Override
    public final void setParentScope(Scriptable scriptable) {
        super.setParentScope(scriptable);
    }

    @Override
    public final void setPrototype(Scriptable scriptable) {
        super.setPrototype(scriptable);
    }

    abstract XMLList text();

    abstract String toSource(int var1);

    public abstract String toString();

    abstract String toXMLString();

    abstract Object valueOf();

    XML xmlFromNode(XmlNode xmlNode) {
        if (xmlNode.getXml() == null) {
            xmlNode.setXml(this.newXML(xmlNode));
        }
        return xmlNode.getXml();
    }
}

