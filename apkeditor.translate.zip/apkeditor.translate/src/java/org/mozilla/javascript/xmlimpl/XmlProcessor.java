/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.Reader
 *  java.io.Serializable
 *  java.io.StringReader
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.ClassNotFoundException
 *  java.lang.Object
 *  java.lang.Runtime
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.LinkedBlockingDeque
 *  javax.xml.parsers.DocumentBuilder
 *  javax.xml.parsers.DocumentBuilderFactory
 *  javax.xml.parsers.ParserConfigurationException
 *  javax.xml.transform.Result
 *  javax.xml.transform.Source
 *  javax.xml.transform.Transformer
 *  javax.xml.transform.TransformerConfigurationException
 *  javax.xml.transform.TransformerException
 *  javax.xml.transform.TransformerFactory
 *  javax.xml.transform.dom.DOMSource
 *  javax.xml.transform.stream.StreamResult
 *  org.w3c.dom.Attr
 *  org.w3c.dom.Comment
 *  org.w3c.dom.Document
 *  org.w3c.dom.Element
 *  org.w3c.dom.Node
 *  org.w3c.dom.NodeList
 *  org.w3c.dom.ProcessingInstruction
 *  org.w3c.dom.Text
 *  org.xml.sax.ErrorHandler
 *  org.xml.sax.InputSource
 *  org.xml.sax.SAXException
 *  org.xml.sax.SAXParseException
 */
package org.mozilla.javascript.xmlimpl;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.LinkedBlockingDeque;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.xmlimpl.XMLObjectImpl;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

class XmlProcessor
implements Serializable {
    private static final long serialVersionUID = 6903514433204808713L;
    private transient LinkedBlockingDeque<DocumentBuilder> documentBuilderPool;
    private transient DocumentBuilderFactory dom;
    private RhinoSAXErrorHandler errorHandler = new RhinoSAXErrorHandler();
    private boolean ignoreComments;
    private boolean ignoreProcessingInstructions;
    private boolean ignoreWhitespace;
    private int prettyIndent;
    private boolean prettyPrint;
    private transient TransformerFactory xform;

    XmlProcessor() {
        this.setDefault();
        this.dom = DocumentBuilderFactory.newInstance();
        this.dom.setNamespaceAware(true);
        this.dom.setIgnoringComments(false);
        this.xform = TransformerFactory.newInstance();
        this.documentBuilderPool = new LinkedBlockingDeque(2 * Runtime.getRuntime().availableProcessors());
    }

    private void addCommentsTo(List<Node> list, Node node) {
        if (node instanceof Comment) {
            list.add((Object)node);
        }
        if (node.getChildNodes() != null) {
            for (int i = 0; i < node.getChildNodes().getLength(); ++i) {
                this.addProcessingInstructionsTo(list, node.getChildNodes().item(i));
            }
        }
    }

    private void addProcessingInstructionsTo(List<Node> list, Node node) {
        if (node instanceof ProcessingInstruction) {
            list.add((Object)node);
        }
        if (node.getChildNodes() != null) {
            for (int i = 0; i < node.getChildNodes().getLength(); ++i) {
                this.addProcessingInstructionsTo(list, node.getChildNodes().item(i));
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void addTextNodesToRemoveAndTrim(List<Node> list, Node node) {
        if (node instanceof Text) {
            Text text = (Text)node;
            if (!false) {
                text.setData(text.getData().trim());
            } else if (text.getData().trim().length() == 0) {
                text.setData("");
            }
            if (text.getData().length() == 0) {
                list.add((Object)node);
            }
        }
        if (node.getChildNodes() != null) {
            for (int i = 0; i < node.getChildNodes().getLength(); ++i) {
                this.addTextNodesToRemoveAndTrim(list, node.getChildNodes().item(i));
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void beautifyElement(Element element, int n) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('\n');
        for (int i = 0; i < n; ++i) {
            stringBuilder.append(' ');
        }
        String string2 = stringBuilder.toString();
        for (int i = 0; i < this.prettyIndent; ++i) {
            stringBuilder.append(' ');
        }
        String string3 = stringBuilder.toString();
        ArrayList arrayList = new ArrayList();
        boolean bl = false;
        for (int i = 0; i < element.getChildNodes().getLength(); ++i) {
            if (i == 1) {
                bl = true;
            }
            if (element.getChildNodes().item(i) instanceof Text) {
                arrayList.add((Object)element.getChildNodes().item(i));
                continue;
            }
            bl = true;
            arrayList.add((Object)element.getChildNodes().item(i));
        }
        if (bl) {
            for (int i = 0; i < arrayList.size(); ++i) {
                element.insertBefore((Node)element.getOwnerDocument().createTextNode(string3), (Node)arrayList.get(i));
            }
        }
        NodeList nodeList = element.getChildNodes();
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < nodeList.getLength(); ++i) {
            if (!(nodeList.item(i) instanceof Element)) continue;
            arrayList2.add((Object)((Element)nodeList.item(i)));
        }
        Iterator iterator = arrayList2.iterator();
        while (iterator.hasNext()) {
            this.beautifyElement((Element)iterator.next(), n + this.prettyIndent);
        }
        if (bl) {
            element.appendChild((Node)element.getOwnerDocument().createTextNode(string2));
        }
    }

    private String elementToXmlString(Element element) {
        Element element2 = (Element)element.cloneNode(true);
        if (this.prettyPrint) {
            this.beautifyElement(element2, 0);
        }
        return this.toString((Node)element2);
    }

    private String escapeElementValue(String string2) {
        return this.escapeTextValue(string2);
    }

    private DocumentBuilder getDocumentBuilderFromPool() throws ParserConfigurationException {
        DocumentBuilder documentBuilder = (DocumentBuilder)this.documentBuilderPool.pollFirst();
        if (documentBuilder == null) {
            documentBuilder = this.getDomFactory().newDocumentBuilder();
        }
        documentBuilder.setErrorHandler((ErrorHandler)this.errorHandler);
        return documentBuilder;
    }

    private DocumentBuilderFactory getDomFactory() {
        return this.dom;
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        this.dom = DocumentBuilderFactory.newInstance();
        this.dom.setNamespaceAware(true);
        this.dom.setIgnoringComments(false);
        this.xform = TransformerFactory.newInstance();
        this.documentBuilderPool = new LinkedBlockingDeque(2 * Runtime.getRuntime().availableProcessors());
    }

    private void returnDocumentBuilderToPool(DocumentBuilder documentBuilder) {
        try {
            documentBuilder.reset();
            this.documentBuilderPool.offerFirst((Object)documentBuilder);
            return;
        }
        catch (UnsupportedOperationException unsupportedOperationException) {
            return;
        }
    }

    private String toString(Node node) {
        DOMSource dOMSource = new DOMSource(node);
        StringWriter stringWriter = new StringWriter();
        StreamResult streamResult = new StreamResult((Writer)stringWriter);
        try {
            Transformer transformer = this.xform.newTransformer();
            transformer.setOutputProperty("omit-xml-declaration", "yes");
            transformer.setOutputProperty("indent", "no");
            transformer.setOutputProperty("method", "xml");
            transformer.transform((Source)dOMSource, (Result)streamResult);
        }
        catch (TransformerConfigurationException transformerConfigurationException) {
            throw new RuntimeException((Throwable)transformerConfigurationException);
        }
        catch (TransformerException transformerException) {
            throw new RuntimeException((Throwable)transformerException);
        }
        return this.toXmlNewlines(stringWriter.toString());
    }

    /*
     * Enabled aggressive block sorting
     */
    private String toXmlNewlines(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        while (n < string2.length()) {
            if (string2.charAt(n) == '\r') {
                if (string2.charAt(n + 1) != '\n') {
                    stringBuilder.append('\n');
                }
            } else {
                stringBuilder.append(string2.charAt(n));
            }
            ++n;
        }
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    final String ecmaToXmlString(Node node) {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.prettyPrint) {
            for (int i = 0; i < 0; ++i) {
                stringBuilder.append(' ');
            }
        }
        if (node instanceof Text) {
            String string2 = ((Text)node).getData();
            String string3 = this.prettyPrint ? string2.trim() : string2;
            stringBuilder.append(this.escapeElementValue(string3));
            return stringBuilder.toString();
        }
        if (node instanceof Attr) {
            stringBuilder.append(this.escapeAttributeValue(((Attr)node).getValue()));
            return stringBuilder.toString();
        }
        if (node instanceof Comment) {
            stringBuilder.append("<!--" + ((Comment)node).getNodeValue() + "-->");
            return stringBuilder.toString();
        }
        if (node instanceof ProcessingInstruction) {
            ProcessingInstruction processingInstruction = (ProcessingInstruction)node;
            stringBuilder.append("<?" + processingInstruction.getTarget() + " " + processingInstruction.getData() + "?>");
            return stringBuilder.toString();
        }
        stringBuilder.append(this.elementToXmlString((Element)node));
        return stringBuilder.toString();
    }

    String escapeAttributeValue(Object object) {
        String string2 = ScriptRuntime.toString(object);
        if (string2.length() == 0) {
            return "";
        }
        Element element = this.newDocument().createElement("a");
        element.setAttribute("b", string2);
        String string3 = this.toString((Node)element);
        int n = string3.indexOf(34);
        int n2 = string3.lastIndexOf(34);
        return string3.substring(n + 1, n2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    String escapeTextValue(Object object) {
        if (object instanceof XMLObjectImpl) {
            return ((XMLObjectImpl)object).toXMLString();
        }
        String string2 = ScriptRuntime.toString(object);
        if (string2.length() == 0) return string2;
        Element element = this.newDocument().createElement("a");
        element.setTextContent(string2);
        String string3 = this.toString((Node)element);
        int n = 1 + string3.indexOf(62);
        int n2 = string3.lastIndexOf(60);
        if (n >= n2) return "";
        return string3.substring(n, n2);
    }

    final int getPrettyIndent() {
        return this.prettyIndent;
    }

    final boolean isIgnoreComments() {
        return this.ignoreComments;
    }

    final boolean isIgnoreProcessingInstructions() {
        return this.ignoreProcessingInstructions;
    }

    final boolean isIgnoreWhitespace() {
        return this.ignoreWhitespace;
    }

    final boolean isPrettyPrinting() {
        return this.prettyPrint;
    }

    Document newDocument() {
        DocumentBuilder documentBuilder = null;
        try {
            documentBuilder = this.getDocumentBuilderFromPool();
            Document document = documentBuilder.newDocument();
            return document;
        }
        catch (ParserConfigurationException parserConfigurationException) {
            throw new RuntimeException((Throwable)parserConfigurationException);
        }
        finally {
            if (documentBuilder != null) {
                this.returnDocumentBuilderToPool(documentBuilder);
            }
        }
    }

    final void setDefault() {
        this.setIgnoreComments(true);
        this.setIgnoreProcessingInstructions(true);
        this.setIgnoreWhitespace(true);
        this.setPrettyPrinting(true);
        this.setPrettyIndent(2);
    }

    final void setIgnoreComments(boolean bl) {
        this.ignoreComments = bl;
    }

    final void setIgnoreProcessingInstructions(boolean bl) {
        this.ignoreProcessingInstructions = bl;
    }

    final void setIgnoreWhitespace(boolean bl) {
        this.ignoreWhitespace = bl;
    }

    final void setPrettyIndent(int n) {
        this.prettyIndent = n;
    }

    final void setPrettyPrinting(boolean bl) {
        this.prettyPrint = bl;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    final Node toXml(String var1_1, String var2_2) throws SAXException {
        var3_3 = null;
        try {
            var7_4 = "<parent xmlns=\"" + var1_1 + "\">" + var2_2 + "</parent>";
            var3_3 = this.getDocumentBuilderFromPool();
            var8_5 = var3_3.parse(new InputSource((Reader)new StringReader(var7_4)));
            if (!this.ignoreProcessingInstructions) ** GOTO lbl-1000
            var9_6 = new ArrayList();
            this.addProcessingInstructionsTo((List<Node>)var9_6, (Node)var8_5);
            for (Node var23_8 : var9_6) {
                var23_8.getParentNode().removeChild(var23_8);
            }
lbl-1000: // 2 sources:
            {
                block15 : {
                    block14 : {
                        if (!this.ignoreComments) break block14;
                        var11_11 = new ArrayList();
                        this.addCommentsTo((List<Node>)var11_11, (Node)var8_5);
                        for (Node var21_13 : var11_11) {
                            var21_13.getParentNode().removeChild(var21_13);
                        }
                    }
                    if (this.ignoreWhitespace) {
                        var13_15 = new ArrayList();
                        this.addTextNodesToRemoveAndTrim((List<Node>)var13_15, (Node)var8_5);
                        for (Node var19_17 : var13_15) {
                            var19_17.getParentNode().removeChild(var19_17);
                        }
                    }
                    if ((var15_18 = var8_5.getDocumentElement().getChildNodes()).getLength() > 1) {
                        throw ScriptRuntime.constructError("SyntaxError", "XML objects may contain at most one node.");
                    }
                    if (var15_18.getLength() != 0) break block15;
                    var18_19 = var8_5.createTextNode("");
                    if (var3_3 == null) return var18_19;
                    this.returnDocumentBuilderToPool(var3_3);
                    return var18_19;
                }
                try {
                    var16_20 = var15_18.item(0);
                    var8_5.getDocumentElement().removeChild(var16_20);
                    if (var3_3 == null) return var16_20;
                }
                catch (IOException var6_9) {}
                throw new RuntimeException("Unreachable.");
            }
        }
        catch (Throwable var5_10) {
            if (var3_3 == null) throw var5_10;
            this.returnDocumentBuilderToPool(var3_3);
            throw var5_10;
        }
        catch (ParserConfigurationException var4_14) {
            throw new RuntimeException((Throwable)var4_14);
        }
        this.returnDocumentBuilderToPool(var3_3);
        return var16_20;
    }

    private static class RhinoSAXErrorHandler
    implements ErrorHandler,
    Serializable {
        private static final long serialVersionUID = 6918417235413084055L;

        private RhinoSAXErrorHandler() {
        }

        private void throwError(SAXParseException sAXParseException) {
            throw ScriptRuntime.constructError("TypeError", sAXParseException.getMessage(), -1 + sAXParseException.getLineNumber());
        }

        public void error(SAXParseException sAXParseException) {
            this.throwError(sAXParseException);
        }

        public void fatalError(SAXParseException sAXParseException) {
            this.throwError(sAXParseException);
        }

        public void warning(SAXParseException sAXParseException) {
            Context.reportWarning(sAXParseException.getMessage());
        }
    }

}

