/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript.xmlimpl;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.EcmaError;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.Ref;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.xmlimpl.XML;
import org.mozilla.javascript.xmlimpl.XMLList;
import org.mozilla.javascript.xmlimpl.XMLObjectImpl;
import org.mozilla.javascript.xmlimpl.XmlNode;

class XMLName
extends Ref {
    static final long serialVersionUID = 3832176310755686977L;
    private boolean isAttributeName;
    private boolean isDescendants;
    private XmlNode.QName qname;
    private XMLObjectImpl xmlObject;

    private XMLName() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static boolean accept(Object object) {
        String string2;
        try {
            string2 = ScriptRuntime.toString(object);
        }
        catch (EcmaError ecmaError) {
            if ("TypeError".equals((Object)ecmaError.getName())) return false;
            {
                throw ecmaError;
            }
        }
        int n = string2.length();
        if (n == 0 || !XMLName.isNCNameStartChar(string2.charAt(0))) return false;
        int n2 = 1;
        while (n2 != n) {
            if (!XMLName.isNCNameChar(string2.charAt(n2))) {
                return false;
            }
            ++n2;
        }
        return true;
    }

    private void addAttributes(XMLList xMLList, XML xML) {
        this.addMatchingAttributes(xMLList, xML);
    }

    private void addDescendantAttributes(XMLList xMLList, XML xML) {
        if (xML.isElement()) {
            this.addMatchingAttributes(xMLList, xML);
            XML[] arrxML = xML.getChildren();
            for (int i = 0; i < arrxML.length; ++i) {
                this.addDescendantAttributes(xMLList, arrxML[i]);
            }
        }
    }

    private void addDescendantChildren(XMLList xMLList, XML xML) {
        if (xML.isElement()) {
            XML[] arrxML = xML.getChildren();
            for (int i = 0; i < arrxML.length; ++i) {
                if (this.matches(arrxML[i])) {
                    xMLList.addToList(arrxML[i]);
                }
                this.addDescendantChildren(xMLList, arrxML[i]);
            }
        }
    }

    static XMLName create(String string2, String string3) {
        if (string3 == null) {
            throw new IllegalArgumentException();
        }
        int n = string3.length();
        if (n != 0) {
            char c = string3.charAt(0);
            if (c == '*') {
                if (n == 1) {
                    return XMLName.formStar();
                }
            } else if (c == '@') {
                XMLName xMLName = XMLName.formProperty("", string3.substring(1));
                xMLName.setAttributeName();
                return xMLName;
            }
        }
        return XMLName.formProperty(string2, string3);
    }

    @Deprecated
    static XMLName create(XmlNode.QName qName) {
        return XMLName.create(qName, false, false);
    }

    static XMLName create(XmlNode.QName qName, boolean bl, boolean bl2) {
        XMLName xMLName = new XMLName();
        xMLName.qname = qName;
        xMLName.isAttributeName = bl;
        xMLName.isDescendants = bl2;
        return xMLName;
    }

    static XMLName formProperty(String string2, String string3) {
        return XMLName.formProperty(XmlNode.Namespace.create(string2), string3);
    }

    @Deprecated
    static XMLName formProperty(XmlNode.Namespace namespace, String string2) {
        if (string2 != null && string2.equals((Object)"*")) {
            string2 = null;
        }
        XMLName xMLName = new XMLName();
        xMLName.qname = XmlNode.QName.create(namespace, string2);
        return xMLName;
    }

    static XMLName formStar() {
        XMLName xMLName = new XMLName();
        xMLName.qname = XmlNode.QName.create(null, null);
        return xMLName;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean isNCNameChar(int n) {
        if ((n & -128) == 0) {
            if (n >= 97) {
                if (n > 122) return false;
                return true;
            }
            if (n >= 65) {
                if (n <= 90) return true;
                if (n == 95) return true;
                return false;
            }
            if (n >= 48) {
                if (n <= 57) return true;
                return false;
            }
            if (n == 45) return true;
            boolean bl = false;
            if (n != 46) return bl;
            return true;
        }
        if ((n & -8192) == 0) {
            if (XMLName.isNCNameStartChar(n)) return true;
            if (n == 183) return true;
            boolean bl = false;
            if (768 > n) return bl;
            bl = false;
            if (n > 879) return bl;
            return true;
        }
        if (XMLName.isNCNameStartChar(n)) return true;
        boolean bl = false;
        if (8255 > n) return bl;
        bl = false;
        if (n > 8256) return bl;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean isNCNameStartChar(int n) {
        if ((n & -128) == 0) {
            if (n >= 97) {
                if (n <= 122) return true;
                return false;
            }
            if (n >= 65) {
                if (n <= 90 || n == 95) return true;
                return false;
            }
        } else if ((n & -8192) == 0) {
            if (192 <= n && n <= 214 || 216 <= n && n <= 246 || 248 <= n && n <= 767 || 880 <= n && n <= 893 || 895 <= n) return true;
            return false;
        }
        if (!(8204 <= n && n <= 8205 || 8304 <= n && n <= 8591 || 11264 <= n && n <= 12271 || 12289 <= n && n <= 55295 || 63744 <= n && n <= 64975 || 65008 <= n && n <= 65533) && (65536 > n || n > 983039)) return false;
        return true;
    }

    void addDescendants(XMLList xMLList, XML xML) {
        if (this.isAttributeName()) {
            this.matchDescendantAttributes(xMLList, xML);
            return;
        }
        this.matchDescendantChildren(xMLList, xML);
    }

    void addMatches(XMLList xMLList, XML xML) {
        if (this.isDescendants()) {
            this.addDescendants(xMLList, xML);
            return;
        }
        if (this.isAttributeName()) {
            this.addAttributes(xMLList, xML);
            return;
        }
        XML[] arrxML = xML.getChildren();
        if (arrxML != null) {
            for (int i = 0; i < arrxML.length; ++i) {
                if (!this.matches(arrxML[i])) continue;
                xMLList.addToList(arrxML[i]);
            }
        }
        xMLList.setTargets(xML, this.toQname());
    }

    void addMatchingAttributes(XMLList xMLList, XML xML) {
        if (xML.isElement()) {
            XML[] arrxML = xML.getAttributes();
            for (int i = 0; i < arrxML.length; ++i) {
                if (!this.matches(arrxML[i])) continue;
                xMLList.addToList(arrxML[i]);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean delete(Context context) {
        block3 : {
            block2 : {
                if (this.xmlObject == null) break block2;
                this.xmlObject.deleteXMLProperty(this);
                if (this.xmlObject.hasXMLProperty(this)) break block3;
            }
            return true;
        }
        return false;
    }

    @Override
    public Object get(Context context) {
        if (this.xmlObject == null) {
            throw ScriptRuntime.undefReadError(Undefined.instance, this.toString());
        }
        return this.xmlObject.getXMLProperty(this);
    }

    XMLList getMyValueOn(XML xML) {
        XMLList xMLList = xML.newXMLList();
        this.addMatches(xMLList, xML);
        return xMLList;
    }

    @Override
    public boolean has(Context context) {
        if (this.xmlObject == null) {
            return false;
        }
        return this.xmlObject.hasXMLProperty(this);
    }

    void initXMLObject(XMLObjectImpl xMLObjectImpl) {
        if (xMLObjectImpl == null) {
            throw new IllegalArgumentException();
        }
        if (this.xmlObject != null) {
            throw new IllegalStateException();
        }
        this.xmlObject = xMLObjectImpl;
    }

    boolean isAttributeName() {
        return this.isAttributeName;
    }

    boolean isDescendants() {
        return this.isDescendants;
    }

    String localName() {
        if (this.qname.getLocalName() == null) {
            return "*";
        }
        return this.qname.getLocalName();
    }

    XMLList matchDescendantAttributes(XMLList xMLList, XML xML) {
        xMLList.setTargets(xML, null);
        this.addDescendantAttributes(xMLList, xML);
        return xMLList;
    }

    XMLList matchDescendantChildren(XMLList xMLList, XML xML) {
        xMLList.setTargets(xML, null);
        this.addDescendantChildren(xMLList, xML);
        return xMLList;
    }

    /*
     * Enabled aggressive block sorting
     */
    final boolean matches(XML xML) {
        XmlNode.QName qName = xML.getNodeQname();
        XmlNode.Namespace namespace = qName.getNamespace();
        String string2 = null;
        if (namespace != null) {
            string2 = qName.getNamespace().getUri();
        }
        if (this.isAttributeName) {
            if (!xML.isAttribute()) {
                return false;
            }
            if ((this.uri() == null || this.uri().equals((Object)string2)) && (this.localName().equals((Object)"*") || this.localName().equals((Object)qName.getLocalName()))) return true;
            return false;
        }
        if (this.uri() != null && (!xML.isElement() || !this.uri().equals((Object)string2)) || !this.localName().equals((Object)"*") && (!xML.isElement() || !this.localName().equals((Object)qName.getLocalName()))) return false;
        return true;
    }

    final boolean matchesElement(XmlNode.QName qName) {
        return !(this.uri() != null && !this.uri().equals((Object)qName.getNamespace().getUri()) || !this.localName().equals((Object)"*") && !this.localName().equals((Object)qName.getLocalName()));
    }

    final boolean matchesLocalName(String string2) {
        return this.localName().equals((Object)"*") || this.localName().equals((Object)string2);
    }

    @Override
    public Object set(Context context, Object object) {
        if (this.xmlObject == null) {
            throw ScriptRuntime.undefWriteError(Undefined.instance, this.toString(), object);
        }
        if (this.isDescendants) {
            throw Kit.codeBug();
        }
        this.xmlObject.putXMLProperty(this, object);
        return object;
    }

    void setAttributeName() {
        this.isAttributeName = true;
    }

    @Deprecated
    void setIsDescendants() {
        this.isDescendants = true;
    }

    /*
     * Enabled aggressive block sorting
     */
    void setMyValueOn(XML xML, Object object) {
        XMLList xMLList;
        XMLObjectImpl xMLObjectImpl;
        if (object == null) {
            object = "null";
        } else if (object instanceof Undefined) {
            object = "undefined";
        }
        if (this.isAttributeName()) {
            xML.setAttribute(this, object);
            return;
        }
        if (this.uri() == null && this.localName().equals((Object)"*")) {
            xML.setChildren(object);
            return;
        }
        if (object instanceof XMLObjectImpl) {
            xMLObjectImpl = (XMLObjectImpl)object;
            if (xMLObjectImpl instanceof XML && ((XML)xMLObjectImpl).isAttribute()) {
                xMLObjectImpl = xML.makeXmlFromString(this, xMLObjectImpl.toString());
            }
            if (xMLObjectImpl instanceof XMLList) {
                for (int i = 0; i < xMLObjectImpl.length(); ++i) {
                    XML xML2 = ((XMLList)xMLObjectImpl).item(i);
                    if (!xML2.isAttribute()) continue;
                    ((XMLList)xMLObjectImpl).replace(i, xML.makeXmlFromString(this, xML2.toString()));
                }
            }
        } else {
            xMLObjectImpl = xML.makeXmlFromString(this, ScriptRuntime.toString(object));
        }
        if ((xMLList = xML.getPropertyList(this)).length() == 0) {
            xML.appendChild(xMLObjectImpl);
            return;
        }
        int n = 1;
        do {
            if (n >= xMLList.length()) {
                xML.replace(xMLList.item(0).childIndex(), (Object)xMLObjectImpl);
                return;
            }
            xML.removeChild(xMLList.item(n).childIndex());
            ++n;
        } while (true);
    }

    final XmlNode.QName toQname() {
        return this.qname;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.isDescendants) {
            stringBuilder.append("..");
        }
        if (this.isAttributeName) {
            stringBuilder.append('@');
        }
        if (this.uri() == null) {
            stringBuilder.append('*');
            if (this.localName().equals((Object)"*")) {
                return stringBuilder.toString();
            }
        } else {
            stringBuilder.append('\"').append(this.uri()).append('\"');
        }
        stringBuilder.append(':').append(this.localName());
        return stringBuilder.toString();
    }

    String uri() {
        if (this.qname.getNamespace() == null) {
            return null;
        }
        return this.qname.getNamespace().getUri();
    }
}

