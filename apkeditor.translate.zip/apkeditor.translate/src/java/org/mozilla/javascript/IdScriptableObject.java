/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.System
 */
package org.mozilla.javascript;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.EcmaError;
import org.mozilla.javascript.IdFunctionCall;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.UniqueTag;

public abstract class IdScriptableObject
extends ScriptableObject
implements IdFunctionCall {
    private transient PrototypeValues prototypeValues;

    public IdScriptableObject() {
    }

    public IdScriptableObject(Scriptable scriptable, Scriptable scriptable2) {
        super(scriptable, scriptable2);
    }

    private ScriptableObject getBuiltInDescriptor(String string2) {
        int n;
        int n2;
        Scriptable scriptable = this.getParentScope();
        if (scriptable == null) {
            scriptable = this;
        }
        if ((n = this.findInstanceIdInfo(string2)) != 0) {
            return IdScriptableObject.buildDataDescriptor(scriptable, this.getInstanceIdValue(n & 65535), n >>> 16);
        }
        if (this.prototypeValues != null && (n2 = this.prototypeValues.findId(string2)) != 0) {
            return IdScriptableObject.buildDataDescriptor(scriptable, this.prototypeValues.get(n2), this.prototypeValues.getAttributes(n2));
        }
        return null;
    }

    protected static EcmaError incompatibleCallError(IdFunctionObject idFunctionObject) {
        throw ScriptRuntime.typeError1("msg.incompat.call", idFunctionObject.getFunctionName());
    }

    protected static int instanceIdInfo(int n, int n2) {
        return n2 | n << 16;
    }

    private IdFunctionObject newIdFunction(Object object, int n, String string2, int n2, Scriptable scriptable) {
        IdFunctionObject idFunctionObject = new IdFunctionObject(this, object, n, string2, n2, scriptable);
        if (this.isSealed()) {
            idFunctionObject.sealObject();
        }
        return idFunctionObject;
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        int n = objectInputStream.readInt();
        if (n != 0) {
            this.activatePrototypeMap(n);
        }
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
        PrototypeValues prototypeValues = this.prototypeValues;
        int n = 0;
        if (prototypeValues != null) {
            n = this.prototypeValues.getMaxId();
        }
        objectOutputStream.writeInt(n);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void activatePrototypeMap(int n) {
        PrototypeValues prototypeValues = new PrototypeValues(this, n);
        IdScriptableObject idScriptableObject = this;
        synchronized (idScriptableObject) {
            if (this.prototypeValues != null) {
                throw new IllegalStateException();
            }
            this.prototypeValues = prototypeValues;
            return;
        }
    }

    protected void addIdFunctionProperty(Scriptable scriptable, Object object, int n, String string2, int n2) {
        this.newIdFunction(object, n, string2, n2, ScriptableObject.getTopLevelScope(scriptable)).addAsProperty(scriptable);
    }

    protected final Object defaultGet(String string2) {
        return super.get(string2, (Scriptable)this);
    }

    protected final boolean defaultHas(String string2) {
        return super.has(string2, (Scriptable)this);
    }

    protected final void defaultPut(String string2, Object object) {
        super.put(string2, (Scriptable)this, object);
    }

    @Override
    public void defineOwnProperty(Context context, Object object, ScriptableObject scriptableObject) {
        int n;
        String string2;
        block7 : {
            int n2;
            int n3;
            block6 : {
                block4 : {
                    block5 : {
                        if (!(object instanceof String)) break block4;
                        string2 = (String)object;
                        n2 = this.findInstanceIdInfo(string2);
                        if (n2 == 0) break block5;
                        n3 = n2 & 65535;
                        if (!this.isAccessorDescriptor(scriptableObject)) break block6;
                        this.delete(n3);
                    }
                    if (this.prototypeValues == null || (n = this.prototypeValues.findId(string2)) == 0) break block4;
                    if (!this.isAccessorDescriptor(scriptableObject)) break block7;
                    this.prototypeValues.delete(n);
                }
                super.defineOwnProperty(context, object, scriptableObject);
                return;
            }
            this.checkPropertyDefinition(scriptableObject);
            this.checkPropertyChange(string2, this.getOwnPropertyDescriptor(context, object), scriptableObject);
            int n4 = n2 >>> 16;
            Object object2 = IdScriptableObject.getProperty((Scriptable)scriptableObject, "value");
            if (object2 != NOT_FOUND && (n4 & 1) == 0 && !this.sameValue(object2, this.getInstanceIdValue(n3))) {
                this.setInstanceIdValue(n3, object2);
            }
            this.setAttributes(string2, this.applyDescriptorToAttributeBitset(n4, scriptableObject));
            return;
        }
        this.checkPropertyDefinition(scriptableObject);
        this.checkPropertyChange(string2, this.getOwnPropertyDescriptor(context, object), scriptableObject);
        int n5 = this.prototypeValues.getAttributes(n);
        Object object3 = IdScriptableObject.getProperty((Scriptable)scriptableObject, "value");
        if (object3 != NOT_FOUND && (n5 & 1) == 0 && !this.sameValue(object3, this.prototypeValues.get(n))) {
            this.prototypeValues.set(n, this, object3);
        }
        this.prototypeValues.setAttributes(n, this.applyDescriptorToAttributeBitset(n5, scriptableObject));
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void delete(String string2) {
        int n;
        int n2 = this.findInstanceIdInfo(string2);
        if (n2 != 0 && !this.isSealed()) {
            if ((4 & n2 >>> 16) != 0) return;
            {
                this.setInstanceIdValue(n2 & 65535, NOT_FOUND);
            }
            return;
        }
        if (this.prototypeValues != null && (n = this.prototypeValues.findId(string2)) != 0) {
            if (this.isSealed()) return;
            {
                this.prototypeValues.delete(n);
                return;
            }
        }
        super.delete(string2);
    }

    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        throw idFunctionObject.unknown();
    }

    public final IdFunctionObject exportAsJSClass(int n, Scriptable scriptable, boolean bl) {
        if (scriptable != this && scriptable != null) {
            this.setParentScope(scriptable);
            this.setPrototype(IdScriptableObject.getObjectPrototype(scriptable));
        }
        this.activatePrototypeMap(n);
        IdFunctionObject idFunctionObject = this.prototypeValues.createPrecachedConstructor();
        if (bl) {
            this.sealObject();
        }
        this.fillConstructorProperties(idFunctionObject);
        if (bl) {
            idFunctionObject.sealObject();
        }
        idFunctionObject.exportAsScopeProperty();
        return idFunctionObject;
    }

    protected void fillConstructorProperties(IdFunctionObject idFunctionObject) {
    }

    protected int findInstanceIdInfo(String string2) {
        return 0;
    }

    protected int findPrototypeId(String string2) {
        throw new IllegalStateException(string2);
    }

    @Override
    public Object get(String string2, Scriptable scriptable) {
        Object object;
        Object object2;
        int n;
        Object object3 = super.get(string2, scriptable);
        if (object3 != NOT_FOUND) {
            return object3;
        }
        int n2 = this.findInstanceIdInfo(string2);
        if (n2 != 0 && (object = this.getInstanceIdValue(n2 & 65535)) != NOT_FOUND) {
            return object;
        }
        if (this.prototypeValues != null && (n = this.prototypeValues.findId(string2)) != 0 && (object2 = this.prototypeValues.get(n)) != NOT_FOUND) {
            return object2;
        }
        return NOT_FOUND;
    }

    @Override
    public int getAttributes(String string2) {
        int n;
        int n2 = this.findInstanceIdInfo(string2);
        if (n2 != 0) {
            return n2 >>> 16;
        }
        if (this.prototypeValues != null && (n = this.prototypeValues.findId(string2)) != 0) {
            return this.prototypeValues.getAttributes(n);
        }
        return super.getAttributes(string2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    Object[] getIds(boolean bl) {
        int n;
        Object[] arrobject = super.getIds(bl);
        if (this.prototypeValues != null) {
            arrobject = this.prototypeValues.getNames(bl, arrobject);
        }
        if ((n = this.getMaxInstanceId()) == 0) return arrobject;
        Object[] arrobject2 = null;
        int n2 = n;
        int n3 = 0;
        do {
            int n4;
            block7 : {
                block5 : {
                    block4 : {
                        int n5;
                        String string2;
                        block6 : {
                            if (n2 == 0) break block4;
                            string2 = this.getInstanceIdName(n2);
                            int n6 = this.findInstanceIdInfo(string2);
                            if (n6 == 0) break block5;
                            n5 = n6 >>> 16;
                            if ((n5 & 4) != 0 || NOT_FOUND != this.getInstanceIdValue(n2)) break block6;
                            n4 = n3;
                            break block7;
                        }
                        if (!bl && (n5 & 2) != 0) break block5;
                        if (n3 == 0) {
                            arrobject2 = new Object[n2];
                        }
                        n4 = n3 + 1;
                        arrobject2[n3] = string2;
                        break block7;
                    }
                    if (n3 == 0) return arrobject;
                    if (arrobject.length == 0 && arrobject2.length == n3) {
                        return arrobject2;
                    }
                    Object[] arrobject3 = new Object[n3 + arrobject.length];
                    System.arraycopy((Object)arrobject, (int)0, (Object)arrobject3, (int)0, (int)arrobject.length);
                    System.arraycopy((Object)arrobject2, (int)0, (Object)arrobject3, (int)arrobject.length, (int)n3);
                    return arrobject3;
                }
                n4 = n3;
            }
            --n2;
            n3 = n4;
        } while (true);
    }

    protected String getInstanceIdName(int n) {
        throw new IllegalArgumentException(String.valueOf((int)n));
    }

    protected Object getInstanceIdValue(int n) {
        throw new IllegalStateException(String.valueOf((int)n));
    }

    protected int getMaxInstanceId() {
        return 0;
    }

    @Override
    protected ScriptableObject getOwnPropertyDescriptor(Context context, Object object) {
        ScriptableObject scriptableObject = super.getOwnPropertyDescriptor(context, object);
        if (scriptableObject == null && object instanceof String) {
            scriptableObject = this.getBuiltInDescriptor((String)object);
        }
        return scriptableObject;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean has(String string2, Scriptable scriptable) {
        int n;
        int n2 = this.findInstanceIdInfo(string2);
        if (n2 != 0) {
            int n3;
            return (4 & n2 >>> 16) != 0 || NOT_FOUND != this.getInstanceIdValue(n3 = n2 & 65535);
        }
        if (this.prototypeValues != null && (n = this.prototypeValues.findId(string2)) != 0) {
            return this.prototypeValues.has(n);
        }
        return super.has(string2, scriptable);
    }

    public final boolean hasPrototypeMap() {
        return this.prototypeValues != null;
    }

    public final void initPrototypeConstructor(IdFunctionObject idFunctionObject) {
        int n = this.prototypeValues.constructorId;
        if (n == 0) {
            throw new IllegalStateException();
        }
        if (idFunctionObject.methodId() != n) {
            throw new IllegalArgumentException();
        }
        if (this.isSealed()) {
            idFunctionObject.sealObject();
        }
        this.prototypeValues.initValue(n, "constructor", idFunctionObject, 2);
    }

    protected void initPrototypeId(int n) {
        throw new IllegalStateException(String.valueOf((int)n));
    }

    public final void initPrototypeMethod(Object object, int n, String string2, int n2) {
        IdFunctionObject idFunctionObject = this.newIdFunction(object, n, string2, n2, ScriptableObject.getTopLevelScope(this));
        this.prototypeValues.initValue(n, string2, idFunctionObject, 2);
    }

    public final void initPrototypeValue(int n, String string2, Object object, int n2) {
        this.prototypeValues.initValue(n, string2, object, n2);
    }

    @Override
    public void put(String string2, Scriptable scriptable, Object object) {
        int n;
        block6 : {
            block8 : {
                block7 : {
                    int n2 = this.findInstanceIdInfo(string2);
                    if (n2 == 0) break block6;
                    if (scriptable == this && this.isSealed()) {
                        throw Context.reportRuntimeError1("msg.modify.sealed", string2);
                    }
                    if ((1 & n2 >>> 16) != 0) break block7;
                    if (scriptable != this) break block8;
                    this.setInstanceIdValue(n2 & 65535, object);
                }
                return;
            }
            scriptable.put(string2, scriptable, object);
            return;
        }
        if (this.prototypeValues != null && (n = this.prototypeValues.findId(string2)) != 0) {
            if (scriptable == this && this.isSealed()) {
                throw Context.reportRuntimeError1("msg.modify.sealed", string2);
            }
            this.prototypeValues.set(n, scriptable, object);
            return;
        }
        super.put(string2, scriptable, object);
    }

    @Override
    public void setAttributes(String string2, int n) {
        int n2;
        ScriptableObject.checkValidAttributes(n);
        int n3 = this.findInstanceIdInfo(string2);
        if (n3 != 0) {
            int n4 = n3 & 65535;
            if (n != n3 >>> 16) {
                this.setInstanceIdAttributes(n4, n);
            }
            return;
        }
        if (this.prototypeValues != null && (n2 = this.prototypeValues.findId(string2)) != 0) {
            this.prototypeValues.setAttributes(n2, n);
            return;
        }
        super.setAttributes(string2, n);
    }

    protected void setInstanceIdAttributes(int n, int n2) {
        throw ScriptRuntime.constructError("InternalError", "Changing attributes not supported for " + this.getClassName() + " " + this.getInstanceIdName(n) + " property");
    }

    protected void setInstanceIdValue(int n, Object object) {
        throw new IllegalStateException(String.valueOf((int)n));
    }

    private static final class PrototypeValues
    implements Serializable {
        private static final int NAME_SLOT = 1;
        private static final int SLOT_SPAN = 2;
        static final long serialVersionUID = 3038645279153854371L;
        private short[] attributeArray;
        private IdFunctionObject constructor;
        private short constructorAttrs;
        int constructorId;
        private int maxId;
        private IdScriptableObject obj;
        private Object[] valueArray;

        PrototypeValues(IdScriptableObject idScriptableObject, int n) {
            if (idScriptableObject == null) {
                throw new IllegalArgumentException();
            }
            if (n < 1) {
                throw new IllegalArgumentException();
            }
            this.obj = idScriptableObject;
            this.maxId = n;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        private Object ensureId(int n) {
            int n2;
            Object object;
            Object[] arrobject = this.valueArray;
            if (arrobject == null) {
                PrototypeValues prototypeValues = this;
                synchronized (prototypeValues) {
                    arrobject = this.valueArray;
                    if (arrobject == null) {
                        this.valueArray = arrobject = new Object[2 * this.maxId];
                        this.attributeArray = new short[this.maxId];
                    }
                }
            }
            if ((object = arrobject[n2 = 2 * (n - 1)]) == null) {
                if (n == this.constructorId) {
                    this.initSlot(this.constructorId, "constructor", this.constructor, this.constructorAttrs);
                    this.constructor = null;
                } else {
                    this.obj.initPrototypeId(n);
                }
                if ((object = arrobject[n2]) == null) {
                    throw new IllegalStateException(this.obj.getClass().getName() + ".initPrototypeId(int id) " + "did not initialize id=" + n);
                }
            }
            return object;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        private void initSlot(int n, String string2, Object object, int n2) {
            Object[] arrobject = this.valueArray;
            if (arrobject == null) {
                throw new IllegalStateException();
            }
            if (object == null) {
                object = UniqueTag.NULL_VALUE;
            }
            int n3 = 2 * (n - 1);
            PrototypeValues prototypeValues = this;
            synchronized (prototypeValues) {
                if (arrobject[n3] == null) {
                    arrobject[n3] = object;
                    arrobject[n3 + 1] = string2;
                    this.attributeArray[n - 1] = (short)n2;
                } else if (!string2.equals(arrobject[n3 + 1])) {
                    throw new IllegalStateException();
                }
                return;
            }
        }

        final IdFunctionObject createPrecachedConstructor() {
            if (this.constructorId != 0) {
                throw new IllegalStateException();
            }
            this.constructorId = this.obj.findPrototypeId("constructor");
            if (this.constructorId == 0) {
                throw new IllegalStateException("No id for constructor property");
            }
            this.obj.initPrototypeId(this.constructorId);
            if (this.constructor == null) {
                throw new IllegalStateException(this.obj.getClass().getName() + ".initPrototypeId() did not " + "initialize id=" + this.constructorId);
            }
            this.constructor.initFunction(this.obj.getClassName(), ScriptableObject.getTopLevelScope(this.obj));
            this.constructor.markAsConstructor(this.obj);
            return this.constructor;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        final void delete(int n) {
            this.ensureId(n);
            if ((4 & this.attributeArray[n - 1]) == 0) {
                int n2 = 2 * (n - 1);
                PrototypeValues prototypeValues = this;
                synchronized (prototypeValues) {
                    this.valueArray[n2] = Scriptable.NOT_FOUND;
                    this.attributeArray[n - 1] = 0;
                    return;
                }
            }
        }

        final int findId(String string2) {
            return this.obj.findPrototypeId(string2);
        }

        final Object get(int n) {
            Object object = this.ensureId(n);
            if (object == UniqueTag.NULL_VALUE) {
                object = null;
            }
            return object;
        }

        final int getAttributes(int n) {
            this.ensureId(n);
            return this.attributeArray[n - 1];
        }

        final int getMaxId() {
            return this.maxId;
        }

        final Object[] getNames(boolean bl, Object[] arrobject) {
            Object[] arrobject2 = null;
            int n = 0;
            for (int i = 1; i <= this.maxId; ++i) {
                Object object = this.ensureId(i);
                if (!bl && (2 & this.attributeArray[i - 1]) != 0 || object == Scriptable.NOT_FOUND) continue;
                int n2 = 1 + 2 * (i - 1);
                String string2 = (String)this.valueArray[n2];
                if (arrobject2 == null) {
                    arrobject2 = new Object[this.maxId];
                }
                int n3 = n + 1;
                arrobject2[n] = string2;
                n = n3;
            }
            if (n == 0) {
                return arrobject;
            }
            if (arrobject == null || arrobject.length == 0) {
                if (n != arrobject2.length) {
                    Object[] arrobject3 = new Object[n];
                    System.arraycopy(arrobject2, (int)0, (Object)arrobject3, (int)0, (int)n);
                    arrobject2 = arrobject3;
                }
                return arrobject2;
            }
            int n4 = arrobject.length;
            Object[] arrobject4 = new Object[n4 + n];
            System.arraycopy((Object)arrobject, (int)0, (Object)arrobject4, (int)0, (int)n4);
            System.arraycopy((Object)arrobject2, (int)0, (Object)arrobject4, (int)n4, (int)n);
            return arrobject4;
        }

        /*
         * Enabled aggressive block sorting
         */
        final boolean has(int n) {
            Object object;
            Object[] arrobject = this.valueArray;
            return arrobject == null || (object = arrobject[2 * (n - 1)]) == null || object != Scriptable.NOT_FOUND;
        }

        final void initValue(int n, String string2, Object object, int n2) {
            if (1 > n || n > this.maxId) {
                throw new IllegalArgumentException();
            }
            if (string2 == null) {
                throw new IllegalArgumentException();
            }
            if (object == Scriptable.NOT_FOUND) {
                throw new IllegalArgumentException();
            }
            ScriptableObject.checkValidAttributes(n2);
            if (this.obj.findPrototypeId(string2) != n) {
                throw new IllegalArgumentException(string2);
            }
            if (n == this.constructorId) {
                if (!(object instanceof IdFunctionObject)) {
                    throw new IllegalArgumentException("consructor should be initialized with IdFunctionObject");
                }
                this.constructor = (IdFunctionObject)object;
                this.constructorAttrs = (short)n2;
                return;
            }
            this.initSlot(n, string2, object, n2);
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        final void set(int n, Scriptable scriptable, Object object) {
            if (object == Scriptable.NOT_FOUND) {
                throw new IllegalArgumentException();
            }
            this.ensureId(n);
            if ((1 & this.attributeArray[n - 1]) == 0) {
                if (scriptable == this.obj) {
                    if (object == null) {
                        object = UniqueTag.NULL_VALUE;
                    }
                    int n2 = 2 * (n - 1);
                    PrototypeValues prototypeValues = this;
                    synchronized (prototypeValues) {
                        this.valueArray[n2] = object;
                        return;
                    }
                }
                int n3 = 1 + 2 * (n - 1);
                scriptable.put((String)this.valueArray[n3], scriptable, object);
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        final void setAttributes(int n, int n2) {
            ScriptableObject.checkValidAttributes(n2);
            this.ensureId(n);
            PrototypeValues prototypeValues = this;
            synchronized (prototypeValues) {
                this.attributeArray[n - 1] = (short)n2;
                return;
            }
        }
    }

}

