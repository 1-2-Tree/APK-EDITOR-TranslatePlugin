/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.Serializable
 *  java.lang.ClassNotFoundException
 *  java.lang.Object
 */
package org.mozilla.javascript;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.UniqueTag;

public class ObjToIntMap
implements Serializable {
    private static final int A = -1640531527;
    private static final Object DELETED = new Object();
    private static final boolean check = false;
    static final long serialVersionUID = -1542220580748809402L;
    private int keyCount;
    private transient Object[] keys;
    private transient int occupiedCount;
    private int power;
    private transient int[] values;

    public ObjToIntMap() {
        this(4);
    }

    public ObjToIntMap(int n) {
        if (n < 0) {
            Kit.codeBug();
        }
        int n2 = n * 4 / 3;
        int n3 = 2;
        while (1 << n3 < n2) {
            ++n3;
        }
        this.power = n3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private int ensureIndex(Object var1_1) {
        block6 : {
            var2_2 = var1_1.hashCode();
            var3_3 = -1;
            var4_4 = -1;
            if (this.keys == null || (var6_6 = this.keys[var3_3 = (var5_5 = var2_2 * -1640531527) >>> 32 - this.power]) == null) ** GOTO lbl15
            var7_7 = 1 << this.power;
            if (var6_6 == var1_1) return var3_3;
            if (this.values[var7_7 + var3_3] == var2_2 && var6_6.equals(var1_1)) {
                return var3_3;
            }
            if (var6_6 == ObjToIntMap.DELETED) {
                var4_4 = var3_3;
            }
            var8_8 = var7_7 - 1;
            var9_9 = ObjToIntMap.tableLookupStep(var5_5, var8_8, this.power);
            do {
                block7 : {
                    if ((var10_10 = this.keys[var3_3 = var8_8 & var3_3 + var9_9]) != null) break block7;
lbl15: // 2 sources:
                    if (var4_4 < 0) break;
                    var3_3 = var4_4;
                    break block6;
                }
                if (var10_10 == var1_1) return var3_3;
                if (this.values[var7_7 + var3_3] == var2_2 && var10_10.equals(var1_1)) {
                    return var3_3;
                }
                if (var10_10 != ObjToIntMap.DELETED || var4_4 >= 0) continue;
                var4_4 = var3_3;
            } while (true);
            if (this.keys == null || 4 * this.occupiedCount >= 3 * (1 << this.power)) {
                this.rehashTable();
                return this.insertNewKey(var1_1, var2_2);
            }
            this.occupiedCount = 1 + this.occupiedCount;
        }
        this.keys[var3_3] = var1_1;
        this.values[var3_3 + (1 << this.power)] = var2_2;
        this.keyCount = 1 + this.keyCount;
        return var3_3;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private int findIndex(Object object) {
        Object object2;
        if (this.keys == null) return -1;
        int n = object.hashCode();
        int n2 = n * -1640531527;
        int n3 = n2 >>> 32 - this.power;
        Object object3 = this.keys[n3];
        if (object3 == null) return -1;
        int n4 = 1 << this.power;
        if (object3 == object) return n3;
        if (this.values[n4 + n3] == n && object3.equals(object)) {
            return n3;
        }
        int n5 = n4 - 1;
        int n6 = ObjToIntMap.tableLookupStep(n2, n5, this.power);
        do {
            if ((object2 = this.keys[n3 = n5 & n3 + n6]) == null) {
                return -1;
            }
            if (object2 == object) return n3;
        } while (this.values[n4 + n3] != n || !object2.equals(object));
        return n3;
    }

    private int insertNewKey(Object object, int n) {
        int n2 = n * -1640531527;
        int n3 = n2 >>> 32 - this.power;
        int n4 = 1 << this.power;
        if (this.keys[n3] != null) {
            int n5 = n4 - 1;
            int n6 = ObjToIntMap.tableLookupStep(n2, n5, this.power);
            while (this.keys[n3 = n5 & n3 + n6] != null) {
            }
        }
        this.keys[n3] = object;
        this.values[n4 + n3] = n;
        this.occupiedCount = 1 + this.occupiedCount;
        this.keyCount = 1 + this.keyCount;
        return n3;
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        int n = this.keyCount;
        if (n != 0) {
            this.keyCount = 0;
            int n2 = 1 << this.power;
            this.keys = new Object[n2];
            this.values = new int[n2 * 2];
            for (int i = 0; i != n; ++i) {
                Object object = objectInputStream.readObject();
                int n3 = this.insertNewKey(object, object.hashCode());
                this.values[n3] = objectInputStream.readInt();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void rehashTable() {
        if (this.keys == null) {
            int n = 1 << this.power;
            this.keys = new Object[n];
            this.values = new int[n * 2];
            return;
        } else {
            if (2 * this.keyCount >= this.occupiedCount) {
                this.power = 1 + this.power;
            }
            int n = 1 << this.power;
            Object[] arrobject = this.keys;
            int[] arrn = this.values;
            int n2 = arrobject.length;
            this.keys = new Object[n];
            this.values = new int[n * 2];
            int n3 = this.keyCount;
            this.keyCount = 0;
            this.occupiedCount = 0;
            int n4 = 0;
            while (n3 != 0) {
                Object object = arrobject[n4];
                if (object != null && object != DELETED) {
                    int n5 = this.insertNewKey(object, arrn[n2 + n4]);
                    this.values[n5] = arrn[n4];
                    --n3;
                }
                ++n4;
            }
        }
    }

    private static int tableLookupStep(int n, int n2, int n3) {
        int n4 = 32 - n3 * 2;
        if (n4 >= 0) {
            return 1 | n2 & n >>> n4;
        }
        return 1 | n & n2 >>> -n4;
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
        int n = this.keyCount;
        int n2 = 0;
        while (n != 0) {
            Object object = this.keys[n2];
            if (object != null && object != DELETED) {
                --n;
                objectOutputStream.writeObject(object);
                objectOutputStream.writeInt(this.values[n2]);
            }
            ++n2;
        }
    }

    public void clear() {
        int n = this.keys.length;
        while (n != 0) {
            Object[] arrobject = this.keys;
            arrobject[--n] = null;
        }
        this.keyCount = 0;
        this.occupiedCount = 0;
    }

    public int get(Object object, int n) {
        int n2;
        if (object == null) {
            object = UniqueTag.NULL_VALUE;
        }
        if ((n2 = this.findIndex(object)) >= 0) {
            n = this.values[n2];
        }
        return n;
    }

    public int getExisting(Object object) {
        int n;
        if (object == null) {
            object = UniqueTag.NULL_VALUE;
        }
        if ((n = this.findIndex(object)) >= 0) {
            return this.values[n];
        }
        Kit.codeBug();
        return 0;
    }

    public void getKeys(Object[] arrobject, int n) {
        int n2 = this.keyCount;
        int n3 = 0;
        while (n2 != 0) {
            Object object = this.keys[n3];
            if (object != null && object != DELETED) {
                if (object == UniqueTag.NULL_VALUE) {
                    object = null;
                }
                arrobject[n] = object;
                ++n;
                --n2;
            }
            ++n3;
        }
    }

    public Object[] getKeys() {
        Object[] arrobject = new Object[this.keyCount];
        this.getKeys(arrobject, 0);
        return arrobject;
    }

    public boolean has(Object object) {
        if (object == null) {
            object = UniqueTag.NULL_VALUE;
        }
        return this.findIndex(object) >= 0;
    }

    final void initIterator(Iterator iterator) {
        iterator.init(this.keys, this.values, this.keyCount);
    }

    public Object intern(Object object) {
        boolean bl = false;
        if (object == null) {
            bl = true;
            object = UniqueTag.NULL_VALUE;
        }
        int n = this.ensureIndex(object);
        this.values[n] = 0;
        if (bl) {
            return null;
        }
        return this.keys[n];
    }

    public boolean isEmpty() {
        return this.keyCount == 0;
    }

    public Iterator newIterator() {
        return new Iterator(this);
    }

    public void put(Object object, int n) {
        if (object == null) {
            object = UniqueTag.NULL_VALUE;
        }
        int n2 = this.ensureIndex(object);
        this.values[n2] = n;
    }

    public void remove(Object object) {
        int n;
        if (object == null) {
            object = UniqueTag.NULL_VALUE;
        }
        if ((n = this.findIndex(object)) >= 0) {
            this.keys[n] = DELETED;
            this.keyCount = -1 + this.keyCount;
        }
    }

    public int size() {
        return this.keyCount;
    }

    public static class Iterator {
        private int cursor;
        private Object[] keys;
        ObjToIntMap master;
        private int remaining;
        private int[] values;

        Iterator(ObjToIntMap objToIntMap) {
            this.master = objToIntMap;
        }

        public boolean done() {
            return this.remaining < 0;
        }

        public Object getKey() {
            Object object = this.keys[this.cursor];
            if (object == UniqueTag.NULL_VALUE) {
                object = null;
            }
            return object;
        }

        public int getValue() {
            return this.values[this.cursor];
        }

        final void init(Object[] arrobject, int[] arrn, int n) {
            this.keys = arrobject;
            this.values = arrn;
            this.cursor = -1;
            this.remaining = n;
        }

        public void next() {
            if (this.remaining == -1) {
                Kit.codeBug();
            }
            if (this.remaining == 0) {
                this.remaining = -1;
                this.cursor = -1;
                return;
            }
            this.cursor = 1 + this.cursor;
            do {
                Object object;
                if ((object = this.keys[this.cursor]) != null && object != DELETED) {
                    this.remaining = -1 + this.remaining;
                    return;
                }
                this.cursor = 1 + this.cursor;
            } while (true);
        }

        public void setValue(int n) {
            this.values[this.cursor] = n;
        }

        public void start() {
            this.master.initIterator(this);
            this.next();
        }
    }

}

