/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.util.EnumMap
 */
package org.mozilla.javascript;

import java.util.EnumMap;
import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

public class TopLevel
extends IdScriptableObject {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    static final long serialVersionUID = -4648046356662472260L;
    private EnumMap<Builtins, BaseFunction> ctors;
    private EnumMap<NativeErrors, BaseFunction> errors;

    /*
     * Enabled aggressive block sorting
     */
    static {
        boolean bl = !TopLevel.class.desiredAssertionStatus();
        $assertionsDisabled = bl;
    }

    public static Function getBuiltinCtor(Context context, Scriptable scriptable, Builtins builtins) {
        BaseFunction baseFunction;
        if (!$assertionsDisabled && scriptable.getParentScope() != null) {
            throw new AssertionError();
        }
        if (scriptable instanceof TopLevel && (baseFunction = ((TopLevel)scriptable).getBuiltinCtor(builtins)) != null) {
            return baseFunction;
        }
        return ScriptRuntime.getExistingCtor(context, scriptable, builtins.name());
    }

    public static Scriptable getBuiltinPrototype(Scriptable scriptable, Builtins builtins) {
        Scriptable scriptable2;
        if (!$assertionsDisabled && scriptable.getParentScope() != null) {
            throw new AssertionError();
        }
        if (scriptable instanceof TopLevel && (scriptable2 = ((TopLevel)scriptable).getBuiltinPrototype(builtins)) != null) {
            return scriptable2;
        }
        return ScriptableObject.getClassPrototype(scriptable, builtins.name());
    }

    static Function getNativeErrorCtor(Context context, Scriptable scriptable, NativeErrors nativeErrors) {
        BaseFunction baseFunction;
        if (!$assertionsDisabled && scriptable.getParentScope() != null) {
            throw new AssertionError();
        }
        if (scriptable instanceof TopLevel && (baseFunction = ((TopLevel)scriptable).getNativeErrorCtor(nativeErrors)) != null) {
            return baseFunction;
        }
        return ScriptRuntime.getExistingCtor(context, scriptable, nativeErrors.name());
    }

    public void cacheBuiltins() {
        this.ctors = new EnumMap(Builtins.class);
        for (Builtins builtins : Builtins.values()) {
            Object object = ScriptableObject.getProperty((Scriptable)this, builtins.name());
            if (!(object instanceof BaseFunction)) continue;
            this.ctors.put((Enum)builtins, (Object)((BaseFunction)object));
        }
        this.errors = new EnumMap(NativeErrors.class);
        for (NativeErrors nativeErrors : NativeErrors.values()) {
            Object object = ScriptableObject.getProperty((Scriptable)this, nativeErrors.name());
            if (!(object instanceof BaseFunction)) continue;
            this.errors.put((Enum)nativeErrors, (Object)((BaseFunction)object));
        }
    }

    public BaseFunction getBuiltinCtor(Builtins builtins) {
        if (this.ctors != null) {
            return (BaseFunction)this.ctors.get((Object)builtins);
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public Scriptable getBuiltinPrototype(Builtins builtins) {
        BaseFunction baseFunction = this.getBuiltinCtor(builtins);
        Object object = baseFunction != null ? baseFunction.getPrototypeProperty() : null;
        if (object instanceof Scriptable) {
            return (Scriptable)object;
        }
        return null;
    }

    @Override
    public String getClassName() {
        return "global";
    }

    BaseFunction getNativeErrorCtor(NativeErrors nativeErrors) {
        if (this.errors != null) {
            return (BaseFunction)this.errors.get((Object)nativeErrors);
        }
        return null;
    }

    public static final class Builtins
    extends Enum<Builtins> {
        private static final /* synthetic */ Builtins[] $VALUES;
        public static final /* enum */ Builtins Array;
        public static final /* enum */ Builtins Boolean;
        public static final /* enum */ Builtins Error;
        public static final /* enum */ Builtins Function;
        public static final /* enum */ Builtins Number;
        public static final /* enum */ Builtins Object;
        public static final /* enum */ Builtins RegExp;
        public static final /* enum */ Builtins String;

        static {
            Object = new Builtins();
            Array = new Builtins();
            Function = new Builtins();
            String = new Builtins();
            Number = new Builtins();
            Boolean = new Builtins();
            RegExp = new Builtins();
            Error = new Builtins();
            Builtins[] arrbuiltins = new Builtins[]{Object, Array, Function, String, Number, Boolean, RegExp, Error};
            $VALUES = arrbuiltins;
        }

        public static Builtins valueOf(String string2) {
            return (Builtins)Enum.valueOf(Builtins.class, (String)string2);
        }

        public static Builtins[] values() {
            return (Builtins[])$VALUES.clone();
        }
    }

    static final class NativeErrors
    extends Enum<NativeErrors> {
        private static final /* synthetic */ NativeErrors[] $VALUES;
        public static final /* enum */ NativeErrors Error = new NativeErrors();
        public static final /* enum */ NativeErrors EvalError = new NativeErrors();
        public static final /* enum */ NativeErrors InternalError;
        public static final /* enum */ NativeErrors JavaException;
        public static final /* enum */ NativeErrors RangeError;
        public static final /* enum */ NativeErrors ReferenceError;
        public static final /* enum */ NativeErrors SyntaxError;
        public static final /* enum */ NativeErrors TypeError;
        public static final /* enum */ NativeErrors URIError;

        static {
            RangeError = new NativeErrors();
            ReferenceError = new NativeErrors();
            SyntaxError = new NativeErrors();
            TypeError = new NativeErrors();
            URIError = new NativeErrors();
            InternalError = new NativeErrors();
            JavaException = new NativeErrors();
            NativeErrors[] arrnativeErrors = new NativeErrors[]{Error, EvalError, RangeError, ReferenceError, SyntaxError, TypeError, URIError, InternalError, JavaException};
            $VALUES = arrnativeErrors;
        }

        public static NativeErrors valueOf(String string2) {
            return (NativeErrors)Enum.valueOf(NativeErrors.class, (String)string2);
        }

        public static NativeErrors[] values() {
            return (NativeErrors[])$VALUES.clone();
        }
    }

}

