/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.mozilla.javascript.debug;

public interface DebuggableObject {
    public Object[] getAllIds();
}

