/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Delegator;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Wrapper;

public class Synchronizer
extends Delegator {
    private Object syncObject;

    public Synchronizer(Scriptable scriptable) {
        super(scriptable);
    }

    public Synchronizer(Scriptable scriptable, Object object) {
        super(scriptable);
        this.syncObject = object;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        Object object = this.syncObject != null ? this.syncObject : scriptable2;
        if (object instanceof Wrapper) {
            object = ((Wrapper)object).unwrap();
        }
        Object object2 = object;
        synchronized (object2) {
            return ((Function)this.obj).call(context, scriptable, scriptable2, arrobject);
        }
    }
}

