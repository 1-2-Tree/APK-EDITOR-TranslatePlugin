/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.math.BigInteger
 */
package org.mozilla.javascript;

import java.math.BigInteger;

class DToA {
    private static final int Bias = 1023;
    private static final int Bletch = 16;
    private static final int Bndry_mask = 1048575;
    static final int DTOSTR_EXPONENTIAL = 3;
    static final int DTOSTR_FIXED = 2;
    static final int DTOSTR_PRECISION = 4;
    static final int DTOSTR_STANDARD = 0;
    static final int DTOSTR_STANDARD_EXPONENTIAL = 1;
    private static final int Exp_11 = 1072693248;
    private static final int Exp_mask = 2146435072;
    private static final int Exp_mask_shifted = 2047;
    private static final int Exp_msk1 = 1048576;
    private static final long Exp_msk1L = 0x10000000000000L;
    private static final int Exp_shift = 20;
    private static final int Exp_shift1 = 20;
    private static final int Exp_shiftL = 52;
    private static final int Frac_mask = 1048575;
    private static final int Frac_mask1 = 1048575;
    private static final long Frac_maskL = 0xFFFFFFFFFFFFFL;
    private static final int Int_max = 14;
    private static final int Log2P = 1;
    private static final int P = 53;
    private static final int Quick_max = 14;
    private static final int Sign_bit = Integer.MIN_VALUE;
    private static final int Ten_pmax = 22;
    private static final double[] bigtens;
    private static final int[] dtoaModes;
    private static final int n_bigtens = 5;
    private static final double[] tens;

    static {
        tens = new double[]{1.0, 10.0, 100.0, 1000.0, 10000.0, 100000.0, 1000000.0, 1.0E7, 1.0E8, 1.0E9, 1.0E10, 1.0E11, 1.0E12, 1.0E13, 1.0E14, 1.0E15, 1.0E16, 1.0E17, 1.0E18, 1.0E19, 1.0E20, 1.0E21, 1.0E22};
        bigtens = new double[]{1.0E16, 1.0E32, 1.0E64, 1.0E128, 1.0E256};
        dtoaModes = new int[]{0, 0, 3, 2, 2};
    }

    DToA() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static char BASEDIGIT(int n) {
        int n2;
        if (n >= 10) {
            n2 = n + 87;
            do {
                return (char)n2;
                break;
            } while (true);
        }
        n2 = n + 48;
        return (char)n2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static int JS_dtoa(double var0, int var2_1, boolean var3_2, int var4_3, boolean[] var5_4, StringBuilder var6_5) {
        block107 : {
            block106 : {
                block112 : {
                    block110 : {
                        block111 : {
                            var7_6 = new int[1];
                            var8_7 = new int[1];
                            if ((Integer.MIN_VALUE & DToA.word0(var0)) != 0) {
                                var5_4[0] = true;
                                var143_8 = Integer.MAX_VALUE & DToA.word0(var0);
                                var0 = DToA.setWord0(var0, var143_8);
                            } else {
                                var5_4[0] = false;
                            }
                            if ((2146435072 & DToA.word0(var0)) == 2146435072) {
                                var141_9 = DToA.word1(var0) == 0 && (1048575 & DToA.word0(var0)) == 0 ? "Infinity" : "NaN";
                                var6_5.append(var141_9);
                                return 9999;
                            }
                            if (var0 == 0.0) {
                                var6_5.setLength(0);
                                var6_5.append('0');
                                return 1;
                            }
                            var9_10 = DToA.d2b(var0, var7_6, var8_7);
                            var10_11 = 2047 & DToA.word0(var0) >>> 20;
                            if (var10_11 != 0) {
                                var139_12 = 1072693248 | 1048575 & DToA.word0(var0);
                                var14_13 = DToA.setWord0(var0, var139_12);
                                var16_14 = var10_11 - 1023;
                                var17_15 = false;
                            } else {
                                var11_16 = 1074 + (var8_7[0] + var7_6[0]);
                                var12_17 = var11_16 > 32 ? (long)DToA.word0(var0) << 64 - var11_16 | (long)(DToA.word1(var0) >>> var11_16 - 32) : (long)DToA.word1(var0) << 32 - var11_16;
                                var14_13 = DToA.setWord0(var12_17, DToA.word0(var12_17) - 32505856);
                                var16_14 = var11_16 - 1075;
                                var17_15 = true;
                            }
                            var18_18 = 0.1760912590558 + 0.289529654602168 * (var14_13 - 1.5) + 0.301029995663981 * (double)var16_14;
                            var20_19 = (int)var18_18;
                            if (var18_18 < 0.0 && var18_18 != (double)var20_19) {
                                --var20_19;
                            }
                            var21_20 = true;
                            if (var20_19 >= 0 && var20_19 <= 22) {
                                if (var0 < DToA.tens[var20_19]) {
                                    --var20_19;
                                }
                                var21_20 = false;
                            }
                            if ((var22_21 = -1 + (var8_7[0] - var16_14)) >= 0) {
                                var23_22 = 0;
                                var24_23 = var22_21;
                            } else {
                                var23_22 = -var22_21;
                                var24_23 = 0;
                            }
                            if (var20_19 >= 0) {
                                var25_24 = 0;
                                var26_25 = var20_19;
                                var24_23 += var20_19;
                            } else {
                                var23_22 -= var20_19;
                                var25_24 = -var20_19;
                                var26_25 = 0;
                            }
                            if (var2_1 < 0 || var2_1 > 9) {
                                var2_1 = 0;
                            }
                            var27_26 = true;
                            if (var2_1 > 5) {
                                var2_1 -= 4;
                                var27_26 = false;
                            }
                            var28_27 = true;
                            var29_28 = 0;
                            var30_29 = 0;
                            switch (var2_1) {
                                case 0: 
                                case 1: {
                                    var29_28 = var30_29 = -1;
                                    var4_3 = 0;
                                    break;
                                }
                                case 2: {
                                    var28_27 = false;
                                }
                                case 4: {
                                    if (var4_3 <= 0) {
                                        var4_3 = 1;
                                    }
                                    var30_29 = var4_3;
                                    var29_28 = var4_3;
                                    break;
                                }
                                case 3: {
                                    var28_27 = false;
                                }
                                case 5: {
                                    var29_28 = var31_30 = 1 + (var4_3 + var20_19);
                                    var30_29 = var31_30 - 1;
                                    if (var31_30 > 0) break;
                                }
                            }
                            if (var29_28 < 0 || var29_28 > 14 || !var27_26) ** GOTO lbl176
                            var101_31 = 0;
                            var102_32 = var0;
                            var104_33 = var20_19;
                            var105_34 = var29_28;
                            var106_35 = 2;
                            if (var20_19 > 0) {
                                var133_36 = DToA.tens[var20_19 & 15];
                                var135_37 = var20_19 >> 4;
                                var136_38 = var135_37 & 16;
                                var137_39 = 0;
                                if (var136_38 != 0) {
                                    var135_37 &= 15;
                                    var0 /= DToA.bigtens[4];
                                    ++var106_35;
                                }
                                while (var135_37 != 0) {
                                    if ((var135_37 & 1) != 0) {
                                        ++var106_35;
                                        var133_36 *= DToA.bigtens[var137_39];
                                    }
                                    var135_37 >>= 1;
                                    ++var137_39;
                                }
                                var0 /= var133_36;
                            } else {
                                var107_40 = -var20_19;
                                if (var107_40 != 0) {
                                    var0 *= DToA.tens[var107_40 & 15];
                                    for (var108_41 = var107_40 >> 4; var108_41 != 0; var108_41 >>= 1, ++var101_31) {
                                        if ((var108_41 & 1) == 0) continue;
                                        ++var106_35;
                                        var0 *= DToA.bigtens[var101_31];
                                    }
                                }
                            }
                            var109_42 = false;
                            if (var21_20) {
                                var132_43 = var0 DCMPG 1.0;
                                var109_42 = false;
                                if (var132_43 < 0) {
                                    var109_42 = false;
                                    if (var29_28 > 0) {
                                        if (var30_29 <= 0) {
                                            var109_42 = true;
                                        } else {
                                            var29_28 = var30_29;
                                            --var20_19;
                                            var0 *= 10.0;
                                            ++var106_35;
                                            var109_42 = false;
                                        }
                                    }
                                }
                            }
                            var110_44 = 7.0 + var0 * (double)var106_35;
                            var112_45 = DToA.setWord0(var110_44, DToA.word0(var110_44) - 54525952);
                            if (var29_28 == 0) {
                                if ((var0 -= 5.0) > var112_45) {
                                    var6_5.append('1');
                                    return 1 + (var20_19 + 1);
                                }
                                if (var0 < -var112_45) {
                                    var6_5.setLength(0);
                                    var6_5.append('0');
                                    return 1;
                                }
                                var109_42 = true;
                            }
                            if (var109_42) break block110;
                            var109_42 = true;
                            if (var28_27) break block111;
                            var114_50 = var112_45 * DToA.tens[var29_28 - 1];
                            var116_51 = 1;
                            break block112;
                        }
                        var122_46 = 0.5 / DToA.tens[var29_28 - 1] - var112_45;
                        var124_47 = 0;
                        do {
                            var125_48 = (long)var0;
                            var0 -= (double)var125_48;
                            var6_5.append((char)(48L + var125_48));
                            if (var0 < var122_46) {
                                return var20_19 + 1;
                            }
                            if (1.0 - var0 < var122_46) {
                                block105 : {
                                    do {
                                        var128_49 = var6_5.charAt(-1 + var6_5.length());
                                        var6_5.setLength(-1 + var6_5.length());
                                        if (var128_49 != 57) break block105;
                                    } while (var6_5.length() != 0);
                                    ++var20_19;
                                    var128_49 = 48;
                                }
                                var6_5.append((char)(var128_49 + '\u0001'));
                                return var20_19 + 1;
                            }
                            if (++var124_47 >= var29_28) break;
                            var122_46 *= 10.0;
                            var0 *= 10.0;
                        } while (true);
                    }
                    do {
                        if (var109_42) {
                            var6_5.setLength(0);
                            var0 = var102_32;
                            var20_19 = var104_33;
                            var29_28 = var105_34;
                        }
lbl176: // 4 sources:
                        if (var7_6[0] >= 0 && var20_19 <= 14) {
                            var87_53 = DToA.tens[var20_19];
                            if (var4_3 < 0 && var29_28 <= 0) {
                                if (var29_28 < 0 || var0 < 5.0 * var87_53 || !var3_2 && var0 == 5.0 * var87_53) {
                                    var6_5.setLength(0);
                                    var6_5.append('0');
                                    return 1;
                                }
                                var6_5.append('1');
                                return 1 + (var20_19 + 1);
                            }
                            break block106;
                        }
                        var32_60 = var23_22;
                        var33_61 = var25_24;
                        var34_62 = null;
                        if (var28_27) {
                            if (var2_1 < 2) {
                                var86_63 = var17_15 ? 1075 + var7_6[0] : 54 - var8_7[0];
                            } else {
                                var84_64 = var29_28 - 1;
                                if (var33_61 >= var84_64) {
                                    var33_61 -= var84_64;
                                } else {
                                    var85_65 = var84_64 - var33_61;
                                    var26_25 += var85_65;
                                    var25_24 += var85_65;
                                    var33_61 = 0;
                                }
                                var86_63 = var29_28;
                                if (var29_28 < 0) {
                                    var32_60 -= var86_63;
                                    var86_63 = 0;
                                }
                            }
                            var23_22 += var86_63;
                            var24_23 += var86_63;
                            var34_62 = BigInteger.valueOf((long)1L);
                        }
                        if (var32_60 > 0 && var24_23 > 0) {
                            var83_66 = var32_60 < var24_23 ? var32_60 : var24_23;
                            var23_22 -= var83_66;
                            var32_60 -= var83_66;
                            var24_23 -= var83_66;
                        }
                        if (var25_24 > 0) {
                            if (var28_27) {
                                if (var33_61 > 0) {
                                    var34_62 = DToA.pow5mult(var34_62, var33_61);
                                    var9_10 = var34_62.multiply(var9_10);
                                }
                                if ((var82_67 = var25_24 - var33_61) != 0) {
                                    var9_10 = DToA.pow5mult(var9_10, var82_67);
                                }
                            } else {
                                var9_10 = DToA.pow5mult(var9_10, var25_24);
                            }
                        }
                        var35_68 = BigInteger.valueOf((long)1L);
                        if (var26_25 > 0) {
                            var35_68 = DToA.pow5mult(var35_68, var26_25);
                        }
                        var36_69 = var2_1;
                        var37_70 = false;
                        if (var36_69 < 2) {
                            var79_71 = DToA.word1(var0);
                            var37_70 = false;
                            if (var79_71 == 0) {
                                var80_72 = 1048575 & DToA.word0(var0);
                                var37_70 = false;
                                if (var80_72 == 0) {
                                    var81_73 = 2145386496 & DToA.word0(var0);
                                    var37_70 = false;
                                    if (var81_73 != 0) {
                                        ++var23_22;
                                        ++var24_23;
                                        var37_70 = true;
                                    }
                                }
                            }
                        }
                        var38_74 = var35_68.toByteArray();
                        var39_75 = 0;
                        for (var40_76 = 0; var40_76 < 4; ++var40_76) {
                            var39_75 <<= 8;
                            var78_77 = var38_74.length;
                            if (var40_76 >= var78_77) continue;
                            var39_75 |= 255 & var38_74[var40_76];
                        }
                        var41_78 = var26_25 != 0 ? 32 - DToA.hi0bits(var39_75) : 1;
                        var42_79 = 31 & var41_78 + var24_23;
                        if (var42_79 != 0) {
                            var42_79 = 32 - var42_79;
                        }
                        if (var42_79 > 4) {
                            var77_80 = var42_79 - 4;
                            var23_22 += var77_80;
                            var32_60 += var77_80;
                            var24_23 += var77_80;
                        } else if (var42_79 < 4) {
                            var43_81 = var42_79 + 28;
                            var23_22 += var43_81;
                            var32_60 += var43_81;
                            var24_23 += var43_81;
                        }
                        if (var23_22 > 0) {
                            var9_10 = var9_10.shiftLeft(var23_22);
                        }
                        if (var24_23 > 0) {
                            var35_68 = var35_68.shiftLeft(var24_23);
                        }
                        if (var21_20 && var9_10.compareTo(var35_68) < 0) {
                            --var20_19;
                            var9_10 = var9_10.multiply(BigInteger.valueOf((long)10L));
                            if (var28_27) {
                                var76_82 = BigInteger.valueOf((long)10L);
                                var34_62 = var34_62.multiply(var76_82);
                            }
                            var29_28 = var30_29;
                        }
                        if (var29_28 <= 0 && var2_1 > 2) {
                            if (var29_28 < 0 || (var74_83 = var9_10.compareTo(var35_68.multiply(BigInteger.valueOf((long)5L)))) < 0 || var74_83 == 0 && !var3_2) {
                                var6_5.setLength(0);
                                var6_5.append('0');
                                return 1;
                            }
                            var6_5.append('1');
                            return 1 + (var20_19 + 1);
                        }
                        if (var28_27) {
                            if (var32_60 > 0) {
                                var34_62 = var34_62.shiftLeft(var32_60);
                            }
                            var52_84 = var34_62;
                            if (var37_70) {
                                var34_62 = var52_84.shiftLeft(1);
                            }
                            break block107;
                        }
                        var44_99 = 1;
                        do {
                            var45_100 = var9_10.divideAndRemainder(var35_68);
                            var46_86 = var45_100[1];
                            var47_87 = (char)(48 + var45_100[0].intValue());
                            var6_5.append(var47_87);
                            if (var44_99 < var29_28) {
                                var9_10 = var46_86.multiply(BigInteger.valueOf((long)10L));
                                ++var44_99;
                                continue;
                            }
                            ** GOTO lbl391
                            break;
                        } while (true);
                        break;
                    } while (true);
                }
                do {
                    var117_52 = (long)var0;
                    var0 -= (double)var117_52;
                    var6_5.append((char)(48L + var117_52));
                    if (var116_51 == var29_28) {
                        if (var0 > 0.5 + var114_50) {
                            block108 : {
                                do {
                                    var120_54 = var6_5.charAt(-1 + var6_5.length());
                                    var6_5.setLength(-1 + var6_5.length());
                                    if (var120_54 != 57) break block108;
                                } while (var6_5.length() != 0);
                                ++var20_19;
                                var120_54 = 48;
                            }
                            var6_5.append((char)(var120_54 + '\u0001'));
                            return var20_19 + 1;
                        }
                        if (!(var0 < 0.5 - var114_50)) ** continue;
                        DToA.stripTrailingZeroes(var6_5);
                        return var20_19 + 1;
                    }
                    ++var116_51;
                    var0 *= 10.0;
                } while (true);
            }
            var89_55 = 1;
            do {
                var90_56 = (long)(var0 / var87_53);
                var92_57 = var0 - var87_53 * (double)var90_56;
                var6_5.append((char)(48L + var90_56));
                if (var89_55 == var29_28) {
                    block109 : {
                        var95_58 = var92_57 + var92_57;
                        if (!(var95_58 > var87_53)) {
                            if (var95_58 != var87_53) return var20_19 + 1;
                            if ((1L & var90_56) == 0L) {
                                if (var3_2 == false) return var20_19 + 1;
                            }
                        }
                        do {
                            var97_59 = var6_5.charAt(-1 + var6_5.length());
                            var6_5.setLength(-1 + var6_5.length());
                            if (var97_59 != 57) break block109;
                        } while (var6_5.length() != 0);
                        ++var20_19;
                        var97_59 = 48;
                    }
                    var6_5.append((char)(var97_59 + '\u0001'));
                    return var20_19 + 1;
                }
                var0 = var92_57 * 10.0;
                if (var0 == 0.0) return var20_19 + 1;
                ++var89_55;
            } while (true);
        }
        var53_85 = 1;
        do {
            block113 : {
                var54_88 = var9_10.divideAndRemainder(var35_68);
                var46_86 = var54_88[1];
                var47_87 = (char)(48 + var54_88[0].intValue());
                var55_89 = var46_86.compareTo(var52_84);
                var56_90 = var35_68.subtract(var34_62);
                var57_91 = var56_90.signum() <= 0 ? 1 : var46_86.compareTo(var56_90);
                if (var57_91 == 0 && var2_1 == 0 && (1 & DToA.word1(var0)) == 0) {
                    if (var47_87 == '9') {
                        var6_5.append('9');
                        if (DToA.roundOff(var6_5) == false) return var20_19 + 1;
                        ++var20_19;
                        var6_5.append('1');
                        return var20_19 + 1;
                    }
                    if (var55_89 > 0) {
                        var47_87 = (char)(var47_87 + '\u0001');
                    }
                    var6_5.append(var47_87);
                    return var20_19 + 1;
                }
                if (var55_89 < 0 || var55_89 == 0 && var2_1 == 0 && (1 & DToA.word1(var0)) == 0) {
                    if (var57_91 > 0 && ((var59_95 = var46_86.shiftLeft(1).compareTo(var35_68)) > 0 || var59_95 == 0 && ((var47_87 & '\u0001') == 1 || var3_2))) {
                        var60_96 = (char)(var47_87 + '\u0001');
                        if (var47_87 == '9') {
                            var6_5.append('9');
                            if (DToA.roundOff(var6_5) == false) return var20_19 + 1;
                            ++var20_19;
                            var6_5.append('1');
                            return var20_19 + 1;
                        }
                        var47_87 = var60_96;
                    }
                    var6_5.append(var47_87);
                    return var20_19 + 1;
                }
                if (var57_91 > 0) {
                    if (var47_87 == '9') {
                        var6_5.append('9');
                        if (DToA.roundOff(var6_5) == false) return var20_19 + 1;
                        ++var20_19;
                        var6_5.append('1');
                        return var20_19 + 1;
                    }
                    var6_5.append((char)(var47_87 + '\u0001'));
                    return var20_19 + 1;
                }
                var6_5.append(var47_87);
                if (var53_85 != var29_28) break block113;
lbl391: // 2 sources:
                if ((var49_97 = var46_86.shiftLeft(1).compareTo(var35_68)) <= 0 && (var49_97 != 0 || (var47_87 & '\u0001') != 1 && !var3_2)) break;
                if (DToA.roundOff(var6_5) == false) return var20_19 + 1;
                var50_98 = var20_19 + 1;
                var6_5.append('1');
                return var50_98 + 1;
            }
            var9_10 = var46_86.multiply(BigInteger.valueOf((long)10L));
            if (var52_84 == var34_62) {
                var66_94 = BigInteger.valueOf((long)10L);
                var52_84 = var34_62 = var34_62.multiply(var66_94);
            } else {
                var64_92 = BigInteger.valueOf((long)10L);
                var52_84 = var52_84.multiply(var64_92);
                var65_93 = BigInteger.valueOf((long)10L);
                var34_62 = var34_62.multiply(var65_93);
            }
            ++var53_85;
        } while (true);
        DToA.stripTrailingZeroes(var6_5);
        return var20_19 + 1;
    }

    /*
     * Enabled aggressive block sorting
     */
    static String JS_dtobasestr(int n, double d) {
        String string2;
        boolean bl;
        BigInteger bigInteger;
        long l;
        double d2;
        if (2 > n || n > 36) {
            throw new IllegalArgumentException("Bad base: " + n);
        }
        if (Double.isNaN((double)d)) {
            return "NaN";
        }
        if (Double.isInfinite((double)d)) {
            if (d > 0.0) {
                return "Infinity";
            }
            return "-Infinity";
        }
        if (d == 0.0) {
            return "0";
        }
        if (d >= 0.0) {
            bl = false;
        } else {
            bl = true;
            d = -d;
        }
        if ((double)(l = (long)(d2 = Math.floor((double)d))) == d2) {
            if (bl) {
                l = -l;
            }
            string2 = Long.toString((long)l, (int)n);
        } else {
            long l2 = Double.doubleToLongBits((double)d2);
            int n2 = 2047 & (int)(l2 >> 52);
            long l3 = n2 == 0 ? (0xFFFFFFFFFFFFFL & l2) << 1 : 0x10000000000000L | 0xFFFFFFFFFFFFFL & l2;
            if (bl) {
                l3 = -l3;
            }
            int n3 = n2 - 1075;
            BigInteger bigInteger2 = BigInteger.valueOf((long)l3);
            if (n3 > 0) {
                bigInteger2 = bigInteger2.shiftLeft(n3);
            } else if (n3 < 0) {
                bigInteger2 = bigInteger2.shiftRight(-n3);
            }
            string2 = bigInteger2.toString(n);
        }
        if (d == d2) {
            return string2;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2).append('.');
        double d3 = d - d2;
        long l4 = Double.doubleToLongBits((double)d);
        int n4 = (int)(l4 >> 32);
        int n5 = (int)l4;
        int[] arrn = new int[1];
        BigInteger bigInteger3 = DToA.d2b(d3, arrn, new int[1]);
        int n6 = -(2047 & n4 >>> 20);
        if (n6 == 0) {
            n6 = -1;
        }
        int n7 = 1076 + n6;
        BigInteger bigInteger4 = bigInteger = BigInteger.valueOf((long)1L);
        if (n5 == 0 && (1048575 & n4) == 0 && (2145386496 & n4) != 0) {
            ++n7;
            bigInteger4 = BigInteger.valueOf((long)2L);
        }
        BigInteger bigInteger5 = bigInteger3.shiftLeft(n7 + arrn[0]);
        BigInteger bigInteger6 = BigInteger.valueOf((long)1L).shiftLeft(n7);
        BigInteger bigInteger7 = BigInteger.valueOf((long)n);
        boolean bl2 = false;
        do {
            BigInteger[] arrbigInteger = bigInteger5.multiply(bigInteger7).divideAndRemainder(bigInteger6);
            bigInteger5 = arrbigInteger[1];
            int n8 = arrbigInteger[0].intValue();
            if (bigInteger == bigInteger4) {
                bigInteger = bigInteger4 = bigInteger.multiply(bigInteger7);
            } else {
                bigInteger = bigInteger.multiply(bigInteger7);
                bigInteger4 = bigInteger4.multiply(bigInteger7);
            }
            int n9 = bigInteger5.compareTo(bigInteger);
            BigInteger bigInteger8 = bigInteger6.subtract(bigInteger4);
            int n10 = bigInteger8.signum() <= 0 ? 1 : bigInteger5.compareTo(bigInteger8);
            if (n10 == 0 && (n5 & 1) == 0) {
                if (n9 > 0) {
                    ++n8;
                }
                bl2 = true;
            } else if (n9 < 0 || n9 == 0 && (n5 & 1) == 0) {
                if (n10 > 0 && (bigInteger5 = bigInteger5.shiftLeft(1)).compareTo(bigInteger6) > 0) {
                    ++n8;
                }
                bl2 = true;
            } else if (n10 > 0) {
                ++n8;
                bl2 = true;
            }
            stringBuilder.append(DToA.BASEDIGIT(n8));
        } while (!bl2);
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    static void JS_dtostr(StringBuilder stringBuilder, int n, int n2, double d) {
        boolean[] arrbl = new boolean[1];
        if (n == 2 && (d >= 1.0E21 || d <= -1.0E21)) {
            n = 0;
        }
        int n3 = dtoaModes[n];
        boolean bl = n >= 2;
        int n4 = DToA.JS_dtoa(d, n3, bl, n2, arrbl, stringBuilder);
        int n5 = stringBuilder.length();
        if (n4 != 9999) {
            boolean bl2 = false;
            int n6 = 0;
            switch (n) {
                case 0: {
                    if (n4 < -5 || n4 > 21) {
                        bl2 = true;
                        n6 = 0;
                        break;
                    }
                    n6 = n4;
                    bl2 = false;
                    break;
                }
                case 2: {
                    if (n2 >= 0) {
                        n6 = n4 + n2;
                        bl2 = false;
                        break;
                    }
                    n6 = n4;
                    bl2 = false;
                    break;
                }
                case 3: {
                    n6 = n2;
                }
                case 1: {
                    bl2 = true;
                    break;
                }
                case 4: {
                    n6 = n2;
                    if (n4 >= -5) {
                        bl2 = false;
                        if (n4 <= n2) break;
                    }
                    bl2 = true;
                }
            }
            if (n5 < n6) {
                int n7 = n6;
                n5 = n6;
                do {
                    stringBuilder.append('0');
                } while (stringBuilder.length() != n7);
            }
            if (bl2) {
                if (n5 != 1) {
                    stringBuilder.insert(1, '.');
                }
                stringBuilder.append('e');
                if (n4 - 1 >= 0) {
                    stringBuilder.append('+');
                }
                stringBuilder.append(n4 - 1);
            } else if (n4 != n5) {
                if (n4 > 0) {
                    stringBuilder.insert(n4, '.');
                } else {
                    for (int i = 0; i < 1 - n4; ++i) {
                        stringBuilder.insert(0, '0');
                    }
                    stringBuilder.insert(1, '.');
                }
            }
        }
        if (arrbl[0] && (DToA.word0(d) != Integer.MIN_VALUE || DToA.word1(d) != 0) && ((2146435072 & DToA.word0(d)) != 2146435072 || DToA.word1(d) == 0 && (1048575 & DToA.word0(d)) == 0)) {
            stringBuilder.insert(0, '-');
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static BigInteger d2b(double d, int[] arrn, int[] arrn2) {
        int n;
        byte[] arrby;
        int n2;
        long l = Double.doubleToLongBits((double)d);
        int n3 = (int)(l >>> 32);
        int n4 = (int)l;
        int n5 = n3 & 1048575;
        int n6 = (n3 & Integer.MAX_VALUE) >>> 20;
        if (n6 != 0) {
            n5 |= 1048576;
        }
        if (n4 != 0) {
            arrby = new byte[8];
            n2 = DToA.lo0bits(n4);
            int n7 = n4 >>> n2;
            if (n2 != 0) {
                DToA.stuffBits(arrby, 4, n7 | n5 << 32 - n2);
                n5 >>= n2;
            } else {
                DToA.stuffBits(arrby, 4, n7);
            }
            DToA.stuffBits(arrby, 0, n5);
            n = n5 != 0 ? 2 : 1;
        } else {
            arrby = new byte[4];
            int n8 = DToA.lo0bits(n5);
            DToA.stuffBits(arrby, 0, n5 >>>= n8);
            n2 = n8 + 32;
            n = 1;
        }
        if (n6 != 0) {
            arrn[0] = n2 + (-52 + (n6 - 1023));
            arrn2[0] = 53 - n2;
            return new BigInteger(arrby);
        }
        arrn[0] = n2 + (1 + (-52 + (n6 - 1023)));
        arrn2[0] = n * 32 - DToA.hi0bits(n5);
        return new BigInteger(arrby);
    }

    private static int hi0bits(int n) {
        int n2 = -65536 & n;
        int n3 = 0;
        if (n2 == 0) {
            n3 = 16;
            n <<= 16;
        }
        if ((-16777216 & n) == 0) {
            n3 += 8;
            n <<= 8;
        }
        if ((-268435456 & n) == 0) {
            n3 += 4;
            n <<= 4;
        }
        if ((-1073741824 & n) == 0) {
            n3 += 2;
            n <<= 2;
        }
        if ((Integer.MIN_VALUE & n) == 0) {
            ++n3;
            if ((1073741824 & n) == 0) {
                return 32;
            }
        }
        return n3;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static int lo0bits(int n) {
        int n2 = n;
        if ((n2 & 7) != 0) {
            if ((n2 & 1) != 0) {
                return 0;
            }
            if ((n2 & 2) == 0) return 2;
            return 1;
        }
        int n3 = 65535 & n2;
        int n4 = 0;
        if (n3 == 0) {
            n4 = 16;
            n2 >>>= 16;
        }
        if ((n2 & 255) == 0) {
            n4 += 8;
            n2 >>>= 8;
        }
        if ((n2 & 15) == 0) {
            n4 += 4;
            n2 >>>= 4;
        }
        if ((n2 & 3) == 0) {
            n4 += 2;
            n2 >>>= 2;
        }
        if ((n2 & 1) != 0) return n4;
        ++n4;
        if ((1 & n2 >>> 1) != 0) return n4;
        return 32;
    }

    static BigInteger pow5mult(BigInteger bigInteger, int n) {
        return bigInteger.multiply(BigInteger.valueOf((long)5L).pow(n));
    }

    static boolean roundOff(StringBuilder stringBuilder) {
        int n = stringBuilder.length();
        while (n != 0) {
            char c;
            if ((c = stringBuilder.charAt(--n)) == '9') continue;
            stringBuilder.setCharAt(n, (char)(c + '\u0001'));
            stringBuilder.setLength(n + 1);
            return false;
        }
        stringBuilder.setLength(0);
        return true;
    }

    static double setWord0(double d, int n) {
        long l = Double.doubleToLongBits((double)d);
        return Double.longBitsToDouble((long)((long)n << 32 | 0xFFFFFFFFL & l));
    }

    private static void stripTrailingZeroes(StringBuilder stringBuilder) {
        int n;
        int n2 = stringBuilder.length();
        do {
            n = n2 - 1;
            if (n2 <= 0 || stringBuilder.charAt(n) != '0') break;
            n2 = n;
        } while (true);
        stringBuilder.setLength(n + 1);
    }

    private static void stuffBits(byte[] arrby, int n, int n2) {
        arrby[n] = (byte)(n2 >> 24);
        arrby[n + 1] = (byte)(n2 >> 16);
        arrby[n + 2] = (byte)(n2 >> 8);
        arrby[n + 3] = (byte)n2;
    }

    static int word0(double d) {
        return (int)(Double.doubleToLongBits((double)d) >> 32);
    }

    static int word1(double d) {
        return (int)Double.doubleToLongBits((double)d);
    }
}

