/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Callable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextAction;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.NativeFunction;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;

public final class NativeGenerator
extends IdScriptableObject {
    public static final int GENERATOR_CLOSE = 2;
    public static final int GENERATOR_SEND = 0;
    private static final Object GENERATOR_TAG = "Generator";
    public static final int GENERATOR_THROW = 1;
    private static final int Id___iterator__ = 5;
    private static final int Id_close = 1;
    private static final int Id_next = 2;
    private static final int Id_send = 3;
    private static final int Id_throw = 4;
    private static final int MAX_PROTOTYPE_ID = 5;
    private static final long serialVersionUID = 1645892441041347273L;
    private boolean firstTime = true;
    private NativeFunction function;
    private int lineNumber;
    private String lineSource;
    private boolean locked;
    private Object savedState;

    private NativeGenerator() {
    }

    public NativeGenerator(Scriptable scriptable, NativeFunction nativeFunction, Object object) {
        this.function = nativeFunction;
        this.savedState = object;
        Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable);
        this.setParentScope(scriptable2);
        this.setPrototype((NativeGenerator)ScriptableObject.getTopScopeValue(scriptable2, GENERATOR_TAG));
    }

    static NativeGenerator init(ScriptableObject scriptableObject, boolean bl) {
        NativeGenerator nativeGenerator = new NativeGenerator();
        if (scriptableObject != null) {
            nativeGenerator.setParentScope(scriptableObject);
            nativeGenerator.setPrototype(NativeGenerator.getObjectPrototype(scriptableObject));
        }
        nativeGenerator.activatePrototypeMap(5);
        if (bl) {
            nativeGenerator.sealObject();
        }
        if (scriptableObject != null) {
            scriptableObject.associateValue(GENERATOR_TAG, nativeGenerator);
        }
        return nativeGenerator;
    }

    /*
     * Exception decompiling
     */
    private Object resume(Context var1_1, Scriptable var2_2, int var3_3, Object var4_4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 17[CATCHBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable object, Object[] arrobject) {
        Object object2;
        if (!idFunctionObject.hasTag(GENERATOR_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, (Scriptable)object, arrobject);
        }
        int n = idFunctionObject.methodId();
        if (!(object instanceof NativeGenerator)) {
            throw NativeGenerator.incompatibleCallError(idFunctionObject);
        }
        NativeGenerator nativeGenerator = (NativeGenerator)object;
        switch (n) {
            case 5: {
                return object;
            }
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                return nativeGenerator.resume(context, scriptable, 2, (Object)new GeneratorClosedException());
            }
            case 2: {
                nativeGenerator.firstTime = false;
                return nativeGenerator.resume(context, scriptable, 0, Undefined.instance);
            }
            case 3: {
                Object object3 = arrobject.length > 0 ? arrobject[0] : Undefined.instance;
                if (!nativeGenerator.firstTime) return nativeGenerator.resume(context, scriptable, 0, object3);
                if (object3.equals(Undefined.instance)) return nativeGenerator.resume(context, scriptable, 0, object3);
                throw ScriptRuntime.typeError0("msg.send.newborn");
            }
            case 4: 
        }
        if (arrobject.length > 0) {
            object2 = arrobject[0];
            return nativeGenerator.resume(context, scriptable, 1, object2);
        }
        object2 = Undefined.instance;
        return nativeGenerator.resume(context, scriptable, 1, object2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        String string3;
        int n;
        int n2 = string2.length();
        if (n2 == 4) {
            char c = string2.charAt(0);
            if (c == 'n') {
                string3 = "next";
                n = 2;
            } else {
                string3 = null;
                n = 0;
                if (c == 's') {
                    string3 = "send";
                    n = 3;
                }
            }
        } else if (n2 == 5) {
            char c = string2.charAt(0);
            if (c == 'c') {
                string3 = "close";
                n = 1;
            } else {
                string3 = null;
                n = 0;
                if (c == 't') {
                    string3 = "throw";
                    n = 4;
                }
            }
        } else {
            string3 = null;
            n = 0;
            if (n2 == 12) {
                string3 = "__iterator__";
                n = 5;
            }
        }
        if (string3 == null) return n;
        if (string3 == string2) return n;
        if (string3.equals((Object)string2)) return n;
        return 0;
    }

    @Override
    public String getClassName() {
        return "Generator";
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 1;
                string2 = "close";
                break;
            }
            case 2: {
                n2 = 1;
                string2 = "next";
                break;
            }
            case 3: {
                string2 = "send";
                n2 = 0;
                break;
            }
            case 4: {
                string2 = "throw";
                n2 = 0;
                break;
            }
            case 5: {
                n2 = 1;
                string2 = "__iterator__";
            }
        }
        this.initPrototypeMethod(GENERATOR_TAG, n, string2, n2);
    }

    private static class CloseGeneratorAction
    implements ContextAction {
        private NativeGenerator generator;

        CloseGeneratorAction(NativeGenerator nativeGenerator) {
            this.generator = nativeGenerator;
        }

        @Override
        public Object run(Context context) {
            Scriptable scriptable = ScriptableObject.getTopLevelScope(this.generator);
            return ScriptRuntime.doTopCall(new Callable(){

                @Override
                public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
                    return ((NativeGenerator)scriptable2).resume(context, scriptable, 2, (Object)new GeneratorClosedException());
                }
            }, context, scriptable, this.generator, null);
        }

    }

    public static class GeneratorClosedException
    extends RuntimeException {
        private static final long serialVersionUID = 2561315658662379681L;
    }

}

