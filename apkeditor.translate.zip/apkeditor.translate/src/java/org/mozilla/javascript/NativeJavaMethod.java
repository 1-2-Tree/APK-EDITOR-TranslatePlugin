/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Void
 *  java.lang.reflect.Array
 *  java.lang.reflect.Member
 *  java.lang.reflect.Method
 *  java.util.concurrent.CopyOnWriteArrayList
 */
package org.mozilla.javascript;

import java.lang.reflect.Array;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.concurrent.CopyOnWriteArrayList;
import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.JavaMembers;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.MemberBox;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.NativeJavaArray;
import org.mozilla.javascript.NativeJavaObject;
import org.mozilla.javascript.ResolvedOverload;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.WrapFactory;
import org.mozilla.javascript.Wrapper;

public class NativeJavaMethod
extends BaseFunction {
    private static final int PREFERENCE_AMBIGUOUS = 3;
    private static final int PREFERENCE_EQUAL = 0;
    private static final int PREFERENCE_FIRST_ARG = 1;
    private static final int PREFERENCE_SECOND_ARG = 2;
    private static final boolean debug = false;
    static final long serialVersionUID = -3440381785576412928L;
    private String functionName;
    MemberBox[] methods;
    private transient CopyOnWriteArrayList<ResolvedOverload> overloadCache;

    public NativeJavaMethod(Method method, String string2) {
        this(new MemberBox(method), string2);
    }

    NativeJavaMethod(MemberBox memberBox, String string2) {
        this.functionName = string2;
        this.methods = new MemberBox[]{memberBox};
    }

    NativeJavaMethod(MemberBox[] arrmemberBox) {
        this.functionName = arrmemberBox[0].getName();
        this.methods = arrmemberBox;
    }

    NativeJavaMethod(MemberBox[] arrmemberBox, String string2) {
        this.functionName = string2;
        this.methods = arrmemberBox;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     */
    static int findFunction(Context var0, MemberBox[] var1_1, Object[] var2_2) {
        block23 : {
            block24 : {
                block29 : {
                    if (var1_1.length == 0) {
                        return -1;
                    }
                    if (var1_1.length == 1) {
                        var27_4 = var1_1[0];
                        var28_5 = var27_4.argTypes;
                        var29_6 = var28_5.length;
                        if (var27_4.vararg != false ? --var29_6 > var2_2.length : var29_6 != var2_2.length) {
                            return -1;
                        }
                        var30_7 = 0;
                        do {
                            if (var30_7 == var29_6) {
                                return 0;
                            }
                            if (!NativeJavaObject.canConvert(var2_2[var30_7], var28_5[var30_7])) {
                                return -1;
                            }
                            ++var30_7;
                        } while (true);
                    }
                    var3_3 = -1;
                    var4_8 = null;
                    var5_9 = 0;
                    var6_10 = 0;
                    block1 : do {
                        block22 : {
                            if (var6_10 < var1_1.length) {
                                var15_11 = var1_1[var6_10];
                                var16_12 = var15_11.argTypes;
                                var17_13 = var16_12.length;
                                if (!(var15_11.vararg == false ? var17_13 != var2_2.length : --var17_13 > var2_2.length)) {
                                    for (var18_14 = 0; var18_14 < var17_13; ++var18_14) {
                                        if (NativeJavaObject.canConvert(var2_2[var18_14], var16_12[var18_14])) {
                                            continue;
                                        }
                                        break block22;
                                    }
                                    if (var3_3 >= 0) break;
                                    var3_3 = var6_10;
                                }
                            } else {
                                if (var3_3 < 0) {
                                    return -1;
                                }
                                if (var5_9 == 0) return var3_3;
                                var7_22 = new StringBuilder();
                                break block23;
                            }
                        }
lbl40: // 7 sources:
                        do {
                            ++var6_10;
                            continue block1;
                            break;
                        } while (true);
                        break;
                    } while (true);
                    var19_15 = 0;
                    var20_16 = 0;
                    var21_17 = -1;
                    do {
                        block27 : {
                            block28 : {
                                block25 : {
                                    block26 : {
                                        if (var21_17 == var5_9) break block25;
                                        var23_19 = var21_17 == -1 ? var3_3 : var4_8[var21_17];
                                        var24_20 = var1_1[var23_19];
                                        if (!var0.hasFeature(13) || (1 & var24_20.member().getModifiers()) == (1 & var15_11.member().getModifiers())) break block26;
                                        if ((1 & var24_20.member().getModifiers()) == 0) {
                                            ++var19_15;
                                        } else {
                                            ++var20_16;
                                        }
                                        break block27;
                                    }
                                    var25_21 = NativeJavaMethod.preferSignature(var2_2, var16_12, var15_11.vararg, var24_20.argTypes, var24_20.vararg);
                                    if (var25_21 != 3) break block28;
                                }
                                if (var19_15 != var5_9 + 1) break block24;
                                var3_3 = var6_10;
                                var5_9 = 0;
                                ** GOTO lbl40
                            }
                            if (var25_21 == 1) {
                                ++var19_15;
                            } else {
                                if (var25_21 != 2) break;
                                ++var20_16;
                            }
                        }
                        ++var21_17;
                    } while (true);
                    if (var25_21 != 0) {
                        Kit.codeBug();
                    }
                    if (!var24_20.isStatic() || !var24_20.getDeclaringClass().isAssignableFrom(var15_11.getDeclaringClass())) ** GOTO lbl40
                    if (var21_17 != -1) break block29;
                    var3_3 = var6_10;
                    ** GOTO lbl40
                }
                var4_8[var21_17] = var6_10;
                ** GOTO lbl40
            }
            var22_18 = var5_9 + 1;
            if (var20_16 == var22_18) ** GOTO lbl40
            if (var4_8 == null) {
                var4_8 = new int[-1 + var1_1.length];
            }
            var4_8[var5_9] = var6_10;
            ++var5_9;
            ** while (true)
        }
        for (var8_23 = -1; var8_23 != var5_9; ++var8_23) {
            var12_24 = var8_23 == -1 ? var3_3 : var4_8[var8_23];
            var7_22.append("\n    ");
            var7_22.append(var1_1[var12_24].toJavaDeclaration());
        }
        var9_25 = var1_1[var3_3];
        var10_26 = var9_25.getName();
        var11_27 = var9_25.getDeclaringClass().getName();
        if (var1_1[0].isCtor() == false) throw Context.reportRuntimeError4("msg.method.ambiguous", var11_27, var10_26, NativeJavaMethod.scriptSignature(var2_2), var7_22.toString());
        throw Context.reportRuntimeError3("msg.constructor.ambiguous", var10_26, NativeJavaMethod.scriptSignature(var2_2), var7_22.toString());
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int preferSignature(Object[] arrobject, Class<?>[] arrclass, boolean bl, Class<?>[] arrclass2, boolean bl2) {
        int n = 0;
        for (int i = 0; i < arrobject.length; ++i) {
            Class<?> class_;
            int n2;
            Class<?> class_2 = bl && i >= arrclass.length ? arrclass[-1 + arrclass.length] : arrclass[i];
            if (class_2 == (class_ = bl2 && i >= arrclass2.length ? arrclass2[-1 + arrclass2.length] : arrclass2[i])) continue;
            Object object = arrobject[i];
            int n3 = NativeJavaObject.getConversionWeight(object, class_2);
            int n4 = n3 < (n2 = NativeJavaObject.getConversionWeight(object, class_)) ? 1 : (n3 > n2 ? 2 : (n3 == 0 ? (class_2.isAssignableFrom(class_) ? 2 : (class_.isAssignableFrom(class_2) ? 1 : 3)) : 3));
            if ((n |= n4) == 3) break;
        }
        return n;
    }

    private static void printDebug(String string2, MemberBox memberBox, Object[] arrobject) {
    }

    /*
     * Enabled aggressive block sorting
     */
    static String scriptSignature(Object[] arrobject) {
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        while (n != arrobject.length) {
            Object object = arrobject[n];
            String string2 = object == null ? "null" : (object instanceof Boolean ? "boolean" : (object instanceof String ? "string" : (object instanceof Number ? "number" : (object instanceof Scriptable ? (object instanceof Undefined ? "undefined" : (object instanceof Wrapper ? ((Wrapper)object).unwrap().getClass().getName() : (object instanceof Function ? "function" : "object"))) : JavaMembers.javaSignature(object.getClass())))));
            if (n != 0) {
                stringBuilder.append(',');
            }
            stringBuilder.append(string2);
            ++n;
        }
        return stringBuilder.toString();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public Object call(Context var1_1, Scriptable var2_2, Scriptable var3_3, Object[] var4_4) {
        if (this.methods.length == 0) {
            throw new RuntimeException("No methods defined for call");
        }
        var5_5 = this.findCachedFunction(var1_1, var4_4);
        if (var5_5 < 0) {
            var24_6 = this.methods[0].method().getDeclaringClass();
            throw Context.reportRuntimeError1("msg.java.no_such_method", var24_6.getName() + '.' + this.getFunctionName() + '(' + NativeJavaMethod.scriptSignature(var4_4) + ')');
        }
        var6_7 = this.methods[var5_5];
        var7_8 = var6_7.argTypes;
        if (var6_7.vararg) {
            var18_9 = new Object[var7_8.length];
            for (var19_10 = 0; var19_10 < -1 + var7_8.length; ++var19_10) {
                var18_9[var19_10] = Context.jsToJava(var4_4[var19_10], var7_8[var19_10]);
            }
            if (var4_4.length == var7_8.length && (var4_4[-1 + var4_4.length] == null || var4_4[-1 + var4_4.length] instanceof NativeArray || var4_4[-1 + var4_4.length] instanceof NativeJavaArray)) {
                var21_11 = Context.jsToJava(var4_4[-1 + var4_4.length], var7_8[-1 + var7_8.length]);
            } else {
                var20_12 = var7_8[-1 + var7_8.length].getComponentType();
                var21_11 = Array.newInstance((Class)var20_12, (int)(1 + (var4_4.length - var7_8.length)));
                for (var22_13 = 0; var22_13 < Array.getLength((Object)var21_11); ++var22_13) {
                    var23_14 = Context.jsToJava(var4_4[var22_13 + (-1 + var7_8.length)], var20_12);
                    Array.set((Object)var21_11, (int)var22_13, (Object)var23_14);
                }
            }
            var18_9[-1 + var7_8.length] = var21_11;
            var4_4 = var18_9;
        } else {
            var8_15 = var4_4;
            for (var9_16 = 0; var9_16 < var4_4.length; ++var9_16) {
                var10_17 = var4_4[var9_16];
                var11_18 = Context.jsToJava(var10_17, var7_8[var9_16]);
                if (var11_18 == var10_17) continue;
                if (var8_15 == var4_4) {
                    var4_4 = (Object[])var4_4.clone();
                }
                var4_4[var9_16] = var11_18;
            }
        }
        if (!var6_7.isStatic()) {
            var12_23 = var3_3;
            var13_24 = var6_7.getDeclaringClass();
        } else {
            var14_19 = null;
            do {
                var15_20 = var6_7.invoke(var14_19, var4_4);
                var16_21 = var6_7.method().getReturnType();
                var17_22 = var1_1.getWrapFactory().wrap(var1_1, var2_2, var15_20, var16_21);
                if (var17_22 != null) return var17_22;
                if (var16_21 != Void.TYPE) return var17_22;
                return Undefined.instance;
                break;
            } while (true);
        }
        do {
            if (var12_23 == null) {
                throw Context.reportRuntimeError3("msg.nonjava.method", this.getFunctionName(), ScriptRuntime.toString(var3_3), var13_24.getName());
            }
            if (var12_23 instanceof Wrapper && var13_24.isInstance(var14_19 = ((Wrapper)var12_23).unwrap())) ** continue;
            var12_23 = var12_23.getPrototype();
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    String decompile(int n, int n2) {
        StringBuilder stringBuilder = new StringBuilder();
        boolean bl = (n2 & 1) != 0;
        if (!bl) {
            stringBuilder.append("function ");
            stringBuilder.append(this.getFunctionName());
            stringBuilder.append("() {");
        }
        stringBuilder.append("/*\n");
        stringBuilder.append(this.toString());
        String string2 = bl ? "*/\n" : "*/}\n";
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    int findCachedFunction(Context context, Object[] arrobject) {
        CopyOnWriteArrayList<ResolvedOverload> copyOnWriteArrayList;
        if (this.methods.length <= 1) {
            return NativeJavaMethod.findFunction(context, this.methods, arrobject);
        }
        if (this.overloadCache != null) {
            for (ResolvedOverload resolvedOverload : this.overloadCache) {
                if (!resolvedOverload.matches(arrobject)) continue;
                return resolvedOverload.index;
            }
        } else {
            this.overloadCache = new CopyOnWriteArrayList();
        }
        int n = NativeJavaMethod.findFunction(context, this.methods, arrobject);
        if (this.overloadCache.size() >= 2 * this.methods.length) return n;
        CopyOnWriteArrayList<ResolvedOverload> copyOnWriteArrayList2 = copyOnWriteArrayList = this.overloadCache;
        synchronized (copyOnWriteArrayList2) {
            ResolvedOverload resolvedOverload = new ResolvedOverload(arrobject, n);
            if (this.overloadCache.contains((Object)resolvedOverload)) return n;
            this.overloadCache.add(0, (Object)resolvedOverload);
            return n;
        }
    }

    @Override
    public String getFunctionName() {
        return this.functionName;
    }

    /*
     * Enabled aggressive block sorting
     */
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        int n2 = this.methods.length;
        while (n != n2) {
            if (this.methods[n].isMethod()) {
                Method method = this.methods[n].method();
                stringBuilder.append(JavaMembers.javaSignature(method.getReturnType()));
                stringBuilder.append(' ');
                stringBuilder.append(method.getName());
            } else {
                stringBuilder.append(this.methods[n].getName());
            }
            stringBuilder.append(JavaMembers.liveConnectSignature(this.methods[n].argTypes));
            stringBuilder.append('\n');
            ++n;
        }
        return stringBuilder.toString();
    }
}

