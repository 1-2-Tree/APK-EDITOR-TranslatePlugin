/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.mozilla.javascript;

import org.mozilla.javascript.BaseFunction;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionCall;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

public class IdFunctionObject
extends BaseFunction {
    static final long serialVersionUID = -5332312783643935019L;
    private int arity;
    private String functionName;
    private final IdFunctionCall idcall;
    private final int methodId;
    private final Object tag;
    private boolean useCallAsConstructor;

    public IdFunctionObject(IdFunctionCall idFunctionCall, Object object, int n, int n2) {
        if (n2 < 0) {
            throw new IllegalArgumentException();
        }
        this.idcall = idFunctionCall;
        this.tag = object;
        this.methodId = n;
        this.arity = n2;
        if (n2 < 0) {
            throw new IllegalArgumentException();
        }
    }

    public IdFunctionObject(IdFunctionCall idFunctionCall, Object object, int n, String string2, int n2, Scriptable scriptable) {
        super(scriptable, null);
        if (n2 < 0) {
            throw new IllegalArgumentException();
        }
        if (string2 == null) {
            throw new IllegalArgumentException();
        }
        this.idcall = idFunctionCall;
        this.tag = object;
        this.methodId = n;
        this.arity = n2;
        this.functionName = string2;
    }

    public final void addAsProperty(Scriptable scriptable) {
        ScriptableObject.defineProperty(scriptable, this.functionName, this, 2);
    }

    @Override
    public Object call(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        return this.idcall.execIdCall(this, context, scriptable, scriptable2, arrobject);
    }

    @Override
    public Scriptable createObject(Context context, Scriptable scriptable) {
        if (this.useCallAsConstructor) {
            return null;
        }
        throw ScriptRuntime.typeError1("msg.not.ctor", this.functionName);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    String decompile(int n, int n2) {
        StringBuilder stringBuilder = new StringBuilder();
        boolean bl = (n2 & 1) != 0;
        if (!bl) {
            stringBuilder.append("function ");
            stringBuilder.append(this.getFunctionName());
            stringBuilder.append("() { ");
        }
        stringBuilder.append("[native code for ");
        if (this.idcall instanceof Scriptable) {
            stringBuilder.append(((Scriptable)((Object)this.idcall)).getClassName());
            stringBuilder.append('.');
        }
        stringBuilder.append(this.getFunctionName());
        stringBuilder.append(", arity=");
        stringBuilder.append(this.getArity());
        String string2 = bl ? "]\n" : "] }\n";
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }

    public void exportAsScopeProperty() {
        this.addAsProperty(this.getParentScope());
    }

    @Override
    public int getArity() {
        return this.arity;
    }

    @Override
    public String getFunctionName() {
        if (this.functionName == null) {
            return "";
        }
        return this.functionName;
    }

    @Override
    public int getLength() {
        return this.getArity();
    }

    @Override
    public Scriptable getPrototype() {
        Scriptable scriptable = super.getPrototype();
        if (scriptable == null) {
            scriptable = IdFunctionObject.getFunctionPrototype(this.getParentScope());
            this.setPrototype(scriptable);
        }
        return scriptable;
    }

    public Object getTag() {
        return this.tag;
    }

    public final boolean hasTag(Object object) {
        if (object == null) {
            return this.tag == null;
        }
        return object.equals(this.tag);
    }

    public void initFunction(String string2, Scriptable scriptable) {
        if (string2 == null) {
            throw new IllegalArgumentException();
        }
        if (scriptable == null) {
            throw new IllegalArgumentException();
        }
        this.functionName = string2;
        this.setParentScope(scriptable);
    }

    public final void markAsConstructor(Scriptable scriptable) {
        this.useCallAsConstructor = true;
        this.setImmunePrototypeProperty(scriptable);
    }

    public final int methodId() {
        return this.methodId;
    }

    public final RuntimeException unknown() {
        return new IllegalArgumentException("BAD FUNCTION ID=" + this.methodId + " MASTER=" + this.idcall);
    }
}

