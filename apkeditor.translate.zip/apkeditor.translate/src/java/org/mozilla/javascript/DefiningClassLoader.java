/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.ClassNotFoundException
 *  java.lang.String
 *  java.security.ProtectionDomain
 */
package org.mozilla.javascript;

import java.security.ProtectionDomain;
import org.mozilla.javascript.GeneratedClassLoader;
import org.mozilla.javascript.SecurityUtilities;

public class DefiningClassLoader
extends ClassLoader
implements GeneratedClassLoader {
    private final ClassLoader parentLoader;

    public DefiningClassLoader() {
        this.parentLoader = this.getClass().getClassLoader();
    }

    public DefiningClassLoader(ClassLoader classLoader) {
        this.parentLoader = classLoader;
    }

    @Override
    public Class<?> defineClass(String string2, byte[] arrby) {
        return super.defineClass(string2, arrby, 0, arrby.length, SecurityUtilities.getProtectionDomain(this.getClass()));
    }

    @Override
    public void linkClass(Class<?> class_) {
        this.resolveClass(class_);
    }

    /*
     * Enabled aggressive block sorting
     */
    public Class<?> loadClass(String string2, boolean bl) throws ClassNotFoundException {
        Class class_ = this.findLoadedClass(string2);
        if (class_ == null) {
            class_ = this.parentLoader != null ? this.parentLoader.loadClass(string2) : this.findSystemClass(string2);
        }
        if (bl) {
            this.resolveClass(class_);
        }
        return class_;
    }
}

