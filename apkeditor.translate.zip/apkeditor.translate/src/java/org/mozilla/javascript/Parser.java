/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.BufferedReader
 *  java.io.IOException
 *  java.io.Reader
 *  java.lang.Boolean
 *  java.lang.IllegalStateException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.StackOverflowError
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package org.mozilla.javascript;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.mozilla.javascript.CompilerEnvirons;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ErrorReporter;
import org.mozilla.javascript.EvaluatorException;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Token;
import org.mozilla.javascript.TokenStream;
import org.mozilla.javascript.ast.ArrayComprehension;
import org.mozilla.javascript.ast.ArrayComprehensionLoop;
import org.mozilla.javascript.ast.ArrayLiteral;
import org.mozilla.javascript.ast.Assignment;
import org.mozilla.javascript.ast.AstNode;
import org.mozilla.javascript.ast.AstRoot;
import org.mozilla.javascript.ast.Block;
import org.mozilla.javascript.ast.BreakStatement;
import org.mozilla.javascript.ast.CatchClause;
import org.mozilla.javascript.ast.Comment;
import org.mozilla.javascript.ast.ConditionalExpression;
import org.mozilla.javascript.ast.ContinueStatement;
import org.mozilla.javascript.ast.DestructuringForm;
import org.mozilla.javascript.ast.DoLoop;
import org.mozilla.javascript.ast.ElementGet;
import org.mozilla.javascript.ast.EmptyExpression;
import org.mozilla.javascript.ast.EmptyStatement;
import org.mozilla.javascript.ast.ErrorNode;
import org.mozilla.javascript.ast.ExpressionStatement;
import org.mozilla.javascript.ast.ForInLoop;
import org.mozilla.javascript.ast.ForLoop;
import org.mozilla.javascript.ast.FunctionCall;
import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.ast.GeneratorExpression;
import org.mozilla.javascript.ast.GeneratorExpressionLoop;
import org.mozilla.javascript.ast.IdeErrorReporter;
import org.mozilla.javascript.ast.IfStatement;
import org.mozilla.javascript.ast.InfixExpression;
import org.mozilla.javascript.ast.Jump;
import org.mozilla.javascript.ast.KeywordLiteral;
import org.mozilla.javascript.ast.Label;
import org.mozilla.javascript.ast.LabeledStatement;
import org.mozilla.javascript.ast.LetNode;
import org.mozilla.javascript.ast.Loop;
import org.mozilla.javascript.ast.Name;
import org.mozilla.javascript.ast.NewExpression;
import org.mozilla.javascript.ast.NumberLiteral;
import org.mozilla.javascript.ast.ObjectLiteral;
import org.mozilla.javascript.ast.ObjectProperty;
import org.mozilla.javascript.ast.ParenthesizedExpression;
import org.mozilla.javascript.ast.PropertyGet;
import org.mozilla.javascript.ast.RegExpLiteral;
import org.mozilla.javascript.ast.ReturnStatement;
import org.mozilla.javascript.ast.Scope;
import org.mozilla.javascript.ast.ScriptNode;
import org.mozilla.javascript.ast.StringLiteral;
import org.mozilla.javascript.ast.SwitchStatement;
import org.mozilla.javascript.ast.Symbol;
import org.mozilla.javascript.ast.ThrowStatement;
import org.mozilla.javascript.ast.TryStatement;
import org.mozilla.javascript.ast.UnaryExpression;
import org.mozilla.javascript.ast.VariableDeclaration;
import org.mozilla.javascript.ast.VariableInitializer;
import org.mozilla.javascript.ast.WhileLoop;
import org.mozilla.javascript.ast.WithStatement;
import org.mozilla.javascript.ast.XmlDotQuery;
import org.mozilla.javascript.ast.XmlElemRef;
import org.mozilla.javascript.ast.XmlExpression;
import org.mozilla.javascript.ast.XmlFragment;
import org.mozilla.javascript.ast.XmlLiteral;
import org.mozilla.javascript.ast.XmlMemberGet;
import org.mozilla.javascript.ast.XmlPropRef;
import org.mozilla.javascript.ast.XmlRef;
import org.mozilla.javascript.ast.XmlString;
import org.mozilla.javascript.ast.Yield;

public class Parser {
    public static final int ARGC_LIMIT = 65536;
    static final int CLEAR_TI_MASK = 65535;
    private static final int GET_ENTRY = 2;
    private static final int METHOD_ENTRY = 8;
    private static final int PROP_ENTRY = 1;
    private static final int SET_ENTRY = 4;
    static final int TI_AFTER_EOL = 65536;
    static final int TI_CHECK_LABEL = 131072;
    boolean calledByCompileFunction;
    CompilerEnvirons compilerEnv;
    private int currentFlaggedToken = 0;
    private Comment currentJsDocComment;
    private LabeledStatement currentLabel;
    Scope currentScope;
    ScriptNode currentScriptOrFn;
    private int currentToken;
    private int endFlags;
    private IdeErrorReporter errorCollector;
    private ErrorReporter errorReporter;
    private boolean inDestructuringAssignment;
    private boolean inForInit;
    protected boolean inUseStrictDirective;
    private Map<String, LabeledStatement> labelSet;
    private List<Jump> loopAndSwitchSet;
    private List<Loop> loopSet;
    protected int nestingOfFunction;
    private boolean parseFinished;
    private int prevNameTokenLineno;
    private int prevNameTokenStart;
    private String prevNameTokenString = "";
    private List<Comment> scannedComments;
    private char[] sourceChars;
    private String sourceURI;
    private int syntaxErrorCount;
    private TokenStream ts;

    public Parser() {
        this(new CompilerEnvirons());
    }

    public Parser(CompilerEnvirons compilerEnvirons) {
        this(compilerEnvirons, compilerEnvirons.getErrorReporter());
    }

    public Parser(CompilerEnvirons compilerEnvirons, ErrorReporter errorReporter) {
        this.compilerEnv = compilerEnvirons;
        this.errorReporter = errorReporter;
        if (errorReporter instanceof IdeErrorReporter) {
            this.errorCollector = (IdeErrorReporter)errorReporter;
        }
    }

    private void addError(String string2, String string3, int n, int n2, int n3, String string4, int n4) {
        this.syntaxErrorCount = 1 + this.syntaxErrorCount;
        String string5 = this.lookupMessage(string2, string3);
        if (this.errorCollector != null) {
            this.errorCollector.error(string5, this.sourceURI, n, n2);
            return;
        }
        this.errorReporter.error(string5, this.sourceURI, n3, string4, n4);
    }

    private AstNode addExpr() throws IOException {
        AstNode astNode = this.mulExpr();
        do {
            int n = this.peekToken();
            int n2 = this.ts.tokenBeg;
            if (n != 21 && n != 22) break;
            this.consumeToken();
            astNode = new InfixExpression(n, astNode, this.mulExpr(), n2);
        } while (true);
        return astNode;
    }

    private void addStrictWarning(String string2, String string3, int n, int n2, int n3, String string4, int n4) {
        if (this.compilerEnv.isStrictMode()) {
            this.addWarning(string2, string3, n, n2, n3, string4, n4);
        }
    }

    private void addWarning(String string2, String string3, int n, int n2, int n3, String string4, int n4) {
        String string5 = this.lookupMessage(string2, string3);
        if (this.compilerEnv.reportWarningAsError()) {
            this.addError(string2, string3, n, n2, n3, string4, n4);
            return;
        }
        if (this.errorCollector != null) {
            this.errorCollector.warning(string5, this.sourceURI, n, n2);
            return;
        }
        this.errorReporter.warning(string5, this.sourceURI, n3, string4, n4);
    }

    private AstNode andExpr() throws IOException {
        AstNode astNode = this.bitOrExpr();
        if (this.matchToken(105)) {
            int n = this.ts.tokenBeg;
            astNode = new InfixExpression(105, astNode, this.andExpr(), n);
        }
        return astNode;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private List<AstNode> argumentList() throws IOException {
        boolean bl;
        if (this.matchToken(88)) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        boolean bl2 = this.inForInit;
        this.inForInit = false;
        do {
            try {
                if (this.peekToken() == 72) {
                    this.reportError("msg.yield.parenthesized");
                }
                AstNode astNode = this.assignExpr();
                int n = this.peekToken();
                if (n == 119) {
                    arrayList.add((Object)this.generatorExpression(astNode, 0, true));
                    continue;
                }
                arrayList.add((Object)astNode);
                continue;
            }
            catch (Throwable throwable) {
                this.inForInit = bl2;
                throw throwable;
            }
            catch (IOException iOException) {}
        } while (bl = this.matchToken(89));
        this.inForInit = bl2;
        this.mustMatchToken(88, "msg.no.paren.arg");
        return arrayList;
    }

    private AstNode arrayComprehension(AstNode astNode, int n) throws IOException {
        ArrayList arrayList = new ArrayList();
        while (this.peekToken() == 119) {
            arrayList.add((Object)this.arrayComprehensionLoop());
        }
        int n2 = -1;
        int n3 = this.peekToken();
        ConditionData conditionData = null;
        if (n3 == 112) {
            this.consumeToken();
            n2 = this.ts.tokenBeg - n;
            conditionData = this.condition();
        }
        this.mustMatchToken(84, "msg.no.bracket.arg");
        ArrayComprehension arrayComprehension = new ArrayComprehension(n, this.ts.tokenEnd - n);
        arrayComprehension.setResult(astNode);
        arrayComprehension.setLoops((List<ArrayComprehensionLoop>)arrayList);
        if (conditionData != null) {
            arrayComprehension.setIfPosition(n2);
            arrayComprehension.setFilter(conditionData.condition);
            arrayComprehension.setFilterLp(conditionData.lp - n);
            arrayComprehension.setFilterRp(conditionData.rp - n);
        }
        return arrayComprehension;
    }

    /*
     * Exception decompiling
     */
    private ArrayComprehensionLoop arrayComprehensionLoop() throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 5[CASE]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    private AstNode arrayLiteral() throws IOException {
        int n = 1;
        if (this.currentToken != 83) {
            this.codeBug();
        }
        int n2 = this.ts.tokenBeg;
        int n3 = this.ts.tokenEnd;
        ArrayList arrayList = new ArrayList();
        ArrayLiteral arrayLiteral = new ArrayLiteral(n2);
        boolean bl = true;
        int n4 = -1;
        int n5 = 0;
        do {
            block16 : {
                block15 : {
                    int n6;
                    block14 : {
                        if ((n6 = this.peekToken()) == 89) {
                            this.consumeToken();
                            n4 = this.ts.tokenEnd;
                            if (!bl) {
                                bl = true;
                                continue;
                            }
                            arrayList.add((Object)new EmptyExpression(this.ts.tokenBeg, n));
                            ++n5;
                            continue;
                        }
                        if (n6 != 84) break block14;
                        this.consumeToken();
                        n3 = this.ts.tokenEnd;
                        int n7 = arrayList.size();
                        if (!bl) {
                            n = 0;
                        }
                        arrayLiteral.setDestructuringLength(n + n7);
                        arrayLiteral.setSkipCount(n5);
                        if (n4 != -1) {
                            this.warnTrailingComma(n2, (List<?>)arrayList, n4);
                        }
                        break block15;
                    }
                    if (n6 == 119 && !bl && arrayList.size() == n) {
                        return this.arrayComprehension((AstNode)arrayList.get(0), n2);
                    }
                    if (n6 != 0) break block16;
                    this.reportError("msg.no.bracket.arg");
                }
                Iterator iterator = arrayList.iterator();
                do {
                    if (!iterator.hasNext()) {
                        arrayLiteral.setLength(n3 - n2);
                        return arrayLiteral;
                    }
                    arrayLiteral.addElement((AstNode)iterator.next());
                } while (true);
            }
            if (!bl) {
                this.reportError("msg.no.bracket.arg");
            }
            arrayList.add((Object)this.assignExpr());
            n4 = -1;
            bl = false;
        } while (true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private AstNode assignExpr() throws IOException {
        int n = this.peekToken();
        if (n == 72) {
            return this.returnOrYield(n, true);
        }
        AstNode astNode = this.condExpr();
        int n2 = this.peekToken();
        if (90 <= n2 && n2 <= 101) {
            this.consumeToken();
            Comment comment = this.getAndResetJsDoc();
            this.markDestructuring(astNode);
            int n3 = this.ts.tokenBeg;
            Assignment assignment = new Assignment(n2, astNode, this.assignExpr(), n3);
            if (comment == null) return assignment;
            assignment.setJsDocNode(comment);
            return assignment;
        }
        if (n2 != 82) return astNode;
        if (this.currentJsDocComment == null) return astNode;
        astNode.setJsDocNode(this.getAndResetJsDoc());
        return astNode;
    }

    private AstNode attributeAccess() throws IOException {
        int n = this.nextToken();
        int n2 = this.ts.tokenBeg;
        switch (n) {
            default: {
                this.reportError("msg.no.name.after.xmlAttr");
                return this.makeErrorNode();
            }
            case 39: {
                return this.propertyName(n2, this.ts.getString(), 0);
            }
            case 23: {
                this.saveNameTokenData(this.ts.tokenBeg, "*", this.ts.lineno);
                return this.propertyName(n2, "*", 0);
            }
            case 83: 
        }
        return this.xmlElemRef(n2, null, -1);
    }

    private void autoInsertSemicolon(AstNode astNode) throws IOException {
        int n = this.peekFlaggedToken();
        int n2 = astNode.getPosition();
        switch (65535 & n) {
            default: {
                if ((65536 & n) != 0) break;
                this.reportError("msg.no.semi.stmt");
                return;
            }
            case 82: {
                this.consumeToken();
                astNode.setLength(this.ts.tokenEnd - n2);
                return;
            }
            case -1: 
            case 0: 
            case 86: {
                this.warnMissingSemi(n2, this.nodeEnd(astNode));
                return;
            }
        }
        this.warnMissingSemi(n2, this.nodeEnd(astNode));
    }

    private AstNode bitAndExpr() throws IOException {
        AstNode astNode = this.eqExpr();
        while (this.matchToken(11)) {
            int n = this.ts.tokenBeg;
            astNode = new InfixExpression(11, astNode, this.eqExpr(), n);
        }
        return astNode;
    }

    private AstNode bitOrExpr() throws IOException {
        AstNode astNode = this.bitXorExpr();
        while (this.matchToken(9)) {
            int n = this.ts.tokenBeg;
            astNode = new InfixExpression(9, astNode, this.bitXorExpr(), n);
        }
        return astNode;
    }

    private AstNode bitXorExpr() throws IOException {
        AstNode astNode = this.bitAndExpr();
        while (this.matchToken(10)) {
            int n = this.ts.tokenBeg;
            astNode = new InfixExpression(10, astNode, this.bitAndExpr(), n);
        }
        return astNode;
    }

    private AstNode block() throws IOException {
        if (this.currentToken != 85) {
            this.codeBug();
        }
        this.consumeToken();
        int n = this.ts.tokenBeg;
        Scope scope = new Scope(n);
        scope.setLineno(this.ts.lineno);
        this.pushScope(scope);
        try {
            this.statements(scope);
            this.mustMatchToken(86, "msg.no.brace.block");
            scope.setLength(this.ts.tokenEnd - n);
            return scope;
        }
        finally {
            this.popScope();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private BreakStatement breakStatement() throws IOException {
        void var7_9;
        void var7_8;
        LabeledStatement labeledStatement;
        if (this.currentToken != 120) {
            this.codeBug();
        }
        this.consumeToken();
        int n = this.ts.lineno;
        int n2 = this.ts.tokenBeg;
        int n3 = this.ts.tokenEnd;
        int n4 = this.peekTokenOrEOL();
        Name name = null;
        if (n4 == 39) {
            name = this.createNameNode();
            n3 = this.getNodeEnd(name);
        }
        if ((labeledStatement = this.matchJumpLabelName()) == null) {
            Object var7_7 = null;
        } else {
            Label label = labeledStatement.getFirstLabel();
        }
        if (var7_8 == null && name == null) {
            if (this.loopAndSwitchSet == null || this.loopAndSwitchSet.size() == 0) {
                if (name == null) {
                    this.reportError("msg.bad.break", n2, n3 - n2);
                }
            } else {
                Jump jump = (Jump)this.loopAndSwitchSet.get(-1 + this.loopAndSwitchSet.size());
            }
        }
        BreakStatement breakStatement = new BreakStatement(n2, n3 - n2);
        breakStatement.setBreakLabel(name);
        if (var7_9 != null) {
            breakStatement.setBreakTarget((Jump)var7_9);
        }
        breakStatement.setLineno(n);
        return breakStatement;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void checkBadIncDec(UnaryExpression unaryExpression) {
        int n = this.removeParens(unaryExpression.getOperand()).getType();
        if (n != 39 && n != 33 && n != 36 && n != 67 && n != 38) {
            String string2 = unaryExpression.getType() == 106 ? "msg.bad.incr" : "msg.bad.decr";
            this.reportError(string2);
        }
    }

    private void checkCallRequiresActivation(AstNode astNode) {
        if (astNode.getType() == 39 && "eval".equals((Object)((Name)astNode).getIdentifier()) || astNode.getType() == 33 && "eval".equals((Object)((PropertyGet)astNode).getProperty().getIdentifier())) {
            this.setRequiresActivation();
        }
    }

    private RuntimeException codeBug() throws RuntimeException {
        throw Kit.codeBug("ts.cursor=" + this.ts.cursor + ", ts.tokenBeg=" + this.ts.tokenBeg + ", currentToken=" + this.currentToken);
    }

    private AstNode condExpr() throws IOException {
        boolean bl;
        AstNode astNode = this.orExpr();
        if (this.matchToken(102)) {
            int n;
            AstNode astNode2;
            int n2;
            int n3;
            block4 : {
                n2 = this.ts.lineno;
                n = this.ts.tokenBeg;
                n3 = -1;
                bl = this.inForInit;
                this.inForInit = false;
                astNode2 = this.assignExpr();
                if (!this.mustMatchToken(103, "msg.no.colon.cond")) break block4;
                n3 = this.ts.tokenBeg;
            }
            AstNode astNode3 = this.assignExpr();
            int n4 = astNode.getPosition();
            ConditionalExpression conditionalExpression = new ConditionalExpression(n4, this.getNodeEnd(astNode3) - n4);
            conditionalExpression.setLineno(n2);
            conditionalExpression.setTestExpression(astNode);
            conditionalExpression.setTrueExpression(astNode2);
            conditionalExpression.setFalseExpression(astNode3);
            conditionalExpression.setQuestionMarkPosition(n - n4);
            conditionalExpression.setColonPosition(n3 - n4);
            astNode = conditionalExpression;
        }
        return astNode;
        finally {
            this.inForInit = bl;
        }
    }

    private ConditionData condition() throws IOException {
        ConditionData conditionData = new ConditionData();
        if (this.mustMatchToken(87, "msg.no.paren.cond")) {
            conditionData.lp = this.ts.tokenBeg;
        }
        conditionData.condition = this.expr();
        if (this.mustMatchToken(88, "msg.no.paren.after.cond")) {
            conditionData.rp = this.ts.tokenBeg;
        }
        if (conditionData.condition instanceof Assignment) {
            this.addStrictWarning("msg.equal.as.assign", "", conditionData.condition.getPosition(), conditionData.condition.getLength());
        }
        return conditionData;
    }

    private void consumeToken() {
        this.currentFlaggedToken = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    private ContinueStatement continueStatement() throws IOException {
        if (this.currentToken != 121) {
            this.codeBug();
        }
        this.consumeToken();
        int n = this.ts.lineno;
        int n2 = this.ts.tokenBeg;
        int n3 = this.ts.tokenEnd;
        int n4 = this.peekTokenOrEOL();
        Name name = null;
        if (n4 == 39) {
            name = this.createNameNode();
            n3 = this.getNodeEnd(name);
        }
        LabeledStatement labeledStatement = this.matchJumpLabelName();
        Loop loop = null;
        if (labeledStatement == null && name == null) {
            if (this.loopSet == null || this.loopSet.size() == 0) {
                this.reportError("msg.continue.outside");
            } else {
                loop = (Loop)this.loopSet.get(-1 + this.loopSet.size());
            }
        } else {
            if (labeledStatement == null || !(labeledStatement.getStatement() instanceof Loop)) {
                this.reportError("msg.continue.nonloop", n2, n3 - n2);
            }
            loop = labeledStatement == null ? null : (Loop)labeledStatement.getStatement();
        }
        ContinueStatement continueStatement = new ContinueStatement(n2, n3 - n2);
        if (loop != null) {
            continueStatement.setTarget(loop);
        }
        continueStatement.setLabel(name);
        continueStatement.setLineno(n);
        return continueStatement;
    }

    private Name createNameNode() {
        return this.createNameNode(false, 39);
    }

    /*
     * Enabled aggressive block sorting
     */
    private Name createNameNode(boolean bl, int n) {
        int n2 = this.ts.tokenBeg;
        String string2 = this.ts.getString();
        int n3 = this.ts.lineno;
        if (!"".equals((Object)this.prevNameTokenString)) {
            n2 = this.prevNameTokenStart;
            string2 = this.prevNameTokenString;
            n3 = this.prevNameTokenLineno;
            this.prevNameTokenStart = 0;
            this.prevNameTokenString = "";
            this.prevNameTokenLineno = 0;
        }
        if (string2 == null) {
            if (this.compilerEnv.isIdeMode()) {
                string2 = "";
            } else {
                this.codeBug();
            }
        }
        Name name = new Name(n2, string2);
        name.setLineno(n3);
        if (bl) {
            this.checkActivationName(string2, n);
        }
        return name;
    }

    private StringLiteral createStringLiteral() {
        int n = this.ts.tokenBeg;
        StringLiteral stringLiteral = new StringLiteral(n, this.ts.tokenEnd - n);
        stringLiteral.setLineno(this.ts.lineno);
        stringLiteral.setValue(this.ts.getString());
        stringLiteral.setQuoteCharacter(this.ts.getQuoteChar());
        return stringLiteral;
    }

    private AstNode defaultXmlNamespace() throws IOException {
        if (this.currentToken != 116) {
            this.codeBug();
        }
        this.consumeToken();
        this.mustHaveXML();
        this.setRequiresActivation();
        int n = this.ts.lineno;
        int n2 = this.ts.tokenBeg;
        if (!this.matchToken(39) || !"xml".equals((Object)this.ts.getString())) {
            this.reportError("msg.bad.namespace");
        }
        if (!this.matchToken(39) || !"namespace".equals((Object)this.ts.getString())) {
            this.reportError("msg.bad.namespace");
        }
        if (!this.matchToken(90)) {
            this.reportError("msg.bad.namespace");
        }
        AstNode astNode = this.expr();
        UnaryExpression unaryExpression = new UnaryExpression(n2, this.getNodeEnd(astNode) - n2);
        unaryExpression.setOperator(74);
        unaryExpression.setOperand(astNode);
        unaryExpression.setLineno(n);
        return new ExpressionStatement(unaryExpression, true);
    }

    private AstNode destructuringPrimaryExpr() throws IOException, ParserException {
        try {
            this.inDestructuringAssignment = true;
            AstNode astNode = this.primaryExpr();
            return astNode;
        }
        finally {
            this.inDestructuringAssignment = false;
        }
    }

    private DoLoop doLoop() throws IOException {
        int n;
        DoLoop doLoop;
        int n2;
        block4 : {
            if (this.currentToken != 118) {
                this.codeBug();
            }
            this.consumeToken();
            n2 = this.ts.tokenBeg;
            doLoop = new DoLoop(n2);
            doLoop.setLineno(this.ts.lineno);
            this.enterLoop(doLoop);
            AstNode astNode = this.statement();
            this.mustMatchToken(117, "msg.no.while.do");
            doLoop.setWhilePosition(this.ts.tokenBeg - n2);
            ConditionData conditionData = this.condition();
            doLoop.setCondition(conditionData.condition);
            doLoop.setParens(conditionData.lp - n2, conditionData.rp - n2);
            n = this.getNodeEnd(astNode);
            doLoop.setBody(astNode);
            if (!this.matchToken(82)) break block4;
            n = this.ts.tokenEnd;
        }
        doLoop.setLength(n - n2);
        return doLoop;
        finally {
            this.exitLoop();
        }
    }

    private void enterLoop(Loop loop) {
        if (this.loopSet == null) {
            this.loopSet = new ArrayList();
        }
        this.loopSet.add((Object)loop);
        if (this.loopAndSwitchSet == null) {
            this.loopAndSwitchSet = new ArrayList();
        }
        this.loopAndSwitchSet.add((Object)loop);
        this.pushScope(loop);
        if (this.currentLabel != null) {
            this.currentLabel.setStatement(loop);
            this.currentLabel.getFirstLabel().setLoop(loop);
            loop.setRelative(-this.currentLabel.getPosition());
        }
    }

    private void enterSwitch(SwitchStatement switchStatement) {
        if (this.loopAndSwitchSet == null) {
            this.loopAndSwitchSet = new ArrayList();
        }
        this.loopAndSwitchSet.add((Object)switchStatement);
    }

    /*
     * Enabled aggressive block sorting
     */
    private AstNode eqExpr() throws IOException {
        AstNode astNode = this.relExpr();
        do {
            int n = this.peekToken();
            int n2 = this.ts.tokenBeg;
            switch (n) {
                default: {
                    return astNode;
                }
                case 12: 
                case 13: 
                case 46: 
                case 47: 
            }
            this.consumeToken();
            int n3 = n;
            if (this.compilerEnv.getLanguageVersion() == 120) {
                if (n == 12) {
                    n3 = 46;
                } else if (n == 13) {
                    n3 = 47;
                }
            }
            astNode = new InfixExpression(n3, astNode, this.relExpr(), n2);
        } while (true);
    }

    private void exitLoop() {
        Loop loop = (Loop)this.loopSet.remove(-1 + this.loopSet.size());
        this.loopAndSwitchSet.remove(-1 + this.loopAndSwitchSet.size());
        if (loop.getParent() != null) {
            loop.setRelative(loop.getParent().getPosition());
        }
        this.popScope();
    }

    private void exitSwitch() {
        this.loopAndSwitchSet.remove(-1 + this.loopAndSwitchSet.size());
    }

    private AstNode expr() throws IOException {
        AstNode astNode = this.assignExpr();
        int n = astNode.getPosition();
        while (this.matchToken(89)) {
            int n2 = this.ts.tokenBeg;
            if (this.compilerEnv.isStrictMode() && !astNode.hasSideEffects()) {
                this.addStrictWarning("msg.no.side.effects", "", n, this.nodeEnd(astNode) - n);
            }
            if (this.peekToken() == 72) {
                this.reportError("msg.yield.parenthesized");
            }
            astNode = new InfixExpression(89, astNode, this.assignExpr(), n2);
        }
        return astNode;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private Loop forLoop() throws IOException {
        block24 : {
            if (this.currentToken != 119) {
                this.codeBug();
            }
            this.consumeToken();
            var1_1 = this.ts.tokenBeg;
            var2_2 = this.ts.lineno;
            var3_3 = -1;
            var4_4 = -1;
            var5_5 = -1;
            var6_6 = -1;
            var7_7 = null;
            var8_8 = new Scope();
            this.pushScope(var8_8);
            try {
                block23 : {
                    block22 : {
                        block26 : {
                            block25 : {
                                var10_9 = this.matchToken(39);
                                var11_10 = false;
                                if (var10_9) {
                                    if ("each".equals((Object)this.ts.getString())) {
                                        var11_10 = true;
                                        var3_3 = this.ts.tokenBeg - var1_1;
                                    } else {
                                        this.reportError("msg.no.paren.for");
                                        var11_10 = false;
                                    }
                                }
                                if (this.mustMatchToken(87, "msg.no.paren.for")) {
                                    var5_5 = this.ts.tokenBeg - var1_1;
                                }
                                var12_11 = this.forLoopInit(this.peekToken());
                                if (!this.matchToken(52)) break block25;
                                var13_12 = true;
                                var4_4 = this.ts.tokenBeg - var1_1;
                                var14_13 = this.expr();
                                ** GOTO lbl55
                            }
                            this.mustMatchToken(82, "msg.no.semi.for");
                            if (this.peekToken() != 82) break block26;
                            var22_22 = new EmptyExpression(this.ts.tokenBeg, 1);
                            var22_22.setLineno(this.ts.lineno);
                            var14_13 = var22_22;
                            ** GOTO lbl43
                        }
                        var14_13 = this.expr();
lbl43: // 3 sources:
                        this.mustMatchToken(82, "msg.no.semi.for.cond");
                        var24_23 = this.ts.tokenEnd;
                        if (this.peekToken() != 88) break block22;
                        var25_24 = new EmptyExpression(var24_23, 1);
                        var25_24.setLineno(this.ts.lineno);
                        var7_7 = var25_24;
                        var13_12 = false;
                        break block23;
                    }
                    var7_7 = this.expr();
                    var13_12 = false;
                }
                if (this.mustMatchToken(88, "msg.no.paren.for.ctrl")) {
                    var6_6 = this.ts.tokenBeg - var1_1;
                }
                if (var13_12) {
                    var15_14 = new ForInLoop(var1_1);
                    if (var12_11 instanceof VariableDeclaration && ((VariableDeclaration)var12_11).getVariables().size() > 1) {
                        this.reportError("msg.mult.index");
                    }
                } else {
                    var20_25 = new ForLoop(var1_1);
                    var20_25.setInitializer(var12_11);
                    var20_25.setCondition(var14_13);
                    var20_25.setIncrement(var7_7);
                    var16_15 = var20_25;
                }
                var15_14.setIterator(var12_11);
                var15_14.setIteratedObject(var14_13);
                var15_14.setInPosition(var4_4);
                var15_14.setIsForEach(var11_10);
                var15_14.setEachPosition(var3_3);
                var16_15 = var15_14;
                this.currentScope.replaceWith(var16_15);
                this.popScope();
                this.enterLoop(var16_15);
            }
            catch (Throwable var9_18) {}
            try {
                var18_16 = this.statement();
                var19_17 = this.getNodeEnd(var18_16) - var1_1;
                var16_15.setLength(var19_17);
                var16_15.setBody(var18_16);
            }
            catch (Throwable var17_26) {
                this.exitLoop();
                throw var17_26;
            }
            this.exitLoop();
            if (this.currentScope != var8_8) break block24;
            this.popScope();
        }
        var16_15.setParens(var5_5, var6_6);
        var16_15.setLineno(var2_2);
        return var16_15;
        ** GOTO lbl-1000
        catch (Throwable var9_20) {
            ** GOTO lbl-1000
        }
        catch (Throwable var9_21) {}
lbl-1000: // 3 sources:
        {
            if (this.currentScope != var8_8) throw var9_19;
            this.popScope();
            throw var9_19;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private AstNode forLoopInit(int n) throws IOException {
        AstNode astNode;
        this.inForInit = true;
        if (n == 82) {
            astNode = new EmptyExpression(this.ts.tokenBeg, 1);
            astNode.setLineno(this.ts.lineno);
            return astNode;
        }
        if (n == 122 || n == 153) {
            this.consumeToken();
            return this.variables(n, this.ts.tokenBeg, false);
        }
        astNode = this.expr();
        this.markDestructuring(astNode);
        return astNode;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private FunctionNode function(int n) throws IOException {
        int n2;
        PerFunctionVariables perFunctionVariables;
        AstNode astNode;
        FunctionNode functionNode;
        block17 : {
            Name name;
            int n3 = n;
            n2 = this.ts.lineno;
            int n4 = this.ts.tokenBeg;
            if (this.matchToken(39)) {
                String string2;
                name = this.createNameNode(true, 39);
                if (this.inUseStrictDirective && ("eval".equals((Object)(string2 = name.getIdentifier())) || "arguments".equals((Object)string2))) {
                    this.reportError("msg.bad.id.strict", string2);
                }
                boolean bl = this.matchToken(87);
                astNode = null;
                if (!bl) {
                    boolean bl2 = this.compilerEnv.isAllowMemberExprAsFunctionName();
                    astNode = null;
                    if (bl2) {
                        Name name2 = name;
                        name = null;
                        astNode = this.memberExprTail(false, name2);
                    }
                    this.mustMatchToken(87, "msg.no.paren.parms");
                }
            } else {
                boolean bl = this.matchToken(87);
                astNode = null;
                name = null;
                if (!bl) {
                    boolean bl3 = this.compilerEnv.isAllowMemberExprAsFunctionName();
                    astNode = null;
                    if (bl3) {
                        astNode = this.memberExpr(false);
                    }
                    this.mustMatchToken(87, "msg.no.paren.parms");
                    name = null;
                }
            }
            int n5 = this.currentToken == 87 ? this.ts.tokenBeg : -1;
            if (astNode != null) {
                n3 = 2;
            }
            if (n3 != 2 && name != null && name.length() > 0) {
                this.defineSymbol(109, name.getIdentifier());
            }
            functionNode = new FunctionNode(n4, name);
            functionNode.setFunctionType(n);
            if (n5 != -1) {
                functionNode.setLp(n5 - n4);
            }
            functionNode.setJsDocNode(this.getAndResetJsDoc());
            perFunctionVariables = new PerFunctionVariables(functionNode);
            try {
                String string3;
                this.parseFunctionParams(functionNode);
                functionNode.setBody(this.parseFunctionBody());
                functionNode.setEncodedSourceBounds(n4, this.ts.tokenEnd);
                functionNode.setLength(this.ts.tokenEnd - n4);
                if (!this.compilerEnv.isStrictMode() || functionNode.getBody().hasConsistentReturnUsage()) break block17;
                String string4 = name != null && name.length() > 0 ? "msg.no.return.value" : "msg.anon.no.return.value";
                if (name == null) {
                    string3 = "";
                } else {
                    String string5;
                    string3 = string5 = name.getIdentifier();
                }
                this.addStrictWarning(string4, string3);
            }
            catch (Throwable throwable) {
                perFunctionVariables.restore();
                throw throwable;
            }
        }
        perFunctionVariables.restore();
        if (astNode != null) {
            Kit.codeBug();
            functionNode.setMemberExprNode(astNode);
        }
        functionNode.setSourceName(this.sourceURI);
        functionNode.setBaseLineno(n2);
        functionNode.setEndLineno(this.ts.lineno);
        if (this.compilerEnv.isIdeMode()) {
            functionNode.setParentScope(this.currentScope);
        }
        return functionNode;
    }

    private AstNode generatorExpression(AstNode astNode, int n) throws IOException {
        return this.generatorExpression(astNode, n, false);
    }

    private AstNode generatorExpression(AstNode astNode, int n, boolean bl) throws IOException {
        ArrayList arrayList = new ArrayList();
        while (this.peekToken() == 119) {
            arrayList.add((Object)this.generatorExpressionLoop());
        }
        int n2 = -1;
        int n3 = this.peekToken();
        ConditionData conditionData = null;
        if (n3 == 112) {
            this.consumeToken();
            n2 = this.ts.tokenBeg - n;
            conditionData = this.condition();
        }
        if (!bl) {
            this.mustMatchToken(88, "msg.no.paren.let");
        }
        GeneratorExpression generatorExpression = new GeneratorExpression(n, this.ts.tokenEnd - n);
        generatorExpression.setResult(astNode);
        generatorExpression.setLoops((List<GeneratorExpressionLoop>)arrayList);
        if (conditionData != null) {
            generatorExpression.setIfPosition(n2);
            generatorExpression.setFilter(conditionData.condition);
            generatorExpression.setFilterLp(conditionData.lp - n);
            generatorExpression.setFilterRp(conditionData.rp - n);
        }
        return generatorExpression;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private GeneratorExpressionLoop generatorExpressionLoop() throws IOException {
        if (this.nextToken() != 119) {
            this.codeBug();
        }
        int n = this.ts.tokenBeg;
        int n2 = -1;
        int n3 = -1;
        int n4 = -1;
        GeneratorExpressionLoop generatorExpressionLoop = new GeneratorExpressionLoop(n);
        this.pushScope(generatorExpressionLoop);
        try {
            if (this.mustMatchToken(87, "msg.no.paren.for")) {
                n2 = this.ts.tokenBeg - n;
            }
            AstNode astNode = null;
            switch (this.peekToken()) {
                default: {
                    this.reportError("msg.bad.var");
                    break;
                }
                case 83: 
                case 85: {
                    astNode = this.destructuringPrimaryExpr();
                    this.markDestructuring(astNode);
                    break;
                }
                case 39: {
                    this.consumeToken();
                    Name name = this.createNameNode();
                    astNode = name;
                }
            }
            if (astNode.getType() == 39) {
                this.defineSymbol(153, this.ts.getString(), true);
            }
            if (this.mustMatchToken(52, "msg.in.after.for.name")) {
                n4 = this.ts.tokenBeg - n;
            }
            AstNode astNode2 = this.expr();
            if (this.mustMatchToken(88, "msg.no.paren.for.ctrl")) {
                n3 = this.ts.tokenBeg - n;
            }
            generatorExpressionLoop.setLength(this.ts.tokenEnd - n);
            generatorExpressionLoop.setIterator(astNode);
            generatorExpressionLoop.setIteratedObject(astNode2);
            generatorExpressionLoop.setInPosition(n4);
            generatorExpressionLoop.setParens(n2, n3);
        }
        catch (Throwable throwable) {
            this.popScope();
            throw throwable;
        }
        this.popScope();
        return generatorExpressionLoop;
    }

    private Comment getAndResetJsDoc() {
        Comment comment = this.currentJsDocComment;
        this.currentJsDocComment = null;
        return comment;
    }

    private String getDirective(AstNode astNode) {
        AstNode astNode2;
        if (astNode instanceof ExpressionStatement && (astNode2 = ((ExpressionStatement)astNode).getExpression()) instanceof StringLiteral) {
            return ((StringLiteral)astNode2).getValue();
        }
        return null;
    }

    private int getNodeEnd(AstNode astNode) {
        return astNode.getPosition() + astNode.getLength();
    }

    private int getNumberOfEols(String string2) {
        int n = 0;
        for (int i = -1 + string2.length(); i >= 0; --i) {
            if (string2.charAt(i) != '\n') continue;
            ++n;
        }
        return n;
    }

    /*
     * Enabled aggressive block sorting
     */
    private IfStatement ifStatement() throws IOException {
        if (this.currentToken != 112) {
            this.codeBug();
        }
        this.consumeToken();
        int n = this.ts.tokenBeg;
        int n2 = this.ts.lineno;
        int n3 = -1;
        ConditionData conditionData = this.condition();
        AstNode astNode = this.statement();
        boolean bl = this.matchToken(113);
        AstNode astNode2 = null;
        if (bl) {
            n3 = this.ts.tokenBeg - n;
            astNode2 = this.statement();
        }
        AstNode astNode3 = astNode2 != null ? astNode2 : astNode;
        IfStatement ifStatement = new IfStatement(n, this.getNodeEnd(astNode3) - n);
        ifStatement.setCondition(conditionData.condition);
        ifStatement.setParens(conditionData.lp - n, conditionData.rp - n);
        ifStatement.setThenPart(astNode);
        ifStatement.setElsePart(astNode2);
        ifStatement.setElsePosition(n3);
        ifStatement.setLineno(n2);
        return ifStatement;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private AstNode let(boolean bl, int n) throws IOException {
        LetNode letNode = new LetNode(n);
        letNode.setLineno(this.ts.lineno);
        if (this.mustMatchToken(87, "msg.no.paren.after.let")) {
            letNode.setLp(this.ts.tokenBeg - n);
        }
        this.pushScope(letNode);
        try {
            boolean bl2;
            letNode.setVariables(this.variables(153, this.ts.tokenBeg, bl));
            if (this.mustMatchToken(88, "msg.no.paren.let")) {
                letNode.setRp(this.ts.tokenBeg - n);
            }
            if (bl && this.peekToken() == 85) {
                this.consumeToken();
                int n2 = this.ts.tokenBeg;
                AstNode astNode = this.statements();
                this.mustMatchToken(86, "msg.no.curly.let");
                astNode.setLength(this.ts.tokenEnd - n2);
                letNode.setLength(this.ts.tokenEnd - n);
                letNode.setBody(astNode);
                letNode.setType(153);
            } else {
                AstNode astNode = this.expr();
                letNode.setLength(this.getNodeEnd(astNode) - n);
                letNode.setBody(astNode);
                if (bl) {
                    bl2 = !this.insideFunction();
                }
            }
            this.popScope();
            return letNode;
            ExpressionStatement expressionStatement = new ExpressionStatement(letNode, bl2);
            expressionStatement.setLineno(letNode.getLineno());
            return expressionStatement;
        }
        finally {
            this.popScope();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private AstNode letStatement() throws IOException {
        if (this.currentToken != 153) {
            this.codeBug();
        }
        this.consumeToken();
        int n = this.ts.lineno;
        int n2 = this.ts.tokenBeg;
        AstNode astNode = this.peekToken() == 87 ? this.let(true, n2) : this.variables(153, n2, true);
        astNode.setLineno(n);
        return astNode;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int lineBeginningFor(int n) {
        if (this.sourceChars == null) {
            return -1;
        }
        int n2 = 0;
        if (n <= 0) return n2;
        char[] arrc = this.sourceChars;
        if (n >= arrc.length) {
            n = -1 + arrc.length;
        }
        do {
            n2 = 0;
            if (--n < 0) return n2;
        } while (!ScriptRuntime.isJSLineTerminator(arrc[n]));
        return n + 1;
    }

    private ErrorNode makeErrorNode() {
        ErrorNode errorNode = new ErrorNode(this.ts.tokenBeg, this.ts.tokenEnd - this.ts.tokenBeg);
        errorNode.setLineno(this.ts.lineno);
        return errorNode;
    }

    private LabeledStatement matchJumpLabelName() throws IOException {
        int n = this.peekTokenOrEOL();
        LabeledStatement labeledStatement = null;
        if (n == 39) {
            this.consumeToken();
            Map<String, LabeledStatement> map = this.labelSet;
            labeledStatement = null;
            if (map != null) {
                labeledStatement = (LabeledStatement)this.labelSet.get((Object)this.ts.getString());
            }
            if (labeledStatement == null) {
                this.reportError("msg.undef.label");
            }
        }
        return labeledStatement;
    }

    private boolean matchToken(int n) throws IOException {
        if (this.peekToken() != n) {
            return false;
        }
        this.consumeToken();
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private AstNode memberExpr(boolean bl) throws IOException {
        AstNode astNode;
        int n = this.peekToken();
        int n2 = this.ts.lineno;
        if (n != 30) {
            astNode = this.primaryExpr();
        } else {
            this.consumeToken();
            int n3 = this.ts.tokenBeg;
            NewExpression newExpression = new NewExpression(n3);
            AstNode astNode2 = this.memberExpr(false);
            int n4 = this.getNodeEnd(astNode2);
            newExpression.setTarget(astNode2);
            if (this.matchToken(87)) {
                int n5 = this.ts.tokenBeg;
                List<AstNode> list = this.argumentList();
                if (list != null && list.size() > 65536) {
                    this.reportError("msg.too.many.constructor.args");
                }
                int n6 = this.ts.tokenBeg;
                n4 = this.ts.tokenEnd;
                if (list != null) {
                    newExpression.setArguments(list);
                }
                newExpression.setParens(n5 - n3, n6 - n3);
            }
            if (this.matchToken(85)) {
                ObjectLiteral objectLiteral = this.objectLiteral();
                n4 = this.getNodeEnd(objectLiteral);
                newExpression.setInitializer(objectLiteral);
            }
            newExpression.setLength(n4 - n3);
            astNode = newExpression;
        }
        astNode.setLineno(n2);
        return this.memberExprTail(bl, astNode);
    }

    /*
     * Enabled aggressive block sorting
     */
    private AstNode memberExprTail(boolean bl, AstNode astNode) throws IOException {
        if (astNode == null) {
            this.codeBug();
        }
        int n = astNode.getPosition();
        block6 : do {
            int n2 = this.peekToken();
            switch (n2) {
                default: {
                    return astNode;
                }
                case 108: 
                case 143: {
                    int n3 = this.ts.lineno;
                    astNode = this.propertyAccess(n2, astNode);
                    astNode.setLineno(n3);
                    continue block6;
                }
                case 146: {
                    this.consumeToken();
                    int n4 = this.ts.tokenBeg;
                    int n5 = -1;
                    int n6 = this.ts.lineno;
                    this.mustHaveXML();
                    this.setRequiresActivation();
                    AstNode astNode2 = this.expr();
                    int n7 = this.getNodeEnd(astNode2);
                    if (this.mustMatchToken(88, "msg.no.paren")) {
                        n5 = this.ts.tokenBeg;
                        n7 = this.ts.tokenEnd;
                    }
                    XmlDotQuery xmlDotQuery = new XmlDotQuery(n, n7 - n);
                    xmlDotQuery.setLeft(astNode);
                    xmlDotQuery.setRight(astNode2);
                    xmlDotQuery.setOperatorPosition(n4);
                    xmlDotQuery.setRp(n5 - n);
                    xmlDotQuery.setLineno(n6);
                    astNode = xmlDotQuery;
                    continue block6;
                }
                case 83: {
                    this.consumeToken();
                    int n8 = this.ts.tokenBeg;
                    int n9 = -1;
                    int n10 = this.ts.lineno;
                    AstNode astNode3 = this.expr();
                    int n11 = this.getNodeEnd(astNode3);
                    if (this.mustMatchToken(84, "msg.no.bracket.index")) {
                        n9 = this.ts.tokenBeg;
                        n11 = this.ts.tokenEnd;
                    }
                    ElementGet elementGet = new ElementGet(n, n11 - n);
                    elementGet.setTarget(astNode);
                    elementGet.setElement(astNode3);
                    elementGet.setParens(n8, n9);
                    elementGet.setLineno(n10);
                    astNode = elementGet;
                    continue block6;
                }
                case 87: {
                    if (!bl) return astNode;
                    int n12 = this.ts.lineno;
                    this.consumeToken();
                    this.checkCallRequiresActivation(astNode);
                    FunctionCall functionCall = new FunctionCall(n);
                    functionCall.setTarget(astNode);
                    functionCall.setLineno(n12);
                    functionCall.setLp(this.ts.tokenBeg - n);
                    List<AstNode> list = this.argumentList();
                    if (list != null && list.size() > 65536) {
                        this.reportError("msg.too.many.function.args");
                    }
                    functionCall.setArguments(list);
                    functionCall.setRp(this.ts.tokenBeg - n);
                    functionCall.setLength(this.ts.tokenEnd - n);
                    astNode = functionCall;
                    continue block6;
                }
            }
            break;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private ObjectProperty methodDefinition(int n, AstNode astNode, int n2) throws IOException {
        FunctionNode functionNode = this.function(2);
        Name name = functionNode.getFunctionName();
        if (name != null && name.length() != 0) {
            this.reportError("msg.bad.prop");
        }
        ObjectProperty objectProperty = new ObjectProperty(n);
        switch (n2) {
            case 2: {
                objectProperty.setIsGetterMethod();
                functionNode.setFunctionIsGetterMethod();
                break;
            }
            case 4: {
                objectProperty.setIsSetterMethod();
                functionNode.setFunctionIsSetterMethod();
                break;
            }
            case 8: {
                objectProperty.setIsNormalMethod();
                functionNode.setFunctionIsNormalMethod();
                break;
            }
        }
        int n3 = this.getNodeEnd(functionNode);
        objectProperty.setLeft(astNode);
        objectProperty.setRight(functionNode);
        objectProperty.setLength(n3 - n);
        return objectProperty;
    }

    private AstNode mulExpr() throws IOException {
        AstNode astNode = this.unaryExpr();
        do {
            int n = this.peekToken();
            int n2 = this.ts.tokenBeg;
            switch (n) {
                default: {
                    return astNode;
                }
                case 23: 
                case 24: 
                case 25: 
            }
            this.consumeToken();
            astNode = new InfixExpression(n, astNode, this.unaryExpr(), n2);
        } while (true);
    }

    private void mustHaveXML() {
        if (!this.compilerEnv.isXmlAvailable()) {
            this.reportError("msg.XML.not.available");
        }
    }

    private boolean mustMatchToken(int n, String string2) throws IOException {
        return this.mustMatchToken(n, string2, this.ts.tokenBeg, this.ts.tokenEnd - this.ts.tokenBeg);
    }

    private boolean mustMatchToken(int n, String string2, int n2, int n3) throws IOException {
        if (this.matchToken(n)) {
            return true;
        }
        this.reportError(string2, n2, n3);
        return false;
    }

    private AstNode name(int n, int n2) throws IOException {
        String string2 = this.ts.getString();
        int n3 = this.ts.tokenBeg;
        int n4 = this.ts.lineno;
        if ((131072 & n) != 0 && this.peekToken() == 103) {
            Label label = new Label(n3, this.ts.tokenEnd - n3);
            label.setName(string2);
            label.setLineno(this.ts.lineno);
            return label;
        }
        this.saveNameTokenData(n3, string2, n4);
        if (this.compilerEnv.isXmlAvailable()) {
            return this.propertyName(-1, string2, 0);
        }
        return this.createNameNode(true, 39);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private AstNode nameOrLabel() throws IOException {
        LabeledStatement labeledStatement;
        int n;
        AstNode astNode;
        block10 : {
            boolean bl = true;
            if (this.currentToken != 39) {
                throw this.codeBug();
            }
            n = this.ts.tokenBeg;
            this.currentFlaggedToken = 131072 | this.currentFlaggedToken;
            AstNode astNode2 = this.expr();
            if (astNode2.getType() != 130) {
                boolean bl2 = !this.insideFunction() ? bl : false;
                ExpressionStatement expressionStatement = new ExpressionStatement(astNode2, bl2);
                expressionStatement.lineno = astNode2.lineno;
                return expressionStatement;
            }
            labeledStatement = new LabeledStatement(n);
            this.recordLabel((Label)astNode2, labeledStatement);
            labeledStatement.setLineno(this.ts.lineno);
            do {
                AstNode astNode3;
                block12 : {
                    block9 : {
                        AstNode astNode4;
                        block11 : {
                            int n2 = this.peekToken();
                            astNode = null;
                            if (n2 != 39) break block11;
                            this.currentFlaggedToken = 131072 | this.currentFlaggedToken;
                            astNode3 = this.expr();
                            if (astNode3.getType() == 130) break block12;
                            if (this.insideFunction()) {
                                bl = false;
                            }
                            astNode = new ExpressionStatement(astNode3, bl);
                            this.autoInsertSemicolon(astNode);
                        }
                        this.currentLabel = labeledStatement;
                        if (astNode != null) break block9;
                        astNode = astNode4 = this.statementHelper();
                    }
                    this.currentLabel = null;
                    for (Label label : labeledStatement.getLabels()) {
                        this.labelSet.remove((Object)label.getName());
                    }
                    break block10;
                }
                this.recordLabel((Label)astNode3, labeledStatement);
            } while (true);
            catch (Throwable throwable) {
                this.currentLabel = null;
                Iterator iterator = labeledStatement.getLabels().iterator();
                while (iterator.hasNext()) {
                    Label label = (Label)iterator.next();
                    this.labelSet.remove((Object)label.getName());
                }
                throw throwable;
            }
        }
        int n3 = astNode.getParent() == null ? this.getNodeEnd(astNode) - n : this.getNodeEnd(astNode);
        labeledStatement.setLength(n3);
        labeledStatement.setStatement(astNode);
        return labeledStatement;
    }

    private int nextFlaggedToken() throws IOException {
        this.peekToken();
        int n = this.currentFlaggedToken;
        this.consumeToken();
        return n;
    }

    private int nextToken() throws IOException {
        int n = this.peekToken();
        this.consumeToken();
        return n;
    }

    private int nodeEnd(AstNode astNode) {
        return astNode.getPosition() + astNode.getLength();
    }

    private static final boolean nowAllSet(int n, int n2, int n3) {
        return (n & n3) != n3 && (n2 & n3) == n3;
    }

    /*
     * Enabled aggressive block sorting
     */
    private ObjectLiteral objectLiteral() throws IOException {
        int n = this.ts.tokenBeg;
        int n2 = this.ts.lineno;
        int n3 = -1;
        ArrayList arrayList = new ArrayList();
        boolean bl = this.inUseStrictDirective;
        HashSet hashSet = null;
        HashSet hashSet2 = null;
        if (bl) {
            hashSet = new HashSet();
            hashSet2 = new HashSet();
        }
        Comment comment = this.getAndResetJsDoc();
        do {
            String string2;
            int n4 = 1;
            int n5 = this.peekToken();
            Comment comment2 = this.getAndResetJsDoc();
            if (n5 == 86) {
                if (n3 == -1) break;
                this.warnTrailingComma(n, (List<?>)arrayList, n3);
                break;
            }
            AstNode astNode = this.objliteralProperty();
            if (astNode == null) {
                string2 = null;
                this.reportError("msg.bad.prop");
            } else {
                string2 = this.ts.getString();
                int n6 = this.ts.tokenBeg;
                this.consumeToken();
                int n7 = this.peekToken();
                if (n7 != 89 && n7 != 103 && n7 != 86) {
                    if (n7 == 87) {
                        n4 = 8;
                    } else if (astNode.getType() == 39) {
                        if ("get".equals((Object)string2)) {
                            n4 = 2;
                        } else if ("set".equals((Object)string2)) {
                            n4 = 4;
                        }
                    }
                    if (n4 == 2 || n4 == 4) {
                        astNode = this.objliteralProperty();
                        if (astNode == null) {
                            this.reportError("msg.bad.prop");
                        }
                        this.consumeToken();
                    }
                    if (astNode == null) {
                        string2 = null;
                    } else {
                        string2 = this.ts.getString();
                        ObjectProperty objectProperty = this.methodDefinition(n6, astNode, n4);
                        astNode.setJsDocNode(comment2);
                        arrayList.add((Object)objectProperty);
                    }
                } else {
                    astNode.setJsDocNode(comment2);
                    arrayList.add((Object)this.plainProperty(astNode, n5));
                }
            }
            if (this.inUseStrictDirective && string2 != null) {
                switch (n4) {
                    case 1: 
                    case 8: {
                        if (hashSet.contains((Object)string2) || hashSet2.contains((Object)string2)) {
                            this.addError("msg.dup.obj.lit.prop.strict", string2);
                        }
                        hashSet.add((Object)string2);
                        hashSet2.add((Object)string2);
                        break;
                    }
                    case 2: {
                        if (hashSet.contains((Object)string2)) {
                            this.addError("msg.dup.obj.lit.prop.strict", string2);
                        }
                        hashSet.add((Object)string2);
                        break;
                    }
                    case 4: {
                        if (hashSet2.contains((Object)string2)) {
                            this.addError("msg.dup.obj.lit.prop.strict", string2);
                        }
                        hashSet2.add((Object)string2);
                        break;
                    }
                }
            }
            this.getAndResetJsDoc();
            if (!this.matchToken(89)) break;
            n3 = this.ts.tokenEnd;
        } while (true);
        this.mustMatchToken(86, "msg.no.brace.prop");
        ObjectLiteral objectLiteral = new ObjectLiteral(n, this.ts.tokenEnd - n);
        if (comment != null) {
            objectLiteral.setJsDocNode(comment);
        }
        objectLiteral.setElements((List<ObjectProperty>)arrayList);
        objectLiteral.setLineno(n2);
        return objectLiteral;
    }

    private AstNode objliteralProperty() throws IOException {
        switch (this.peekToken()) {
            default: {
                if (!this.compilerEnv.isReservedKeywordAsIdentifier() || !TokenStream.isKeyword(this.ts.getString())) break;
                return this.createNameNode();
            }
            case 39: {
                return this.createNameNode();
            }
            case 41: {
                return this.createStringLiteral();
            }
            case 40: {
                return new NumberLiteral(this.ts.tokenBeg, this.ts.getString(), this.ts.getNumber());
            }
        }
        return null;
    }

    private AstNode orExpr() throws IOException {
        AstNode astNode = this.andExpr();
        if (this.matchToken(104)) {
            int n = this.ts.tokenBeg;
            astNode = new InfixExpression(104, astNode, this.orExpr(), n);
        }
        return astNode;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private AstNode parenExpr() throws IOException {
        boolean bl = this.inForInit;
        this.inForInit = false;
        try {
            Comment comment = this.getAndResetJsDoc();
            int n = this.ts.lineno;
            int n2 = this.ts.tokenBeg;
            AstNode astNode = this.expr();
            if (this.peekToken() == 119) {
                AstNode astNode2 = this.generatorExpression(astNode, n2);
                return astNode2;
            }
            ParenthesizedExpression parenthesizedExpression = new ParenthesizedExpression(astNode);
            if (comment == null) {
                comment = this.getAndResetJsDoc();
            }
            if (comment != null) {
                parenthesizedExpression.setJsDocNode(comment);
            }
            this.mustMatchToken(88, "msg.no.paren");
            parenthesizedExpression.setLength(this.ts.tokenEnd - parenthesizedExpression.getPosition());
            parenthesizedExpression.setLineno(n);
            return parenthesizedExpression;
        }
        finally {
            this.inForInit = bl;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private AstRoot parse() throws IOException {
        int n;
        AstRoot astRoot;
        int n2;
        block16 : {
            astRoot = new AstRoot(0);
            this.currentScriptOrFn = astRoot;
            this.currentScope = astRoot;
            n = this.ts.lineno;
            n2 = 0;
            boolean bl = true;
            boolean bl2 = this.inUseStrictDirective;
            this.inUseStrictDirective = false;
            do {
                AstNode astNode;
                block15 : {
                    String string2;
                    block17 : {
                        try {
                            block19 : {
                                block18 : {
                                    int n3 = this.peekToken();
                                    if (n3 <= 0) break block18;
                                    if (n3 != 109) break block19;
                                    try {
                                        this.consumeToken();
                                        try {
                                            int n4 = this.calledByCompileFunction ? 2 : 1;
                                            FunctionNode functionNode = this.function(n4);
                                            astNode = functionNode;
                                            break block15;
                                        }
                                        catch (ParserException parserException) {}
                                    }
                                    catch (StackOverflowError stackOverflowError) {
                                        String string3 = this.lookupMessage("msg.too.deep.parser.recursion");
                                        if (this.compilerEnv.isIdeMode()) break;
                                        throw Context.reportRuntimeError(string3, this.sourceURI, this.ts.lineno, null, 0);
                                    }
                                }
                                this.inUseStrictDirective = bl2;
                                break block16;
                            }
                            astNode = this.statement();
                            if (!bl) break block15;
                            string2 = this.getDirective(astNode);
                            if (string2 != null) break block17;
                            bl = false;
                            break block15;
                        }
                        catch (Throwable throwable) {
                            this.inUseStrictDirective = bl2;
                            throw throwable;
                        }
                    }
                    if (string2.equals((Object)"use strict")) {
                        this.inUseStrictDirective = true;
                        astRoot.setInStrictMode(true);
                    }
                }
                n2 = this.getNodeEnd(astNode);
                astRoot.addChildToBack(astNode);
                astNode.setParent(astRoot);
            } while (true);
            this.inUseStrictDirective = bl2;
        }
        if (this.syntaxErrorCount != 0) {
            String string4 = this.lookupMessage("msg.got.syntax.errors", String.valueOf((int)this.syntaxErrorCount));
            if (!this.compilerEnv.isIdeMode()) {
                throw this.errorReporter.runtimeError(string4, this.sourceURI, n, null, 0);
            }
        }
        if (this.scannedComments != null) {
            int n5 = -1 + this.scannedComments.size();
            n2 = Math.max((int)n2, (int)this.getNodeEnd((AstNode)this.scannedComments.get(n5)));
            Iterator iterator = this.scannedComments.iterator();
            while (iterator.hasNext()) {
                astRoot.addComment((Comment)iterator.next());
            }
        }
        astRoot.setLength(n2 - 0);
        astRoot.setSourceName(this.sourceURI);
        astRoot.setBaseLineno(n);
        astRoot.setEndLineno(this.ts.lineno);
        return astRoot;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private AstNode parseFunctionBody() throws IOException {
        block16 : {
            var1_1 = this.matchToken(85);
            var2_2 = false;
            if (!var1_1) {
                if (this.compilerEnv.getLanguageVersion() < 180) {
                    this.reportError("msg.no.brace.body");
                } else {
                    var2_2 = true;
                }
            }
            this.nestingOfFunction = 1 + this.nestingOfFunction;
            var3_3 = this.ts.tokenBeg;
            var4_4 = new Block(var3_3);
            var5_5 = true;
            var6_6 = this.inUseStrictDirective;
            var4_4.setLineno(this.ts.lineno);
            if (!var2_2) ** GOTO lbl36
            try {
                var13_7 = new ReturnStatement(this.ts.lineno);
                var13_7.setReturnValue(this.assignExpr());
                var13_7.putProp(25, (Object)Boolean.TRUE);
                var4_4.putProp(25, (Object)Boolean.TRUE);
                var4_4.addStatement(var13_7);
                break block16;
            }
            catch (ParserException var8_11) {}
            break block16;
            finally {
                this.nestingOfFunction = -1 + this.nestingOfFunction;
                this.inUseStrictDirective = var6_6;
            }
        }
lbl28: // 2 sources:
        do {
            var9_8 = this.ts.tokenEnd;
            this.getAndResetJsDoc();
            if (!var2_2 && this.mustMatchToken(86, "msg.no.brace.after.body")) {
                var9_8 = this.ts.tokenEnd;
            }
            var4_4.setLength(var9_8 - var3_3);
            return var4_4;
            break;
        } while (true);
lbl-1000: // 5 sources:
        {
            var4_4.addStatement(var11_9);
lbl36: // 2 sources:
            switch (this.peekToken()) {
                case -1: 
                case 0: 
                case 86: {
                    ** continue;
                }
                case 109: {
                    this.consumeToken();
                    var11_9 = this.function(1);
                    continue block10;
                }
            }
            var11_9 = this.statement();
            if (!var5_5) continue;
            var12_10 = this.getDirective(var11_9);
            if (var12_10 == null) {
                var5_5 = false;
                continue;
            }
            if (!var12_10.equals((Object)"use strict")) continue;
            this.inUseStrictDirective = true;
            ** while (true)
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void parseFunctionParams(FunctionNode functionNode) throws IOException {
        if (this.matchToken(88)) {
            functionNode.setRp(this.ts.tokenBeg - functionNode.getPosition());
            return;
        }
        HashMap hashMap = null;
        HashSet hashSet = new HashSet();
        do {
            int n;
            if ((n = this.peekToken()) == 83 || n == 85) {
                AstNode astNode = this.destructuringPrimaryExpr();
                this.markDestructuring(astNode);
                functionNode.addParam(astNode);
                if (hashMap == null) {
                    hashMap = new HashMap();
                }
                String string2 = this.currentScriptOrFn.getNextTempName();
                this.defineSymbol(87, string2, false);
                hashMap.put((Object)string2, (Object)astNode);
                continue;
            }
            if (this.mustMatchToken(39, "msg.no.parm")) {
                functionNode.addParam(this.createNameNode());
                String string3 = this.ts.getString();
                this.defineSymbol(87, string3);
                if (!this.inUseStrictDirective) continue;
                if ("eval".equals((Object)string3) || "arguments".equals((Object)string3)) {
                    this.reportError("msg.bad.id.strict", string3);
                }
                if (hashSet.contains((Object)string3)) {
                    this.addError("msg.dup.param.strict", string3);
                }
                hashSet.add((Object)string3);
                continue;
            }
            functionNode.addParam(this.makeErrorNode());
        } while (this.matchToken(89));
        if (hashMap != null) {
            Node node = new Node(89);
            for (Map.Entry entry : hashMap.entrySet()) {
                node.addChildToBack(this.createDestructuringAssignment(122, (Node)entry.getValue(), this.createName((String)entry.getKey())));
            }
            functionNode.putProp(23, node);
        }
        if (!this.mustMatchToken(88, "msg.no.paren.after.parms")) return;
        functionNode.setRp(this.ts.tokenBeg - functionNode.getPosition());
    }

    private int peekFlaggedToken() throws IOException {
        this.peekToken();
        return this.currentFlaggedToken;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int peekToken() throws IOException {
        if (this.currentFlaggedToken != 0) {
            return this.currentToken;
        }
        int n = this.ts.getLineno();
        int n2 = this.ts.getToken();
        boolean bl = false;
        while (n2 == 1 || n2 == 161) {
            if (n2 == 1) {
                ++n;
                bl = true;
            } else if (this.compilerEnv.isRecordingComments()) {
                String string2 = this.ts.getAndResetCurrentComment();
                this.recordComment(n, string2);
                n += this.getNumberOfEols(string2);
            }
            n2 = this.ts.getToken();
        }
        this.currentToken = n2;
        int n3 = bl ? 65536 : 0;
        this.currentFlaggedToken = n3 | n2;
        return this.currentToken;
    }

    private int peekTokenOrEOL() throws IOException {
        int n = this.peekToken();
        if ((65536 & this.currentFlaggedToken) != 0) {
            n = 1;
        }
        return n;
    }

    private ObjectProperty plainProperty(AstNode astNode, int n) throws IOException {
        int n2 = this.peekToken();
        if ((n2 == 89 || n2 == 86) && n == 39 && this.compilerEnv.getLanguageVersion() >= 180) {
            if (!this.inDestructuringAssignment) {
                this.reportError("msg.bad.object.init");
            }
            Name name = new Name(astNode.getPosition(), astNode.getString());
            ObjectProperty objectProperty = new ObjectProperty();
            objectProperty.putProp(26, (Object)Boolean.TRUE);
            objectProperty.setLeftAndRight(astNode, name);
            return objectProperty;
        }
        this.mustMatchToken(103, "msg.no.colon.prop");
        ObjectProperty objectProperty = new ObjectProperty();
        objectProperty.setOperatorPosition(this.ts.tokenBeg);
        objectProperty.setLeftAndRight(astNode, this.assignExpr());
        return objectProperty;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private AstNode primaryExpr() throws IOException {
        var1_1 = this.nextFlaggedToken();
        var2_2 = var1_1 & 65535;
        switch (var2_2) {
            default: {
                this.reportError("msg.syntax");
                ** GOTO lbl45
            }
            case 109: {
                return this.function(2);
            }
            case 83: {
                return this.arrayLiteral();
            }
            case 85: {
                return this.objectLiteral();
            }
            case 153: {
                return this.let(false, this.ts.tokenBeg);
            }
            case 87: {
                return this.parenExpr();
            }
            case 147: {
                this.mustHaveXML();
                return this.attributeAccess();
            }
            case 39: {
                return this.name(var1_1, var2_2);
            }
            case 40: {
                var6_3 = this.ts.getString();
                if (this.inUseStrictDirective && this.ts.isNumberOctal()) {
                    this.reportError("msg.no.octal.strict");
                }
                if (this.ts.isNumberOctal()) {
                    var6_3 = "0" + var6_3;
                }
                if (this.ts.isNumberHex() == false) return new NumberLiteral(this.ts.tokenBeg, var6_3, this.ts.getNumber());
                var6_3 = "0x" + var6_3;
                return new NumberLiteral(this.ts.tokenBeg, var6_3, this.ts.getNumber());
            }
            case 41: {
                return this.createStringLiteral();
            }
            case 24: 
            case 100: {
                this.ts.readRegExp(var2_2);
                var4_4 = this.ts.tokenBeg;
                var5_5 = new RegExpLiteral(var4_4, this.ts.tokenEnd - var4_4);
                var5_5.setValue(this.ts.getString());
                var5_5.setFlags(this.ts.readAndClearRegExpFlags());
                return var5_5;
            }
            case 42: 
            case 43: 
            case 44: 
            case 45: {
                var3_6 = this.ts.tokenBeg;
                return new KeywordLiteral(var3_6, this.ts.tokenEnd - var3_6, var2_2);
            }
            case 127: {
                this.reportError("msg.reserved.id");
            }
lbl45: // 3 sources:
            case -1: {
                return this.makeErrorNode();
            }
            case 0: 
        }
        this.reportError("msg.unexpected.eof");
        return this.makeErrorNode();
    }

    /*
     * Enabled aggressive block sorting
     */
    private AstNode propertyAccess(int n, AstNode astNode) throws IOException {
        AstNode astNode2;
        int n2;
        InfixExpression infixExpression;
        boolean bl;
        block12 : {
            if (astNode == null) {
                this.codeBug();
            }
            int n3 = this.ts.lineno;
            n2 = this.ts.tokenBeg;
            this.consumeToken();
            int n4 = 0;
            if (n == 143) {
                this.mustHaveXML();
                n4 = 4;
            }
            if (!this.compilerEnv.isXmlAvailable()) {
                if (!(this.nextToken() == 39 || this.compilerEnv.isReservedKeywordAsIdentifier() && TokenStream.isKeyword(this.ts.getString()))) {
                    this.reportError("msg.no.name.after.dot");
                }
                PropertyGet propertyGet = new PropertyGet(astNode, this.createNameNode(true, 33), n2);
                propertyGet.setLineno(n3);
                return propertyGet;
            }
            int n5 = this.nextToken();
            switch (n5) {
                default: {
                    String string2;
                    if (this.compilerEnv.isReservedKeywordAsIdentifier() && (string2 = Token.keywordToName(n5)) != null) {
                        this.saveNameTokenData(this.ts.tokenBeg, string2, this.ts.lineno);
                        astNode2 = this.propertyName(-1, string2, n4);
                        break;
                    }
                    break block12;
                }
                case 50: {
                    this.saveNameTokenData(this.ts.tokenBeg, "throw", this.ts.lineno);
                    astNode2 = this.propertyName(-1, "throw", n4);
                    break;
                }
                case 39: {
                    astNode2 = this.propertyName(-1, this.ts.getString(), n4);
                    break;
                }
                case 23: {
                    this.saveNameTokenData(this.ts.tokenBeg, "*", this.ts.lineno);
                    astNode2 = this.propertyName(-1, "*", n4);
                    break;
                }
                case 147: {
                    astNode2 = this.attributeAccess();
                }
            }
            infixExpression = (bl = astNode2 instanceof XmlRef) ? new XmlMemberGet() : new PropertyGet();
        }
        this.reportError("msg.no.name.after.dot");
        return this.makeErrorNode();
        if (bl && n == 108) {
            infixExpression.setType(108);
        }
        int n6 = astNode.getPosition();
        infixExpression.setPosition(n6);
        infixExpression.setLength(this.getNodeEnd(astNode2) - n6);
        infixExpression.setOperatorPosition(n2 - n6);
        infixExpression.setLineno(astNode.getLineno());
        infixExpression.setLeft(astNode);
        infixExpression.setRight(astNode2);
        return infixExpression;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private AstNode propertyName(int var1_1, String var2_2, int var3_3) throws IOException {
        block6 : {
            var4_4 = var1_1 != -1 ? var1_1 : this.ts.tokenBeg;
            var5_5 = this.ts.lineno;
            var6_6 = -1;
            var7_7 = this.createNameNode(true, this.currentToken);
            var8_8 = this.matchToken(144);
            var9_9 = null;
            if (!var8_8) ** GOTO lbl20
            var9_9 = var7_7;
            var6_6 = this.ts.tokenBeg;
            switch (this.nextToken()) {
                default: {
                    this.reportError("msg.no.name.after.coloncolon");
                    return this.makeErrorNode();
                }
                case 39: {
                    var7_7 = this.createNameNode();
                    ** GOTO lbl20
                }
                case 23: {
                    this.saveNameTokenData(this.ts.tokenBeg, "*", this.ts.lineno);
                    var7_7 = this.createNameNode(false, -1);
lbl20: // 3 sources:
                    if (var9_9 == null && var3_3 == 0 && var1_1 == -1) {
                        return var7_7;
                    }
                    break block6;
                }
                case 83: 
            }
            return this.xmlElemRef(var1_1, var9_9, var6_6);
        }
        var10_10 = new XmlPropRef(var4_4, this.getNodeEnd(var7_7) - var4_4);
        var10_10.setAtPos(var1_1);
        var10_10.setNamespace(var9_9);
        var10_10.setColonPos(var6_6);
        var10_10.setPropName(var7_7);
        var10_10.setLineno(var5_5);
        return var10_10;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private String readFully(Reader reader) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(reader);
        try {
            int n;
            char[] arrc = new char[1024];
            StringBuilder stringBuilder = new StringBuilder(1024);
            while ((n = bufferedReader.read(arrc, 0, 1024)) != -1) {
                stringBuilder.append(arrc, 0, n);
            }
            String string2 = stringBuilder.toString();
            return string2;
        }
        finally {
            bufferedReader.close();
        }
    }

    private void recordComment(int n, String string2) {
        if (this.scannedComments == null) {
            this.scannedComments = new ArrayList();
        }
        Comment comment = new Comment(this.ts.tokenBeg, this.ts.getTokenLength(), this.ts.commentType, string2);
        if (this.ts.commentType == Token.CommentType.JSDOC && this.compilerEnv.isRecordingLocalJsDocComments()) {
            this.currentJsDocComment = comment;
        }
        comment.setLineno(n);
        this.scannedComments.add((Object)comment);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void recordLabel(Label label, LabeledStatement labeledStatement) throws IOException {
        if (this.peekToken() != 103) {
            this.codeBug();
        }
        this.consumeToken();
        String string2 = label.getName();
        if (this.labelSet == null) {
            this.labelSet = new HashMap();
        } else {
            LabeledStatement labeledStatement2 = (LabeledStatement)this.labelSet.get((Object)string2);
            if (labeledStatement2 != null) {
                if (this.compilerEnv.isIdeMode()) {
                    Label label2 = labeledStatement2.getLabelByName(string2);
                    this.reportError("msg.dup.label", label2.getAbsolutePosition(), label2.getLength());
                }
                this.reportError("msg.dup.label", label.getPosition(), label.getLength());
            }
        }
        labeledStatement.addLabel(label);
        this.labelSet.put((Object)string2, (Object)labeledStatement);
    }

    /*
     * Enabled aggressive block sorting
     */
    private AstNode relExpr() throws IOException {
        AstNode astNode = this.shiftExpr();
        do {
            int n = this.peekToken();
            int n2 = this.ts.tokenBeg;
            switch (n) {
                case 52: {
                    if (!this.inForInit) break;
                }
                default: {
                    return astNode;
                }
                case 14: 
                case 15: 
                case 16: 
                case 17: 
                case 53: 
            }
            this.consumeToken();
            astNode = new InfixExpression(n, astNode, this.shiftExpr(), n2);
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     */
    private AstNode returnOrYield(int n, boolean bl) throws IOException {
        void var9_13;
        if (!this.insideFunction()) {
            String string2 = n == 4 ? "msg.bad.return" : "msg.bad.yield";
            this.reportError(string2);
        }
        this.consumeToken();
        int n2 = this.ts.lineno;
        int n3 = this.ts.tokenBeg;
        int n4 = this.ts.tokenEnd;
        int n5 = this.peekTokenOrEOL();
        AstNode astNode = null;
        switch (n5) {
            default: {
                astNode = this.expr();
                n4 = this.getNodeEnd(astNode);
            }
            case -1: 
            case 0: 
            case 1: 
            case 72: 
            case 82: 
            case 84: 
            case 86: 
            case 88: 
        }
        int n6 = this.endFlags;
        if (n == 4) {
            int n7 = this.endFlags;
            int n8 = astNode == null ? 2 : 4;
            this.endFlags = n8 | n7;
            ReturnStatement returnStatement = new ReturnStatement(n3, n4 - n3, astNode);
            if (Parser.nowAllSet(n6, this.endFlags, 6)) {
                this.addStrictWarning("msg.return.inconsistent", "", n3, n4 - n3);
            }
        } else {
            if (!this.insideFunction()) {
                this.reportError("msg.bad.yield");
            }
            this.endFlags = 8 | this.endFlags;
            Yield yield = new Yield(n3, n4 - n3, astNode);
            this.setRequiresActivation();
            this.setIsGenerator();
            if (!bl) {
                ExpressionStatement expressionStatement = new ExpressionStatement(yield);
            }
        }
        if (this.insideFunction() && Parser.nowAllSet(n6, this.endFlags, 12)) {
            Name name = ((FunctionNode)this.currentScriptOrFn).getFunctionName();
            if (name == null || name.length() == 0) {
                this.addError("msg.anon.generator.returns", "");
            } else {
                this.addError("msg.generator.returns", name.getIdentifier());
            }
        }
        var9_13.setLineno(n2);
        return var9_13;
    }

    private void saveNameTokenData(int n, String string2, int n2) {
        this.prevNameTokenStart = n;
        this.prevNameTokenString = string2;
        this.prevNameTokenLineno = n2;
    }

    private AstNode shiftExpr() throws IOException {
        AstNode astNode = this.addExpr();
        do {
            int n = this.peekToken();
            int n2 = this.ts.tokenBeg;
            switch (n) {
                default: {
                    return astNode;
                }
                case 18: 
                case 19: 
                case 20: 
            }
            this.consumeToken();
            astNode = new InfixExpression(n, astNode, this.addExpr(), n2);
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private AstNode statement() throws IOException {
        int n;
        block7 : {
            n = this.ts.tokenBeg;
            try {
                AstNode astNode = this.statementHelper();
                if (astNode == null) break block7;
                if (!this.compilerEnv.isStrictMode() || astNode.hasSideEffects()) return astNode;
                {
                    int n2 = astNode.getPosition();
                    int n3 = Math.max((int)n2, (int)this.lineBeginningFor(n2));
                    String string2 = astNode instanceof EmptyStatement ? "msg.extra.trailing.semi" : "msg.no.side.effects";
                    this.addStrictWarning(string2, "", n3, this.nodeEnd(astNode) - n3);
                    return astNode;
                }
            }
            catch (ParserException parserException) {}
        }
        block5 : do {
            int n4 = this.peekTokenOrEOL();
            this.consumeToken();
            switch (n4) {
                default: {
                    continue block5;
                }
                case -1: 
                case 0: 
                case 1: 
                case 82: 
            }
            break;
        } while (true);
        return new EmptyStatement(n, this.ts.tokenBeg - n);
    }

    /*
     * Enabled aggressive block sorting
     */
    private AstNode statementHelper() throws IOException {
        AstNode astNode;
        block27 : {
            AstNode astNode2;
            int n;
            boolean bl;
            block26 : {
                bl = true;
                if (this.currentLabel != null && this.currentLabel.getStatement() != null) {
                    this.currentLabel = null;
                }
                int n2 = this.peekToken();
                switch (n2) {
                    default: {
                        n = this.ts.lineno;
                        astNode2 = this.expr();
                        if (this.insideFunction()) break;
                        break block26;
                    }
                    case 112: {
                        return this.ifStatement();
                    }
                    case 114: {
                        return this.switchStatement();
                    }
                    case 117: {
                        return this.whileLoop();
                    }
                    case 118: {
                        return this.doLoop();
                    }
                    case 119: {
                        return this.forLoop();
                    }
                    case 81: {
                        return this.tryStatement();
                    }
                    case 50: {
                        astNode = this.throwStatement();
                        break block27;
                    }
                    case 120: {
                        astNode = this.breakStatement();
                        break block27;
                    }
                    case 121: {
                        astNode = this.continueStatement();
                        break block27;
                    }
                    case 123: {
                        if (this.inUseStrictDirective) {
                            this.reportError("msg.no.with.strict");
                        }
                        return this.withStatement();
                    }
                    case 122: 
                    case 154: {
                        this.consumeToken();
                        int n3 = this.ts.lineno;
                        astNode = this.variables(this.currentToken, this.ts.tokenBeg, bl);
                        astNode.setLineno(n3);
                        break block27;
                    }
                    case 153: {
                        astNode = this.letStatement();
                        if (!(astNode instanceof VariableDeclaration) || this.peekToken() != 82) {
                            return astNode;
                        }
                        break block27;
                    }
                    case 4: 
                    case 72: {
                        astNode = this.returnOrYield(n2, false);
                        break block27;
                    }
                    case 160: {
                        this.consumeToken();
                        astNode = new KeywordLiteral(this.ts.tokenBeg, this.ts.tokenEnd - this.ts.tokenBeg, n2);
                        astNode.setLineno(this.ts.lineno);
                        break block27;
                    }
                    case 85: {
                        return this.block();
                    }
                    case -1: {
                        this.consumeToken();
                        return this.makeErrorNode();
                    }
                    case 82: {
                        this.consumeToken();
                        int n4 = this.ts.tokenBeg;
                        EmptyStatement emptyStatement = new EmptyStatement(n4, this.ts.tokenEnd - n4);
                        emptyStatement.setLineno(this.ts.lineno);
                        return emptyStatement;
                    }
                    case 109: {
                        this.consumeToken();
                        return this.function(3);
                    }
                    case 116: {
                        astNode = this.defaultXmlNamespace();
                        break block27;
                    }
                    case 39: {
                        astNode = this.nameOrLabel();
                        if (!(astNode instanceof ExpressionStatement)) {
                            return astNode;
                        }
                        break block27;
                    }
                }
                bl = false;
            }
            astNode = new ExpressionStatement(astNode2, bl);
            astNode.setLineno(n);
        }
        this.autoInsertSemicolon(astNode);
        return astNode;
    }

    private AstNode statements() throws IOException {
        return this.statements(null);
    }

    /*
     * Enabled aggressive block sorting
     */
    private AstNode statements(AstNode astNode) throws IOException {
        int n;
        if (this.currentToken != 85 && !this.compilerEnv.isIdeMode()) {
            this.codeBug();
        }
        int n2 = this.ts.tokenBeg;
        AstNode astNode2 = astNode != null ? astNode : new Block(n2);
        astNode2.setLineno(this.ts.lineno);
        while ((n = this.peekToken()) > 0 && n != 86) {
            astNode2.addChild(this.statement());
        }
        astNode2.setLength(this.ts.tokenBeg - n2);
        return astNode2;
    }

    /*
     * Exception decompiling
     */
    private SwitchStatement switchStatement() throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 11[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    private ThrowStatement throwStatement() throws IOException {
        if (this.currentToken != 50) {
            this.codeBug();
        }
        this.consumeToken();
        int n = this.ts.tokenBeg;
        int n2 = this.ts.lineno;
        if (this.peekTokenOrEOL() == 1) {
            this.reportError("msg.bad.throw.eol");
        }
        AstNode astNode = this.expr();
        ThrowStatement throwStatement = new ThrowStatement(n, this.getNodeEnd(astNode), astNode);
        throwStatement.setLineno(n2);
        return throwStatement;
    }

    /*
     * Enabled aggressive block sorting
     */
    private TryStatement tryStatement() throws IOException {
        if (this.currentToken != 81) {
            this.codeBug();
        }
        this.consumeToken();
        Comment comment = this.getAndResetJsDoc();
        int n = this.ts.tokenBeg;
        int n2 = this.ts.lineno;
        int n3 = -1;
        if (this.peekToken() != 85) {
            this.reportError("msg.no.brace.try");
        }
        AstNode astNode = this.statement();
        int n4 = this.getNodeEnd(astNode);
        int n5 = this.peekToken();
        ArrayList arrayList = null;
        boolean bl = false;
        if (n5 != 124) {
            arrayList = null;
            if (n5 != 125) {
                this.mustMatchToken(125, "msg.try.no.catchfinally");
            }
        } else {
            while (this.matchToken(124)) {
                AstNode astNode2;
                int n6 = this.ts.lineno;
                if (bl) {
                    this.reportError("msg.catch.unreachable");
                }
                int n7 = this.ts.tokenBeg;
                int n8 = -1;
                int n9 = -1;
                int n10 = -1;
                if (this.mustMatchToken(87, "msg.no.paren.catch")) {
                    n8 = this.ts.tokenBeg;
                }
                this.mustMatchToken(39, "msg.bad.catchcond");
                Name name = this.createNameNode();
                String string2 = name.getIdentifier();
                if (this.inUseStrictDirective && ("eval".equals((Object)string2) || "arguments".equals((Object)string2))) {
                    this.reportError("msg.bad.id.strict", string2);
                }
                if (this.matchToken(112)) {
                    n10 = this.ts.tokenBeg;
                    astNode2 = this.expr();
                } else {
                    bl = true;
                    astNode2 = null;
                }
                if (this.mustMatchToken(88, "msg.bad.catchcond")) {
                    n9 = this.ts.tokenBeg;
                }
                this.mustMatchToken(85, "msg.no.brace.catchblock");
                Block block = (Block)this.statements();
                n4 = this.getNodeEnd(block);
                CatchClause catchClause = new CatchClause(n7);
                catchClause.setVarName(name);
                catchClause.setCatchCondition(astNode2);
                catchClause.setBody(block);
                if (n10 != -1) {
                    catchClause.setIfPosition(n10 - n7);
                }
                catchClause.setParens(n8, n9);
                catchClause.setLineno(n6);
                if (this.mustMatchToken(86, "msg.no.brace.after.body")) {
                    n4 = this.ts.tokenEnd;
                }
                catchClause.setLength(n4 - n7);
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add((Object)catchClause);
            }
        }
        boolean bl2 = this.matchToken(125);
        AstNode astNode3 = null;
        if (bl2) {
            n3 = this.ts.tokenBeg;
            astNode3 = this.statement();
            n4 = this.getNodeEnd(astNode3);
        }
        TryStatement tryStatement = new TryStatement(n, n4 - n);
        tryStatement.setTryBlock(astNode);
        tryStatement.setCatchClauses((List<CatchClause>)arrayList);
        tryStatement.setFinallyBlock(astNode3);
        if (n3 != -1) {
            tryStatement.setFinallyPosition(n3 - n);
        }
        tryStatement.setLineno(n2);
        if (comment != null) {
            tryStatement.setJsDocNode(comment);
        }
        return tryStatement;
    }

    /*
     * Enabled aggressive block sorting
     */
    private AstNode unaryExpr() throws IOException {
        int n = this.peekToken();
        int n2 = this.ts.lineno;
        switch (n) {
            case 26: 
            case 27: 
            case 32: 
            case 126: {
                this.consumeToken();
                UnaryExpression unaryExpression = new UnaryExpression(n, this.ts.tokenBeg, this.unaryExpr());
                unaryExpression.setLineno(n2);
                return unaryExpression;
            }
            case 21: {
                this.consumeToken();
                UnaryExpression unaryExpression = new UnaryExpression(28, this.ts.tokenBeg, this.unaryExpr());
                unaryExpression.setLineno(n2);
                return unaryExpression;
            }
            case 22: {
                this.consumeToken();
                UnaryExpression unaryExpression = new UnaryExpression(29, this.ts.tokenBeg, this.unaryExpr());
                unaryExpression.setLineno(n2);
                return unaryExpression;
            }
            case 106: 
            case 107: {
                this.consumeToken();
                UnaryExpression unaryExpression = new UnaryExpression(n, this.ts.tokenBeg, this.memberExpr(true));
                unaryExpression.setLineno(n2);
                this.checkBadIncDec(unaryExpression);
                return unaryExpression;
            }
            case 31: {
                this.consumeToken();
                UnaryExpression unaryExpression = new UnaryExpression(n, this.ts.tokenBeg, this.unaryExpr());
                unaryExpression.setLineno(n2);
                return unaryExpression;
            }
            case -1: {
                this.consumeToken();
                return this.makeErrorNode();
            }
            case 14: {
                if (this.compilerEnv.isXmlAvailable()) {
                    this.consumeToken();
                    return this.memberExprTail(true, this.xmlInitializer());
                } else {
                    break;
                }
            }
        }
        AstNode astNode = this.memberExpr(true);
        int n3 = this.peekTokenOrEOL();
        if (n3 != 106 && n3 != 107) {
            return astNode;
        }
        this.consumeToken();
        UnaryExpression unaryExpression = new UnaryExpression(n3, this.ts.tokenBeg, astNode, true);
        unaryExpression.setLineno(n2);
        this.checkBadIncDec(unaryExpression);
        return unaryExpression;
    }

    /*
     * Enabled aggressive block sorting
     */
    private VariableDeclaration variables(int n, int n2, boolean bl) throws IOException {
        int n3;
        VariableDeclaration variableDeclaration = new VariableDeclaration(n2);
        variableDeclaration.setType(n);
        variableDeclaration.setLineno(this.ts.lineno);
        Comment comment = this.getAndResetJsDoc();
        if (comment != null) {
            variableDeclaration.setJsDocNode(comment);
        }
        do {
            AstNode astNode;
            Name name = null;
            int n4 = this.peekToken();
            int n5 = this.ts.tokenBeg;
            n3 = this.ts.tokenEnd;
            if (n4 == 83 || n4 == 85) {
                astNode = this.destructuringPrimaryExpr();
                n3 = this.getNodeEnd(astNode);
                if (!(astNode instanceof DestructuringForm)) {
                    this.reportError("msg.bad.assign.left", n5, n3 - n5);
                }
                this.markDestructuring(astNode);
            } else {
                String string2;
                this.mustMatchToken(39, "msg.bad.var");
                name = this.createNameNode();
                name.setLineno(this.ts.getLineno());
                if (this.inUseStrictDirective && ("eval".equals((Object)(string2 = this.ts.getString())) || "arguments".equals((Object)this.ts.getString()))) {
                    this.reportError("msg.bad.id.strict", string2);
                }
                this.defineSymbol(n, this.ts.getString(), this.inForInit);
                astNode = null;
            }
            int n6 = this.ts.lineno;
            Comment comment2 = this.getAndResetJsDoc();
            boolean bl2 = this.matchToken(90);
            AstNode astNode2 = null;
            if (bl2) {
                astNode2 = this.assignExpr();
                n3 = this.getNodeEnd(astNode2);
            }
            VariableInitializer variableInitializer = new VariableInitializer(n5, n3 - n5);
            if (astNode != null) {
                if (astNode2 == null && !this.inForInit) {
                    this.reportError("msg.destruct.assign.no.init");
                }
                variableInitializer.setTarget(astNode);
            } else {
                variableInitializer.setTarget(name);
            }
            variableInitializer.setInitializer(astNode2);
            variableInitializer.setType(n);
            variableInitializer.setJsDocNode(comment2);
            variableInitializer.setLineno(n6);
            variableDeclaration.addVariable(variableInitializer);
        } while (this.matchToken(89));
        variableDeclaration.setLength(n3 - n2);
        variableDeclaration.setIsStatement(bl);
        return variableDeclaration;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void warnMissingSemi(int n, int n2) {
        if (this.compilerEnv.isStrictMode()) {
            int[] arrn = new int[2];
            String string2 = this.ts.getLine(n2, arrn);
            int n3 = this.compilerEnv.isIdeMode() ? Math.max((int)n, (int)(n2 - arrn[1])) : n;
            if (string2 == null) {
                this.addStrictWarning("msg.missing.semi", "", n3, n2 - n3);
                return;
            }
            this.addStrictWarning("msg.missing.semi", "", n3, n2 - n3, arrn[0], string2, arrn[1]);
        }
    }

    private void warnTrailingComma(int n, List<?> list, int n2) {
        if (this.compilerEnv.getWarnTrailingComma()) {
            if (!list.isEmpty()) {
                n = ((AstNode)list.get(0)).getPosition();
            }
            int n3 = Math.max((int)n, (int)this.lineBeginningFor(n2));
            this.addWarning("msg.extra.trailing.comma", n3, n2 - n3);
        }
    }

    private WhileLoop whileLoop() throws IOException {
        if (this.currentToken != 117) {
            this.codeBug();
        }
        this.consumeToken();
        int n = this.ts.tokenBeg;
        WhileLoop whileLoop = new WhileLoop(n);
        whileLoop.setLineno(this.ts.lineno);
        this.enterLoop(whileLoop);
        try {
            ConditionData conditionData = this.condition();
            whileLoop.setCondition(conditionData.condition);
            whileLoop.setParens(conditionData.lp - n, conditionData.rp - n);
            AstNode astNode = this.statement();
            whileLoop.setLength(this.getNodeEnd(astNode) - n);
            whileLoop.setBody(astNode);
            return whileLoop;
        }
        finally {
            this.exitLoop();
        }
    }

    private WithStatement withStatement() throws IOException {
        if (this.currentToken != 123) {
            this.codeBug();
        }
        this.consumeToken();
        Comment comment = this.getAndResetJsDoc();
        int n = this.ts.lineno;
        int n2 = this.ts.tokenBeg;
        int n3 = -1;
        int n4 = -1;
        if (this.mustMatchToken(87, "msg.no.paren.with")) {
            n3 = this.ts.tokenBeg;
        }
        AstNode astNode = this.expr();
        if (this.mustMatchToken(88, "msg.no.paren.after.with")) {
            n4 = this.ts.tokenBeg;
        }
        AstNode astNode2 = this.statement();
        WithStatement withStatement = new WithStatement(n2, this.getNodeEnd(astNode2) - n2);
        withStatement.setJsDocNode(comment);
        withStatement.setExpression(astNode);
        withStatement.setStatement(astNode2);
        withStatement.setParens(n3, n4);
        withStatement.setLineno(n);
        return withStatement;
    }

    /*
     * Enabled aggressive block sorting
     */
    private XmlElemRef xmlElemRef(int n, Name name, int n2) throws IOException {
        int n3 = this.ts.tokenBeg;
        int n4 = -1;
        int n5 = n != -1 ? n : n3;
        AstNode astNode = this.expr();
        int n6 = this.getNodeEnd(astNode);
        if (this.mustMatchToken(84, "msg.no.bracket.index")) {
            n4 = this.ts.tokenBeg;
            n6 = this.ts.tokenEnd;
        }
        XmlElemRef xmlElemRef = new XmlElemRef(n5, n6 - n5);
        xmlElemRef.setNamespace(name);
        xmlElemRef.setColonPos(n2);
        xmlElemRef.setAtPos(n);
        xmlElemRef.setExpression(astNode);
        xmlElemRef.setBrackets(n3, n4);
        return xmlElemRef;
    }

    /*
     * Enabled aggressive block sorting
     */
    private AstNode xmlInitializer() throws IOException {
        if (this.currentToken != 14) {
            this.codeBug();
        }
        int n = this.ts.tokenBeg;
        int n2 = this.ts.getFirstXMLToken();
        if (n2 != 145 && n2 != 148) {
            this.reportError("msg.syntax");
            return this.makeErrorNode();
        }
        XmlLiteral xmlLiteral = new XmlLiteral(n);
        xmlLiteral.setLineno(this.ts.lineno);
        block4 : do {
            switch (n2) {
                default: {
                    this.reportError("msg.syntax");
                    return this.makeErrorNode();
                }
                case 145: {
                    xmlLiteral.addFragment(new XmlString(this.ts.tokenBeg, this.ts.getString()));
                    this.mustMatchToken(85, "msg.syntax");
                    int n3 = this.ts.tokenBeg;
                    AstNode astNode = this.peekToken() == 86 ? new EmptyExpression(n3, this.ts.tokenEnd - n3) : this.expr();
                    this.mustMatchToken(86, "msg.syntax");
                    XmlExpression xmlExpression = new XmlExpression(n3, astNode);
                    xmlExpression.setIsXmlAttribute(this.ts.isXMLAttribute());
                    xmlExpression.setLength(this.ts.tokenEnd - n3);
                    xmlLiteral.addFragment(xmlExpression);
                    n2 = this.ts.getNextXMLToken();
                    continue block4;
                }
                case 148: 
            }
            break;
        } while (true);
        xmlLiteral.addFragment(new XmlString(this.ts.tokenBeg, this.ts.getString()));
        return xmlLiteral;
    }

    void addError(String string2) {
        this.addError(string2, this.ts.tokenBeg, this.ts.tokenEnd - this.ts.tokenBeg);
    }

    void addError(String string2, int n, int n2) {
        this.addError(string2, null, n, n2);
    }

    void addError(String string2, String string3) {
        this.addError(string2, string3, this.ts.tokenBeg, this.ts.tokenEnd - this.ts.tokenBeg);
    }

    void addError(String string2, String string3, int n, int n2) {
        this.syntaxErrorCount = 1 + this.syntaxErrorCount;
        String string4 = this.lookupMessage(string2, string3);
        if (this.errorCollector != null) {
            this.errorCollector.error(string4, this.sourceURI, n, n2);
            return;
        }
        int n3 = 1;
        int n4 = 1;
        String string5 = "";
        if (this.ts != null) {
            n3 = this.ts.getLineno();
            string5 = this.ts.getLine();
            n4 = this.ts.getOffset();
        }
        this.errorReporter.error(string4, this.sourceURI, n3, string5, n4);
    }

    void addStrictWarning(String string2, String string3) {
        int n = -1;
        int n2 = -1;
        if (this.ts != null) {
            n = this.ts.tokenBeg;
            n2 = this.ts.tokenEnd - this.ts.tokenBeg;
        }
        this.addStrictWarning(string2, string3, n, n2);
    }

    void addStrictWarning(String string2, String string3, int n, int n2) {
        if (this.compilerEnv.isStrictMode()) {
            this.addWarning(string2, string3, n, n2);
        }
    }

    void addWarning(String string2, int n, int n2) {
        this.addWarning(string2, null, n, n2);
    }

    void addWarning(String string2, String string3) {
        int n = -1;
        int n2 = -1;
        if (this.ts != null) {
            n = this.ts.tokenBeg;
            n2 = this.ts.tokenEnd - this.ts.tokenBeg;
        }
        this.addWarning(string2, string3, n, n2);
    }

    void addWarning(String string2, String string3, int n, int n2) {
        String string4 = this.lookupMessage(string2, string3);
        if (this.compilerEnv.reportWarningAsError()) {
            this.addError(string2, string3, n, n2);
            return;
        }
        if (this.errorCollector != null) {
            this.errorCollector.warning(string4, this.sourceURI, n, n2);
            return;
        }
        this.errorReporter.warning(string4, this.sourceURI, this.ts.getLineno(), this.ts.getLine(), this.ts.getOffset());
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void checkActivationName(String string2, int n) {
        block9 : {
            block8 : {
                boolean bl;
                if (!this.insideFunction()) break block8;
                if ("arguments".equals((Object)string2) || this.compilerEnv.getActivationNames() != null && this.compilerEnv.getActivationNames().contains((Object)string2)) {
                    bl = true;
                } else {
                    boolean bl2 = "length".equals((Object)string2);
                    bl = false;
                    if (bl2) {
                        bl = false;
                        if (n == 33) {
                            int n2 = this.compilerEnv.getLanguageVersion();
                            bl = false;
                            if (n2 == 120) {
                                bl = true;
                            }
                        }
                    }
                }
                if (bl) break block9;
            }
            return;
        }
        this.setRequiresActivation();
    }

    protected void checkMutableReference(Node node) {
        if ((4 & node.getIntProp(16, 0)) != 0) {
            this.reportError("msg.bad.assign.left");
        }
    }

    Node createDestructuringAssignment(int n, Node node, Node node2) {
        String string2 = this.currentScriptOrFn.getNextTempName();
        Node node3 = this.destructuringAssignmentHelper(n, node, node2, string2);
        node3.getLastChild().addChildToBack(this.createName(string2));
        return node3;
    }

    protected Node createName(int n, String string2, Node node) {
        Node node2 = this.createName(string2);
        node2.setType(n);
        if (node != null) {
            node2.addChildToBack(node);
        }
        return node2;
    }

    protected Node createName(String string2) {
        this.checkActivationName(string2, 39);
        return Node.newString(39, string2);
    }

    protected Node createNumber(double d) {
        return Node.newNumber(d);
    }

    protected Scope createScopeNode(int n, int n2) {
        Scope scope = new Scope();
        scope.setType(n);
        scope.setLineno(n2);
        return scope;
    }

    void defineSymbol(int n, String string2) {
        this.defineSymbol(n, string2, false);
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    void defineSymbol(int n, String string2, boolean bl) {
        Scope scope;
        if (string2 == null) {
            if (this.compilerEnv.isIdeMode()) {
                return;
            }
            this.codeBug();
        }
        Symbol symbol = (scope = this.currentScope.getDefiningScope(string2)) != null ? scope.getSymbol(string2) : null;
        int n2 = symbol != null ? symbol.getDeclType() : -1;
        if (symbol != null && (n2 == 154 || n == 154 || scope == this.currentScope && n2 == 153)) {
            String string3 = n2 == 154 ? "msg.const.redecl" : (n2 == 153 ? "msg.let.redecl" : (n2 == 122 ? "msg.var.redecl" : (n2 == 109 ? "msg.fn.redecl" : "msg.parm.redecl")));
            this.addError(string3, string2);
            return;
        }
        switch (n) {
            default: {
                throw this.codeBug();
            }
            case 153: {
                if (!bl && (this.currentScope.getType() == 112 || this.currentScope instanceof Loop)) {
                    this.addError("msg.let.decl.not.in.block");
                    return;
                }
                this.currentScope.putSymbol(new Symbol(n, string2));
                return;
            }
            case 109: 
            case 122: 
            case 154: {
                if (symbol == null) {
                    this.currentScriptOrFn.putSymbol(new Symbol(n, string2));
                    return;
                }
                if (n2 == 122) {
                    this.addStrictWarning("msg.var.redecl", string2);
                    return;
                }
                if (n2 != 87) return;
                this.addStrictWarning("msg.var.hides.arg", string2);
                return;
            }
            case 87: 
        }
        if (symbol != null) {
            this.addWarning("msg.dup.parms", string2);
        }
        this.currentScriptOrFn.putSymbol(new Symbol(n, string2));
    }

    /*
     * Enabled aggressive block sorting
     */
    boolean destructuringArray(ArrayLiteral arrayLiteral, int n, String string2, Node node, List<String> list) {
        boolean bl = true;
        int n2 = n == 154 ? 155 : 8;
        int n3 = 0;
        Iterator iterator = arrayLiteral.getElements().iterator();
        while (iterator.hasNext()) {
            AstNode astNode = (AstNode)iterator.next();
            if (astNode.getType() == 128) {
                ++n3;
                continue;
            }
            Node node2 = new Node(36, this.createName(string2), this.createNumber(n3));
            if (astNode.getType() == 39) {
                String string3 = astNode.getString();
                node.addChildToBack(new Node(n2, this.createName(49, string3, null), node2));
                if (n != -1) {
                    this.defineSymbol(n, string3, true);
                    list.add((Object)string3);
                }
            } else {
                node.addChildToBack(this.destructuringAssignmentHelper(n, astNode, node2, this.currentScriptOrFn.getNextTempName()));
            }
            ++n3;
            bl = false;
        }
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    Node destructuringAssignmentHelper(int n, Node node, Node node2, String string2) {
        Scope scope = this.createScopeNode(158, node.getLineno());
        scope.addChildToFront(new Node(153, this.createName(39, string2, node2)));
        this.pushScope(scope);
        this.defineSymbol(153, string2, true);
        Node node3 = new Node(89);
        scope.addChildToBack(node3);
        ArrayList arrayList = new ArrayList();
        boolean bl = true;
        switch (node.getType()) {
            default: {
                this.reportError("msg.bad.assign.left");
                break;
            }
            finally {
                this.popScope();
            }
            case 65: {
                bl = this.destructuringArray((ArrayLiteral)node, n, string2, node3, (List<String>)arrayList);
                break;
            }
            case 66: {
                bl = this.destructuringObject((ObjectLiteral)node, n, string2, node3, (List<String>)arrayList);
                break;
            }
            case 33: 
            case 36: {
                switch (n) {
                    default: {
                        break;
                    }
                    case 122: 
                    case 153: 
                    case 154: {
                        this.reportError("msg.bad.assign.left");
                    }
                }
                node3.addChildToBack(this.simpleAssignment(node, this.createName(string2)));
            }
        }
        if (bl) {
            node3.addChildToBack(this.createNumber(0.0));
        }
        scope.putProp(22, (Object)arrayList);
        return scope;
    }

    /*
     * Enabled aggressive block sorting
     */
    boolean destructuringObject(ObjectLiteral objectLiteral, int n, String string2, Node node, List<String> list) {
        boolean bl = true;
        int n2 = n == 154 ? 155 : 8;
        Iterator iterator = objectLiteral.getElements().iterator();
        while (iterator.hasNext()) {
            AstNode astNode;
            Node node2;
            ObjectProperty objectProperty = (ObjectProperty)iterator.next();
            TokenStream tokenStream = this.ts;
            int n3 = 0;
            if (tokenStream != null) {
                n3 = this.ts.lineno;
            }
            if ((astNode = objectProperty.getLeft()) instanceof Name) {
                Node node3 = Node.newString(((Name)astNode).getIdentifier());
                node2 = new Node(33, this.createName(string2), node3);
            } else if (astNode instanceof StringLiteral) {
                Node node4 = Node.newString(((StringLiteral)astNode).getValue());
                node2 = new Node(33, this.createName(string2), node4);
            } else {
                if (!(astNode instanceof NumberLiteral)) {
                    throw this.codeBug();
                }
                Node node5 = this.createNumber((int)((NumberLiteral)astNode).getNumber());
                node2 = new Node(36, this.createName(string2), node5);
            }
            node2.setLineno(n3);
            AstNode astNode2 = objectProperty.getRight();
            if (astNode2.getType() == 39) {
                String string3 = ((Name)astNode2).getIdentifier();
                node.addChildToBack(new Node(n2, this.createName(49, string3, null), node2));
                if (n != -1) {
                    this.defineSymbol(n, string3, true);
                    list.add((Object)string3);
                }
            } else {
                node.addChildToBack(this.destructuringAssignmentHelper(n, astNode2, node2, this.currentScriptOrFn.getNextTempName()));
            }
            bl = false;
        }
        return bl;
    }

    public boolean eof() {
        return this.ts.eof();
    }

    boolean insideFunction() {
        return this.nestingOfFunction != 0;
    }

    String lookupMessage(String string2) {
        return this.lookupMessage(string2, null);
    }

    String lookupMessage(String string2, String string3) {
        if (string3 == null) {
            return ScriptRuntime.getMessage0(string2);
        }
        return ScriptRuntime.getMessage1(string2, string3);
    }

    /*
     * Enabled aggressive block sorting
     */
    void markDestructuring(AstNode astNode) {
        if (astNode instanceof DestructuringForm) {
            ((DestructuringForm)((Object)astNode)).setIsDestructuring(true);
            return;
        } else {
            if (!(astNode instanceof ParenthesizedExpression)) return;
            {
                this.markDestructuring(((ParenthesizedExpression)astNode).getExpression());
                return;
            }
        }
    }

    public AstRoot parse(Reader reader, String string2, int n) throws IOException {
        if (this.parseFinished) {
            throw new IllegalStateException("parser reused");
        }
        if (this.compilerEnv.isIdeMode()) {
            return this.parse(this.readFully(reader), string2, n);
        }
        try {
            this.sourceURI = string2;
            this.ts = new TokenStream(this, reader, null, n);
            AstRoot astRoot = this.parse();
            return astRoot;
        }
        finally {
            this.parseFinished = true;
        }
    }

    public AstRoot parse(String string2, String string3, int n) {
        if (this.parseFinished) {
            throw new IllegalStateException("parser reused");
        }
        this.sourceURI = string3;
        if (this.compilerEnv.isIdeMode()) {
            this.sourceChars = string2.toCharArray();
        }
        this.ts = new TokenStream(this, null, string2, n);
        try {
            AstRoot astRoot = this.parse();
            return astRoot;
        }
        catch (IOException iOException) {
            throw new IllegalStateException();
        }
        finally {
            this.parseFinished = true;
        }
    }

    void popScope() {
        this.currentScope = this.currentScope.getParentScope();
    }

    /*
     * Enabled aggressive block sorting
     */
    void pushScope(Scope scope) {
        Scope scope2 = scope.getParentScope();
        if (scope2 != null) {
            if (scope2 != this.currentScope) {
                this.codeBug();
            }
        } else {
            this.currentScope.addChildScope(scope);
        }
        this.currentScope = scope;
    }

    protected AstNode removeParens(AstNode astNode) {
        while (astNode instanceof ParenthesizedExpression) {
            astNode = ((ParenthesizedExpression)astNode).getExpression();
        }
        return astNode;
    }

    void reportError(String string2) {
        this.reportError(string2, null);
    }

    void reportError(String string2, int n, int n2) {
        this.reportError(string2, null, n, n2);
    }

    void reportError(String string2, String string3) {
        if (this.ts == null) {
            this.reportError(string2, string3, 1, 1);
            return;
        }
        this.reportError(string2, string3, this.ts.tokenBeg, this.ts.tokenEnd - this.ts.tokenBeg);
    }

    void reportError(String string2, String string3, int n, int n2) {
        this.addError(string2, n, n2);
        if (!this.compilerEnv.recoverFromErrors()) {
            throw new ParserException();
        }
    }

    protected void setIsGenerator() {
        if (this.insideFunction()) {
            ((FunctionNode)this.currentScriptOrFn).setIsGenerator();
        }
    }

    protected void setRequiresActivation() {
        if (this.insideFunction()) {
            ((FunctionNode)this.currentScriptOrFn).setRequiresActivation();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected Node simpleAssignment(Node node, Node node2) {
        int n = node.getType();
        switch (n) {
            default: {
                throw this.codeBug();
            }
            case 39: {
                if (this.inUseStrictDirective && "eval".equals((Object)((Name)node).getIdentifier())) {
                    this.reportError("msg.bad.id.strict", ((Name)node).getIdentifier());
                }
                node.setType(49);
                return new Node(8, node, node2);
            }
            case 33: 
            case 36: {
                Node node3;
                void var5_5;
                int n2;
                if (node instanceof PropertyGet) {
                    AstNode astNode = ((PropertyGet)node).getTarget();
                    node3 = ((PropertyGet)node).getProperty();
                } else if (node instanceof ElementGet) {
                    AstNode astNode = ((ElementGet)node).getTarget();
                    node3 = ((ElementGet)node).getElement();
                } else {
                    Node node4 = node.getFirstChild();
                    node3 = node.getLastChild();
                }
                if (n == 33) {
                    n2 = 35;
                    node3.setType(41);
                    return new Node(n2, (Node)var5_5, node3, node2);
                }
                n2 = 37;
                return new Node(n2, (Node)var5_5, node3, node2);
            }
            case 67: 
        }
        Node node5 = node.getFirstChild();
        this.checkMutableReference(node5);
        return new Node(68, node5, node2);
    }

    private static class ConditionData {
        AstNode condition;
        int lp = -1;
        int rp = -1;

        private ConditionData() {
        }
    }

    private static class ParserException
    extends RuntimeException {
        static final long serialVersionUID = 5882582646773765630L;

        private ParserException() {
        }
    }

    protected class PerFunctionVariables {
        private Scope savedCurrentScope;
        private ScriptNode savedCurrentScriptOrFn;
        private int savedEndFlags;
        private boolean savedInForInit;
        private Map<String, LabeledStatement> savedLabelSet;
        private List<Jump> savedLoopAndSwitchSet;
        private List<Loop> savedLoopSet;

        PerFunctionVariables(FunctionNode functionNode) {
            this.savedCurrentScriptOrFn = Parser.this.currentScriptOrFn;
            Parser.this.currentScriptOrFn = functionNode;
            this.savedCurrentScope = Parser.this.currentScope;
            Parser.this.currentScope = functionNode;
            this.savedLabelSet = Parser.this.labelSet;
            Parser.this.labelSet = null;
            this.savedLoopSet = Parser.this.loopSet;
            Parser.this.loopSet = null;
            this.savedLoopAndSwitchSet = Parser.this.loopAndSwitchSet;
            Parser.this.loopAndSwitchSet = null;
            this.savedEndFlags = Parser.this.endFlags;
            Parser.this.endFlags = 0;
            this.savedInForInit = Parser.this.inForInit;
            Parser.this.inForInit = false;
        }

        void restore() {
            Parser.this.currentScriptOrFn = this.savedCurrentScriptOrFn;
            Parser.this.currentScope = this.savedCurrentScope;
            Parser.this.labelSet = this.savedLabelSet;
            Parser.this.loopSet = this.savedLoopSet;
            Parser.this.loopAndSwitchSet = this.savedLoopAndSwitchSet;
            Parser.this.endFlags = this.savedEndFlags;
            Parser.this.inForInit = this.savedInForInit;
        }
    }

}

