/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.InstantiationException
 *  java.lang.Iterable
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Member
 *  java.lang.reflect.Method
 *  java.util.Iterator
 */
package org.mozilla.javascript.jdk15;

import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.Iterator;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Wrapper;
import org.mozilla.javascript.jdk13.VMBridge_jdk13;

public class VMBridge_jdk15
extends VMBridge_jdk13 {
    public VMBridge_jdk15() throws SecurityException, InstantiationException {
        try {
            Method.class.getMethod("isVarArgs", (Class[])null);
            return;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new InstantiationException(noSuchMethodException.getMessage());
        }
    }

    @Override
    public Iterator<?> getJavaIterator(Context context, Scriptable scriptable, Object object) {
        if (object instanceof Wrapper) {
            Object object2 = ((Wrapper)object).unwrap();
            boolean bl = object2 instanceof Iterator;
            Iterator iterator = null;
            if (bl) {
                iterator = (Iterator)object2;
            }
            if (object2 instanceof Iterable) {
                iterator = ((Iterable)object2).iterator();
            }
            return iterator;
        }
        return null;
    }

    @Override
    public boolean isVarArgs(Member member) {
        if (member instanceof Method) {
            return ((Method)member).isVarArgs();
        }
        if (member instanceof Constructor) {
            return ((Constructor)member).isVarArgs();
        }
        return false;
    }
}

