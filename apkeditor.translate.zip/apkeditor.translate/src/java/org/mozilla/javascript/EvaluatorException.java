/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.String
 */
package org.mozilla.javascript;

import org.mozilla.javascript.RhinoException;

public class EvaluatorException
extends RhinoException {
    static final long serialVersionUID = -8743165779676009808L;

    public EvaluatorException(String string2) {
        super(string2);
    }

    public EvaluatorException(String string2, String string3, int n) {
        this(string2, string3, n, null, 0);
    }

    public EvaluatorException(String string2, String string3, int n, String string4, int n2) {
        super(string2);
        this.recordErrorOrigin(string3, n, string4, n2);
    }

    @Deprecated
    public int getColumnNumber() {
        return this.columnNumber();
    }

    @Deprecated
    public int getLineNumber() {
        return this.lineNumber();
    }

    @Deprecated
    public String getLineSource() {
        return this.lineSource();
    }

    @Deprecated
    public String getSourceName() {
        return this.sourceName();
    }
}

