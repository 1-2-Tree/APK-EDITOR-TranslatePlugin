/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 */
package org.mozilla.javascript;

import java.util.Iterator;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.NativeGenerator;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.VMBridge;
import org.mozilla.javascript.WrapFactory;

public final class NativeIterator
extends IdScriptableObject {
    public static final String ITERATOR_PROPERTY_NAME = "__iterator__";
    private static final Object ITERATOR_TAG = "Iterator";
    private static final int Id___iterator__ = 3;
    private static final int Id_constructor = 1;
    private static final int Id_next = 2;
    private static final int MAX_PROTOTYPE_ID = 3;
    private static final String STOP_ITERATION = "StopIteration";
    private static final long serialVersionUID = -4136968203581667681L;
    private Object objectIterator;

    private NativeIterator() {
    }

    private NativeIterator(Object object) {
        this.objectIterator = object;
    }

    public static Object getStopIterationObject(Scriptable scriptable) {
        return ScriptableObject.getTopScopeValue(ScriptableObject.getTopLevelScope(scriptable), ITERATOR_TAG);
    }

    static void init(ScriptableObject scriptableObject, boolean bl) {
        new NativeIterator().exportAsJSClass(3, scriptableObject, bl);
        NativeGenerator.init(scriptableObject, bl);
        StopIteration stopIteration = new StopIteration();
        stopIteration.setPrototype(NativeIterator.getObjectPrototype(scriptableObject));
        stopIteration.setParentScope(scriptableObject);
        if (bl) {
            stopIteration.sealObject();
        }
        ScriptableObject.defineProperty(scriptableObject, STOP_ITERATION, stopIteration, 2);
        scriptableObject.associateValue(ITERATOR_TAG, stopIteration);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Object jsConstructor(Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        if (arrobject.length == 0 || arrobject[0] == null || arrobject[0] == Undefined.instance) {
            Object object;
            if (arrobject.length == 0) {
                object = Undefined.instance;
                throw ScriptRuntime.typeError1("msg.no.properties", ScriptRuntime.toString(object));
            }
            object = arrobject[0];
            throw ScriptRuntime.typeError1("msg.no.properties", ScriptRuntime.toString(object));
        }
        Scriptable scriptable3 = ScriptRuntime.toObject(context, scriptable, arrobject[0]);
        int n = arrobject.length;
        boolean bl = false;
        if (n > 1) {
            boolean bl2 = ScriptRuntime.toBoolean(arrobject[1]);
            bl = false;
            if (bl2) {
                bl = true;
            }
        }
        if (scriptable2 != null) {
            Iterator<?> iterator = VMBridge.instance.getJavaIterator(context, scriptable, scriptable3);
            if (iterator != null) {
                Scriptable scriptable4 = ScriptableObject.getTopLevelScope(scriptable);
                return context.getWrapFactory().wrap(context, scriptable4, new WrappedJavaIterator(iterator, scriptable4), WrappedJavaIterator.class);
            }
            Scriptable scriptable5 = ScriptRuntime.toIterator(context, scriptable, scriptable3, bl);
            if (scriptable5 != null) return scriptable5;
        }
        int n2 = bl ? 3 : 5;
        Object object = ScriptRuntime.enumInit(scriptable3, context, scriptable, n2);
        ScriptRuntime.setEnumNumbers(object, true);
        NativeIterator nativeIterator = new NativeIterator(object);
        nativeIterator.setPrototype(ScriptableObject.getClassPrototype(scriptable, nativeIterator.getClassName()));
        nativeIterator.setParentScope(scriptable);
        return nativeIterator;
    }

    private Object next(Context context, Scriptable scriptable) {
        if (!ScriptRuntime.enumNext(this.objectIterator).booleanValue()) {
            throw new JavaScriptException(NativeIterator.getStopIterationObject(scriptable), null, 0);
        }
        return ScriptRuntime.enumId(this.objectIterator, context);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable object, Object[] arrobject) {
        if (!idFunctionObject.hasTag(ITERATOR_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, (Scriptable)object, arrobject);
        }
        int n = idFunctionObject.methodId();
        if (n == 1) {
            return NativeIterator.jsConstructor(context, scriptable, (Scriptable)object, arrobject);
        }
        if (!(object instanceof NativeIterator)) {
            throw NativeIterator.incompatibleCallError(idFunctionObject);
        }
        NativeIterator nativeIterator = (NativeIterator)object;
        switch (n) {
            case 3: {
                return object;
            }
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 2: 
        }
        return nativeIterator.next(context, scriptable);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        String string3;
        int n;
        int n2 = string2.length();
        if (n2 == 4) {
            string3 = "next";
            n = 2;
        } else if (n2 == 11) {
            string3 = "constructor";
            n = 1;
        } else {
            string3 = null;
            n = 0;
            if (n2 == 12) {
                string3 = ITERATOR_PROPERTY_NAME;
                n = 3;
            }
        }
        if (string3 == null) return n;
        if (string3 == string2) return n;
        if (string3.equals((Object)string2)) return n;
        return 0;
    }

    @Override
    public String getClassName() {
        return "Iterator";
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        String string2;
        int n2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 2;
                string2 = "constructor";
                break;
            }
            case 2: {
                string2 = "next";
                n2 = 0;
                break;
            }
            case 3: {
                n2 = 1;
                string2 = ITERATOR_PROPERTY_NAME;
            }
        }
        this.initPrototypeMethod(ITERATOR_TAG, n, string2, n2);
    }

    static class StopIteration
    extends NativeObject {
        private static final long serialVersionUID = 2485151085722377663L;

        StopIteration() {
        }

        @Override
        public String getClassName() {
            return NativeIterator.STOP_ITERATION;
        }

        @Override
        public boolean hasInstance(Scriptable scriptable) {
            return scriptable instanceof StopIteration;
        }
    }

    public static class WrappedJavaIterator {
        private Iterator<?> iterator;
        private Scriptable scope;

        WrappedJavaIterator(Iterator<?> iterator, Scriptable scriptable) {
            this.iterator = iterator;
            this.scope = scriptable;
        }

        public Object __iterator__(boolean bl) {
            return this;
        }

        public Object next() {
            if (!this.iterator.hasNext()) {
                throw new JavaScriptException(NativeIterator.getStopIterationObject(this.scope), null, 0);
            }
            return this.iterator.next();
        }
    }

}

