/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.System
 */
package org.mozilla.javascript;

import org.mozilla.javascript.CompilerEnvirons;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Icode;
import org.mozilla.javascript.InterpreterData;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.NodeTransformer;
import org.mozilla.javascript.ObjArray;
import org.mozilla.javascript.ObjToIntMap;
import org.mozilla.javascript.RegExpProxy;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.UintMap;
import org.mozilla.javascript.ast.AstRoot;
import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.ast.Jump;
import org.mozilla.javascript.ast.Name;
import org.mozilla.javascript.ast.ScriptNode;

class CodeGenerator
extends Icode {
    private static final int ECF_TAIL = 1;
    private static final int MIN_FIXUP_TABLE_SIZE = 40;
    private static final int MIN_LABEL_TABLE_SIZE = 32;
    private CompilerEnvirons compilerEnv;
    private int doubleTableTop;
    private int exceptionTableTop;
    private long[] fixupTable;
    private int fixupTableTop;
    private int iCodeTop;
    private InterpreterData itsData;
    private boolean itsInFunctionFlag;
    private boolean itsInTryFlag;
    private int[] labelTable;
    private int labelTableTop;
    private int lineNumber;
    private ObjArray literalIds = new ObjArray();
    private int localTop;
    private ScriptNode scriptOrFn;
    private int stackDepth;
    private ObjToIntMap strings = new ObjToIntMap(20);

    CodeGenerator() {
    }

    private void addBackwardGoto(int n, int n2) {
        int n3 = this.iCodeTop;
        if (n3 <= n2) {
            throw Kit.codeBug();
        }
        this.addGotoOp(n);
        this.resolveGoto(n3, n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void addExceptionHandler(int n, int n2, int n3, boolean bl, int n4, int n5) {
        int n6 = this.exceptionTableTop;
        int[] arrn = this.itsData.itsExceptionTable;
        if (arrn == null) {
            if (n6 != 0) {
                Kit.codeBug();
            }
            this.itsData.itsExceptionTable = arrn = new int[12];
        } else if (arrn.length == n6) {
            arrn = new int[2 * arrn.length];
            System.arraycopy((Object)this.itsData.itsExceptionTable, (int)0, (Object)arrn, (int)0, (int)n6);
            this.itsData.itsExceptionTable = arrn;
        }
        arrn[n6 + 0] = n;
        arrn[n6 + 1] = n2;
        arrn[n6 + 2] = n3;
        int n7 = n6 + 3;
        int n8 = 0;
        if (bl) {
            n8 = 1;
        }
        arrn[n7] = n8;
        arrn[n6 + 4] = n4;
        arrn[n6 + 5] = n5;
        this.exceptionTableTop = n6 + 6;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void addGoto(Node node, int n) {
        int n2;
        int n3 = this.getTargetLabel(node);
        if (n3 >= this.labelTableTop) {
            Kit.codeBug();
        }
        if ((n2 = this.labelTable[n3]) != -1) {
            this.addBackwardGoto(n, n2);
            return;
        }
        int n4 = this.iCodeTop;
        this.addGotoOp(n);
        int n5 = this.fixupTableTop;
        if (this.fixupTable == null || n5 == this.fixupTable.length) {
            if (this.fixupTable == null) {
                this.fixupTable = new long[40];
            } else {
                long[] arrl = new long[2 * this.fixupTable.length];
                System.arraycopy((Object)this.fixupTable, (int)0, (Object)arrl, (int)0, (int)n5);
                this.fixupTable = arrl;
            }
        }
        this.fixupTableTop = n5 + 1;
        this.fixupTable[n5] = (long)n3 << 32 | (long)n4;
    }

    private void addGotoOp(int n) {
        int n2 = this.iCodeTop;
        byte[] arrby = this.itsData.itsICode;
        if (n2 + 3 > arrby.length) {
            arrby = this.increaseICodeCapacity(3);
        }
        arrby[n2] = (byte)n;
        this.iCodeTop = 2 + (n2 + 1);
    }

    private void addIcode(int n) {
        if (!Icode.validIcode(n)) {
            throw Kit.codeBug();
        }
        this.addUint8(n & 255);
    }

    private void addIndexOp(int n, int n2) {
        this.addIndexPrefix(n2);
        if (Icode.validIcode(n)) {
            this.addIcode(n);
            return;
        }
        this.addToken(n);
    }

    private void addIndexPrefix(int n) {
        if (n < 0) {
            Kit.codeBug();
        }
        if (n < 6) {
            this.addIcode(-32 - n);
            return;
        }
        if (n <= 255) {
            this.addIcode(-38);
            this.addUint8(n);
            return;
        }
        if (n <= 65535) {
            this.addIcode(-39);
            this.addUint16(n);
            return;
        }
        this.addIcode(-40);
        this.addInt(n);
    }

    private void addInt(int n) {
        int n2 = this.iCodeTop;
        byte[] arrby = this.itsData.itsICode;
        if (n2 + 4 > arrby.length) {
            arrby = this.increaseICodeCapacity(4);
        }
        arrby[n2] = (byte)(n >>> 24);
        arrby[n2 + 1] = (byte)(n >>> 16);
        arrby[n2 + 2] = (byte)(n >>> 8);
        arrby[n2 + 3] = (byte)n;
        this.iCodeTop = n2 + 4;
    }

    private void addStringOp(int n, String string2) {
        this.addStringPrefix(string2);
        if (Icode.validIcode(n)) {
            this.addIcode(n);
            return;
        }
        this.addToken(n);
    }

    private void addStringPrefix(String string2) {
        int n = this.strings.get(string2, -1);
        if (n == -1) {
            n = this.strings.size();
            this.strings.put(string2, n);
        }
        if (n < 4) {
            this.addIcode(-41 - n);
            return;
        }
        if (n <= 255) {
            this.addIcode(-45);
            this.addUint8(n);
            return;
        }
        if (n <= 65535) {
            this.addIcode(-46);
            this.addUint16(n);
            return;
        }
        this.addIcode(-47);
        this.addInt(n);
    }

    private void addToken(int n) {
        if (!Icode.validTokenCode(n)) {
            throw Kit.codeBug();
        }
        this.addUint8(n);
    }

    private void addUint16(int n) {
        if ((-65536 & n) != 0) {
            throw Kit.codeBug();
        }
        int n2 = this.iCodeTop;
        byte[] arrby = this.itsData.itsICode;
        if (n2 + 2 > arrby.length) {
            arrby = this.increaseICodeCapacity(2);
        }
        arrby[n2] = (byte)(n >>> 8);
        arrby[n2 + 1] = (byte)n;
        this.iCodeTop = n2 + 2;
    }

    private void addUint8(int n) {
        if ((n & -256) != 0) {
            throw Kit.codeBug();
        }
        int n2 = this.iCodeTop;
        byte[] arrby = this.itsData.itsICode;
        if (n2 == arrby.length) {
            arrby = this.increaseICodeCapacity(1);
        }
        arrby[n2] = (byte)n;
        this.iCodeTop = n2 + 1;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void addVarOp(int n, int n2) {
        switch (n) {
            default: {
                throw Kit.codeBug();
            }
            case 156: {
                if (n2 < 128) {
                    this.addIcode(-61);
                    this.addUint8(n2);
                    return;
                }
                this.addIndexOp(-60, n2);
                return;
            }
            case 55: 
            case 56: {
                if (n2 >= 128) break;
                int n3 = n == 55 ? -48 : -49;
                this.addIcode(n3);
                this.addUint8(n2);
                return;
            }
            case -7: 
        }
        this.addIndexOp(n, n2);
    }

    private int allocLocal() {
        int n = this.localTop;
        this.localTop = 1 + this.localTop;
        if (this.localTop > this.itsData.itsMaxLocals) {
            this.itsData.itsMaxLocals = this.localTop;
        }
        return n;
    }

    private RuntimeException badTree(Node node) {
        throw new RuntimeException(node.toString());
    }

    private void fixLabelGotos() {
        for (int i = 0; i < this.fixupTableTop; ++i) {
            long l = this.fixupTable[i];
            int n = (int)(l >> 32);
            int n2 = (int)l;
            int n3 = this.labelTable[n];
            if (n3 == -1) {
                throw Kit.codeBug();
            }
            this.resolveGoto(n2, n3);
        }
        this.fixupTableTop = 0;
    }

    private void generateCallFunAndThis(Node node) {
        int n = node.getType();
        switch (n) {
            default: {
                this.visitExpression(node, 0);
                this.addIcode(-18);
                this.stackChange(1);
                return;
            }
            case 39: {
                this.addStringOp(-15, node.getString());
                this.stackChange(2);
                return;
            }
            case 33: 
            case 36: 
        }
        Node node2 = node.getFirstChild();
        this.visitExpression(node2, 0);
        Node node3 = node2.getNext();
        if (n == 33) {
            this.addStringOp(-16, node3.getString());
            this.stackChange(1);
            return;
        }
        this.visitExpression(node3, 0);
        this.addIcode(-17);
    }

    private void generateFunctionICode() {
        this.itsInFunctionFlag = true;
        FunctionNode functionNode = (FunctionNode)this.scriptOrFn;
        this.itsData.itsFunctionType = functionNode.getFunctionType();
        this.itsData.itsNeedsActivation = functionNode.requiresActivation();
        if (functionNode.getFunctionName() != null) {
            this.itsData.itsName = functionNode.getName();
        }
        if (functionNode.isGenerator()) {
            this.addIcode(-62);
            this.addUint16(65535 & functionNode.getBaseLineno());
        }
        this.generateICodeFromTree(functionNode.getLastChild());
    }

    /*
     * Enabled aggressive block sorting
     */
    private void generateICodeFromTree(Node node) {
        this.generateNestedFunctions();
        this.generateRegExpLiterals();
        this.visitStatement(node, 0);
        this.fixLabelGotos();
        if (this.itsData.itsFunctionType == 0) {
            this.addToken(64);
        }
        if (this.itsData.itsICode.length != this.iCodeTop) {
            byte[] arrby = new byte[this.iCodeTop];
            System.arraycopy((Object)this.itsData.itsICode, (int)0, (Object)arrby, (int)0, (int)this.iCodeTop);
            this.itsData.itsICode = arrby;
        }
        if (this.strings.size() == 0) {
            this.itsData.itsStringTable = null;
        } else {
            this.itsData.itsStringTable = new String[this.strings.size()];
            ObjToIntMap.Iterator iterator = this.strings.newIterator();
            iterator.start();
            while (!iterator.done()) {
                String string2 = (String)iterator.getKey();
                int n = iterator.getValue();
                if (this.itsData.itsStringTable[n] != null) {
                    Kit.codeBug();
                }
                this.itsData.itsStringTable[n] = string2;
                iterator.next();
            }
        }
        if (this.doubleTableTop == 0) {
            this.itsData.itsDoubleTable = null;
        } else if (this.itsData.itsDoubleTable.length != this.doubleTableTop) {
            double[] arrd = new double[this.doubleTableTop];
            System.arraycopy((Object)this.itsData.itsDoubleTable, (int)0, (Object)arrd, (int)0, (int)this.doubleTableTop);
            this.itsData.itsDoubleTable = arrd;
        }
        if (this.exceptionTableTop != 0 && this.itsData.itsExceptionTable.length != this.exceptionTableTop) {
            int[] arrn = new int[this.exceptionTableTop];
            System.arraycopy((Object)this.itsData.itsExceptionTable, (int)0, (Object)arrn, (int)0, (int)this.exceptionTableTop);
            this.itsData.itsExceptionTable = arrn;
        }
        this.itsData.itsMaxVars = this.scriptOrFn.getParamAndVarCount();
        this.itsData.itsMaxFrameArray = this.itsData.itsMaxVars + this.itsData.itsMaxLocals + this.itsData.itsMaxStack;
        this.itsData.argNames = this.scriptOrFn.getParamAndVarNames();
        this.itsData.argIsConst = this.scriptOrFn.getParamAndVarConst();
        this.itsData.argCount = this.scriptOrFn.getParamCount();
        this.itsData.encodedSourceStart = this.scriptOrFn.getEncodedSourceStart();
        this.itsData.encodedSourceEnd = this.scriptOrFn.getEncodedSourceEnd();
        if (this.literalIds.size() != 0) {
            this.itsData.literalIds = this.literalIds.toArray();
        }
    }

    private void generateNestedFunctions() {
        int n = this.scriptOrFn.getFunctionCount();
        if (n == 0) {
            return;
        }
        InterpreterData[] arrinterpreterData = new InterpreterData[n];
        for (int i = 0; i != n; ++i) {
            FunctionNode functionNode = this.scriptOrFn.getFunctionNode(i);
            CodeGenerator codeGenerator = new CodeGenerator();
            codeGenerator.compilerEnv = this.compilerEnv;
            codeGenerator.scriptOrFn = functionNode;
            codeGenerator.itsData = new InterpreterData(this.itsData);
            codeGenerator.generateFunctionICode();
            arrinterpreterData[i] = codeGenerator.itsData;
        }
        this.itsData.itsNestedFunctions = arrinterpreterData;
    }

    private void generateRegExpLiterals() {
        int n = this.scriptOrFn.getRegexpCount();
        if (n == 0) {
            return;
        }
        Context context = Context.getContext();
        RegExpProxy regExpProxy = ScriptRuntime.checkRegExpProxy(context);
        Object[] arrobject = new Object[n];
        for (int i = 0; i != n; ++i) {
            arrobject[i] = regExpProxy.compileRegExp(context, this.scriptOrFn.getRegexpString(i), this.scriptOrFn.getRegexpFlags(i));
        }
        this.itsData.itsRegExpLiterals = arrobject;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int getDoubleIndex(double d) {
        int n = this.doubleTableTop;
        if (n == 0) {
            this.itsData.itsDoubleTable = new double[64];
        } else if (this.itsData.itsDoubleTable.length == n) {
            double[] arrd = new double[n * 2];
            System.arraycopy((Object)this.itsData.itsDoubleTable, (int)0, (Object)arrd, (int)0, (int)n);
            this.itsData.itsDoubleTable = arrd;
        }
        this.itsData.itsDoubleTable[n] = d;
        this.doubleTableTop = n + 1;
        return n;
    }

    private int getLocalBlockRef(Node node) {
        return ((Node)node.getProp(3)).getExistingIntProp(2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private int getTargetLabel(Node node) {
        int n = node.labelId();
        if (n != -1) {
            return n;
        }
        int n2 = this.labelTableTop;
        if (this.labelTable == null || n2 == this.labelTable.length) {
            if (this.labelTable == null) {
                this.labelTable = new int[32];
            } else {
                int[] arrn = new int[2 * this.labelTable.length];
                System.arraycopy((Object)this.labelTable, (int)0, (Object)arrn, (int)0, (int)n2);
                this.labelTable = arrn;
            }
        }
        this.labelTableTop = n2 + 1;
        this.labelTable[n2] = -1;
        node.labelId(n2);
        return n2;
    }

    private byte[] increaseICodeCapacity(int n) {
        int n2 = this.iCodeTop;
        int n3 = this.itsData.itsICode.length;
        if (n2 + n <= n3) {
            throw Kit.codeBug();
        }
        int n4 = n3 * 2;
        if (n2 + n > n4) {
            n4 = n2 + n;
        }
        byte[] arrby = new byte[n4];
        System.arraycopy((Object)this.itsData.itsICode, (int)0, (Object)arrby, (int)0, (int)n2);
        this.itsData.itsICode = arrby;
        return arrby;
    }

    private void markTargetLabel(Node node) {
        int n = this.getTargetLabel(node);
        if (this.labelTable[n] != -1) {
            Kit.codeBug();
        }
        this.labelTable[n] = this.iCodeTop;
    }

    private void releaseLocal(int n) {
        this.localTop = -1 + this.localTop;
        if (n != this.localTop) {
            Kit.codeBug();
        }
    }

    private void resolveForwardGoto(int n) {
        if (this.iCodeTop < n + 3) {
            throw Kit.codeBug();
        }
        this.resolveGoto(n, this.iCodeTop);
    }

    private void resolveGoto(int n, int n2) {
        int n3 = n2 - n;
        if (n3 >= 0 && n3 <= 2) {
            throw Kit.codeBug();
        }
        int n4 = n + 1;
        if (n3 != (short)n3) {
            if (this.itsData.longJumps == null) {
                this.itsData.longJumps = new UintMap();
            }
            this.itsData.longJumps.put(n4, n2);
            n3 = 0;
        }
        byte[] arrby = this.itsData.itsICode;
        arrby[n4] = (byte)(n3 >> 8);
        arrby[n4 + 1] = (byte)n3;
    }

    private void stackChange(int n) {
        if (n <= 0) {
            this.stackDepth = n + this.stackDepth;
            return;
        }
        int n2 = n + this.stackDepth;
        if (n2 > this.itsData.itsMaxStack) {
            this.itsData.itsMaxStack = n2;
        }
        this.stackDepth = n2;
    }

    private void updateLineNumber(Node node) {
        int n = node.getLineno();
        if (n != this.lineNumber && n >= 0) {
            if (this.itsData.firstLinePC < 0) {
                this.itsData.firstLinePC = n;
            }
            this.lineNumber = n;
            this.addIcode(-26);
            this.addUint16(65535 & n);
        }
    }

    private void visitArrayComprehension(Node node, Node node2, Node node3) {
        this.visitStatement(node2, this.stackDepth);
        this.visitExpression(node3, 0);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitExpression(Node node, int n) {
        int n2 = node.getType();
        int n3 = this.stackDepth;
        switch (n2) {
            Node node2;
            default: {
                throw this.badTree(node);
            }
            case 109: {
                int n4 = node.getExistingIntProp(1);
                if (this.scriptOrFn.getFunctionNode(n4).getFunctionType() != 2) {
                    throw Kit.codeBug();
                }
                this.addIndexOp(-19, n4);
                this.stackChange(1);
                break;
            }
            case 54: {
                this.addIndexOp(54, this.getLocalBlockRef(node));
                this.stackChange(1);
                break;
            }
            case 89: {
                Node node3 = node.getLastChild();
                for (node2 = node.getFirstChild(); node2 != node3; node2 = node2.getNext()) {
                    this.visitExpression(node2, 0);
                    this.addIcode(-4);
                    this.stackChange(-1);
                }
                this.visitExpression(node2, n & 1);
                break;
            }
            case 138: {
                this.stackChange(1);
                break;
            }
            case 30: 
            case 38: 
            case 70: {
                if (n2 == 30) {
                    this.visitExpression(node2, 0);
                } else {
                    this.generateCallFunAndThis(node2);
                }
                int n5 = 0;
                while ((node2 = node2.getNext()) != null) {
                    this.visitExpression(node2, 0);
                    ++n5;
                }
                int n6 = node.getIntProp(10, 0);
                if (n2 != 70 && n6 != 0) {
                    this.addIndexOp(-21, n5);
                    this.addUint8(n6);
                    int n7 = n2 == 30 ? 1 : 0;
                    this.addUint8(n7);
                    this.addUint16(65535 & this.lineNumber);
                } else {
                    if (n2 == 38 && (n & 1) != 0 && !this.compilerEnv.isGenerateDebugInfo() && !this.itsInTryFlag) {
                        n2 = -55;
                    }
                    this.addIndexOp(n2, n5);
                }
                if (n2 == 30) {
                    this.stackChange(-n5);
                } else {
                    this.stackChange(-1 - n5);
                }
                if (n5 <= this.itsData.itsMaxCalleeArgs) break;
                this.itsData.itsMaxCalleeArgs = n5;
                break;
            }
            case 104: 
            case 105: {
                this.visitExpression(node2, 0);
                this.addIcode(-1);
                this.stackChange(1);
                int n8 = this.iCodeTop;
                int n9 = n2 == 105 ? 7 : 6;
                this.addGotoOp(n9);
                this.stackChange(-1);
                this.addIcode(-4);
                this.stackChange(-1);
                this.visitExpression(node2.getNext(), n & 1);
                this.resolveForwardGoto(n8);
                break;
            }
            case 102: {
                Node node4 = node2.getNext();
                Node node5 = node4.getNext();
                this.visitExpression(node2, 0);
                int n10 = this.iCodeTop;
                this.addGotoOp(7);
                this.stackChange(-1);
                this.visitExpression(node4, n & 1);
                int n11 = this.iCodeTop;
                this.addGotoOp(5);
                this.resolveForwardGoto(n10);
                this.stackDepth = n3;
                this.visitExpression(node5, n & 1);
                this.resolveForwardGoto(n11);
                break;
            }
            case 33: 
            case 34: {
                this.visitExpression(node2, 0);
                String string2 = node2.getNext().getString();
                this.addStringOp(n2, string2);
                break;
            }
            case 31: {
                boolean bl = node2.getType() == 49;
                this.visitExpression(node2, 0);
                this.visitExpression(node2.getNext(), 0);
                if (bl) {
                    this.addIcode(0);
                } else {
                    this.addToken(31);
                }
                this.stackChange(-1);
                break;
            }
            case 9: 
            case 10: 
            case 11: 
            case 12: 
            case 13: 
            case 14: 
            case 15: 
            case 16: 
            case 17: 
            case 18: 
            case 19: 
            case 20: 
            case 21: 
            case 22: 
            case 23: 
            case 24: 
            case 25: 
            case 36: 
            case 46: 
            case 47: 
            case 52: 
            case 53: {
                this.visitExpression(node2, 0);
                this.visitExpression(node2.getNext(), 0);
                this.addToken(n2);
                this.stackChange(-1);
                break;
            }
            case 26: 
            case 27: 
            case 28: 
            case 29: 
            case 32: 
            case 126: {
                this.visitExpression(node2, 0);
                if (n2 == 126) {
                    this.addIcode(-4);
                    this.addIcode(-50);
                    break;
                }
                this.addToken(n2);
                break;
            }
            case 67: 
            case 69: {
                this.visitExpression(node2, 0);
                this.addToken(n2);
                break;
            }
            case 35: 
            case 139: {
                this.visitExpression(node2, 0);
                Node node6 = node2.getNext();
                String string3 = node6.getString();
                Node node7 = node6.getNext();
                if (n2 == 139) {
                    this.addIcode(-1);
                    this.stackChange(1);
                    this.addStringOp(33, string3);
                    this.stackChange(-1);
                }
                this.visitExpression(node7, 0);
                this.addStringOp(35, string3);
                this.stackChange(-1);
                break;
            }
            case 37: 
            case 140: {
                this.visitExpression(node2, 0);
                Node node8 = node2.getNext();
                this.visitExpression(node8, 0);
                Node node9 = node8.getNext();
                if (n2 == 140) {
                    this.addIcode(-2);
                    this.stackChange(2);
                    this.addToken(36);
                    this.stackChange(-1);
                    this.stackChange(-1);
                }
                this.visitExpression(node9, 0);
                this.addToken(37);
                this.stackChange(-2);
                break;
            }
            case 68: 
            case 142: {
                this.visitExpression(node2, 0);
                Node node10 = node2.getNext();
                if (n2 == 142) {
                    this.addIcode(-1);
                    this.stackChange(1);
                    this.addToken(67);
                    this.stackChange(-1);
                }
                this.visitExpression(node10, 0);
                this.addToken(68);
                this.stackChange(-1);
                break;
            }
            case 8: 
            case 73: {
                String string4 = node2.getString();
                this.visitExpression(node2, 0);
                this.visitExpression(node2.getNext(), 0);
                this.addStringOp(n2, string4);
                this.stackChange(-1);
                break;
            }
            case 155: {
                String string5 = node2.getString();
                this.visitExpression(node2, 0);
                this.visitExpression(node2.getNext(), 0);
                this.addStringOp(-59, string5);
                this.stackChange(-1);
                break;
            }
            case 137: {
                int n12 = -1;
                if (this.itsInFunctionFlag && !this.itsData.itsNeedsActivation) {
                    n12 = this.scriptOrFn.getIndexForNameNode(node);
                }
                if (n12 == -1) {
                    this.addStringOp(-14, node.getString());
                    this.stackChange(1);
                    break;
                }
                this.addVarOp(55, n12);
                this.stackChange(1);
                this.addToken(32);
                break;
            }
            case 39: 
            case 41: 
            case 49: {
                String string6 = node.getString();
                this.addStringOp(n2, string6);
                this.stackChange(1);
                break;
            }
            case 106: 
            case 107: {
                this.visitIncDec(node, node2);
                break;
            }
            case 40: {
                double d = node.getDouble();
                int n13 = (int)d;
                if ((double)n13 == d) {
                    if (n13 == 0) {
                        this.addIcode(-51);
                        if (1.0 / d < 0.0) {
                            this.addToken(29);
                        }
                    } else if (n13 == 1) {
                        this.addIcode(-52);
                    } else if ((short)n13 == n13) {
                        this.addIcode(-27);
                        this.addUint16(65535 & n13);
                    } else {
                        this.addIcode(-28);
                        this.addInt(n13);
                    }
                } else {
                    this.addIndexOp(40, this.getDoubleIndex(d));
                }
                this.stackChange(1);
                break;
            }
            case 55: {
                if (this.itsData.itsNeedsActivation) {
                    Kit.codeBug();
                }
                this.addVarOp(55, this.scriptOrFn.getIndexForNameNode(node));
                this.stackChange(1);
                break;
            }
            case 56: {
                if (this.itsData.itsNeedsActivation) {
                    Kit.codeBug();
                }
                int n14 = this.scriptOrFn.getIndexForNameNode(node2);
                this.visitExpression(node2.getNext(), 0);
                this.addVarOp(56, n14);
                break;
            }
            case 156: {
                if (this.itsData.itsNeedsActivation) {
                    Kit.codeBug();
                }
                int n15 = this.scriptOrFn.getIndexForNameNode(node2);
                this.visitExpression(node2.getNext(), 0);
                this.addVarOp(156, n15);
                break;
            }
            case 42: 
            case 43: 
            case 44: 
            case 45: 
            case 63: {
                this.addToken(n2);
                this.stackChange(1);
                break;
            }
            case 61: 
            case 62: {
                int n16 = this.getLocalBlockRef(node);
                this.addIndexOp(n2, n16);
                this.stackChange(1);
                break;
            }
            case 48: {
                this.addIndexOp(48, node.getExistingIntProp(4));
                this.stackChange(1);
                break;
            }
            case 65: 
            case 66: {
                this.visitLiteral(node, node2);
                break;
            }
            case 157: {
                this.visitArrayComprehension(node, node2, node2.getNext());
                break;
            }
            case 71: {
                this.visitExpression(node2, 0);
                String string7 = (String)node.getProp(17);
                this.addStringOp(n2, string7);
                break;
            }
            case 77: 
            case 78: 
            case 79: 
            case 80: {
                int n17 = node.getIntProp(16, 0);
                int n18 = 0;
                do {
                    this.visitExpression(node2, 0);
                    ++n18;
                } while ((node2 = node2.getNext()) != null);
                this.addIndexOp(n2, n17);
                this.stackChange(1 - n18);
                break;
            }
            case 146: {
                this.updateLineNumber(node);
                this.visitExpression(node2, 0);
                this.addIcode(-53);
                this.stackChange(-1);
                int n19 = this.iCodeTop;
                this.visitExpression(node2.getNext(), 0);
                this.addBackwardGoto(-54, n19);
                break;
            }
            case 74: 
            case 75: 
            case 76: {
                this.visitExpression(node2, 0);
                this.addToken(n2);
                break;
            }
            case 72: {
                if (node2 != null) {
                    this.visitExpression(node2, 0);
                } else {
                    this.addIcode(-50);
                    this.stackChange(1);
                }
                this.addToken(72);
                this.addUint16(65535 & node.getLineno());
                break;
            }
            case 159: {
                Node node11 = node.getFirstChild();
                Node node12 = node11.getNext();
                this.visitExpression(node11.getFirstChild(), 0);
                this.addToken(2);
                this.stackChange(-1);
                this.visitExpression(node12.getFirstChild(), 0);
                this.addToken(3);
            }
        }
        if (n3 + 1 != this.stackDepth) {
            Kit.codeBug();
        }
    }

    private void visitIncDec(Node node, Node node2) {
        int n = node.getExistingIntProp(13);
        switch (node2.getType()) {
            default: {
                throw this.badTree(node);
            }
            case 55: {
                if (this.itsData.itsNeedsActivation) {
                    Kit.codeBug();
                }
                this.addVarOp(-7, this.scriptOrFn.getIndexForNameNode(node2));
                this.addUint8(n);
                this.stackChange(1);
                return;
            }
            case 39: {
                this.addStringOp(-8, node2.getString());
                this.addUint8(n);
                this.stackChange(1);
                return;
            }
            case 33: {
                Node node3 = node2.getFirstChild();
                this.visitExpression(node3, 0);
                this.addStringOp(-9, node3.getNext().getString());
                this.addUint8(n);
                return;
            }
            case 36: {
                Node node4 = node2.getFirstChild();
                this.visitExpression(node4, 0);
                this.visitExpression(node4.getNext(), 0);
                this.addIcode(-10);
                this.addUint8(n);
                this.stackChange(-1);
                return;
            }
            case 67: 
        }
        this.visitExpression(node2.getFirstChild(), 0);
        this.addIcode(-11);
        this.addUint8(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void visitLiteral(Node node, Node node2) {
        int n;
        Object[] arrobject;
        int n2 = node.getType();
        if (n2 == 65) {
            n = 0;
            Node node3 = node2;
            do {
                arrobject = null;
                if (node3 != null) {
                    ++n;
                    node3 = node3.getNext();
                    continue;
                }
                break;
            } while (true);
        } else {
            if (n2 != 66) {
                throw this.badTree(node);
            }
            arrobject = (Object[])node.getProp(12);
            n = arrobject.length;
        }
        this.addIndexOp(-29, n);
        this.stackChange(2);
        while (node2 != null) {
            int n3 = node2.getType();
            if (n3 == 151) {
                this.visitExpression(node2.getFirstChild(), 0);
                this.addIcode(-57);
            } else if (n3 == 152) {
                this.visitExpression(node2.getFirstChild(), 0);
                this.addIcode(-58);
            } else if (n3 == 163) {
                this.visitExpression(node2.getFirstChild(), 0);
                this.addIcode(-30);
            } else {
                this.visitExpression(node2, 0);
                this.addIcode(-30);
            }
            this.stackChange(-1);
            node2 = node2.getNext();
        }
        if (n2 == 65) {
            int[] arrn = (int[])node.getProp(11);
            if (arrn == null) {
                this.addToken(65);
            } else {
                int n4 = this.literalIds.size();
                this.literalIds.add(arrn);
                this.addIndexOp(-31, n4);
            }
        } else {
            int n5 = this.literalIds.size();
            this.literalIds.add(arrobject);
            this.addIndexOp(66, n5);
        }
        this.stackChange(-1);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void visitStatement(Node var1_1, int var2_2) {
        var3_3 = var1_1.getType();
        switch (var3_3) {
            default: {
                throw this.badTree(var1_1);
            }
            case 109: {
                var24_5 = var1_1.getExistingIntProp(1);
                var25_6 = this.scriptOrFn.getFunctionNode(var24_5).getFunctionType();
                if (var25_6 == 3) {
                    this.addIndexOp(-20, var24_5);
                } else if (var25_6 != 1) {
                    throw Kit.codeBug();
                }
                if (!this.itsInFunctionFlag) {
                    this.addIndexOp(-19, var24_5);
                    this.stackChange(1);
                    this.addIcode(-5);
                    this.stackChange(-1);
                    break;
                }
                ** GOTO lbl162
            }
            case 123: 
            case 128: 
            case 129: 
            case 130: 
            case 132: {
                this.updateLineNumber(var1_1);
            }
            case 136: {
                while (var4_4 != null) {
                    this.visitStatement(var4_4, var2_2);
                    var4_4 = var4_4.getNext();
                }
                ** GOTO lbl162
            }
            case 2: {
                this.visitExpression(var4_4, 0);
                this.addToken(2);
                this.stackChange(-1);
                break;
            }
            case 3: {
                this.addToken(3);
                break;
            }
            case 141: {
                var23_7 = this.allocLocal();
                var1_1.putIntProp(2, var23_7);
                this.updateLineNumber(var1_1);
                for (var4_4 = var1_1.getFirstChild(); var4_4 != null; var4_4 = var4_4.getNext()) {
                    this.visitStatement(var4_4, var2_2);
                }
                this.addIndexOp(-56, var23_7);
                this.releaseLocal(var23_7);
                break;
            }
            case 160: {
                this.addIcode(-64);
                break;
            }
            case 114: {
                this.updateLineNumber(var1_1);
                this.visitExpression(var4_4, 0);
                for (var21_8 = (Jump)var4_4.getNext(); var21_8 != null; var21_8 = (Jump)var21_8.getNext()) {
                    if (var21_8.getType() != 115) {
                        throw this.badTree(var21_8);
                    }
                    var22_9 = var21_8.getFirstChild();
                    this.addIcode(-1);
                    this.stackChange(1);
                    this.visitExpression(var22_9, 0);
                    this.addToken(46);
                    this.stackChange(-1);
                    this.addGoto(var21_8.target, -6);
                    this.stackChange(-1);
                }
                this.addIcode(-4);
                this.stackChange(-1);
                break;
            }
            case 131: {
                this.markTargetLabel(var1_1);
                break;
            }
            case 6: 
            case 7: {
                var20_10 = ((Jump)var1_1).target;
                this.visitExpression(var4_4, 0);
                this.addGoto(var20_10, var3_3);
                this.stackChange(-1);
                break;
            }
            case 5: {
                this.addGoto(((Jump)var1_1).target, var3_3);
                break;
            }
            case 135: {
                this.addGoto(((Jump)var1_1).target, -23);
                break;
            }
            case 125: {
                this.stackChange(1);
                var19_11 = this.getLocalBlockRef(var1_1);
                this.addIndexOp(-24, var19_11);
                this.stackChange(-1);
                while (var4_4 != null) {
                    this.visitStatement(var4_4, var2_2);
                    var4_4 = var4_4.getNext();
                }
                this.addIndexOp(-25, var19_11);
                break;
            }
            case 133: 
            case 134: {
                this.updateLineNumber(var1_1);
                this.visitExpression(var4_4, 0);
                var18_12 = var3_3 == 133 ? -4 : -5;
                this.addIcode(var18_12);
                this.stackChange(-1);
                break;
            }
            case 81: {
                var9_13 = (Jump)var1_1;
                var10_14 = this.getLocalBlockRef(var9_13);
                var11_15 = this.allocLocal();
                this.addIndexOp(-13, var11_15);
                var12_16 = this.iCodeTop;
                var13_17 = this.itsInTryFlag;
                this.itsInTryFlag = true;
                while (var4_4 != null) {
                    this.visitStatement(var4_4, var2_2);
                    var4_4 = var4_4.getNext();
                }
                this.itsInTryFlag = var13_17;
                var14_18 = var9_13.target;
                if (var14_18 != null) {
                    var17_19 = this.labelTable[this.getTargetLabel(var14_18)];
                    this.addExceptionHandler(var12_16, var17_19, var17_19, false, var10_14, var11_15);
                }
                if ((var15_20 = var9_13.getFinally()) != null) {
                    var16_21 = this.labelTable[this.getTargetLabel(var15_20)];
                    this.addExceptionHandler(var12_16, var16_21, var16_21, true, var10_14, var11_15);
                }
                this.addIndexOp(-56, var11_15);
                this.releaseLocal(var11_15);
                break;
            }
            case 57: {
                var5_22 = this.getLocalBlockRef(var1_1);
                var6_23 = var1_1.getExistingIntProp(14);
                var7_24 = var4_4.getString();
                this.visitExpression(var4_4.getNext(), 0);
                this.addStringPrefix(var7_24);
                this.addIndexPrefix(var5_22);
                this.addToken(57);
                var8_25 = var6_23 != 0 ? 1 : 0;
                this.addUint8(var8_25);
                this.stackChange(-1);
                break;
            }
            case 50: {
                this.updateLineNumber(var1_1);
                this.visitExpression(var4_4, 0);
                this.addToken(50);
                this.addUint16(65535 & this.lineNumber);
                this.stackChange(-1);
                break;
            }
            case 51: {
                this.updateLineNumber(var1_1);
                this.addIndexOp(51, this.getLocalBlockRef(var1_1));
                break;
            }
            case 4: {
                this.updateLineNumber(var1_1);
                if (var1_1.getIntProp(20, 0) != 0) {
                    this.addIcode(-63);
                    this.addUint16(65535 & this.lineNumber);
                    break;
                }
                if (var4_4 != null) {
                    this.visitExpression(var4_4, 1);
                    this.addToken(4);
                    this.stackChange(-1);
                    break;
                }
                this.addIcode(-22);
                break;
            }
            case 64: {
                this.updateLineNumber(var1_1);
                this.addToken(64);
            }
lbl162: // 4 sources:
            case -62: {
                break;
            }
            case 58: 
            case 59: 
            case 60: {
                this.visitExpression(var4_4, 0);
                this.addIndexOp(var3_3, this.getLocalBlockRef(var1_1));
                this.stackChange(-1);
            }
        }
        if (this.stackDepth == var2_2) return;
        throw Kit.codeBug();
    }

    /*
     * Enabled aggressive block sorting
     */
    public InterpreterData compile(CompilerEnvirons compilerEnvirons, ScriptNode scriptNode, String string2, boolean bl) {
        this.compilerEnv = compilerEnvirons;
        new NodeTransformer().transform(scriptNode);
        this.scriptOrFn = bl ? scriptNode.getFunctionNode(0) : scriptNode;
        this.itsData = new InterpreterData(compilerEnvirons.getLanguageVersion(), this.scriptOrFn.getSourceName(), string2, ((AstRoot)scriptNode).isInStrictMode());
        this.itsData.topLevel = true;
        if (bl) {
            this.generateFunctionICode();
            return this.itsData;
        }
        this.generateICodeFromTree(this.scriptOrFn);
        return this.itsData;
    }
}

