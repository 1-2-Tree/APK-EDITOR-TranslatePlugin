/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Kit;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Token;
import org.mozilla.javascript.UintMap;

public class Decompiler {
    public static final int CASE_GAP_PROP = 3;
    private static final int FUNCTION_END = 165;
    public static final int INDENT_GAP_PROP = 2;
    public static final int INITIAL_INDENT_PROP = 1;
    public static final int ONLY_BODY_FLAG = 1;
    public static final int TO_SOURCE_FLAG = 2;
    private static final boolean printSource;
    private char[] sourceBuffer = new char[128];
    private int sourceTop;

    private void append(char c) {
        if (this.sourceTop == this.sourceBuffer.length) {
            this.increaseSourceCapacity(1 + this.sourceTop);
        }
        this.sourceBuffer[this.sourceTop] = c;
        this.sourceTop = 1 + this.sourceTop;
    }

    private void appendString(String string2) {
        int n;
        int n2 = string2.length();
        int n3 = 1;
        if (n2 >= 32768) {
            n3 = 2;
        }
        if ((n = n2 + (n3 + this.sourceTop)) > this.sourceBuffer.length) {
            this.increaseSourceCapacity(n);
        }
        if (n2 >= 32768) {
            this.sourceBuffer[this.sourceTop] = (char)(32768 | n2 >>> 16);
            this.sourceTop = 1 + this.sourceTop;
        }
        this.sourceBuffer[this.sourceTop] = (char)n2;
        this.sourceTop = 1 + this.sourceTop;
        string2.getChars(0, n2, this.sourceBuffer, this.sourceTop);
        this.sourceTop = n;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static String decompile(String var0, int var1_1, UintMap var2_2) {
        var3_3 = var0.length();
        if (var3_3 == 0) {
            return "";
        }
        var4_4 = var2_2.getInt(1, 0);
        if (var4_4 < 0) {
            throw new IllegalArgumentException();
        }
        var5_5 = var2_2.getInt(2, 4);
        if (var5_5 < 0) {
            throw new IllegalArgumentException();
        }
        var6_6 = var2_2.getInt(3, 2);
        if (var6_6 < 0) {
            throw new IllegalArgumentException();
        }
        var7_7 = new StringBuilder();
        var8_8 = (var1_1 & 1) != 0;
        var9_9 = (var1_1 & 2) != 0;
        if (var0.charAt(0) == '\u0088') {
            var11_10 = 0 + 1;
            var10_11 = -1;
        } else {
            var10_11 = var0.charAt(1);
            var11_10 = 0;
        }
        if (!var9_9) {
            var7_7.append('\n');
            var121_12 = 0;
            do {
                var13_13 = false;
                var14_14 = 0;
                if (var121_12 < var4_4) {
                    var7_7.append(' ');
                    ++var121_12;
                    continue;
                }
                break;
            } while (true);
        } else {
            var12_15 = var10_11;
            var13_13 = false;
            var14_14 = 0;
            if (var12_15 == 2) {
                var7_7.append('(');
            }
        }
        block100 : while (var11_10 < var3_3) {
            block0 : switch (var0.charAt(var11_10)) {
                default: {
                    throw new RuntimeException("Token: " + Token.name(var0.charAt(var11_10)));
                }
                case '\u0097': 
                case '\u0098': 
                case '\u00a3': {
                    if (var0.charAt(var11_10) == '\u0097') {
                        var7_7.append("get ");
                    } else if (var0.charAt(var11_10) == '\u0098') {
                        var7_7.append("set ");
                    }
                    var11_10 = 1 + Decompiler.printSourceString(var0, 1 + (var11_10 + 1), false, var7_7);
                    break;
                }
                case '\'': 
                case '0': {
                    var11_10 = Decompiler.printSourceString(var0, var11_10 + 1, false, var7_7);
                    continue block100;
                }
                case ')': {
                    var11_10 = Decompiler.printSourceString(var0, var11_10 + 1, true, var7_7);
                    continue block100;
                }
                case '(': {
                    var11_10 = Decompiler.printSourceNumber(var0, var11_10 + 1, var7_7);
                    continue block100;
                }
                case '-': {
                    var7_7.append("true");
                    break;
                }
                case ',': {
                    var7_7.append("false");
                    break;
                }
                case '*': {
                    var7_7.append("null");
                    break;
                }
                case '+': {
                    var7_7.append("this");
                    break;
                }
                case 'm': {
                    ++var11_10;
                    var7_7.append("function ");
                    break;
                }
                case 'Y': {
                    var7_7.append(", ");
                    break;
                }
                case 'U': {
                    ++var14_14;
                    if (1 == Decompiler.getNext(var0, var3_3, var11_10)) {
                        var4_4 += var5_5;
                    }
                    var7_7.append('{');
                    break;
                }
                case 'V': {
                    if (!var8_8 || --var14_14 != 0) {
                        var7_7.append('}');
                        switch (Decompiler.getNext(var0, var3_3, var11_10)) {
                            default: {
                                break block0;
                            }
                            case 1: 
                            case 165: {
                                var4_4 -= var5_5;
                                break block0;
                            }
                            case 113: 
                            case 117: 
                        }
                        var4_4 -= var5_5;
                        var7_7.append(' ');
                        break;
                    }
                    ** GOTO lbl379
                }
                case 'W': {
                    var7_7.append('(');
                    break;
                }
                case 'X': {
                    var7_7.append(')');
                    if (85 == Decompiler.getNext(var0, var3_3, var11_10)) {
                        var7_7.append(' ');
                        break;
                    }
                    ** GOTO lbl379
                }
                case 'S': {
                    var7_7.append('[');
                    break;
                }
                case 'T': {
                    var7_7.append(']');
                    break;
                }
                case '\u0001': {
                    if (!var9_9) {
                        var97_16 = true;
                        if (!var13_13) {
                            var13_13 = true;
                            if (var8_8) {
                                var7_7.setLength(0);
                                var4_4 -= var5_5;
                                var97_16 = false;
                            }
                        }
                        if (var97_16) {
                            var7_7.append('\n');
                        }
                        if (var11_10 + 1 < var3_3) {
                            var98_17 = var0.charAt(var11_10 + 1);
                            if (var98_17 == 's' || var98_17 == 't') {
                                var99_18 = var5_5 - var6_6;
                            } else if (var98_17 == 'V') {
                                var99_18 = var5_5;
                            } else {
                                var99_18 = 0;
                                if (var98_17 == '\'') {
                                    var101_19 = var0.charAt(Decompiler.getSourceStringEnd(var0, var11_10 + 2));
                                    var99_18 = 0;
                                    if (var101_19 == 'g') {
                                        var99_18 = var5_5;
                                    }
                                }
                            }
                            while (var99_18 < var4_4) {
                                var7_7.append(' ');
                                ++var99_18;
                            }
                        }
                    }
                    ** GOTO lbl379
                }
                case 'l': {
                    var7_7.append('.');
                    break;
                }
                case '\u001e': {
                    var7_7.append("new ");
                    break;
                }
                case '\u001f': {
                    var7_7.append("delete ");
                    break;
                }
                case 'p': {
                    var7_7.append("if ");
                    break;
                }
                case 'q': {
                    var7_7.append("else ");
                    break;
                }
                case 'w': {
                    var7_7.append("for ");
                    break;
                }
                case '4': {
                    var7_7.append(" in ");
                    break;
                }
                case '{': {
                    var7_7.append("with ");
                    break;
                }
                case 'u': {
                    var7_7.append("while ");
                    break;
                }
                case 'v': {
                    var7_7.append("do ");
                    break;
                }
                case 'Q': {
                    var7_7.append("try ");
                    break;
                }
                case '|': {
                    var7_7.append("catch ");
                    break;
                }
                case '}': {
                    var7_7.append("finally ");
                    break;
                }
                case '2': {
                    var7_7.append("throw ");
                    break;
                }
                case 'r': {
                    var7_7.append("switch ");
                    break;
                }
                case 'x': {
                    var7_7.append("break");
                    if (39 == Decompiler.getNext(var0, var3_3, var11_10)) {
                        var7_7.append(' ');
                        break;
                    }
                    ** GOTO lbl379
                }
                case 'y': {
                    var7_7.append("continue");
                    if (39 == Decompiler.getNext(var0, var3_3, var11_10)) {
                        var7_7.append(' ');
                        break;
                    }
                    ** GOTO lbl379
                }
                case 's': {
                    var7_7.append("case ");
                    break;
                }
                case 't': {
                    var7_7.append("default");
                    break;
                }
                case '\u0004': {
                    var7_7.append("return");
                    if (82 != Decompiler.getNext(var0, var3_3, var11_10)) {
                        var7_7.append(' ');
                        break;
                    }
                    ** GOTO lbl379
                }
                case 'z': {
                    var7_7.append("var ");
                    break;
                }
                case '\u0099': {
                    var7_7.append("let ");
                    break;
                }
                case 'R': {
                    var7_7.append(';');
                    if (1 != Decompiler.getNext(var0, var3_3, var11_10)) {
                        var7_7.append(' ');
                        break;
                    }
                    ** GOTO lbl379
                }
                case 'Z': {
                    var7_7.append(" = ");
                    break;
                }
                case 'a': {
                    var7_7.append(" += ");
                    break;
                }
                case 'b': {
                    var7_7.append(" -= ");
                    break;
                }
                case 'c': {
                    var7_7.append(" *= ");
                    break;
                }
                case 'd': {
                    var7_7.append(" /= ");
                    break;
                }
                case 'e': {
                    var7_7.append(" %= ");
                    break;
                }
                case '[': {
                    var7_7.append(" |= ");
                    break;
                }
                case '\\': {
                    var7_7.append(" ^= ");
                    break;
                }
                case ']': {
                    var7_7.append(" &= ");
                    break;
                }
                case '^': {
                    var7_7.append(" <<= ");
                    break;
                }
                case '_': {
                    var7_7.append(" >>= ");
                    break;
                }
                case '`': {
                    var7_7.append(" >>>= ");
                    break;
                }
                case 'f': {
                    var7_7.append(" ? ");
                    break;
                }
                case 'B': {
                    var7_7.append(": ");
                    break;
                }
                case 'g': {
                    if (1 == Decompiler.getNext(var0, var3_3, var11_10)) {
                        var7_7.append(':');
                        break;
                    }
                    var7_7.append(" : ");
                    break;
                }
                case 'h': {
                    var7_7.append(" || ");
                    break;
                }
                case 'i': {
                    var7_7.append(" && ");
                    break;
                }
                case '\t': {
                    var7_7.append(" | ");
                    break;
                }
                case '\n': {
                    var7_7.append(" ^ ");
                    break;
                }
                case '\u000b': {
                    var7_7.append(" & ");
                    break;
                }
                case '.': {
                    var7_7.append(" === ");
                    break;
                }
                case '/': {
                    var7_7.append(" !== ");
                    break;
                }
                case '\f': {
                    var7_7.append(" == ");
                    break;
                }
                case '\r': {
                    var7_7.append(" != ");
                    break;
                }
                case '\u000f': {
                    var7_7.append(" <= ");
                    break;
                }
                case '\u000e': {
                    var7_7.append(" < ");
                    break;
                }
                case '\u0011': {
                    var7_7.append(" >= ");
                    break;
                }
                case '\u0010': {
                    var7_7.append(" > ");
                    break;
                }
                case '5': {
                    var7_7.append(" instanceof ");
                    break;
                }
                case '\u0012': {
                    var7_7.append(" << ");
                    break;
                }
                case '\u0013': {
                    var7_7.append(" >> ");
                    break;
                }
                case '\u0014': {
                    var7_7.append(" >>> ");
                    break;
                }
                case ' ': {
                    var7_7.append("typeof ");
                    break;
                }
                case '~': {
                    var7_7.append("void ");
                    break;
                }
                case '\u009a': {
                    var7_7.append("const ");
                    break;
                }
                case 'H': {
                    var7_7.append("yield ");
                    break;
                }
                case '\u001a': {
                    var7_7.append('!');
                    break;
                }
                case '\u001b': {
                    var7_7.append('~');
                    break;
                }
                case '\u001c': {
                    var7_7.append('+');
                    break;
                }
                case '\u001d': {
                    var7_7.append('-');
                    break;
                }
                case 'j': {
                    var7_7.append("++");
                    break;
                }
                case 'k': {
                    var7_7.append("--");
                    break;
                }
                case '\u0015': {
                    var7_7.append(" + ");
                    break;
                }
                case '\u0016': {
                    var7_7.append(" - ");
                    break;
                }
                case '\u0017': {
                    var7_7.append(" * ");
                    break;
                }
                case '\u0018': {
                    var7_7.append(" / ");
                    break;
                }
                case '\u0019': {
                    var7_7.append(" % ");
                    break;
                }
                case '\u0090': {
                    var7_7.append("::");
                    break;
                }
                case '\u008f': {
                    var7_7.append("..");
                    break;
                }
                case '\u0092': {
                    var7_7.append(".(");
                    break;
                }
                case '\u0093': {
                    var7_7.append('@');
                }
lbl379: // 9 sources:
                case '\u00a5': {
                    break;
                }
                case '\u00a0': {
                    var7_7.append("debugger;\n");
                }
            }
            ++var11_10;
        }
        if (!var9_9) {
            if (var8_8 != false) return var7_7.toString();
            var7_7.append('\n');
            return var7_7.toString();
        }
        if (var10_11 != 2) return var7_7.toString();
        var7_7.append(')');
        return var7_7.toString();
    }

    private static int getNext(String string2, int n, int n2) {
        if (n2 + 1 < n) {
            return string2.charAt(n2 + 1);
        }
        return 0;
    }

    private static int getSourceStringEnd(String string2, int n) {
        return Decompiler.printSourceString(string2, n, false, null);
    }

    private void increaseSourceCapacity(int n) {
        int n2;
        if (n <= this.sourceBuffer.length) {
            Kit.codeBug();
        }
        if ((n2 = 2 * this.sourceBuffer.length) < n) {
            n2 = n;
        }
        char[] arrc = new char[n2];
        System.arraycopy((Object)this.sourceBuffer, (int)0, (Object)arrc, (int)0, (int)this.sourceTop);
        this.sourceBuffer = arrc;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int printSourceNumber(String string2, int n, StringBuilder stringBuilder) {
        int n2;
        double d = 0.0;
        char c = string2.charAt(n);
        int n3 = n + 1;
        if (c == 'S') {
            if (stringBuilder != null) {
                d = string2.charAt(n3);
            }
            n2 = n3 + 1;
        } else {
            if (c != 'J' && c != 'D') {
                throw new RuntimeException();
            }
            if (stringBuilder != null) {
                long l = (long)string2.charAt(n3) << 48 | (long)string2.charAt(n3 + 1) << 32 | (long)string2.charAt(n3 + 2) << 16 | (long)string2.charAt(n3 + 3);
                d = c == 'J' ? (double)l : Double.longBitsToDouble((long)l);
            }
            n2 = n3 + 4;
        }
        if (stringBuilder != null) {
            stringBuilder.append(ScriptRuntime.numberToString(d, 10));
        }
        return n2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static int printSourceString(String string2, int n, boolean bl, StringBuilder stringBuilder) {
        String string3;
        int n2;
        int n3;
        block6 : {
            block5 : {
                n2 = string2.charAt(n);
                n3 = n + 1;
                if ((32768 & n2) != 0) {
                    n2 = (n2 & 32767) << 16 | string2.charAt(n3);
                    ++n3;
                }
                if (stringBuilder == null) break block5;
                string3 = string2.substring(n3, n3 + n2);
                if (bl) break block6;
                stringBuilder.append(string3);
            }
            do {
                return n3 + n2;
                break;
            } while (true);
        }
        stringBuilder.append('\"');
        stringBuilder.append(ScriptRuntime.escapeString(string3));
        stringBuilder.append('\"');
        return n3 + n2;
    }

    private String sourceToString(int n) {
        if (n < 0 || this.sourceTop < n) {
            Kit.codeBug();
        }
        return new String(this.sourceBuffer, n, this.sourceTop - n);
    }

    void addEOL(int n) {
        if (n < 0 || n > 164) {
            throw new IllegalArgumentException();
        }
        this.append((char)n);
        this.append('\u0001');
    }

    void addName(String string2) {
        this.addToken(39);
        this.appendString(string2);
    }

    void addNumber(double d) {
        this.addToken(40);
        long l = (long)d;
        if ((double)l != d) {
            long l2 = Double.doubleToLongBits((double)d);
            this.append('D');
            this.append((char)(l2 >> 48));
            this.append((char)(l2 >> 32));
            this.append((char)(l2 >> 16));
            this.append((char)l2);
            return;
        }
        if (l < 0L) {
            Kit.codeBug();
        }
        if (l <= 65535L) {
            this.append('S');
            this.append((char)l);
            return;
        }
        this.append('J');
        this.append((char)(l >> 48));
        this.append((char)(l >> 32));
        this.append((char)(l >> 16));
        this.append((char)l);
    }

    void addRegexp(String string2, String string3) {
        this.addToken(48);
        this.appendString('/' + string2 + '/' + string3);
    }

    void addString(String string2) {
        this.addToken(41);
        this.appendString(string2);
    }

    void addToken(int n) {
        if (n < 0 || n > 164) {
            throw new IllegalArgumentException();
        }
        this.append((char)n);
    }

    int getCurrentOffset() {
        return this.sourceTop;
    }

    String getEncodedSource() {
        return this.sourceToString(0);
    }

    int markFunctionEnd(int n) {
        int n2 = this.getCurrentOffset();
        this.append('\u00a5');
        return n2;
    }

    int markFunctionStart(int n) {
        int n2 = this.getCurrentOffset();
        this.addToken(109);
        this.append((char)n);
        return n2;
    }
}

