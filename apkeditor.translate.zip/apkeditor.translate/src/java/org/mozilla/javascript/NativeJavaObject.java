/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.IllegalAccessException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.NoSuchMethodException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SecurityException
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.reflect.Array
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.Date
 *  java.util.Map
 */
package org.mozilla.javascript;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.Map;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.EvaluatorException;
import org.mozilla.javascript.FieldAndMethods;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.InterfaceAdapter;
import org.mozilla.javascript.JavaMembers;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.NativeDate;
import org.mozilla.javascript.NativeFunction;
import org.mozilla.javascript.NativeJavaArray;
import org.mozilla.javascript.NativeJavaClass;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.TopLevel;
import org.mozilla.javascript.Undefined;
import org.mozilla.javascript.WrapFactory;
import org.mozilla.javascript.Wrapper;

public class NativeJavaObject
implements Scriptable,
Wrapper,
Serializable {
    private static final Object COERCED_INTERFACE_KEY;
    static final byte CONVERSION_NONE = 99;
    static final byte CONVERSION_NONTRIVIAL = 0;
    static final byte CONVERSION_TRIVIAL = 1;
    private static final int JSTYPE_BOOLEAN = 2;
    private static final int JSTYPE_JAVA_ARRAY = 7;
    private static final int JSTYPE_JAVA_CLASS = 5;
    private static final int JSTYPE_JAVA_OBJECT = 6;
    private static final int JSTYPE_NULL = 1;
    private static final int JSTYPE_NUMBER = 3;
    private static final int JSTYPE_OBJECT = 8;
    private static final int JSTYPE_STRING = 4;
    private static final int JSTYPE_UNDEFINED = 0;
    private static Method adapter_readAdapterObject;
    private static Method adapter_writeAdapterObject;
    static final long serialVersionUID = -6948590651130498591L;
    private transient Map<String, FieldAndMethods> fieldAndMethods;
    protected transient boolean isAdapter;
    protected transient Object javaObject;
    protected transient JavaMembers members;
    protected Scriptable parent;
    protected Scriptable prototype;
    protected transient Class<?> staticType;

    static {
        block2 : {
            COERCED_INTERFACE_KEY = "Coerced Interface";
            Class[] arrclass = new Class[2];
            Class<?> class_ = Kit.classOrNull("org.mozilla.javascript.JavaAdapter");
            if (class_ == null) break block2;
            try {
                arrclass[0] = ScriptRuntime.ObjectClass;
                arrclass[1] = Kit.classOrNull("java.io.ObjectOutputStream");
                adapter_writeAdapterObject = class_.getMethod("writeAdapterObject", arrclass);
                arrclass[0] = ScriptRuntime.ScriptableClass;
                arrclass[1] = Kit.classOrNull("java.io.ObjectInputStream");
                adapter_readAdapterObject = class_.getMethod("readAdapterObject", arrclass);
            }
            catch (NoSuchMethodException noSuchMethodException) {
                adapter_writeAdapterObject = null;
                adapter_readAdapterObject = null;
            }
        }
    }

    public NativeJavaObject() {
    }

    public NativeJavaObject(Scriptable scriptable, Object object, Class<?> class_) {
        this(scriptable, object, class_, false);
    }

    public NativeJavaObject(Scriptable scriptable, Object object, Class<?> class_, boolean bl) {
        this.parent = scriptable;
        this.javaObject = object;
        this.staticType = class_;
        this.isAdapter = bl;
        this.initMembers();
    }

    public static boolean canConvert(Object object, Class<?> class_) {
        return NativeJavaObject.getConversionWeight(object, class_) < 99;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Object coerceToNumber(Class<?> class_, Object object) {
        Class class_2 = object.getClass();
        if (class_ == Character.TYPE || class_ == ScriptRuntime.CharacterClass) {
            if (class_2 != ScriptRuntime.CharacterClass) return Character.valueOf((char)((char)NativeJavaObject.toInteger(object, ScriptRuntime.CharacterClass, 0.0, 65535.0)));
            return object;
        }
        if (class_ == ScriptRuntime.ObjectClass || class_ == ScriptRuntime.DoubleClass || class_ == Double.TYPE) {
            if (class_2 == ScriptRuntime.DoubleClass) return object;
            return new Double(NativeJavaObject.toDouble(object));
        }
        if (class_ == ScriptRuntime.FloatClass || class_ == Float.TYPE) {
            float f;
            if (class_2 == ScriptRuntime.FloatClass) return object;
            double d = NativeJavaObject.toDouble(object);
            if (Double.isInfinite((double)d)) return new Float((float)d);
            if (Double.isNaN((double)d)) return new Float((float)d);
            if (d == 0.0) {
                return new Float((float)d);
            }
            double d2 = Math.abs((double)d);
            if (d2 < 1.401298464324817E-45) {
                double d3;
                if (d > 0.0) {
                    d3 = 0.0;
                    do {
                        return new Float(d3);
                        break;
                    } while (true);
                }
                d3 = 0.0;
                return new Float(d3);
            }
            if (!(d2 > 3.4028234663852886E38)) return new Float((float)d);
            if (d > 0.0) {
                f = Float.POSITIVE_INFINITY;
                do {
                    return new Float(f);
                    break;
                } while (true);
            }
            f = Float.NEGATIVE_INFINITY;
            return new Float(f);
        }
        if (class_ == ScriptRuntime.IntegerClass || class_ == Integer.TYPE) {
            if (class_2 == ScriptRuntime.IntegerClass) return object;
            return (int)NativeJavaObject.toInteger(object, ScriptRuntime.IntegerClass, -2.147483648E9, 2.147483647E9);
        }
        if (class_ == ScriptRuntime.LongClass || class_ == Long.TYPE) {
            if (class_2 == ScriptRuntime.LongClass) return object;
            double d = Double.longBitsToDouble((long)4890909195324358655L);
            double d4 = Double.longBitsToDouble((long)-4332462841530417152L);
            return NativeJavaObject.toInteger(object, ScriptRuntime.LongClass, d4, d);
        }
        if (class_ == ScriptRuntime.ShortClass || class_ == Short.TYPE) {
            if (class_2 == ScriptRuntime.ShortClass) return object;
            return (short)NativeJavaObject.toInteger(object, ScriptRuntime.ShortClass, -32768.0, 32767.0);
        }
        if (class_ != ScriptRuntime.ByteClass) {
            if (class_ != Byte.TYPE) return new Double(NativeJavaObject.toDouble(object));
        }
        if (class_2 == ScriptRuntime.ByteClass) return object;
        return (byte)NativeJavaObject.toInteger(object, ScriptRuntime.ByteClass, -128.0, 127.0);
    }

    @Deprecated
    public static Object coerceType(Class<?> class_, Object object) {
        return NativeJavaObject.coerceTypeImpl(class_, object);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static Object coerceTypeImpl(Class<?> var0, Object var1_1) {
        if (var1_1 != null && var1_1.getClass() == var0) {
            return var1_1;
        }
        switch (NativeJavaObject.getJSTypeCode(var1_1)) {
            case 1: {
                if (var0.isPrimitive() == false) return null;
                NativeJavaObject.reportConversionError(var1_1, var0);
                return null;
            }
            case 0: {
                if (var0 == ScriptRuntime.StringClass) return "undefined";
                if (var0 == ScriptRuntime.ObjectClass) {
                    return "undefined";
                }
                NativeJavaObject.reportConversionError("undefined", var0);
                ** break;
            }
            case 2: {
                if (var0 == Boolean.TYPE) return var1_1;
                if (var0 == ScriptRuntime.BooleanClass) return var1_1;
                if (var0 == ScriptRuntime.ObjectClass) {
                    return var1_1;
                }
                if (var0 == ScriptRuntime.StringClass) {
                    return var1_1.toString();
                }
                NativeJavaObject.reportConversionError(var1_1, var0);
                ** break;
            }
            case 3: {
                if (var0 == ScriptRuntime.StringClass) {
                    return ScriptRuntime.toString(var1_1);
                }
                if (var0 == ScriptRuntime.ObjectClass) {
                    return NativeJavaObject.coerceToNumber(Double.TYPE, var1_1);
                }
                if (var0.isPrimitive()) {
                    if (var0 != Boolean.TYPE) return NativeJavaObject.coerceToNumber(var0, var1_1);
                }
                if (ScriptRuntime.NumberClass.isAssignableFrom(var0)) {
                    return NativeJavaObject.coerceToNumber(var0, var1_1);
                }
                NativeJavaObject.reportConversionError(var1_1, var0);
                ** break;
            }
            case 4: {
                if (var0 == ScriptRuntime.StringClass) return var1_1.toString();
                if (var0.isInstance(var1_1)) {
                    return var1_1.toString();
                }
                if (var0 == Character.TYPE || var0 == ScriptRuntime.CharacterClass) {
                    if (((CharSequence)var1_1).length() != 1) return NativeJavaObject.coerceToNumber(var0, var1_1);
                    return Character.valueOf((char)((CharSequence)var1_1).charAt(0));
                }
                if (var0.isPrimitive()) {
                    if (var0 != Boolean.TYPE) return NativeJavaObject.coerceToNumber(var0, var1_1);
                }
                if (ScriptRuntime.NumberClass.isAssignableFrom(var0)) {
                    return NativeJavaObject.coerceToNumber(var0, var1_1);
                }
                NativeJavaObject.reportConversionError(var1_1, var0);
                ** break;
            }
            case 5: {
                if (var1_1 instanceof Wrapper) {
                    var1_1 = ((Wrapper)var1_1).unwrap();
                }
                if (var0 == ScriptRuntime.ClassClass) return var1_1;
                if (var0 == ScriptRuntime.ObjectClass) {
                    return var1_1;
                }
                if (var0 == ScriptRuntime.StringClass) {
                    return var1_1.toString();
                }
                NativeJavaObject.reportConversionError(var1_1, var0);
                ** break;
            }
            case 6: 
            case 7: {
                if (var1_1 instanceof Wrapper) {
                    var1_1 = ((Wrapper)var1_1).unwrap();
                }
                if (var0.isPrimitive()) {
                    if (var0 != Boolean.TYPE) return NativeJavaObject.coerceToNumber(var0, var1_1);
                    NativeJavaObject.reportConversionError(var1_1, var0);
                    return NativeJavaObject.coerceToNumber(var0, var1_1);
                }
                if (var0 == ScriptRuntime.StringClass) {
                    return var1_1.toString();
                }
                if (var0.isInstance(var1_1)) {
                    return var1_1;
                }
                NativeJavaObject.reportConversionError(var1_1, var0);
            }
lbl69: // 7 sources:
            default: {
                return var1_1;
            }
            case 8: 
        }
        if (var0 == ScriptRuntime.StringClass) {
            return ScriptRuntime.toString(var1_1);
        }
        if (var0.isPrimitive()) {
            if (var0 != Boolean.TYPE) return NativeJavaObject.coerceToNumber(var0, var1_1);
            NativeJavaObject.reportConversionError(var1_1, var0);
            return NativeJavaObject.coerceToNumber(var0, var1_1);
        }
        if (var0.isInstance(var1_1)) {
            return var1_1;
        }
        if (var0 == ScriptRuntime.DateClass && var1_1 instanceof NativeDate) {
            return new Date((long)((NativeDate)var1_1).getJSTimeValue());
        }
        if (!var0.isArray() || !(var1_1 instanceof NativeArray)) {
            if (var1_1 instanceof Wrapper) {
                if (var0.isInstance(var1_1 = ((Wrapper)var1_1).unwrap())) {
                    return var1_1;
                }
                NativeJavaObject.reportConversionError(var1_1, var0);
                return var1_1;
            }
            if (var0.isInterface()) {
                if (var1_1 instanceof NativeObject != false) return NativeJavaObject.createInterfaceAdapter(var0, (ScriptableObject)var1_1);
                if (var1_1 instanceof NativeFunction) {
                    return NativeJavaObject.createInterfaceAdapter(var0, (ScriptableObject)var1_1);
                }
            }
            NativeJavaObject.reportConversionError(var1_1, var0);
            return var1_1;
        }
        var2_3 = (NativeArray)var1_1;
        var3_4 = var2_3.getLength();
        var5_5 = var0.getComponentType();
        var6_2 = Array.newInstance((Class)var5_5, (int)((int)var3_4));
        var7_6 = 0;
        while ((long)var7_6 < var3_4) {
            try {
                Array.set((Object)var6_2, (int)var7_6, (Object)NativeJavaObject.coerceTypeImpl(var5_5, var2_3.get(var7_6, var2_3)));
            }
            catch (EvaluatorException var8_7) {
                NativeJavaObject.reportConversionError(var1_1, var0);
            }
            ++var7_6;
        }
        return var6_2;
    }

    protected static Object createInterfaceAdapter(Class<?> class_, ScriptableObject scriptableObject) {
        Object object = Kit.makeHashKeyFromPair(COERCED_INTERFACE_KEY, class_);
        Object object2 = scriptableObject.getAssociatedValue(object);
        if (object2 != null) {
            return object2;
        }
        return scriptableObject.associateValue(object, InterfaceAdapter.create(Context.getContext(), class_, scriptableObject));
    }

    /*
     * Enabled aggressive block sorting
     */
    static int getConversionWeight(Object object, Class<?> class_) {
        int n = NativeJavaObject.getJSTypeCode(object);
        switch (n) {
            case 0: {
                if (class_ != ScriptRuntime.StringClass && class_ != ScriptRuntime.ObjectClass) return 99;
                return 1;
            }
            case 1: {
                if (class_.isPrimitive()) return 99;
                return 1;
            }
            case 2: {
                if (class_ == Boolean.TYPE) {
                    return 1;
                }
                if (class_ == ScriptRuntime.BooleanClass) {
                    return 2;
                }
                if (class_ == ScriptRuntime.ObjectClass) {
                    return 3;
                }
                if (class_ != ScriptRuntime.StringClass) return 99;
                return 4;
            }
            case 3: {
                if (class_.isPrimitive()) {
                    if (class_ == Double.TYPE) {
                        return 1;
                    }
                    if (class_ == Boolean.TYPE) return 99;
                    return 1 + NativeJavaObject.getSizeRank(class_);
                } else {
                    if (class_ == ScriptRuntime.StringClass) {
                        return 9;
                    }
                    if (class_ == ScriptRuntime.ObjectClass) {
                        return 10;
                    }
                    if (!ScriptRuntime.NumberClass.isAssignableFrom(class_)) return 99;
                    return 2;
                }
            }
            case 4: {
                if (class_ == ScriptRuntime.StringClass) {
                    return 1;
                }
                if (class_.isInstance(object)) {
                    return 2;
                }
                if (!class_.isPrimitive()) return 99;
                {
                    if (class_ == Character.TYPE) {
                        return 3;
                    }
                    if (class_ == Boolean.TYPE) return 99;
                    return 4;
                }
            }
            case 5: {
                if (class_ == ScriptRuntime.ClassClass) {
                    return 1;
                }
                if (class_ == ScriptRuntime.ObjectClass) {
                    return 3;
                }
                if (class_ != ScriptRuntime.StringClass) return 99;
                return 4;
            }
            case 6: 
            case 7: {
                Object object2 = object;
                if (object2 instanceof Wrapper) {
                    object2 = ((Wrapper)object2).unwrap();
                }
                if (class_.isInstance(object2)) {
                    return 0;
                }
                if (class_ == ScriptRuntime.StringClass) {
                    return 2;
                }
                if (!class_.isPrimitive() || class_ == Boolean.TYPE || n == 7) return 99;
                return 2 + NativeJavaObject.getSizeRank(class_);
            }
            default: {
                return 99;
            }
            case 8: 
        }
        if (class_ != ScriptRuntime.ObjectClass && class_.isInstance(object)) {
            return 1;
        }
        if (class_.isArray()) {
            if (!(object instanceof NativeArray)) return 99;
            return 2;
        } else {
            if (class_ == ScriptRuntime.ObjectClass) {
                return 3;
            }
            if (class_ == ScriptRuntime.StringClass) {
                return 4;
            }
            if (class_ == ScriptRuntime.DateClass) {
                if (!(object instanceof NativeDate)) return 99;
                return 1;
            } else {
                if (class_.isInterface()) {
                    if (object instanceof NativeObject || object instanceof NativeFunction) return 1;
                    return 12;
                }
                if (!class_.isPrimitive() || class_ == Boolean.TYPE) return 99;
                return 4 + NativeJavaObject.getSizeRank(class_);
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static int getJSTypeCode(Object object) {
        int n = 5;
        if (object == null) {
            return 1;
        }
        if (object == Undefined.instance) {
            return 0;
        }
        if (object instanceof CharSequence) {
            return 4;
        }
        if (object instanceof Number) {
            return 3;
        }
        if (object instanceof Boolean) {
            return 2;
        }
        if (object instanceof Scriptable) {
            if (object instanceof NativeJavaClass) return n;
            if (object instanceof NativeJavaArray) {
                return 7;
            }
            if (!(object instanceof Wrapper)) return 8;
            return 6;
        }
        if (object instanceof Class) return n;
        if (!object.getClass().isArray()) return 6;
        return 7;
    }

    static int getSizeRank(Class<?> class_) {
        if (class_ == Double.TYPE) {
            return 1;
        }
        if (class_ == Float.TYPE) {
            return 2;
        }
        if (class_ == Long.TYPE) {
            return 3;
        }
        if (class_ == Integer.TYPE) {
            return 4;
        }
        if (class_ == Short.TYPE) {
            return 5;
        }
        if (class_ == Character.TYPE) {
            return 6;
        }
        if (class_ == Byte.TYPE) {
            return 7;
        }
        if (class_ == Boolean.TYPE) {
            return 99;
        }
        return 8;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        String string2;
        objectInputStream.defaultReadObject();
        this.isAdapter = objectInputStream.readBoolean();
        if (this.isAdapter) {
            if (adapter_readAdapterObject == null) {
                throw new ClassNotFoundException();
            }
            Object[] arrobject = new Object[]{this, objectInputStream};
            try {
                this.javaObject = adapter_readAdapterObject.invoke(null, arrobject);
            }
            catch (Exception exception) {
                throw new IOException();
            }
        } else {
            this.javaObject = objectInputStream.readObject();
        }
        this.staticType = (string2 = (String)objectInputStream.readObject()) != null ? Class.forName((String)string2) : null;
        this.initMembers();
    }

    static void reportConversionError(Object object, Class<?> class_) {
        throw Context.reportRuntimeError2("msg.conversion.not.allowed", String.valueOf((Object)object), JavaMembers.javaSignature(class_));
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static double toDouble(Object object) {
        Method method;
        if (object instanceof Number) {
            return ((Number)object).doubleValue();
        }
        if (object instanceof String) {
            return ScriptRuntime.toNumber((String)object);
        }
        if (object instanceof Scriptable) {
            if (!(object instanceof Wrapper)) return ScriptRuntime.toNumber(object);
            return NativeJavaObject.toDouble(((Wrapper)object).unwrap());
        }
        try {
            Method method2;
            method = method2 = object.getClass().getMethod("doubleValue", (Class[])null);
        }
        catch (NoSuchMethodException noSuchMethodException) {
            method = null;
        }
        catch (SecurityException securityException) {
            method = null;
        }
        if (method == null) return ScriptRuntime.toNumber(object.toString());
        try {
            return ((Number)method.invoke(object, (Object[])null)).doubleValue();
        }
        catch (IllegalAccessException illegalAccessException) {
            NativeJavaObject.reportConversionError(object, Double.TYPE);
        }
        return ScriptRuntime.toNumber(object.toString());
        catch (InvocationTargetException invocationTargetException) {
            NativeJavaObject.reportConversionError(object, Double.TYPE);
            return ScriptRuntime.toNumber(object.toString());
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static long toInteger(Object object, Class<?> class_, double d, double d2) {
        double d3;
        double d4 = NativeJavaObject.toDouble(object);
        if (Double.isInfinite((double)d4) || Double.isNaN((double)d4)) {
            NativeJavaObject.reportConversionError(ScriptRuntime.toString(object), class_);
        }
        if ((d3 = d4 > 0.0 ? Math.floor((double)d4) : Math.ceil((double)d4)) < d || d3 > d2) {
            NativeJavaObject.reportConversionError(ScriptRuntime.toString(object), class_);
        }
        return (long)d3;
    }

    @Deprecated
    public static Object wrap(Scriptable scriptable, Object object, Class<?> class_) {
        Context context = Context.getContext();
        return context.getWrapFactory().wrap(context, scriptable, object, class_);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
        objectOutputStream.writeBoolean(this.isAdapter);
        if (this.isAdapter) {
            if (adapter_writeAdapterObject == null) {
                throw new IOException();
            }
            Object[] arrobject = new Object[]{this.javaObject, objectOutputStream};
            try {
                adapter_writeAdapterObject.invoke(null, arrobject);
            }
            catch (Exception exception) {
                throw new IOException();
            }
        } else {
            objectOutputStream.writeObject(this.javaObject);
        }
        if (this.staticType != null) {
            objectOutputStream.writeObject((Object)this.staticType.getClass().getName());
            return;
        }
        objectOutputStream.writeObject(null);
    }

    @Override
    public void delete(int n) {
    }

    @Override
    public void delete(String string2) {
    }

    @Override
    public Object get(int n, Scriptable scriptable) {
        throw this.members.reportMemberNotFound(Integer.toString((int)n));
    }

    @Override
    public Object get(String string2, Scriptable scriptable) {
        Object object;
        if (this.fieldAndMethods != null && (object = this.fieldAndMethods.get((Object)string2)) != null) {
            return object;
        }
        return this.members.get(this, string2, this.javaObject, false);
    }

    @Override
    public String getClassName() {
        return "JavaObject";
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object getDefaultValue(Class<?> class_) {
        String string2;
        double d;
        Object object;
        if (class_ == null && this.javaObject instanceof Boolean) {
            class_ = ScriptRuntime.BooleanClass;
        }
        if (class_ == null) return this.javaObject.toString();
        if (class_ == ScriptRuntime.StringClass) {
            return this.javaObject.toString();
        }
        if (class_ == ScriptRuntime.BooleanClass) {
            string2 = "booleanValue";
        } else {
            if (class_ != ScriptRuntime.NumberClass) throw Context.reportRuntimeError0("msg.default.value");
            string2 = "doubleValue";
        }
        if ((object = this.get(string2, (Scriptable)this)) instanceof Function) {
            Function function = (Function)object;
            return function.call(Context.getContext(), function.getParentScope(), this, ScriptRuntime.emptyArgs);
        }
        if (class_ != ScriptRuntime.NumberClass) return this.javaObject.toString();
        if (!(this.javaObject instanceof Boolean)) return this.javaObject.toString();
        if (((Boolean)this.javaObject).booleanValue()) {
            d = 1.0;
            return ScriptRuntime.wrapNumber(d);
        }
        d = 0.0;
        return ScriptRuntime.wrapNumber(d);
    }

    @Override
    public Object[] getIds() {
        return this.members.getIds(false);
    }

    @Override
    public Scriptable getParentScope() {
        return this.parent;
    }

    @Override
    public Scriptable getPrototype() {
        if (this.prototype == null && this.javaObject instanceof String) {
            return TopLevel.getBuiltinPrototype(ScriptableObject.getTopLevelScope(this.parent), TopLevel.Builtins.String);
        }
        return this.prototype;
    }

    @Override
    public boolean has(int n, Scriptable scriptable) {
        return false;
    }

    @Override
    public boolean has(String string2, Scriptable scriptable) {
        return this.members.has(string2, false);
    }

    @Override
    public boolean hasInstance(Scriptable scriptable) {
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void initMembers() {
        Class class_ = this.javaObject != null ? this.javaObject.getClass() : this.staticType;
        this.members = JavaMembers.lookupClass(this.parent, class_, this.staticType, this.isAdapter);
        this.fieldAndMethods = this.members.getFieldAndMethodsObjects(this, this.javaObject, false);
    }

    @Override
    public void put(int n, Scriptable scriptable, Object object) {
        throw this.members.reportMemberNotFound(Integer.toString((int)n));
    }

    @Override
    public void put(String string2, Scriptable scriptable, Object object) {
        if (this.prototype == null || this.members.has(string2, false)) {
            this.members.put(this, string2, this.javaObject, object, false);
            return;
        }
        this.prototype.put(string2, this.prototype, object);
    }

    @Override
    public void setParentScope(Scriptable scriptable) {
        this.parent = scriptable;
    }

    @Override
    public void setPrototype(Scriptable scriptable) {
        this.prototype = scriptable;
    }

    @Override
    public Object unwrap() {
        return this.javaObject;
    }
}

