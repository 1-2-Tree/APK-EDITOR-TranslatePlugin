/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 */
package org.mozilla.javascript;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.ObjArray;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.ast.AstRoot;
import org.mozilla.javascript.ast.FunctionNode;
import org.mozilla.javascript.ast.Jump;
import org.mozilla.javascript.ast.Scope;
import org.mozilla.javascript.ast.ScriptNode;
import org.mozilla.javascript.ast.Symbol;

public class NodeTransformer {
    private boolean hasFinally;
    private ObjArray loopEnds;
    private ObjArray loops;

    private static Node addBeforeCurrent(Node node, Node node2, Node node3, Node node4) {
        if (node2 == null) {
            if (node3 != node.getFirstChild()) {
                Kit.codeBug();
            }
            node.addChildToFront(node4);
            return node4;
        }
        if (node3 != node2.getNext()) {
            Kit.codeBug();
        }
        node.addChildAfter(node4, node2);
        return node4;
    }

    private static Node replaceCurrent(Node node, Node node2, Node node3, Node node4) {
        if (node2 == null) {
            if (node3 != node.getFirstChild()) {
                Kit.codeBug();
            }
            node.replaceChild(node3, node4);
            return node4;
        }
        if (node2.next == node3) {
            node.replaceChildAfter(node2, node4);
            return node4;
        }
        node.replaceChild(node3, node4);
        return node4;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void transformCompilationUnit(ScriptNode scriptNode) {
        this.loops = new ObjArray();
        this.loopEnds = new ObjArray();
        this.hasFinally = false;
        boolean bl = scriptNode.getType() != 109 || ((FunctionNode)scriptNode).requiresActivation();
        boolean bl2 = !bl;
        scriptNode.flattenSymbolTable(bl2);
        boolean bl3 = scriptNode instanceof AstRoot && ((AstRoot)scriptNode).isInStrictMode();
        this.transformCompilationUnit_r(scriptNode, scriptNode, scriptNode, bl, bl3);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void transformCompilationUnit_r(ScriptNode scriptNode, Node node, Scope scope, boolean bl, boolean bl2) {
        Node node2 = null;
        block17 : do {
            Scope scope2;
            Node node3 = null;
            if (node2 == null) {
                node2 = node.getFirstChild();
            } else {
                node3 = node2;
                node2 = node2.getNext();
            }
            if (node2 == null) {
                return;
            }
            int n = node2.getType();
            if (bl && (n == 129 || n == 132 || n == 157) && node2 instanceof Scope && (scope2 = (Scope)node2).getSymbolTable() != null) {
                int n2 = n == 157 ? 158 : 153;
                Node node4 = new Node(n2);
                Node node5 = new Node(153);
                node4.addChildToBack(node5);
                Iterator iterator = scope2.getSymbolTable().keySet().iterator();
                while (iterator.hasNext()) {
                    node5.addChildToBack(Node.newString(39, (String)iterator.next()));
                }
                scope2.setSymbolTable(null);
                Node node6 = node2;
                node2 = NodeTransformer.replaceCurrent(node, node3, node2, node4);
                n = node2.getType();
                node4.addChildToBack(node6);
            }
            block0 : switch (n) {
                case 114: 
                case 130: 
                case 132: {
                    this.loops.push(node2);
                    this.loopEnds.push(((Jump)node2).target);
                    break;
                }
                case 123: {
                    this.loops.push(node2);
                    Node node7 = node2.getNext();
                    if (node7.getType() != 3) {
                        Kit.codeBug();
                    }
                    this.loopEnds.push(node7);
                    break;
                }
                case 81: {
                    Node node8 = ((Jump)node2).getFinally();
                    if (node8 == null) break;
                    this.hasFinally = true;
                    this.loops.push(node2);
                    this.loopEnds.push(node8);
                    break;
                }
                case 3: 
                case 131: {
                    if (this.loopEnds.isEmpty() || this.loopEnds.peek() != node2) break;
                    this.loopEnds.pop();
                    this.loops.pop();
                    break;
                }
                case 72: {
                    ((FunctionNode)scriptNode).addResumptionPoint(node2);
                    break;
                }
                case 4: {
                    boolean bl3 = scriptNode.getType() == 109 && ((FunctionNode)scriptNode).isGenerator();
                    if (bl3) {
                        node2.putIntProp(20, 1);
                    }
                    if (!this.hasFinally) break;
                    Node node9 = null;
                    for (int i = -1 + this.loops.size(); i >= 0; --i) {
                        Node node10;
                        Node node11 = (Node)this.loops.get(i);
                        int n3 = node11.getType();
                        if (n3 != 81 && n3 != 123) continue;
                        if (n3 == 81) {
                            Jump jump = new Jump(135);
                            jump.target = ((Jump)node11).getFinally();
                            node10 = jump;
                        } else {
                            node10 = new Node(3);
                        }
                        if (node9 == null) {
                            int n4 = node2.getLineno();
                            node9 = new Node(129, n4);
                        }
                        node9.addChildToBack(node10);
                    }
                    if (node9 == null) break;
                    Node node12 = node2;
                    Node node13 = node12.getFirstChild();
                    Node node14 = NodeTransformer.replaceCurrent(node, node3, node2, node9);
                    if (node13 == null || bl3) {
                        node9.addChildToBack(node12);
                        node2 = node14;
                        continue block17;
                    }
                    Node node15 = new Node(134, node13);
                    node9.addChildToFront(node15);
                    Node node16 = new Node(64);
                    node9.addChildToBack(node16);
                    this.transformCompilationUnit_r(scriptNode, node15, scope, bl, bl2);
                    node2 = node14;
                    continue block17;
                }
                case 120: 
                case 121: {
                    Jump jump = (Jump)node2;
                    Jump jump2 = jump.getJumpStatement();
                    if (jump2 == null) {
                        Kit.codeBug();
                    }
                    int n5 = this.loops.size();
                    do {
                        Node node17;
                        if (n5 == 0) {
                            throw Kit.codeBug();
                        }
                        if ((node17 = (Node)this.loops.get(--n5)) == jump2) {
                            jump.target = n == 120 ? jump2.target : jump2.getContinue();
                            jump.setType(5);
                            break block0;
                        }
                        int n6 = node17.getType();
                        if (n6 == 123) {
                            Node node18 = new Node(3);
                            node3 = NodeTransformer.addBeforeCurrent(node, node3, node2, node18);
                            continue;
                        }
                        if (n6 != 81) continue;
                        Jump jump3 = (Jump)node17;
                        Jump jump4 = new Jump(135);
                        jump4.target = jump3.getFinally();
                        node3 = NodeTransformer.addBeforeCurrent(node, node3, node2, jump4);
                    } while (true);
                }
                case 38: {
                    this.visitCall(node2, scriptNode);
                    break;
                }
                case 30: {
                    this.visitNew(node2, scriptNode);
                    break;
                }
                case 153: 
                case 158: {
                    if (node2.getFirstChild().getType() == 153) {
                        boolean bl4 = scriptNode.getType() != 109 || ((FunctionNode)scriptNode).requiresActivation();
                        node2 = this.visitLet(bl4, node, node3, node2);
                        break;
                    }
                }
                case 122: 
                case 154: {
                    Node node19 = new Node(129);
                    Node node20 = node2.getFirstChild();
                    while (node20 != null) {
                        Node node21 = node20;
                        node20 = node20.getNext();
                        if (node21.getType() == 39) {
                            Node node22;
                            if (!node21.hasChildren()) continue;
                            Node node23 = node21.getFirstChild();
                            node21.removeChild(node23);
                            node21.setType(49);
                            int n7 = n == 154 ? 155 : 8;
                            node21 = node22 = new Node(n7, node21, node23);
                        } else if (node21.getType() != 158) {
                            throw Kit.codeBug();
                        }
                        int n8 = node2.getLineno();
                        Node node24 = new Node(133, node21, n8);
                        node19.addChildToBack(node24);
                    }
                    node2 = NodeTransformer.replaceCurrent(node, node3, node2, node19);
                    break;
                }
                case 137: {
                    Scope scope3 = scope.getDefiningScope(node2.getString());
                    if (scope3 == null) break;
                    node2.setScope(scope3);
                    break;
                }
                case 7: 
                case 32: {
                    Node node25 = node2.getFirstChild();
                    if (n == 7) {
                        while (node25.getType() == 26) {
                            node25 = node25.getFirstChild();
                        }
                        if (node25.getType() == 12 || node25.getType() == 13) {
                            Node node26 = node25.getFirstChild();
                            Node node27 = node25.getLastChild();
                            if (node26.getType() == 39 && node26.getString().equals((Object)"undefined")) {
                                node25 = node27;
                            } else if (node27.getType() == 39 && node27.getString().equals((Object)"undefined")) {
                                node25 = node26;
                            }
                        }
                    }
                    if (node25.getType() != 33) break;
                    node25.setType(34);
                    break;
                }
                case 8: {
                    if (bl2) {
                        node2.setType(73);
                    }
                }
                case 31: 
                case 39: 
                case 155: {
                    Node node28;
                    Scope scope4;
                    if (bl) break;
                    if (n == 39) {
                        node28 = node2;
                    } else {
                        node28 = node2.getFirstChild();
                        if (node28.getType() != 49) {
                            if (n == 31) break;
                            throw Kit.codeBug();
                        }
                    }
                    if (node28.getScope() != null || (scope4 = scope.getDefiningScope(node28.getString())) == null) break;
                    node28.setScope(scope4);
                    if (n == 39) {
                        node2.setType(55);
                        break;
                    }
                    if (n == 8 || n == 73) {
                        node2.setType(56);
                        node28.setType(41);
                        break;
                    }
                    if (n == 155) {
                        node2.setType(156);
                        node28.setType(41);
                        break;
                    }
                    if (n != 31) {
                        throw Kit.codeBug();
                    }
                    Node node29 = new Node(44);
                    node2 = NodeTransformer.replaceCurrent(node, node3, node2, node29);
                }
            }
            Scope scope5 = node2 instanceof Scope ? (Scope)node2 : scope;
            this.transformCompilationUnit_r(scriptNode, node2, scope5, bl, bl2);
        } while (true);
    }

    public final void transform(ScriptNode scriptNode) {
        this.transformCompilationUnit(scriptNode);
        for (int i = 0; i != scriptNode.getFunctionCount(); ++i) {
            this.transform(scriptNode.getFunctionNode(i));
        }
    }

    protected void visitCall(Node node, ScriptNode scriptNode) {
    }

    /*
     * Enabled aggressive block sorting
     */
    protected Node visitLet(boolean bl, Node node, Node node2, Node node3) {
        Node node4 = node3.getFirstChild();
        Node node5 = node4.getNext();
        node3.removeChild(node4);
        node3.removeChild(node5);
        boolean bl2 = node3.getType() == 158;
        if (bl) {
            int n = bl2 ? 159 : 129;
            Node node6 = NodeTransformer.replaceCurrent(node, node2, node3, new Node(n));
            ArrayList arrayList = new ArrayList();
            Node node7 = new Node(66);
            Node node8 = node4.getFirstChild();
            Node node9 = node5;
            do {
                Node node10;
                if (node8 == null) {
                    node7.putProp(12, arrayList.toArray());
                    node6.addChildToBack(new Node(2, node7));
                    Node node11 = new Node(123, node9);
                    node6.addChildToBack(node11);
                    node6.addChildToBack(new Node(3));
                    return node6;
                }
                Node node12 = node8;
                if (node12.getType() == 158) {
                    List list = (List)node12.getProp(22);
                    Node node13 = node12.getFirstChild();
                    if (node13.getType() != 153) {
                        throw Kit.codeBug();
                    }
                    node10 = bl2 ? new Node(89, node13.getNext(), node9) : new Node(129, new Node(133, node13.getNext()), node9);
                    if (list != null) {
                        arrayList.addAll((Collection)list);
                        for (int i = 0; i < list.size(); ++i) {
                            node7.addChildToBack(new Node(126, Node.newNumber(0.0)));
                        }
                    }
                    node12 = node13.getFirstChild();
                } else {
                    node10 = node9;
                }
                if (node12.getType() != 39) {
                    throw Kit.codeBug();
                }
                arrayList.add(ScriptRuntime.getIndexObject(node12.getString()));
                Node node14 = node12.getFirstChild();
                if (node14 == null) {
                    node14 = new Node(126, Node.newNumber(0.0));
                }
                node7.addChildToBack(node14);
                node8 = node8.getNext();
                node9 = node10;
            } while (true);
        }
        int n = bl2 ? 89 : 129;
        Node node15 = NodeTransformer.replaceCurrent(node, node2, node3, new Node(n));
        Node node16 = new Node(89);
        Node node17 = node4.getFirstChild();
        Node node18 = node5;
        do {
            Node node19;
            Node node20;
            block20 : {
                block19 : {
                    block18 : {
                        if (node17 == null) break block18;
                        node20 = node17;
                        if (node20.getType() != 158) break block19;
                        Node node21 = node20.getFirstChild();
                        if (node21.getType() != 153) {
                            throw Kit.codeBug();
                        }
                        node19 = bl2 ? new Node(89, node21.getNext(), node18) : new Node(129, new Node(133, node21.getNext()), node18);
                        Scope.joinScopes((Scope)node20, (Scope)node3);
                        node20 = node21.getFirstChild();
                        break block20;
                    }
                    if (bl2) {
                        node15.addChildToBack(node16);
                        node3.setType(89);
                        node15.addChildToBack(node3);
                        node3.addChildToBack(node18);
                        if (!(node18 instanceof Scope)) return node15;
                        {
                            Scope scope = ((Scope)node18).getParentScope();
                            ((Scope)node18).setParentScope((Scope)node3);
                            ((Scope)node3).setParentScope(scope);
                            return node15;
                        }
                    } else {
                        Node node22 = new Node(133, node16);
                        node15.addChildToBack(node22);
                        node3.setType(129);
                        node15.addChildToBack(node3);
                        node3.addChildrenToBack(node18);
                        if (!(node18 instanceof Scope)) return node15;
                        {
                            Scope scope = ((Scope)node18).getParentScope();
                            ((Scope)node18).setParentScope((Scope)node3);
                            ((Scope)node3).setParentScope(scope);
                        }
                    }
                    return node15;
                }
                node19 = node18;
            }
            if (node20.getType() != 39) {
                throw Kit.codeBug();
            }
            Node node23 = Node.newString(node20.getString());
            node23.setScope((Scope)node3);
            Node node24 = node20.getFirstChild();
            if (node24 == null) {
                node24 = new Node(126, Node.newNumber(0.0));
            }
            Node node25 = new Node(56, node23, node24);
            node16.addChildToBack(node25);
            node17 = node17.getNext();
            node18 = node19;
        } while (true);
    }

    protected void visitNew(Node node, ScriptNode scriptNode) {
    }
}

