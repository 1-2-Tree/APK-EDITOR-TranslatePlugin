/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript;

public final class StackStyle
extends Enum<StackStyle> {
    private static final /* synthetic */ StackStyle[] $VALUES;
    public static final /* enum */ StackStyle MOZILLA;
    public static final /* enum */ StackStyle RHINO;
    public static final /* enum */ StackStyle V8;

    static {
        RHINO = new StackStyle();
        MOZILLA = new StackStyle();
        V8 = new StackStyle();
        StackStyle[] arrstackStyle = new StackStyle[]{RHINO, MOZILLA, V8};
        $VALUES = arrstackStyle;
    }

    public static StackStyle valueOf(String string2) {
        return (StackStyle)Enum.valueOf(StackStyle.class, (String)string2);
    }

    public static StackStyle[] values() {
        return (StackStyle[])$VALUES.clone();
    }
}

