/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.IdFunctionObject;
import org.mozilla.javascript.IdScriptableObject;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

final class NativeBoolean
extends IdScriptableObject {
    private static final Object BOOLEAN_TAG = "Boolean";
    private static final int Id_constructor = 1;
    private static final int Id_toSource = 3;
    private static final int Id_toString = 2;
    private static final int Id_valueOf = 4;
    private static final int MAX_PROTOTYPE_ID = 4;
    static final long serialVersionUID = -3716996899943880933L;
    private boolean booleanValue;

    NativeBoolean(boolean bl) {
        this.booleanValue = bl;
    }

    static void init(Scriptable scriptable, boolean bl) {
        new NativeBoolean(false).exportAsJSClass(4, scriptable, bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object execIdCall(IdFunctionObject idFunctionObject, Context context, Scriptable scriptable, Scriptable scriptable2, Object[] arrobject) {
        int n = 1;
        if (!idFunctionObject.hasTag(BOOLEAN_TAG)) {
            return super.execIdCall(idFunctionObject, context, scriptable, scriptable2, arrobject);
        }
        int n2 = idFunctionObject.methodId();
        if (n2 == n) {
            if (arrobject.length == 0) {
                n = 0;
            } else if (!(arrobject[0] instanceof ScriptableObject) || !((ScriptableObject)arrobject[0]).avoidObjectDetection()) {
                n = ScriptRuntime.toBoolean(arrobject[0]);
            }
            if (scriptable2 == null) {
                return new NativeBoolean((boolean)n);
            }
            return ScriptRuntime.wrapBoolean((boolean)n);
        }
        if (!(scriptable2 instanceof NativeBoolean)) {
            throw NativeBoolean.incompatibleCallError(idFunctionObject);
        }
        boolean bl = ((NativeBoolean)scriptable2).booleanValue;
        switch (n2) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n2));
            }
            case 2: {
                if (bl) {
                    return "true";
                }
                return "false";
            }
            case 3: {
                if (bl) {
                    return "(new Boolean(true))";
                }
                return "(new Boolean(false))";
            }
            case 4: 
        }
        return ScriptRuntime.wrapBoolean(bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected int findPrototypeId(String string2) {
        String string3;
        int n;
        int n2 = string2.length();
        if (n2 == 7) {
            string3 = "valueOf";
            n = 4;
        } else if (n2 == 8) {
            char c = string2.charAt(3);
            if (c == 'o') {
                string3 = "toSource";
                n = 3;
            } else {
                string3 = null;
                n = 0;
                if (c == 't') {
                    string3 = "toString";
                    n = 2;
                }
            }
        } else {
            string3 = null;
            n = 0;
            if (n2 == 11) {
                string3 = "constructor";
                n = 1;
            }
        }
        if (string3 == null) return n;
        if (string3 == string2) return n;
        if (string3.equals((Object)string2)) return n;
        return 0;
    }

    @Override
    public String getClassName() {
        return "Boolean";
    }

    @Override
    public Object getDefaultValue(Class<?> class_) {
        if (class_ == ScriptRuntime.BooleanClass) {
            return ScriptRuntime.wrapBoolean(this.booleanValue);
        }
        return super.getDefaultValue(class_);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void initPrototypeId(int n) {
        int n2;
        String string2;
        switch (n) {
            default: {
                throw new IllegalArgumentException(String.valueOf((int)n));
            }
            case 1: {
                n2 = 1;
                string2 = "constructor";
                break;
            }
            case 2: {
                string2 = "toString";
                n2 = 0;
                break;
            }
            case 3: {
                string2 = "toSource";
                n2 = 0;
                break;
            }
            case 4: {
                string2 = "valueOf";
                n2 = 0;
            }
        }
        this.initPrototypeMethod(BOOLEAN_TAG, n, string2, n2);
    }
}

