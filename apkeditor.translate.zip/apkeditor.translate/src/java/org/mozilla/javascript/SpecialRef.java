/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 */
package org.mozilla.javascript;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Kit;
import org.mozilla.javascript.Ref;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;

class SpecialRef
extends Ref {
    private static final int SPECIAL_NONE = 0;
    private static final int SPECIAL_PARENT = 2;
    private static final int SPECIAL_PROTO = 1;
    static final long serialVersionUID = -7521596632456797847L;
    private String name;
    private Scriptable target;
    private int type;

    private SpecialRef(Scriptable scriptable, int n, String string2) {
        this.target = scriptable;
        this.type = n;
        this.name = string2;
    }

    /*
     * Enabled aggressive block sorting
     */
    static Ref createSpecial(Context context, Scriptable scriptable, Object object, String string2) {
        int n;
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 == null) {
            throw ScriptRuntime.undefReadError(object, string2);
        }
        if (string2.equals((Object)"__proto__")) {
            n = 1;
        } else {
            if (!string2.equals((Object)"__parent__")) {
                throw new IllegalArgumentException(string2);
            }
            n = 2;
        }
        if (!context.hasFeature(5)) {
            n = 0;
        }
        return new SpecialRef(scriptable2, n, string2);
    }

    @Override
    public boolean delete(Context context) {
        if (this.type == 0) {
            return ScriptRuntime.deleteObjectElem(this.target, this.name, context);
        }
        return false;
    }

    @Override
    public Object get(Context context) {
        switch (this.type) {
            default: {
                throw Kit.codeBug();
            }
            case 0: {
                return ScriptRuntime.getObjectProp(this.target, this.name, context);
            }
            case 1: {
                return this.target.getPrototype();
            }
            case 2: 
        }
        return this.target.getParentScope();
    }

    @Override
    public boolean has(Context context) {
        if (this.type == 0) {
            return ScriptRuntime.hasObjectElem(this.target, this.name, context);
        }
        return true;
    }

    @Deprecated
    @Override
    public Object set(Context context, Object object) {
        throw new IllegalStateException();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Object set(Context context, Scriptable scriptable, Object object) {
        switch (this.type) {
            default: {
                throw Kit.codeBug();
            }
            case 0: {
                return ScriptRuntime.setObjectProp(this.target, this.name, object, context);
            }
            case 1: 
            case 2: 
        }
        Scriptable scriptable2 = ScriptRuntime.toObjectOrNull(context, object, scriptable);
        if (scriptable2 != null) {
            Scriptable scriptable3 = scriptable2;
            do {
                if (scriptable3 != this.target) continue;
                throw Context.reportRuntimeError1("msg.cyclic.value", this.name);
            } while ((scriptable3 = this.type == 1 ? scriptable3.getPrototype() : scriptable3.getParentScope()) != null);
        }
        if (this.type == 1) {
            this.target.setPrototype(scriptable2);
            return scriptable2;
        }
        this.target.setParentScope(scriptable2);
        return scriptable2;
    }
}

