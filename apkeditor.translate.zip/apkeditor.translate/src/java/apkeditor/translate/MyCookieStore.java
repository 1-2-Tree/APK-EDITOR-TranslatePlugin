/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.List
 *  org.apache.http.client.CookieStore
 *  org.apache.http.cookie.Cookie
 *  org.apache.http.impl.cookie.BasicClientCookie
 */
package apkeditor.translate;

import apkeditor.translate.CookieInfo;
import apkeditor.translate.Debug;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.apache.http.client.CookieStore;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.cookie.BasicClientCookie;

public class MyCookieStore
implements CookieStore {
    private List<CookieInfo> cookieList = this.getCookieFile("CookieFile");
    File file = null;

    public MyCookieStore() {
        if (this.cookieList == null) {
            this.cookieList = new ArrayList();
        }
    }

    private void dumpCookieList() {
        Iterator iterator = this.cookieList.iterator();
        while (iterator.hasNext()) {
            CookieInfo cookieInfo = (CookieInfo)iterator.next();
            Debug.log("\tName: " + cookieInfo.getCookieName(), new Object[0]);
            Debug.log("\tValue: " + cookieInfo.getCookieValue(), new Object[0]);
            Debug.log("\tDomain: " + cookieInfo.getCookieDomain(), new Object[0]);
            Debug.log("\tDate: " + (Object)cookieInfo.getCookieDate(), new Object[0]);
        }
        return;
    }

    private List<CookieInfo> getCookieFile(String string2) {
        return new ArrayList();
    }

    private void putCookie(String string2, List<CookieInfo> list) {
    }

    private void updateCookieList(CookieInfo cookieInfo) {
        CookieInfo cookieInfo2;
        String string2 = cookieInfo.getCookieName();
        Iterator iterator = this.cookieList.iterator();
        do {
            if (iterator.hasNext()) continue;
            this.cookieList.add((Object)cookieInfo);
            return;
        } while (!(cookieInfo2 = (CookieInfo)iterator.next()).getCookieName().equals((Object)string2));
        cookieInfo2.setCookieDate(cookieInfo.getCookieDate());
        cookieInfo2.setCookieDomain(cookieInfo.getCookieDomain());
        cookieInfo2.setCookieName(cookieInfo.getCookieName());
        cookieInfo2.setCookieValue(cookieInfo.getCookieValue());
    }

    public void addCookie(Cookie cookie) {
        if (cookie == null) {
            return;
        }
        if (this.cookieList == null) {
            this.cookieList = new ArrayList();
        }
        CookieInfo cookieInfo = new CookieInfo();
        if (cookie.getExpiryDate() != null) {
            cookieInfo.setCookieDate(cookie.getExpiryDate());
        }
        cookieInfo.setCookieName(cookie.getName());
        cookieInfo.setCookieValue(cookie.getValue());
        cookieInfo.setCookieDomain(cookie.getDomain());
        this.updateCookieList(cookieInfo);
    }

    public void addCookies(List<Cookie> list) {
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            this.addCookie((Cookie)iterator.next());
        }
        return;
    }

    public void clear() {
    }

    public boolean clearExpired(Date date) {
        return false;
    }

    public Cookie convertCookie(CookieInfo cookieInfo) {
        BasicClientCookie basicClientCookie = new BasicClientCookie(cookieInfo.getCookieName(), cookieInfo.getCookieValue());
        basicClientCookie.setDomain(cookieInfo.getCookieDomain());
        basicClientCookie.setExpiryDate(cookieInfo.getCookieDate());
        return basicClientCookie;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public List<Cookie> getCookies() {
        ArrayList arrayList = new ArrayList();
        if (this.cookieList == null) return arrayList;
        int n = 0;
        while (n < this.cookieList.size()) {
            CookieInfo cookieInfo = (CookieInfo)this.cookieList.get(n);
            if (cookieInfo != null) {
                arrayList.add((Object)this.convertCookie(cookieInfo));
            }
            ++n;
        }
        return arrayList;
    }

    public void saveCookies() {
        if (this.cookieList != null) {
            this.putCookie("CookieFile", this.cookieList);
        }
    }
}

