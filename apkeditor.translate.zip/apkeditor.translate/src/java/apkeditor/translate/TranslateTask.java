/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.AsyncTask
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Void
 *  java.lang.ref.WeakReference
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Random
 */
package apkeditor.translate;

import android.content.Context;
import android.os.AsyncTask;
import android.webkit.WebSettings;
import android.webkit.WebView;
import apkeditor.translate.TranslateActivity;
import apkeditor.translate.Translator;
import com.gmail.heagoo.apkeditor.translate.TranslateItem;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class TranslateTask
extends AsyncTask<Void, ArrayList<TranslateItem>, Boolean> {
    private WeakReference<TranslateActivity> activityRef;
    Random r = new Random();
    private List<TranslateItem> untranslated;
    private String userAgent;

    public TranslateTask(List<TranslateItem> list, TranslateActivity translateActivity) {
        this.untranslated = list;
        this.activityRef = new WeakReference((Object)translateActivity);
    }

    private void checkResult(List<TranslateItem> list) {
        ArrayList arrayList = new ArrayList();
        arrayList.addAll(list);
        this.publishProgress((Object[])new ArrayList[]{arrayList});
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void doTranslate(Translator translator, List<TranslateItem> list) {
        block6 : {
            block5 : {
                if (list.isEmpty()) break block5;
                try {
                    Thread.sleep((long)(300 + this.r.nextInt(500)));
                }
                catch (InterruptedException interruptedException) {}
                if (!this.isCancelled()) break block6;
            }
            return;
        }
        translator.translate(list);
        this.checkResult(list);
        list.clear();
    }

    private int getTotalCharaters(List<TranslateItem> list) {
        int n = 0;
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            n += ((TranslateItem)iterator.next()).originValue.length();
        }
        return n;
    }

    private static String getUserAgent(Context context) {
        WebView webView = new WebView(context);
        webView.layout(0, 0, 0, 0);
        WebSettings webSettings = webView.getSettings();
        String string2 = null;
        if (webSettings != null) {
            string2 = webSettings.getUserAgentString();
        }
        if (string2 != null) {
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("Mozilla/5.0");
            stringBuffer.append(" (Windows");
            stringBuffer.append(" NX".replace('X', 'T').concat(" 6.1; WOW64) "));
            stringBuffer.append("AppleWebKit/537.11 (KHTML, like Gecko) ");
            stringBuffer.append("Chrome/23.0.1271.97 ");
            stringBuffer.append("Safari/537.11");
            string2 = stringBuffer.toString();
        }
        return string2;
    }

    protected /* varargs */ Boolean doInBackground(Void ... arrvoid) {
        int n = 10 + new Random(System.currentTimeMillis()).nextInt(5);
        String string2 = ((TranslateActivity)((Object)this.activityRef.get())).getGoogleLangCode();
        Translator translator = new Translator(this.userAgent, string2);
        ArrayList arrayList = new ArrayList();
        Iterator iterator = this.untranslated.iterator();
        do {
            if (!iterator.hasNext()) {
                if (!this.isCancelled()) break;
                return arrayList.isEmpty();
            }
            TranslateItem translateItem = (TranslateItem)iterator.next();
            if (this.isCancelled()) {
                return false;
            }
            if (translateItem.originValue.contains((CharSequence)"\n")) {
                if (!arrayList.isEmpty()) {
                    this.doTranslate(translator, (List<TranslateItem>)arrayList);
                }
                arrayList.add((Object)translateItem);
                this.doTranslate(translator, (List<TranslateItem>)arrayList);
                continue;
            }
            if (arrayList.size() >= n || this.getTotalCharaters((List<TranslateItem>)arrayList) + translateItem.originValue.length() > 900) {
                this.doTranslate(translator, (List<TranslateItem>)arrayList);
                arrayList.add((Object)translateItem);
                continue;
            }
            arrayList.add((Object)translateItem);
        } while (true);
        if (!arrayList.isEmpty()) {
            this.doTranslate(translator, (List<TranslateItem>)arrayList);
        }
        return true;
    }

    protected void onPostExecute(Boolean bl) {
        ((TranslateActivity)((Object)this.activityRef.get())).translateCompleted();
    }

    protected void onPreExecute() {
        this.userAgent = TranslateTask.getUserAgent((Context)this.activityRef.get());
    }

    protected /* varargs */ void onProgressUpdate(ArrayList<TranslateItem> ... arrarrayList) {
        ArrayList<TranslateItem> arrayList = arrarrayList[0];
        ((TranslateActivity)((Object)this.activityRef.get())).updateView((List<TranslateItem>)arrayList);
    }
}

