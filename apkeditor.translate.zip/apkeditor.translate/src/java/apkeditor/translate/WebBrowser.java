/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.util.List
 *  org.apache.http.Header
 *  org.apache.http.HttpEntity
 *  org.apache.http.HttpHost
 *  org.apache.http.HttpResponse
 *  org.apache.http.NameValuePair
 *  org.apache.http.client.CookieStore
 *  org.apache.http.client.entity.UrlEncodedFormEntity
 *  org.apache.http.client.methods.HttpGet
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.cookie.Cookie
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.apache.http.params.HttpParams
 */
package apkeditor.translate;

import apkeditor.translate.Debug;
import apkeditor.translate.MyCookieStore;
import apkeditor.translate.SSLSocketFactoryEx;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpParams;

public class WebBrowser {
    private MyCookieStore cookieStore = new MyCookieStore();
    HttpHost proxy = new HttpHost("xxx", 911, "http");
    private boolean useProxy = false;
    private boolean useSSL = false;
    private String userAgent = null;

    public WebBrowser() {
        this(false);
    }

    public WebBrowser(String string2) {
        this.userAgent = string2;
    }

    public WebBrowser(boolean bl) {
        this.useSSL = bl;
    }

    private DefaultHttpClient getHttpClient() {
        if (this.useSSL) {
            return SSLSocketFactoryEx.getNewHttpClient();
        }
        return new DefaultHttpClient();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private String getString(InputStream var1_1) {
        var3_2 = new byte[262144];
        var4_3 = 262144 - 1;
        var5_4 = 0;
        ** GOTO lbl16
lbl6: // 2 sources:
        do {
            if (var5_4 <= 0) return "";
            try {
                return new String(var3_2, 0, var5_4, "UTF-8");
            }
            catch (IOException var2_6) {
                var2_6.printStackTrace();
            }
            return "";
            break;
        } while (true);
lbl-1000: // 1 sources:
        {
            var6_5 = var1_1.read(var3_2, var5_4, var4_3 - var5_4);
            if (var6_5 <= 0) ** GOTO lbl6
            var5_4 += var6_5;
lbl16: // 2 sources:
            ** while (var5_4 < var4_3)
        }
lbl17: // 1 sources:
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String get(String string2, String string3, String string4) {
        String string5 = null;
        try {
            HttpGet httpGet = new HttpGet(string3);
            httpGet.getParams().setParameter("http.protocol.cookie-policy", (Object)"compatibility");
            DefaultHttpClient defaultHttpClient = this.getHttpClient();
            if (this.userAgent != null) {
                httpGet.addHeader("User-Agent", this.userAgent);
            }
            if (string4 != null) {
                httpGet.addHeader("Referer", string4);
            }
            MyCookieStore myCookieStore = this.cookieStore;
            string5 = null;
            if (myCookieStore != null) {
                defaultHttpClient.setCookieStore((CookieStore)this.cookieStore);
            }
            boolean bl = this.useProxy;
            string5 = null;
            if (bl) {
                defaultHttpClient.getParams().setParameter("http.route.default-proxy", (Object)this.proxy);
            }
            defaultHttpClient.getParams().setParameter("http.connection.timeout", (Object)15000);
            defaultHttpClient.getParams().setParameter("http.socket.timeout", (Object)15000);
            string5 = this.getString(defaultHttpClient.execute((HttpUriRequest)httpGet).getEntity().getContent());
            List list = defaultHttpClient.getCookieStore().getCookies();
            this.cookieStore.addCookies((List<Cookie>)list);
            return string5;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            Debug.dump(String.valueOf((Object)string2) + ".error", exception.getMessage());
            return string5;
        }
    }

    public MyCookieStore getCookieStore() {
        return this.cookieStore;
    }

    public String post(String string2, String string3, List<NameValuePair> list) {
        HttpPost httpPost = new HttpPost(string3);
        httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded; charset=\"UTF-8\"");
        httpPost.addHeader("X-Requested-With", "XMLHttpRequest");
        httpPost.addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.99 Mobile Safari/537.36");
        httpPost.addHeader("Accept", "application/json, text/javascript, */*; q=0.01");
        httpPost.addHeader("Accept-Encoding", "gzip,deflate,sdch");
        httpPost.addHeader("Accept-Language", "en-US,en;q=0.8");
        httpPost.addHeader("Accept-Charset", "ISO-8859-1,utf-8;q=0.7,*;q=0.3");
        return this.post(string2, httpPost, list);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String post(String string2, HttpPost httpPost, List<NameValuePair> list) {
        int n;
        Header[] arrheader;
        int n2;
        StringBuffer stringBuffer;
        DefaultHttpClient defaultHttpClient;
        String string3 = null;
        try {
            int n3 = list.size();
            string3 = null;
            if (n3 > 0) {
                UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(list, "UTF-8");
                httpPost.setEntity((HttpEntity)urlEncodedFormEntity);
            }
            if (!httpPost.containsHeader("Content-Type")) {
                httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded; charset=\"UTF-8\"");
            }
            if (!httpPost.containsHeader("User-Agent") && this.userAgent != null) {
                httpPost.addHeader("User-Agent", this.userAgent);
            }
            httpPost.getParams().setParameter("http.protocol.cookie-policy", (Object)"compatibility");
            defaultHttpClient = this.getHttpClient();
            MyCookieStore myCookieStore = this.cookieStore;
            string3 = null;
            if (myCookieStore != null) {
                defaultHttpClient.setCookieStore((CookieStore)this.cookieStore);
            }
            boolean bl = this.useProxy;
            string3 = null;
            if (bl) {
                defaultHttpClient.getParams().setParameter("http.route.default-proxy", (Object)this.proxy);
            }
            defaultHttpClient.getParams().setParameter("http.connection.timeout", (Object)15000);
            defaultHttpClient.getParams().setParameter("http.socket.timeout", (Object)15000);
            HttpResponse httpResponse = defaultHttpClient.execute((HttpUriRequest)httpPost);
            string3 = this.getString(httpResponse.getEntity().getContent());
            arrheader = httpResponse.getAllHeaders();
            stringBuffer = new StringBuffer();
            n2 = arrheader.length;
            n = 0;
        }
        catch (Exception exception) {
            Debug.dump(String.valueOf((Object)string2) + ".error", exception.getMessage());
            return string3;
        }
        do {
            if (n >= n2) {
                Debug.dump(String.valueOf((Object)string2) + ".header", stringBuffer.toString());
                Debug.dump(String.valueOf((Object)string2) + ".html", string3);
                List list2 = defaultHttpClient.getCookieStore().getCookies();
                this.cookieStore.addCookies((List<Cookie>)list2);
                return string3;
            }
            Header header = arrheader[n];
            stringBuffer.append(String.valueOf((Object)header.getName()) + ": " + header.getValue() + "\n");
            ++n;
        } while (true);
    }
}

