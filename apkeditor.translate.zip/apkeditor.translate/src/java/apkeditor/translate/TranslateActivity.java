/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  android.text.Editable
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.Window
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Void
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package apkeditor.translate;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import apkeditor.translate.TranslateTask;
import com.gmail.heagoo.apkeditor.translate.TranslateItem;
import com.gmail.heagoo.common.ActivityUtil;
import com.gmail.heagoo.common.IOUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TranslateActivity
extends Activity
implements View.OnClickListener {
    private Map<String, EditText> etMap = new HashMap();
    private boolean isDark;
    private boolean isFullScreen;
    private int numFailed = 0;
    private int numSucceed = 0;
    private int numToTranslate = 0;
    private Button stopOrSaveBtn;
    private LinearLayout stringLayout;
    private String targetLanguageCode;
    private boolean translateFinished = false;
    private String translatedFilePath;
    private LinearLayout translatedLayout;
    private List<TranslateItem> translatedList;
    private TextView translatedMsg;
    private LinearLayout translatingLayout;
    private TextView translatingMsg;
    private TranslateTask translatingTask;
    private boolean translationSaved = false;
    private List<TranslateItem> untranslatedList;

    static /* synthetic */ void access$1(TranslateActivity translateActivity, boolean bl) {
        translateActivity.translationSaved = bl;
    }

    private void initData(Intent intent) {
        if (intent.getExtras() != null) {
            this.targetLanguageCode = ActivityUtil.getParam(intent, "targetLanguageCode");
            this.translatedFilePath = ActivityUtil.getParam(intent, "translatedList_file");
            this.translatedList = (List)IOUtils.readObjectFromFile(this.translatedFilePath);
            this.untranslatedList = (List)IOUtils.readObjectFromFile(ActivityUtil.getParam(intent, "untranslatedList_file"));
            return;
        }
        this.targetLanguageCode = "-zh-rCN";
        this.translatedList = new ArrayList();
        this.untranslatedList = new ArrayList();
        this.translatedList.add((Object)new TranslateItem("test", "Test", "\u6d4b\u8bd5"));
        this.untranslatedList.add((Object)new TranslateItem("write", "Write"));
    }

    private void initView(List<TranslateItem> list) {
        this.stringLayout = (LinearLayout)this.findViewById(2131296326);
        this.translatingLayout = (LinearLayout)this.findViewById(2131296319);
        this.translatedLayout = (LinearLayout)this.findViewById(2131296322);
        this.translatingMsg = (TextView)this.translatingLayout.findViewById(2131296321);
        this.translatedMsg = (TextView)this.translatedLayout.findViewById(2131296323);
        int n = 0;
        do {
            if (n >= list.size()) {
                this.stopOrSaveBtn = (Button)this.findViewById(2131296324);
                this.stopOrSaveBtn.setOnClickListener((View.OnClickListener)this);
                return;
            }
            View view = this.createStringView((TranslateItem)list.get(n));
            this.stringLayout.addView(view);
            ++n;
        } while (true);
    }

    private void saveStringAsResource() {
        ArrayList arrayList = new ArrayList();
        Iterator iterator = this.etMap.entrySet().iterator();
        do {
            if (!iterator.hasNext()) {
                if (!arrayList.isEmpty()) break;
                return;
            }
            Map.Entry entry = (Map.Entry)iterator.next();
            String string2 = (String)entry.getKey();
            String string3 = ((EditText)entry.getValue()).getText().toString();
            if ("".equals((Object)string3)) continue;
            arrayList.add((Object)new TranslateItem(string2, null, string3));
        } while (true);
        this.setResult((List<TranslateItem>)arrayList);
    }

    private void setResult(List<TranslateItem> list) {
        Intent intent = new Intent();
        intent.putExtra("targetLanguageCode", this.targetLanguageCode);
        IOUtils.writeObjectToFile(this.translatedFilePath, list);
        intent.putExtra("translatedList_file", this.translatedFilePath);
        this.setResult(-1, intent);
    }

    private void showSaveDialog(final boolean bl) {
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)this);
        builder.setTitle(2131361822);
        builder.setMessage(2131361823);
        builder.setPositiveButton(17039379, new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n) {
                TranslateActivity.this.saveStringAsResource();
                TranslateActivity.access$1(TranslateActivity.this, true);
            }
        });
        builder.setNegativeButton(17039369, new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n) {
                String string2 = TranslateActivity.this.getResources().getString(2131361824);
                Object[] arrobject = new Object[]{TranslateActivity.this.numSucceed};
                String string3 = String.format((String)string2, (Object[])arrobject);
                Toast.makeText((Context)TranslateActivity.this, (CharSequence)string3, (int)1).show();
            }
        });
        builder.show();
    }

    private void startTranslating() {
        this.translatingMsg.setText(2131361813);
        this.translatingLayout.setVisibility(0);
        this.translatedLayout.setVisibility(8);
        this.stopOrSaveBtn.setText(2131361809);
        this.translationSaved = false;
        this.translateFinished = false;
        this.numToTranslate = this.untranslatedList.size();
        this.numSucceed = 0;
        this.numFailed = 0;
        if (this.numToTranslate > 0) {
            this.translatingTask = new TranslateTask(this.untranslatedList, this);
            this.translatingTask.execute((Object[])new Void[0]);
            return;
        }
        this.translateCompleted();
    }

    private void stopTranslating() {
        this.translatingTask.cancel(true);
        this.translateCompleted();
    }

    /*
     * Enabled aggressive block sorting
     */
    @SuppressLint(value={"InflateParams"})
    protected View createStringView(TranslateItem translateItem) {
        int n = this.isDark ? 2130903068 : 2130903067;
        View view = this.getLayoutInflater().inflate(n, null, false);
        ((TextView)view.findViewById(2131296328)).setText((CharSequence)translateItem.name);
        ((TextView)view.findViewById(2131296329)).setText((CharSequence)translateItem.originValue);
        EditText editText = (EditText)view.findViewById(2131296330);
        this.etMap.put((Object)translateItem.name, (Object)editText);
        if (translateItem.translatedValue != null) {
            editText.setText((CharSequence)translateItem.translatedValue);
        }
        return view;
    }

    public String getGoogleLangCode() {
        String string2 = this.targetLanguageCode.substring(1);
        int n = string2.indexOf("-");
        if (n != -1) {
            string2 = String.valueOf((Object)string2.substring(0, n + 1)) + string2.substring(n + 2);
        }
        return string2;
    }

    public void onClick(View view) {
        block3 : {
            block2 : {
                if (view.getId() != 2131296324) break block2;
                if (!this.translateFinished) break block3;
                this.saveStringAsResource();
                this.translationSaved = true;
                this.finish();
            }
            return;
        }
        this.stopTranslating();
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.getWindow().requestFeature(1);
        this.isFullScreen = false;
        this.isDark = false;
        Intent intent = this.getIntent();
        if (intent.getExtras() != null) {
            this.isFullScreen = ActivityUtil.getBoolParam(intent, "isFullScreen");
            this.isDark = ActivityUtil.getBoolParam(intent, "isDark");
        }
        if (this.isFullScreen) {
            this.getWindow().setFlags(1024, 1024);
        }
        if (this.isDark) {
            this.setTheme(16973833);
            this.setContentView(2130903065);
        } else {
            this.setContentView(2130903064);
        }
        this.initData(intent);
        this.initView(this.translatedList);
        this.startTranslating();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void translateCompleted() {
        int n;
        String string2;
        this.translateFinished = true;
        this.translatingLayout.setVisibility(8);
        this.translatedLayout.setVisibility(0);
        if (this.numToTranslate == 0) {
            string2 = this.getString(2131361818);
        } else {
            String string3 = this.getString(2131361815);
            Object[] arrobject = new Object[]{this.numSucceed};
            string2 = String.format((String)string3, (Object[])arrobject);
        }
        if (this.numFailed > 0) {
            StringBuilder stringBuilder = new StringBuilder(String.valueOf((Object)string2));
            String string4 = ", " + this.getString(2131361816);
            Object[] arrobject = new Object[]{this.numFailed};
            string2 = stringBuilder.append(String.format((String)string4, (Object[])arrobject)).toString();
        }
        if ((n = this.numToTranslate - this.numSucceed - this.numFailed) > 0) {
            StringBuilder stringBuilder = new StringBuilder(String.valueOf((Object)string2));
            String string5 = ", " + this.getString(2131361817);
            Object[] arrobject = new Object[]{n};
            string2 = stringBuilder.append(String.format((String)string5, (Object[])arrobject)).toString();
        }
        this.translatedMsg.setText((CharSequence)string2);
        if (this.numSucceed > 0) {
            this.stopOrSaveBtn.setText(2131361812);
            return;
        }
        this.stopOrSaveBtn.setText(2131361811);
    }

    @SuppressLint(value={"DefaultLocale"})
    public void updateView(List<TranslateItem> list) {
        Iterator iterator = list.iterator();
        do {
            if (!iterator.hasNext()) {
                String string2 = this.getString(2131361814);
                int n = this.numToTranslate - this.numFailed;
                String string3 = "%d / %d " + string2;
                Object[] arrobject = new Object[]{this.numSucceed, n};
                String string4 = String.format((String)string3, (Object[])arrobject);
                this.translatingMsg.setText((CharSequence)string4);
                return;
            }
            TranslateItem translateItem = (TranslateItem)iterator.next();
            View view = this.createStringView(translateItem);
            this.stringLayout.addView(view);
            if (translateItem.translatedValue != null) {
                this.numSucceed = 1 + this.numSucceed;
                continue;
            }
            this.numFailed = 1 + this.numFailed;
        } while (true);
    }

}

