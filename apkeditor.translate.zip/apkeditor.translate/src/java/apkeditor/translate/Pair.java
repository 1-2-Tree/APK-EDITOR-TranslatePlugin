/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package apkeditor.translate;

public class Pair<T1, T2> {
    public final T1 m1;
    public T2 m2;

    public Pair(T1 T1, T2 T2) {
        this.m1 = T1;
        this.m2 = T2;
    }
}

