/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package apkeditor.translate;

public class Debug {
    public static void dump(String string2, String string3) {
    }

    public static void dumpClassName(Object object) {
        Object[] arrobject = new Object[]{object.getClass().getName()};
        Debug.log("** Class Name: %", arrobject);
    }

    public static /* varargs */ void log(String string2, Object ... arrobject) {
    }
}

