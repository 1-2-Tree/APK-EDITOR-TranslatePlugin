/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.StringBuilder
 *  java.net.URLEncoder
 *  java.util.Iterator
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONTokener
 */
package apkeditor.translate;

import apkeditor.translate.Debug;
import apkeditor.translate.WebBrowser;
import com.gmail.heagoo.apkeditor.translate.TranslateItem;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONTokener;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

public class Translator {
    private WebBrowser browser;
    private int jsonIndex = 0;
    private String startUrl;
    private String targetLangCode;
    private String tkk;

    /*
     * Enabled aggressive block sorting
     */
    public Translator(String string2, String string3) {
        int n;
        this.browser = new WebBrowser(string2);
        this.startUrl = "https://translate.google.com/m/translate";
        this.targetLangCode = string3;
        String string4 = this.browser.get("main", this.startUrl, null);
        if (string4 == null || (n = string4.indexOf("tkk:'")) == -1) {
            return;
        }
        int n2 = n + "tkk:'".length();
        this.tkk = string4.substring(n2, string4.indexOf("'", n2));
    }

    private static char decodeChar(char c, char c2) {
        int n = Translator.hex2Int(c);
        return (char)(Translator.hex2Int(c2) + n * 16);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String escapeTkkScript(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        while (n < string2.length()) {
            char c = string2.charAt(n);
            if (c == '\\' && n + 3 < string2.length() && string2.charAt(n + 1) == 'x') {
                stringBuilder.append(Translator.decodeChar(string2.charAt(n + 2), string2.charAt(n + 3)));
                n += 3;
            } else {
                stringBuilder.append(c);
            }
            ++n;
        }
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    private String extractAllValueFromJson(JSONArray jSONArray) throws JSONException {
        int n = 0;
        StringBuffer stringBuffer = new StringBuffer();
        do {
            int n2;
            String string2;
            block4 : {
                block3 : {
                    if (n >= -1 + jSONArray.length()) break block3;
                    n2 = n + 1;
                    string2 = (String)((JSONArray)jSONArray.get(n)).get(0);
                    if (string2 != null) break block4;
                }
                if (stringBuffer.length() <= 0) break;
                return stringBuffer.toString();
            }
            stringBuffer.append(string2);
            n = n2;
        } while (true);
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private String extractOneItemFromJson(JSONArray jSONArray) throws JSONException {
        StringBuffer stringBuffer = new StringBuffer();
        while (this.jsonIndex < -1 + jSONArray.length()) {
            int n = this.jsonIndex;
            this.jsonIndex = n + 1;
            String string2 = (String)((JSONArray)jSONArray.get(n)).get(0);
            if (string2 == null) break;
            stringBuffer.append(string2);
            if (!string2.endsWith("\n")) continue;
            stringBuffer.deleteCharAt(-1 + stringBuffer.length());
            break;
        }
        if (stringBuffer.length() > 0) {
            return stringBuffer.toString();
        }
        return null;
    }

    protected static String getToken(String string2, String string3) {
        String string4 = Translator.escapeTkkScript(string2);
        Context context = Context.enter();
        context.setOptimizationLevel(-1);
        try {
            ScriptableObject scriptableObject = context.initStandardObjects();
            Object object = context.evaluateString(scriptableObject, string4, "JavaScript", 1, null);
            context.evaluateString(scriptableObject, "var Wl=function(a, b) {for (var c = 0; c < b.length - 2; c += 3) {var d = b.charAt(c + 2) , d = \"a\" <= d ? d.charCodeAt(0) - 87 : Number(d) , d = \"+\" == b.charAt(c + 1) ? a >>> d : a << d;a = \"+\" == b.charAt(c) ? a + d & 4294967295 : a ^ d}return a},Yl = function(b,a) {var c,d;d = b.split(\".\");b = Number(d[0]) || 0;for (var e = [], f = 0, g = 0; g < a.length; g++) {var k = a.charCodeAt(g);128 > k ? e[f++] = k : (2048 > k ? e[f++] = k >> 6 | 192 : (55296 == (k & 64512) && g + 1 < a.length && 56320 == (a.charCodeAt(g + 1) & 64512) ? (k = 65536 + ((k & 1023) << 10) + (a.charCodeAt(++g) & 1023),e[f++] = k >> 18 | 240,e[f++] = k >> 12 & 63 | 128) : e[f++] = k >> 12 | 224,e[f++] = k >> 6 & 63 | 128),e[f++] = k & 63 | 128)}a = b;for (f = 0; f < e.length; f++)a += e[f],a = Wl(a, \"+-a^+6\");a = Wl(a, \"+-3^+b+-f\");a ^= Number(d[1]) || 0;0 > a && (a = (a & 2147483647) + 2147483648);a = a % 1E6;return a.toString() + \".\" +(a ^ b)};", "JavaScript", 1, null);
            Object object2 = scriptableObject.get("Yl", (Scriptable)scriptableObject);
            if (object2 instanceof Function) {
                Function function = (Function)object2;
                Object[] arrobject = new Object[]{object.toString(), string3};
                String string5 = Context.toString(function.call(context, scriptableObject, scriptableObject, arrobject));
                return string5;
            }
        }
        finally {
            Context.exit();
        }
        return null;
    }

    protected static void getToken_Origin(String string2, String string3) {
    }

    private static int hex2Int(char c) {
        if (c >= '0' && c <= '9') {
            return c - 48;
        }
        if (c >= 'a' && c <= 'f') {
            return 10 + (c - 97);
        }
        return 10 + (c - 65);
    }

    private void parseContent(String string2, List<TranslateItem> list) {
        JSONArray jSONArray = (JSONArray)new JSONTokener(string2).nextValue();
        if (list.size() == 1) {
            ((TranslateItem)list.get((int)0)).translatedValue = this.extractAllValueFromJson(jSONArray);
            return;
        }
        int n = list.size();
        this.jsonIndex = 0;
        for (int i = 0; i < n; ++i) {
            try {
                ((TranslateItem)list.get((int)i)).translatedValue = this.extractOneItemFromJson(jSONArray);
            }
            catch (Exception exception) {
                exception.printStackTrace();
                break;
            }
            continue;
        }
    }

    protected String encode(String string2) {
        try {
            String string3 = URLEncoder.encode((String)string2, (String)"UTF-8");
            return string3;
        }
        catch (Exception exception) {
            return string2;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void translate(List<TranslateItem> list) {
        String string2;
        int n;
        block3 : {
            if (this.tkk != null) {
                StringBuffer stringBuffer = new StringBuffer();
                Iterator iterator = list.iterator();
                do {
                    if (!iterator.hasNext()) {
                        stringBuffer.deleteCharAt(-1 + stringBuffer.length());
                        String string3 = stringBuffer.toString();
                        String string4 = "https://translate.google.com/translate_a/single?client=webapp&sl=auto&tl=" + this.targetLangCode + "&hl=en&dt=bd&dt=ex&dt=ld&dt=md&dt=qca&dt=rw&dt=rm&dt=ss&dt=t&otf=1&ssel=0&tsel=0&kc=1&tk=" + this.encode(Translator.getToken(this.tkk, string3)) + "&q=" + this.encode(string3);
                        Debug.log("url=%s", string4);
                        string2 = this.browser.get("translate", string4, this.startUrl);
                        if (string2 == null || !string2.startsWith("[[[\"") || (n = string2.indexOf("]]")) == -1) break;
                        break block3;
                    }
                    stringBuffer.append(((TranslateItem)iterator.next()).originValue);
                    stringBuffer.append('\n');
                } while (true);
            }
            return;
        }
        this.parseContent(string2.substring(1, n + 2), list);
    }
}

