/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Date
 */
package apkeditor.translate;

import java.io.Serializable;
import java.util.Date;

public class CookieInfo
implements Serializable {
    private static final long serialVersionUID = -1906450774713846916L;
    private String domain;
    private Date expiryDate;
    private String name;
    private String value;

    public Date getCookieDate() {
        return this.expiryDate;
    }

    public String getCookieDomain() {
        return this.domain;
    }

    public String getCookieName() {
        return this.name;
    }

    public String getCookieValue() {
        return this.value;
    }

    public void setCookieDate(Date date) {
        this.expiryDate = date;
    }

    public void setCookieDomain(String string2) {
        this.domain = string2;
    }

    public void setCookieName(String string2) {
        this.name = string2;
    }

    public void setCookieValue(String string2) {
        this.value = string2;
    }
}

